@echo off
setlocal
cd /d "%~dp0"
set "CLOAK_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "CLOAK_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%CLOAK_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Verificar.ps1"
if errorlevel 1 pause
endlocal
