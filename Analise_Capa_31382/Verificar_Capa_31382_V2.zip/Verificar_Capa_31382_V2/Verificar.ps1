﻿param([string]$Cliente)
$ErrorActionPreference='Stop'
try {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=New-Object Security.Principal.WindowsPrincipal($identity)
 if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"'
  if($Cliente){$arguments+=' -Cliente "'+$Cliente+'"'}
  $child=Start-Process -FilePath powershell.exe -ArgumentList $arguments -Verb RunAs -PassThru -Wait
  exit $child.ExitCode
 }
 $games=@(Get-Process -Name L2 -ErrorAction SilentlyContinue)
 if(!$games.Count){throw 'Abra o jogo, entre no personagem e equipe a capa 31382. Depois execute VERIFICAR.bat com o jogo aberto.'}
 if(!$Cliente){$Cliente='C:\Program Files (x86)\LINEAGE ROYAL NOVO'}
 if(!(Test-Path -LiteralPath (Join-Path $Cliente 'system\L2.exe'))){
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='Escolha a pasta do seu jogo (que contem system).'
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0}
  $Cliente=$dialog.SelectedPath
 }
 $root=(Resolve-Path -LiteralPath $Cliente).Path
 if((Split-Path -Leaf $root) -ieq 'system'){$root=Split-Path -Parent $root}
 $lines=New-Object 'System.Collections.Generic.List[string]'
 $lines.Add('MILENIUM - VERIFICACAO V2 DA CAPA 31382 / HUMANO FIGHTER')
 $lines.Add('Leitura somente: nenhum arquivo do cliente, configuracao ou memoria do jogo foi alterado.')
 $lines.Add('Captura: '+(Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
 $expected=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'esperado.json') -Raw | ConvertFrom-Json
 $ok=0;$missing=0;$different=0;$checked=0
 foreach($entry in $expected.resources){
  $checked++
  Write-Progress -Activity 'Conferindo arquivos de capas' -Status $entry.file -PercentComplete ([int](100*$checked/@($expected.resources).Count))
  $path=Join-Path $root $entry.file
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){$missing++;$lines.Add('AUSENTE: '+$entry.file);continue}
  $hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  if($hash -eq $entry.sha256){$ok++}else{$different++;$lines.Add('DIFERENTE: '+$entry.file+' SHA256='+$hash)}
 }
 Write-Progress -Activity 'Conferindo arquivos de capas' -Completed
 $lines.Add("Recursos do kit: iguais=$ok ausentes=$missing diferentes=$different total=$checked")
 $lines.Add('')
 $lines.Add('ARQUIVOS BASE (diferenca da referencia nao prova erro):')
 foreach($entry in $expected.base){
  $path=Join-Path $root ('system\'+$entry.file)
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){$lines.Add($entry.file+': ausente');continue}
  $hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  $lines.Add($entry.file+': SHA256='+$hash+'; igual_destino_enviado='+($hash -eq $entry.current)+'; igual_referencia='+($hash -eq $entry.reference))
 }
 $lines.Add('')
 $lines.Add('MODULOS CARREGADOS (somente os componentes selecionados):')
 $moduleNames=@('CapasClassic.dll','d3d9.dll','Engine.dll','D3DDrv.dll','Core.dll','NWindow.dll','CliExt.dll','L2modExCore.dll','dsetup.dll','dsetup_base.dll')
 foreach($game in $games){
  $lines.Add('Processo L2 PID='+$game.Id)
  try{
   foreach($module in $game.Modules){
    if($moduleNames -contains $module.ModuleName){
     $hash=(Get-FileHash -LiteralPath $module.FileName -Algorithm SHA256).Hash.ToLowerInvariant()
     $localExpected=Join-Path $root ('system\'+$module.ModuleName)
     $samePath=[string]::Equals([IO.Path]::GetFullPath($module.FileName),[IO.Path]::GetFullPath($localExpected),[StringComparison]::OrdinalIgnoreCase)
     $lines.Add('  '+$module.ModuleName+'; da_system_escolhida='+$samePath+'; SHA256='+$hash)
    }
   }
  }catch{$lines.Add('  Nao foi possivel ler a lista de modulos: '+$_.Exception.GetType().Name)}
 }
 $lines.Add('')
 $lines.Add('ESTADO INTERNO DO MOTOR E CONTADORES (canal nativo CCLV, leitura):')
 Write-Host 'CAPTURANDO POR 12 SEGUNDOS: volte ao jogo e caminhe/gire com a capa equipada.' -ForegroundColor Yellow
 $map=$null;$view=$null
 try {
  $map=[IO.MemoryMappedFiles.MemoryMappedFile]::OpenExisting('Local\CapasClassicLive_v1',[IO.MemoryMappedFiles.MemoryMappedFileRights]::Read)
  $view=$map.CreateViewAccessor(0,256,[IO.MemoryMappedFiles.MemoryMappedFileAccess]::Read)
  for($sample=0;$sample -lt 24;$sample++){
   $bytes=New-Object byte[] 256
   for($index=0;$index -lt 256;$index++){$bytes[$index]=$view.ReadByte($index)}
   $magic=[BitConverter]::ToUInt32($bytes,0)
   $version=[BitConverter]::ToUInt32($bytes,4)
   if($magic -ne 0x564C4343 -or $version -ne 2){$lines.Add('Formato de telemetria diferente do analisado. Sem interpretar o conteudo.');break}
   $gamePid=[BitConverter]::ToUInt32($bytes,8)
   $stage=[BitConverter]::ToUInt32($bytes,16)
   $message=[Text.Encoding]::UTF8.GetString($bytes,144,96).Split([char]0)[0]
   $belongs=@($games | Where-Object {$_.Id -eq $gamePid}).Count -gt 0
   $lines.Add('Amostra '+($sample+1)+'; PID='+$gamePid+'; pertence_ao_jogo_aberto='+$belongs+'; estado='+$stage+'; mensagem='+$message)
   $tracked=[Text.Encoding]::UTF8.GetString($bytes,64,80).Split([char]0)[0]
   $fields=New-Object 'System.Collections.Generic.List[string]'
   foreach($offset in @(20,24,28,32,36,40,44,48,52,56,240,244,248,252)){
    $fields.Add(('u{0:X2}={1}' -f $offset,[BitConverter]::ToUInt32($bytes,$offset)))
   }
   $lines.Add('  objeto_rastreado='+$tracked+'; '+($fields -join '; '))
   Start-Sleep -Milliseconds 500
  }
 }catch{$lines.Add('Canal nao lido: '+$_.Exception.GetType().Name+' - '+$_.Exception.Message)}
 finally{if($null -ne $view){$view.Dispose()};if($null -ne $map){$map.Dispose()}}
 $lines.Add('')
 $lines.Add('Interpretacao: u20/u24/u28 sao contadores incrementados em callbacks nativos. Os outros campos numericos foram preservados com nomes de offset: seu significado nao foi presumido. Estado 3 confirma inicializacao, nao igualdade visual da simulacao.')
 $report=Join-Path $PSScriptRoot 'Resultado_Capas_V2.txt'
 $lines | Set-Content -LiteralPath $report -Encoding UTF8
 Write-Host ''
 Write-Host 'VERIFICACAO CONCLUIDA.' -ForegroundColor Green
 Write-Host "Envie este arquivo no chat: $report"
 Write-Host 'Nenhum ajuste foi aplicado ao jogo.'
}catch{Write-Host ('NAO CONCLUIDO: '+$_.Exception.Message) -ForegroundColor Red;Read-Host 'Pressione Enter para fechar';exit 1}
Read-Host 'Pressione Enter para fechar'
