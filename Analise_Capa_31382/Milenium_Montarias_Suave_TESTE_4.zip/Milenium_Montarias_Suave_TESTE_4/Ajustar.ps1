﻿param([ValidateSet('Aplicar','Desfazer')][string]$Acao='Aplicar',[string]$Cliente)
$ErrorActionPreference='Stop'
try{
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=New-Object Security.Principal.WindowsPrincipal($identity)
 if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Acao '+$Acao
  if($Cliente){$arguments+=' -Cliente "'+$Cliente+'"'}
  $child=Start-Process -FilePath powershell.exe -ArgumentList $arguments -Verb RunAs -Wait -PassThru
  exit $child.ExitCode
 }
 if(Get-Process -Name L2 -ErrorAction SilentlyContinue){throw 'Feche o jogo. A DLL le esta configuracao somente na inicializacao.'}
 if(!$Cliente){$Cliente='C:\Program Files (x86)\LINEAGE ROYAL NOVO'}
 if(!(Test-Path -LiteralPath (Join-Path $Cliente 'system\L2.exe'))){
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='Escolha a pasta do seu jogo (que contem system).'
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0}
  $Cliente=$dialog.SelectedPath
 }
 $root=(Resolve-Path -LiteralPath $Cliente).Path
 if((Split-Path -Leaf $root) -ieq 'system'){$root=Split-Path -Parent $root}
 if(!(Test-Path -LiteralPath (Join-Path $root 'system\L2.exe'))){throw 'Pasta do cliente incorreta.'}
 $path=Join-Path $root 'system\CapasClassic.ini'
 $saved=Join-Path $root 'Milenium_Montarias_Backup_TESTE4'
 $journal=Join-Path $saved 'alteracao.json'
 $backup=Join-Path $saved 'CapasClassic.ini'
 $original=[IO.File]::ReadAllBytes($path)
 $before=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
 if($Acao -eq 'Desfazer'){
  if(!(Test-Path -LiteralPath $journal)){throw 'Nao existe backup deste ajuste. Nenhuma alteracao aplicada.'}
  $record=Get-Content -LiteralPath $journal -Raw | ConvertFrom-Json
  if((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.before){throw 'Backup diferente do registrado.'}
  if($before -eq $record.before){Write-Host 'A configuracao ja esta restaurada.';Read-Host 'Pressione Enter para fechar';exit 0}
  if($before -ne $record.after){throw 'A configuracao foi alterada depois do teste. Restauracao automatica interrompida para preservar essas alteracoes.'}
  Copy-Item -LiteralPath $backup -Destination $path -Force
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.before){throw 'Falha na conferencia da restauracao.'}
  Write-Host 'AJUSTE DE MONTARIA DESFEITO.' -ForegroundColor Green
 }else{
  if(Test-Path -LiteralPath $journal){
   $previous=Get-Content -LiteralPath $journal -Raw | ConvertFrom-Json
   if($before -eq $previous.after){Write-Host 'Este ajuste ja esta aplicado.';Read-Host 'Pressione Enter para fechar';exit 0}
   if($before -ne $previous.before){throw 'Existe um teste anterior e a configuracao atual mudou. Nenhuma alteracao aplicada.'}
  }
  # ASCII-only byte-preserving substitutions in the existing [Capa] section.
  # Latin-1 roundtrips every byte, preserving comments, newline style and encoding.
  $encoding=[Text.Encoding]::GetEncoding(28591)
  $text=$encoding.GetString($original)
  if($original.Length -ge 2 -and (($original[0] -eq 255 -and $original[1] -eq 254) -or ($original[0] -eq 254 -and $original[1] -eq 255))){throw 'INI UTF-16 inesperado. Nenhuma alteracao aplicada.'}
  $bomPrefix=''
  if($original.Length -ge 3 -and $original[0] -eq 239 -and $original[1] -eq 187 -and $original[2] -eq 191){$bomPrefix=$text.Substring(0,3);$text=$text.Substring(3)}
  $section=[regex]::Match($text,'(?ims)^\s*\[Capa\][^\r\n]*(?:\r?\n)(?<body>.*?)(?=^\s*\[|\z)')
  if(!$section.Success){throw 'Secao [Capa] ausente ou diferente da analisada.'}
  $body=$section.Groups['body'].Value
  $settings=@(
   [pscustomobject]@{name='mount_stiffness';value='0.45'},
   [pscustomobject]@{name='mount_stiffness_slow';value='0.60'},
   [pscustomobject]@{name='mount_wind_cap';value='24'}
  )
  $changes=New-Object 'System.Collections.Generic.List[object]'
  foreach($setting in $settings){
   $pattern='(?im)^(?<prefix>[ \t]*'+[regex]::Escape($setting.name)+'[ \t]*=[ \t]*)(?<number>[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+))(?<suffix>[ \t]*(?:;[^\r\n]*)?)(?=\r?$)'
   $matches=[regex]::Matches($body,$pattern)
   if($matches.Count -ne 1){throw ('Chave ausente, duplicada ou invalida: '+$setting.name)}
   $match=$matches[0]
   $oldValue=[double]::Parse($match.Groups['number'].Value,[Globalization.CultureInfo]::InvariantCulture)
   if([double]::IsNaN($oldValue) -or [double]::IsInfinity($oldValue) -or $oldValue -lt 0){throw 'Valor original invalido.'}
   $changes.Add([pscustomobject]@{name=$setting.name;before=$match.Groups['number'].Value;after=$setting.value})
   $start=$match.Groups['number'].Index;$length=$match.Groups['number'].Length
   $body=$body.Substring(0,$start)+$setting.value+$body.Substring($start+$length)
  }
  $start=$section.Groups['body'].Index;$length=$section.Groups['body'].Length
  $updated=$bomPrefix+$text.Substring(0,$start)+$body+$text.Substring($start+$length)
  $newBytes=$encoding.GetBytes($updated)
  New-Item -ItemType Directory -Force -Path $saved | Out-Null
  if(!(Test-Path -LiteralPath $backup)){Copy-Item -LiteralPath $path -Destination $backup}
  if((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $before){throw 'O backup nao corresponde ao estado atual.'}
  $sha=[Security.Cryptography.SHA256]::Create()
  try{$after=([BitConverter]::ToString($sha.ComputeHash($newBytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  [pscustomobject]@{before=$before;after=$after;changes=$changes.ToArray()} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $journal -Encoding UTF8
  try{
   [IO.File]::WriteAllBytes($path,$newBytes)
   if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $after){throw 'Falha ao conferir o INI atualizado.'}
  }catch{
   Copy-Item -LiteralPath $backup -Destination $path -Force
   throw
  }
  Write-Host 'AJUSTE DE MONTARIA APLICADO PARA TESTE.' -ForegroundColor Green
  Write-Host 'Rigidez lenta: 0.60. Rigidez em movimento: 0.45. Limite de vento montado: 24.'
  Write-Host 'Reabra o jogo e teste a capa parado e andando na montaria.'
  Write-Host 'A animacao de abrir/cair ao equipar nao foi implementada por este ajuste.'
 }
}catch{Write-Host ('NAO CONCLUIDO: '+$_.Exception.Message) -ForegroundColor Red;Read-Host 'Pressione Enter para fechar';exit 1}
Read-Host 'Pressione Enter para fechar'
