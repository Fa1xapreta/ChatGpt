﻿param([ValidateSet('Aplicar','Desfazer')][string]$Acao='Aplicar',[string]$Cliente)
$ErrorActionPreference='Stop'
try{
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 $principal=New-Object Security.Principal.WindowsPrincipal($identity)
 if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Acao '+$Acao
  if($Cliente){$arguments+=' -Cliente "'+$Cliente+'"'}
  $child=Start-Process -FilePath powershell.exe -ArgumentList $arguments -Verb RunAs -Wait -PassThru
  exit $child.ExitCode
 }
 if(Get-Process -Name L2 -ErrorAction SilentlyContinue){throw 'Feche o jogo antes de aplicar ou desfazer este teste.'}
 if(!$Cliente){$Cliente='C:\Program Files (x86)\LINEAGE ROYAL NOVO'}
 if(!(Test-Path -LiteralPath (Join-Path $Cliente 'system\L2.exe'))){
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='Escolha a pasta do seu jogo (que contem system).'
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0}
  $Cliente=$dialog.SelectedPath
 }
 $root=(Resolve-Path -LiteralPath $Cliente).Path
 if((Split-Path -Leaf $root) -ieq 'system'){$root=Split-Path -Parent $root}
 if(!(Test-Path -LiteralPath (Join-Path $root 'system\L2.exe'))){throw 'Pasta do cliente incorreta.'}
 $versions=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'versoes.json') -Raw | ConvertFrom-Json
 $destination=Join-Path $root 'system\D3DDrv.dll'
 $current=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
 if(@($versions.original,$versions.modelo) -notcontains $current){throw 'D3DDrv.dll diferente das duas versoes analisadas. Nenhum arquivo foi alterado.'}
 $source=Join-Path $PSScriptRoot 'modelo\D3DDrv.dll';$wanted=$versions.modelo
 if($Acao -eq 'Desfazer'){$source=Join-Path $PSScriptRoot 'original\D3DDrv.dll';$wanted=$versions.original}
 if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $wanted){throw 'Arquivo do kit incompleto ou alterado. Extraia o ZIP novamente.'}
 if($current -eq $wanted){Write-Host 'O arquivo ja esta na versao solicitada. Nenhuma alteracao necessaria.';Read-Host 'Pressione Enter para fechar';exit 0}
 $backup=Join-Path $root 'Milenium_Render_Backup_TESTE3'
 if($Acao -eq 'Aplicar'){
  New-Item -ItemType Directory -Force -Path $backup | Out-Null
  $saved=Join-Path $backup 'D3DDrv.dll'
  if(Test-Path -LiteralPath $saved){
   if((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $versions.original){throw 'Backup existente diferente; teste interrompido sem substituir o driver.'}
  }else{
   Copy-Item -LiteralPath $destination -Destination $saved
   if((Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $versions.original){throw 'Falha ao conferir backup; driver nao foi substituido.'}
  }
 }
 # Keep a verified copy of the current version in the kit for automatic rollback of a failed copy.
 $temp=Join-Path $PSScriptRoot ('antes_render_'+[guid]::NewGuid().ToString('N')+'.tmp')
 Copy-Item -LiteralPath $destination -Destination $temp
 if((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $current){Remove-Item -LiteralPath $temp;throw 'Falha ao preparar restauracao temporaria.'}
 try{
  Copy-Item -LiteralPath $source -Destination $destination -Force
  if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $wanted){throw 'Falha ao conferir o driver copiado.'}
 }catch{
  Copy-Item -LiteralPath $temp -Destination $destination -Force
  if((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $current){throw 'Restauracao automatica falhou. Guarde o arquivo antes_render_*.tmp desta pasta e o backup no cliente.'}
  throw
 }
 Remove-Item -LiteralPath $temp
 if($Acao -eq 'Aplicar'){
  Write-Host 'TESTE DE RENDERIZACAO APLICADO.' -ForegroundColor Green
  Write-Host 'Somente D3DDrv.dll foi substituido pelo do modelo.'
  Write-Host 'Abra o jogo e compare a capa 31382. Para voltar, use DESFAZER.bat deste kit.'
 }else{Write-Host 'DRIVER ORIGINAL RESTAURADO. O sistema de capas continua instalado.' -ForegroundColor Green}
}catch{Write-Host ('NAO CONCLUIDO: '+$_.Exception.Message) -ForegroundColor Red;Read-Host 'Pressione Enter para fechar';exit 1}
Read-Host 'Pressione Enter para fechar'
