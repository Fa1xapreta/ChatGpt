class ToolTipHandle extends UIScript;

var CustomTooltip Tooltip;

static function ToolTipHandle Inst() {
	return new class'ToolTipHandle';
}

function Init(int MinimumWidth, optional int SimpleLineCount) {
    Tooltip.MinimumWidth = MinimumWidth;
	Tooltip.SimpleLineCount = SimpleLineCount;

	Tooltip.DrawList.Remove(0, Tooltip.DrawList.Length);
}

function DrawText(string strText, int nOffSetX, int nOffSetY, Color t_color, bool bDrawOneLine, bool bLineBreak) {
	local DrawItemInfo TooltipInfo;

	TooltipInfo.eType = DIT_TEXT;
	TooltipInfo.t_color = t_color;
	TooltipInfo.t_bDrawOneLine = bDrawOneLine;
	TooltipInfo.bLineBreak = bLineBreak;
	TooltipInfo.nOffSetX = nOffSetX;
	TooltipInfo.nOffSetY = nOffSetY;
	TooltipInfo.t_strText = strText;

	Tooltip.DrawList.Length = Tooltip.DrawList.Length + 1;

	Tooltip.DrawList[Tooltip.DrawList.Length - 1] = TooltipInfo;
}

function DrawTex(string strTexture, int Width, int Height, int UWidth, int UHeight, int nOffSetX, int nOffSetY, bool bDrawOneLine, bool bLineBreak) {
	local DrawItemInfo TooltipInfo;

	TooltipInfo.eType = DIT_TEXTURE;
	TooltipInfo.t_bDrawOneLine = bDrawOneLine;
	TooltipInfo.bLineBreak = bLineBreak;
	TooltipInfo.u_nTextureWidth = Width;
	TooltipInfo.u_nTextureHeight = Height;
	TooltipInfo.u_nTextureUWidth = UWidth;
	TooltipInfo.u_nTextureUHeight = UHeight;
	TooltipInfo.nOffSetX = nOffSetX;
	TooltipInfo.nOffSetY = nOffSetY;
	TooltipInfo.u_strTexture = strTexture;

	Tooltip.DrawList.Length = Tooltip.DrawList.Length + 1;

	Tooltip.DrawList[Tooltip.DrawList.Length - 1] = TooltipInfo;
}

function DrawBlank(int Height) {
	local DrawItemInfo TooltipInfo;
	
	TooltipInfo.eType = DIT_BLANK;
	TooltipInfo.b_nHeight = Height;
	
	Tooltip.DrawList.Length = Tooltip.DrawList.Length + 1;

	Tooltip.DrawList[Tooltip.DrawList.Length - 1] = TooltipInfo;
}

function DrawLine(int OffSetY) {
	self.DrawTex( "MUI_AUGM.tooltip_line", self.Tooltip.MinimumWidth, 1, 1, 1, 0, OffSetY, true, true );
}

function int GetLength() {
	return self.Tooltip.DrawList.Length;
}

defaultproperties
{
}
