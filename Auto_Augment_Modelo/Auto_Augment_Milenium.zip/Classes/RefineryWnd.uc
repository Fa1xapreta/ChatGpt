class RefineryWnd extends MileniumAugmentAPI;

const TIMER_REF = 32320;
const TIMER_UNREF = 32321;
const DELAY_REF = 1500;

const C_ANIMLOOPCOUNT = 1;
const C_ANIMLOOPCOUNT1 = 1;
const C_ANIMLOOPCOUNT2 = 1;
const C_ANIMLOOPCOUNT3 = 1;

var bool procedure1stat;
var bool procedure2stat;
var bool procedure3stat;

var ItemInfo RefineItemInfo;
var ItemInfo LifeStoneItemInfo;
var ItemInfo GemStoneItemInfo;
var ItemInfo RefinedITemInfo;

var WindowHandle me;
var WindowHandle m_Highlight1;
var WindowHandle m_Highlight2;
var WindowHandle m_Highlight3;
var WindowHandle m_SeletedItemHighlight1;
var WindowHandle m_SeletedItemHighlight2;
var WindowHandle m_SeletedItemHighlight3;
var WindowHandle m_DragBox1;
var WindowHandle m_DragBox2;
var WindowHandle m_DragBox3;
var WindowHandle m_ItemListWnd;
var WindowHandle m_ResultAnimation1;
var WindowHandle m_ResultAnimation2;
var WindowHandle m_ResultAnimation3;

var AnimTextureHandle m_ResultAnim1;
var AnimTextureHandle m_ResultAnim2;
var AnimTextureHandle m_ResultAnim3;

var AnimTextureHandle m_bsAnim;
var AnimTextureHandle m_progressAnim;

var ButtonHandle m_CloseBtn;
var ButtonHandle m_RefineryBtn;
var ButtonHandle m_UnRefineryBtn;

var ItemWindowHandle m_DragboxItem1;
var ItemWindowHandle m_DragBoxItem2;
var ItemWindowHandle m_DragBoxItem3;

var ItemWindowHandle m_itemList;

var TextBoxHandle m_InstructionText;
var TextBoxHandle m_RefText;

var int i_NeededGemstone;
var int i_NeededGemstoneCount;

var bool isRepeat;

var InventoryWnd invScript;

var bool onAnimStart;

var L2UITimerObject zz_TimerEnableUnref;

var AutoRefineryWnd zz_AutoRefineryRef;

var bool zz_AutoRefineryOn;

var int zz_CostToRemove;

enum REF
{
	WEAPON,
	LIFESTONE,
	GEMSTONE,
};

function OnLoad()
{
	RegisterEvent( EV_ShowRefineryInteface );
	RegisterEvent( EV_RefineryConfirmTargetItemResult );
	RegisterEvent( EV_RefineryConfirmRefinerItemResult );
	RegisterEvent( EV_RefineryConfirmGemStoneResult );
	RegisterEvent( EV_RefineryRefineResult );
	RegisterEvent( EV_RefineryConfirmCancelItemResult );
	RegisterEvent( EV_RefineryRefineCancelResult );

	procedure1stat = false;
	procedure2stat = false;
	procedure3stat = false;
	
	me = GetHandle( "RefineryWnd" );
    m_Highlight1 = GetHandle( "RefineryWnd.ItemDragBox1Wnd.DropHighlight");
    m_Highlight2 = GetHandle( "RefineryWnd.ItemDragBox2Wnd.DropHighlight");
    m_Highlight3 = GetHandle( "RefineryWnd.ItemDragBox3Wnd.DropHighlight");
	m_SeletedItemHighlight1 = GetHandle( "RefineryWnd.ItemDragBox1Wnd.SelectedItemHighlight");
    m_SeletedItemHighlight2 = GetHandle( "RefineryWnd.ItemDragBox2Wnd.SelectedItemHighlight");
    m_SeletedItemHighlight3 = GetHandle( "RefineryWnd.ItemDragBox3Wnd.SelectedItemHighlight");
    m_DragBox1 = GetHandle( "RefineryWnd.ItemDragBox1Wnd");
    m_DragBox2 = GetHandle( "RefineryWnd.ItemDragBox2Wnd");
    m_DragBox3 = GetHandle( "RefineryWnd.ItemDragBox3Wnd");
	m_ResultAnimation1 = GetHandle( "RefineryWnd.RefineResultAnimation01");
	m_ResultAnimation2 = GetHandle( "RefineryWnd.RefineResultAnimation02");
	m_ResultAnimation3 = GetHandle( "RefineryWnd.RefineResultAnimation03");

	m_ResultAnim1 = AnimTextureHandle ( GetHandle( "RefineryWnd.ItemDragBox1Wnd.RefineResult1") );
	m_ResultAnim2 = AnimTextureHandle ( GetHandle( "RefineryWnd.ItemDragBox1Wnd.RefineResult2") );
	m_ResultAnim3 = AnimTextureHandle ( GetHandle( "RefineryWnd.ItemDragBox1Wnd.RefineResult3") );

	m_bsAnim = AnimTextureHandle ( GetHandle( "RefineryWnd.bs_anim") );
	m_progressAnim = AnimTextureHandle ( GetHandle( "RefineryWnd.progressAnim") );

	m_DragboxItem1 = ItemWindowHandle ( GetHandle( "RefineryWnd.ItemDragBox1Wnd.ItemDragBox1") );
	m_DragBoxItem2 = ItemWindowHandle ( GetHandle( "RefineryWnd.ItemDragBox2Wnd.ItemDragBox2") );
	m_DragBoxItem3 = ItemWindowHandle ( GetHandle( "RefineryWnd.ItemDragBox3Wnd.ItemDragBox3") );

	m_ItemListWnd = GetHandle( "RefineryWnd.ItemListWnd");
	m_itemList = ItemWindowHandle ( GetHandle( "RefineryWnd.ItemListWnd.itemList") );

	m_CloseBtn = ButtonHandle ( GetHandle ("RefineryWnd.btnClose") );
	m_RefineryBtn = ButtonHandle ( GetHandle ("RefineryWnd.btnRefine") );
	m_UnRefineryBtn = ButtonHandle ( GetHandle ("RefineryWnd.btnUnRefine") );

	m_InstructionText = TextBoxHandle ( GetHandle ("RefineryWnd.txtInstruction") );
	m_RefText = TextBoxHandle ( GetHandle ("RefineryWnd.txtRef") );
       
	m_ResultAnim1.SetLoopCount( C_ANIMLOOPCOUNT1 );
	m_ResultAnim2.SetLoopCount( C_ANIMLOOPCOUNT2 );
	m_ResultAnim3.SetLoopCount( C_ANIMLOOPCOUNT3 );
	
	
	

	invScript = InventoryWnd( GetScript( "InventoryWnd" ) );

	zz_AutoRefineryRef = AutoRefineryWnd( GetScript("AutoRefineryWnd") );

	HideWindow("RefineryWnd.tex_autoRefinery");

	class'UIAPI_PROGRESSCTRL'.static.SetProgressTime( "RefineryWnd.barRef", 1000);

	zz_TimerEnableUnref = class'L2UITimer'.static.Inst()._AddNewTimerObject( 1000, 1 );
    zz_TimerEnableUnref._DelegateOnEnd = xxEnableToUnrefinery;
}

function xxEnableToUnrefinery()
{
	local ItemInfo info;

	if(zz_CostToRemove > GetAdena()) {
		m_InstructionText.SetText(xxReplace(GetSystemString(1885), "$s1", MakeCostString(string(zz_CostToRemove))));
		return;
	}

	m_UnRefineryBtn.EnableWindow();

	if( !xxFindInventoryItem( RefineItemInfo.ServerID, info ) ) return;

	if( zz_AutoRefineryOn && zz_AutoRefineryRef.xxGetAutoRefineryStatus() && !zz_AutoRefineryRef.xxIsCheckedRefID( RefineItemInfo.RefineryOp1, RefineItemInfo.RefineryOp2 )) {
		OnUnRefineRequest();
		return;
	}

	m_RefineryBtn.SetButtonName(1477);
}

function OnShow()
{
	ResetReady();

	m_bsAnim.SetLoopCount( -1 );
	m_bsAnim.Play();
	// invScript.HandleOpenWindow();

	if( IsShowWindow("CompoundWnd") )
		HideWindow("CompoundWnd");
}

function OnHide()
{
	m_bsAnim.Stop();

	zz_AutoRefineryOn = false;

	procedure1stat = false;
	procedure2stat = false;
	procedure3stat = false;
}

function ResetReady()
{
	local ItemInfo clsItem;

	zz_AutoRefineryOn = false;

	procedure1stat = false;
	procedure2stat = false;
	procedure3stat = false;
	me.ShowWindow();
	m_DragBox2.HideWindow();
	m_DragBox3.HideWindow();
	m_Highlight1.ShowWindow();
	m_Highlight2.HideWindow();
	m_Highlight3.HideWindow();
	m_SeletedItemHighlight1.HideWindow();
	m_SeletedItemHighlight2.HideWindow();
	m_SeletedItemHighlight3.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	m_ResultAnim1.Stop();
	m_ResultAnim2.Stop();
	m_ResultAnim3.Stop();
	m_InstructionText.SetText(GetSystemString(1679));
	m_DragBoxItem1.Clear();
	m_DragBoxItem2.Clear();
	m_DragBoxItem3.Clear();
	m_RefineryBtn.DisableWindow();
	m_UnRefineryBtn.DisableWindow();
	m_UnRefineryBtn.SetTooltipText( "" );
	m_DragBoxItem1.EnableWindow();
	m_DragBoxItem2.DisableWindow();
	m_DragBoxItem3.DisableWindow();
	Playsound("ItemSound2.smelting.Smelting_dragin");
	m_CloseBtn.EnableWindow();
	m_RefText.SetText("");

	m_progressAnim.HideWindow();
	m_progressAnim.Stop();

	m_DragBox1.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 0, 225);
	m_DragBox2.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", -130, 225);
	m_DragBox3.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 130, 225);

	m_ItemListWnd.ShowWindow();
	GetAllValidItems( REF.WEAPON );

	LifeStoneItemInfo = clsItem;
}      
       
function OnWeaponValidationResult()
{
	m_Highlight1.HideWindow();
	m_SeletedItemHighlight1.ShowWindow();
	m_SeletedItemHighlight2.HideWindow();
	m_SeletedItemHighlight3.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	procedure1stat = true;
	procedure2stat = false;
	procedure3stat = false;
	m_DragBoxItem1.EnableWindow();
	m_DragBoxItem2.EnableWindow();
	m_DragBoxItem3.DisableWindow();
	m_RefineryBtn.DisableWindow();
	m_DragBox2.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", -100, 225);
	m_DragBox3.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 130, 225);

	if(m_RefText.GetText() == "")
	{
		m_InstructionText.SetText(GetSystemString(1680));
		m_DragBoxItem2.Clear();
		m_DragBoxItem3.Clear();
		m_Highlight2.ShowWindow();
		m_DragBox2.ShowWindow();
		m_DragBox3.HideWindow();
		m_ItemListWnd.ShowWindow();

		m_DragBox1.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 100, 225);

		GetAllValidItems( REF.LIFESTONE );
	}else{
		m_InstructionText.SetText(GetSystemString(1694));
		m_ItemListWnd.HideWindow();
	}
}      

function OnLifeStoneValidationResult()
{
	local ItemInfo infItem;

	m_DragBox3.ShowWindow();

	m_DragBox1.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 0, 225);
	m_DragBox2.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", -130, 225);
	m_DragBox3.SetAnchor("RefineryWnd", "TopCenter", "TopCenter", 130, 225);

	m_Highlight1.HideWindow();
	m_Highlight2.HideWindow();
	m_Highlight3.ShowWindow();
	m_SeletedItemHighlight1.ShowWindow();
	m_SeletedItemHighlight2.ShowWindow();
	m_SeletedItemHighlight3.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	
	procedure1stat = true;
	procedure2stat = true;
	procedure3stat = false;

	m_InstructionText.SetText( GetSystemString(1684) $ ": " $ class'UIDATA_ITEM'.static.GetItemName(i_NeededGemstone) $ " (" $ i_NeededGemstoneCount $ ")" );
	
	m_DragBoxItem1.EnableWindow();
	m_DragBoxItem2.EnableWindow();
	m_DragBoxItem3.EnableWindow();

	m_DragBoxItem3.Clear();

	GetAllValidItems( REF.GEMSTONE );
	m_ItemListWnd.ShowWindow();
	m_RefineryBtn.DisableWindow();

	if(isRepeat && m_DragBoxItem3.GetItemNum() < 1 && GetRepeatItemInfo( GemStoneItemInfo, i_NeededGemstoneCount, infItem ))
	{
		ValidateGemstone(infItem);
		isRepeat = false;
	}
}

function OnGemStoneValidationResult(string param)
{	
	GemStoneItemInfo.ItemNum = i_NeededGemstoneCount;

	texCount( GemStoneItemInfo );

	if( !m_DragBoxItem3.SetItem( 0, GemStoneItemInfo ) )
		m_DragBoxItem3.AddItem( GemStoneItemInfo );

	m_Highlight1.HideWindow();
	m_Highlight2.HideWindow();
	m_Highlight3.HideWindow();
	m_SeletedItemHighlight1.ShowWindow();
	m_SeletedItemHighlight2.ShowWindow();
	m_SeletedItemHighlight3.ShowWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	
	procedure1stat = true;
	procedure2stat = true;
	procedure3stat = false;

	m_InstructionText.SetText( GetSystemString(1681) );
	
	m_DragBoxItem1.EnableWindow();
	m_DragBoxItem2.EnableWindow();
	m_DragBoxItem3.EnableWindow();

	m_ItemListWnd.HideWindow();
	m_RefineryBtn.EnableWindow();

	if( zz_AutoRefineryOn && zz_AutoRefineryRef.xxGetAutoRefineryStatus()) {
		onAnimStart = false;
		OnClickRefineButton();
	}
}

function OnRefineryRefineResult()
{
	m_Highlight1.HideWindow();
	m_Highlight2.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	procedure1stat = true;
	procedure2stat = true;
	procedure3stat = true;
	m_InstructionText.SetText(GetSystemString(1682));
}

//Event
function OnEvent( int a_EventID, String a_Param )
{
	switch( a_EventID )
	{
		// Refinery Window Open
		case EV_ShowRefineryInteface:
			if (procedure1stat == false)
			{
				ShowRefineryInterface();
			}
			break;
		case EV_RefineryConfirmRefinerItemResult:
			Playsound("ItemSound2.smelting.Smelting_dragin");
			OnLifeStoneValidation( a_Param );
			break;
		case EV_RefineryConfirmGemStoneResult:
			Playsound("ItemSound2.smelting.Smelting_dragin");
			OnGemStoneValidationResult( a_Param );
			break;
		// Final Refine Result
		case EV_RefineryRefineResult:
			OnRefineDoneResult( a_Param );
			break;
		case EV_RefineryConfirmCancelItemResult:
			SetAdenaTooltip(a_Param);
			break;
		case EV_RefineryRefineCancelResult:
			OnUnrefineDoneResult( a_Param );
			break;
		default:
			break;
	}	
}

function ShowRefineryInterface()
{
	ResetReady();
}

function OnDropItem( String a_WindowID, ItemInfo a_ItemInfo, int X, int Y)
{
	switch (a_WindowID)
	{
		case "ItemDragBox1":
			if (procedure1stat == false && procedure2stat == false && procedure3stat == false)
				ValidateWeapon( a_ItemInfo );
		break;
		case "ItemDragBox2":
			if(procedure1stat == true && procedure2stat == false && procedure3stat == false)
				ValidateLifeStone( a_ItemInfo );
		break;
		case "ItemDragBox3":
			if(procedure1stat == true && procedure2stat == true && procedure3stat == false)
				ValidateGemstone( a_ItemInfo );
		break;
	}
}

function printRefInfo(ItemInfo info)
{
	local string strDesc1, strDesc2, strDesc3, tmp;
	local int Quality;
	local Color a_Color;

	if(info.SlotBitType == 8192)
	{
		Quality = class'UIDATA_REFINERYOPTION'.static.GetQuality(info.RefineryOp1);
		a_Color = GetRefineColor(Quality);
	}
	else
	{
		Quality = class'UIDATA_REFINERYOPTION'.static.GetQuality(info.RefineryOp2);
		a_Color = GetRefineColor(Quality);
	}

	if(class'UIDATA_REFINERYOPTION'.static.GetOptionDescription( info.RefineryOp1, strDesc1, strDesc2, strDesc3 ))
	{
		if ( -1 != InStr( strDesc1, "\n" ) ) strDesc1 = xxReplace(strDesc1, "\\n", "");
		if ( -1 != InStr( strDesc2, "\n" ) ) strDesc2 = xxReplace(strDesc2, "\\n", "");
		if ( -1 != InStr( strDesc3, "\n" ) ) strDesc3 = xxReplace(strDesc3, "\\n", "");

		if(strDesc1 != "")
			tmp = tmp $ strDesc1 $ "\\n";

		if(strDesc2 != "")
			tmp = tmp $ strDesc2 $ "\\n";

		if(strDesc3 != "")
			tmp = tmp $ strDesc3 $ "\\n";
	}
	if(class'UIDATA_REFINERYOPTION'.static.GetOptionDescription( info.RefineryOp2, strDesc1, strDesc2, strDesc3 ))
	{
		if ( -1 != InStr( strDesc1, "\n" ) ) strDesc1 = xxReplace(strDesc1, "\\n", "");
		if ( -1 != InStr( strDesc2, "\n" ) ) strDesc2 = xxReplace(strDesc2, "\\n", "");
		if ( -1 != InStr( strDesc3, "\n" ) ) strDesc3 = xxReplace(strDesc3, "\\n", "");

		if(strDesc1 != "")
			tmp = tmp $ strDesc1 $ "\\n";

		if(strDesc2 != "")
			tmp = tmp $ strDesc2 $ "\\n";

		if(strDesc3 != "")
			tmp = tmp $ strDesc3 $ "\\n";
	}

	m_RefText.SetTextColor( a_Color );
	m_RefText.SetText(tmp);

	if(tmp != "")
	{
		class'RefineryAPI'.static.ConfirmCancelItem( info.ServerID );

		m_RefineryBtn.DisableWindow();

		zz_TimerEnableUnref._Stop();
    	zz_TimerEnableUnref._Play();
	}else
	{
		m_RefineryBtn.EnableWindow();
		m_UnRefineryBtn.DisableWindow();
		m_UnRefineryBtn.SetTooltipText( "" );
	}
	m_CloseBtn.EnableWindow();
}

function ValidateWeapon(ItemInfo a_ItemInfo)
{
	if(a_ItemInfo.ItemType != 0 || a_ItemInfo.CrystalType <= 0) return;

	RefineItemInfo = a_ItemInfo;

	OnWeaponValidation( a_ItemInfo.ServerID );
}

function OnWeaponValidation(int Item1ServerID)
{
	if (Item1ServerID == RefineItemInfo.ServerID)
	{
		if( !m_DragBoxItem1.SetItem( 0, RefineItemInfo ) )
			m_DragBoxItem1.AddItem( RefineItemInfo );
		
		printRefInfo( RefineItemInfo );
		OnWeaponValidationResult();
	}
}

function ValidateLifeStone(ItemInfo a_ItemInfo)
{
	if(m_RefText.GetText() != "") return;

	LifeStoneItemInfo = a_ItemInfo;
	class'RefineryAPI'.static.ConfirmRefinerItem( RefineItemInfo.ServerID, LifeStoneItemInfo.ServerID );
}

function ValidateGemstone(ItemInfo a_ItemInfo)
{
	if(m_RefText.GetText() != "") return;

	GemStoneItemInfo = a_ItemInfo;

	if(a_ItemInfo.ItemNum >= i_NeededGemstoneCount)
		class'RefineryAPI'.static.ConfirmGemStone( RefineItemInfo.ServerID, LifeStoneItemInfo.ServerID, GemStoneItemInfo.ServerID, i_NeededGemstoneCount );
	else
		class'RefineryAPI'.static.ConfirmGemStone( RefineItemInfo.ServerID, LifeStoneItemInfo.ServerID, GemStoneItemInfo.ServerID, a_ItemInfo.ItemNum );
}

function OnLifeStoneValidation(string a_Param)
{
	local int Item2ServerID;
	local int Item2ClassID;
	local int ItemValidationResult2;
	local int GemID, GemCount;
	
	ParseInt(a_Param, "RefinerItemServerID", Item2ServerID);
	ParseInt(a_Param, "RefinerItemClassID", Item2ClassID);
	ParseInt(a_Param, "Result", ItemValidationResult2);
	ParseInt(a_Param, "GemStoneClassID", GemID);
	ParseInt(a_Param, "GemStoneCount", GemCount);
	
	switch( ItemValidationResult2 )
	{
	case 1:
		if (Item2ServerID == LifeStoneItemInfo.ServerID)
		{
			if( !m_DragBoxItem2.SetItem( 0, LifeStoneItemInfo ) )
			{
				LifeStoneItemInfo.ItemNum = 1;
				texCount( LifeStoneItemInfo );
				m_DragBoxItem2.AddItem( LifeStoneItemInfo );
			}
			i_NeededGemstone = GemID;
			i_NeededGemstoneCount = GemCount;

			OnLifeStoneValidationResult();
		}
		break;
	case 0:
		break;
	}
}
     
function OnClickButton( string strID )
{
	switch (strID)
	{
		case "btnRefine":

			if( zz_AutoRefineryOn ) {
				zz_AutoRefineryOn = false;
				m_RefineryBtn.SetButtonName(1477);
				return;
			}

			if( zz_AutoRefineryRef.xxGetAutoRefineryStatus() ) {
				zz_AutoRefineryOn = true;
				m_RefineryBtn.SetButtonName(1673);
			}

			Playsound("Itemsound2.smelting.smelting_loding");
			OnClickRefineButton();
			break;
		case "btnUnRefine":
			zz_AutoRefineryOn = false;
			OnUnRefineRequest();
			break;
		case "btnClose":
			OnClickCancelButton();
			break;
		case "btn_autoRefineryConfig":
			if( IsShowWindow("AutoRefineryWnd") )
				HideWindow("AutoRefineryWnd");
			else
				ShowWindow("AutoRefineryWnd");
			break;
	}
}


function OnClickCancelButton()
{
	// if( zz_AutoRefineryOn ) return;

	ResetReady();

	me.HideWindow();
	Playsound("Itemsound2.smelting.smelting_dragout");
	
	procedure1stat = false;
	procedure2stat = false;
	procedure3stat = false;
}

function OnClickRefineButton()
{
	m_Highlight1.HideWindow();
	m_Highlight2.HideWindow();
	m_ResultAnimation1.HideWindow();
	m_ResultAnimation2.HideWindow();
	m_ResultAnimation3.HideWindow();
	m_CloseBtn.DisableWindow();
	procedure1stat = true;
	procedure2stat = true;
	procedure3stat = true;

	if( !zz_AutoRefineryOn )
		m_RefineryBtn.DisableWindow();

	OnRefineRequest();
}

function OnTextureAnimEnd( AnimTextureHandle a_WindowHandle )
{
	
	switch ( a_WindowHandle )
	{
		case m_ResultAnim1:
		case m_ResultAnim2:
		case m_ResultAnim3:
			OnResultAnimEnd();
			break;
		case m_bsAnim:
			if(onAnimStart)
			{
				onAnimStart = False;

				m_bsAnim.SetTexture("MUI_AUGM.RefAnimWait.black_wait_00");
				// m_bsAnim.Stop();
				m_bsAnim.SetLoopCount( -1 );
				m_bsAnim.Play();

				m_progressAnim.HideWindow();
				m_progressAnim.Stop();
			}
			break;
	}
}

function OnTimer( int TimerID )
{
	switch ( TimerID )
	{
		case TIMER_REF:
			me.KillTimer(TIMER_REF);
			class'RefineryAPI'.static.RequestRefine( RefineItemInfo.ServerID, LifeStoneItemInfo.ServerID, GemStoneItemInfo.ServerID, i_NeededGemstoneCount);
			break;
	}
}

function OnResultAnimEnd()
{
	//m_ResultAnim1.Stop();
	m_ResultAnimation1.HideWindow();
	//m_ResultAnim2.Stop();
	m_ResultAnimation2.HideWindow();
	//m_ResultAnim3.Stop();
	m_ResultAnimation3.HideWindow();
}

function bool GetRepeatItemInfo(ItemInfo PreferredInfo, int MinCount, out ItemInfo Info)
{
	local int Index, i;
	local ItemInfo CandidateInfo;
	local InventoryWnd m_scriptInventoryWnd;

	m_scriptInventoryWnd = InventoryWnd( GetScript("InventoryWnd") );

	Index = m_scriptInventoryWnd.m_invenItem.FindItemWithServerID(PreferredInfo.ServerID);
	if(Index >= 0 && m_scriptInventoryWnd.m_invenItem.GetItem(Index, Info) && Info.ItemNum >= MinCount)
		return true;

	for(i = 0; i < m_scriptInventoryWnd.m_invenItem.GetItemNum(); i++)
	{
		if(!m_scriptInventoryWnd.m_invenItem.GetItem(i, CandidateInfo))
			continue;

		if(CandidateInfo.ClassID == PreferredInfo.ClassID && CandidateInfo.Damaged == PreferredInfo.Damaged && CandidateInfo.ItemNum >= MinCount)
		{
			Info = CandidateInfo;
			return true;
		}
	}

	return false;
}

function OnRefineRequest()
{
	if(onAnimStart) return;

	m_DragBox3.ClearAnchor();
	m_DragBox2.ClearAnchor();
	m_DragBox3.Move(-130, 0, 1.0);
	m_DragBox2.Move(130, 0, 1.0);

	// m_RefineryBtn.DisableWindow();

	StartAnimBS();

	me.SetTimer(TIMER_REF, DELAY_REF);
}

function StartAnimBS()
{
	onAnimStart = True;

	m_bsAnim.Stop();
	m_bsAnim.SetTexture("MUI_AUGM.RefAnimStart.black_start_0");
	m_bsAnim.SetLoopCount( 1 );
	m_bsAnim.Play();

	m_progressAnim.ShowWindow();
	m_progressAnim.SetLoopCount( 1 );
	m_progressAnim.Play();
}

function OnUnRefineRequest()
{
	if(zz_CostToRemove > GetAdena()) {
		m_InstructionText.SetText(xxReplace(GetSystemString(1885), "$s1", MakeCostString(string(zz_CostToRemove))));
		m_UnRefineryBtn.SetTooltipCustomType( SetTooltipItem( zz_CostToRemove, GetAdena()) );
		return;
	}
	
	m_RefText.SetText("");
	m_UnRefineryBtn.DisableWindow();
	m_UnRefineryBtn.SetTooltipText( "" );

	class'RefineryAPI'.static.RequestRefineCancel( RefineItemInfo.ServerID );

	RefineItemInfo.RefineryOp1 = 0;
	RefineItemInfo.RefineryOp2 = 0;

	ValidateWeapon(RefineItemInfo);
}

function OnUnrefineDoneResult(string param)
{
	local ItemInfo infItem;

	if(m_DragBoxItem2.GetItemNum() < 1 && GetRepeatItemInfo( LifeStoneItemInfo, 1, infItem ))
	{
		ValidateLifeStone( infItem );
		isRepeat = True;
	}
}
function OnRefineDoneResult(string a_Param)
{
	local int Option1;
	local int Option2;
	local int RefineResult;
	local int Quality;
	
	ParseInt(a_Param, "Option1", Option1);
	ParseInt(a_Param, "Option2", Option2);
	ParseInt(a_Param, "Result", RefineResult);
	
	switch (RefineResult)
	{
	case 1:
		RefineItemInfo.RefineryOp1 = Option1;
		RefineItemInfo.RefineryOp2 = Option2;

		
		if(!m_DragboxItem1.SetItem( 0, RefineItemInfo ))
		{
			m_DragboxItem1.AddItem( RefineItemInfo );
		}

		// if( zz_AutoRefineryOn && zz_AutoRefineryRef.xxGetAutoRefineryStatus() && !zz_AutoRefineryRef.xxIsCheckedRefID( Option1, Option2 )) {
		// 	OnUnRefineRequest();
		// 	return;
		// }

		// zz_AutoRefineryOn = false;
		// m_RefineryBtn.SetButtonName(1477);
		
		printRefInfo( RefineItemInfo );
			
		OnRefineryRefineResult();

		Quality = class'UIDATA_REFINERYOPTION'.static.GetQuality( Option2 );
		if( 0 >= Quality )
			Quality = 1;
		else if( 4 < Quality )
			Quality = 4;

		PlayResultAnimation( Quality );
		break;
		
	case 0:
		OnClickCancelButton();
		break;
	}
}

function PlayResultAnimation(int Grade)
{
	m_ResultAnim1.SetLoopCount( C_ANIMLOOPCOUNT1 );
	m_ResultAnim2.SetLoopCount( C_ANIMLOOPCOUNT2 );
	m_ResultAnim3.SetLoopCount( C_ANIMLOOPCOUNT3 );
	switch(Grade)
	{
	case 1:
		m_ResultAnimation1.ShowWindow();
		Playsound("ItemSound2.smelting.smelting_finalB");
		m_ResultAnim1.Play();
		break;
	case 2:
		m_ResultAnimation2.ShowWindow();
		Playsound("ItemSound2.smelting.smelting_finalC");
		m_ResultAnim2.Play();
		break;
	case 3:
		m_ResultAnimation3.ShowWindow();
		Playsound("ItemSound2.smelting.smelting_finalD");
		m_ResultAnim3.Play();
		break;
	case 4:
		m_ResultAnimation1.ShowWindow();
		m_ResultAnimation2.ShowWindow();
		m_ResultAnimation3.ShowWindow();
		Playsound("ItemSound2.smelting.smelting_finalD");
		m_ResultAnim1.Play();
		m_ResultAnim2.Play();
		m_ResultAnim3.Play();
		break;
	
	}
}

function Color GetRefineColor(int Quality)
{
	local Color tmp;

	switch (Quality)
	{
		case 1:
			tmp.R = 187;
			tmp.G = 181;
			tmp.B = 138;
		break;
		case 2:
			tmp.R = 132;
			tmp.G = 174;
			tmp.B = 216;
		break;
		case 3:
			tmp.R = 193;
			tmp.G = 112;
			tmp.B = 202;
		break;
		case 4:
			tmp.R = 225;
			tmp.G = 109;
			tmp.B = 109;
		break;
		default:
			tmp.R = 187;
			tmp.G = 181;
			tmp.B = 138;
		break;
	}

	return tmp;
}

function GetAllValidItems(int ItemType)
{
	local int i, invLimit;
	local ItemInfo infItem;

	invLimit = invScript.m_invenItem.GetItemNum();

	m_itemList.Clear();

	if(invScript.zzm_equipItem[ 5 ].GetItem(0, infItem) && ItemType == REF.WEAPON)
		if(infItem.ItemType == 0 && infItem.CrystalType > 1)
			m_itemList.AddItem(infItem);

	for(i = 0; i < invLimit; i++)
	{
		if(!invScript.m_invenItem.GetItem(i, infItem)) return;

		if(ItemType == REF.WEAPON)
		{
			if(infItem.ItemType == 0 && infItem.CrystalType > 1)
				m_itemList.AddItem(infItem);
		}else if(ItemType == REF.LIFESTONE)
		{
			if(isLifeStone(infItem.Name))
				m_itemList.AddItem(infItem);
		}else if(ItemType == REF.GEMSTONE)
		{
			if(isGemStone(infItem.Name))
				m_itemList.AddItem(infItem);
		}
		
	}
}

function bool isLifeStone(string name)
{
	if(inStr(name, "Life Stone") > -1)
		return True;
	
	return False;
}

function bool isGemStone(string name)
{
	if(inStr(name, "Gemstone") > -1)
		return True;
	
	return False;
}

function OnRClickItemWithHandle( ItemWindowHandle a_hItemWindow, int index )
{
	local ItemInfo info;

	if( a_hItemWindow == m_itemList )
	{
		m_itemList.GetItem(index, info);

		if (procedure1stat == false && procedure2stat == false && procedure3stat == false)
			ValidateWeapon( info );

		if(procedure1stat == true && procedure2stat == false && procedure3stat == false)
			ValidateLifeStone( info );

		if(procedure1stat == true && procedure2stat == true && procedure3stat == false)
			ValidateGemstone( info );
	}else if(a_hItemWindow == m_DragboxItem1)
	{
		ResetReady();
	}else if(a_hItemWindow == m_DragboxItem2)
	{
		OnWeaponValidationResult();
	}else if(a_hItemWindow == m_DragboxItem3)
	{
		OnLifeStoneValidationResult();
	}
}

function OnDBClickItemWithHandle( ItemWindowHandle a_hItemWindow, int a_Index )
{
	OnRClickItemWithHandle( a_hItemWindow, a_Index );
}

function SetAdenaTooltip(string a_Param)
{
	local INT64 i_Adena;
	local int n_Adena, my_Adena;

	ParseInt64(a_Param, "Adena", i_Adena);

	n_Adena = int(Int64ToString( i_Adena ));

	my_Adena = GetAdena();

	zz_CostToRemove = n_Adena;
	
	m_UnRefineryBtn.SetTooltipCustomType( SetTooltipItem( n_Adena, my_Adena) );
}

function CustomTooltip SetTooltipItem( int itemNum, int myAdena )
{
	local int i;
	local CustomTooltip DetailTooltip;
	local ItemInfo info;
	class'UIDATA_ITEM'.static.GetItemInfo( 57, info );

	i = 0;

	// DetailTooltip.MinimumWidth = 166;
	DetailTooltip.DrawList.length = 1;
	
	DetailTooltip.DrawList[i].eType = DIT_TEXT;
	DetailTooltip.DrawList[i].nOffSetX = 3;
	DetailTooltip.DrawList[i].t_color.R = 255;
	DetailTooltip.DrawList[i].t_color.G = 255;
	DetailTooltip.DrawList[i].t_color.B = 255;
	DetailTooltip.DrawList[i].t_color.A = 255;
	DetailTooltip.DrawList[i].t_strText = GetSystemString( 1683 );

	i++;
	DetailTooltip.DrawList.length = i + 1;
	DetailTooltip.DrawList[i].eType = DIT_TEXTURE;
	DetailTooltip.DrawList[i].bLineBreak = true;
	DetailTooltip.DrawList[i].nOffSetX = 1;
	DetailTooltip.DrawList[i].nOffSetY = 4;
	DetailTooltip.DrawList[i].u_nTextureWidth = 36;
	DetailTooltip.DrawList[i].u_nTextureHeight = 36;
	DetailTooltip.DrawList[i].u_strTexture = "MUI_AUGM.InventoryWnd.ItemWindow_DF_Slotbox_2x2";	

	i++;
	DetailTooltip.DrawList.length = i + 1;
	DetailTooltip.DrawList[i].eType = DIT_TEXTURE;
	DetailTooltip.DrawList[i].nOffSetX = -34;
	DetailTooltip.DrawList[i].nOffSetY = 5;
	DetailTooltip.DrawList[i].u_nTextureWidth = 32;
	DetailTooltip.DrawList[i].u_nTextureHeight = 32;
	DetailTooltip.DrawList[i].u_strTexture = info.IconName;	
	
	i++;
	DetailTooltip.DrawList.length = i + 1;
	DetailTooltip.DrawList[i].eType = DIT_TEXT;
	DetailTooltip.DrawList[i].nOffSetX = 5;
	DetailTooltip.DrawList[i].nOffSetY = 4;
	DetailTooltip.DrawList[i].t_bDrawOneLine = true;
	DetailTooltip.DrawList[i].t_color.R = 255;
	DetailTooltip.DrawList[i].t_color.G = 255;
	DetailTooltip.DrawList[i].t_color.B = 255;
	DetailTooltip.DrawList[i].t_color.A = 255;
	DetailTooltip.DrawList[i].t_strText = info.Name;

	i++;
	DetailTooltip.DrawList.length = i + 1;
	DetailTooltip.DrawList[i].eType = DIT_TEXT;
	DetailTooltip.DrawList[i].nOffSetX = 40;
	DetailTooltip.DrawList[i].nOffSetY = -17;
	DetailTooltip.DrawList[i].bLineBreak = true;
	DetailTooltip.DrawList[i].t_bDrawOneLine = true;
	DetailTooltip.DrawList[i].t_color.R = 255;
	DetailTooltip.DrawList[i].t_color.G = 255;
	DetailTooltip.DrawList[i].t_color.B = 255;
	DetailTooltip.DrawList[i].t_color.A = 255;
	DetailTooltip.DrawList[i].t_strText = "x " $ MakeCostString( string(itemNum) );

	i++;
	DetailTooltip.DrawList.length = i + 1;
	DetailTooltip.DrawList[i].eType = DIT_TEXT;
	DetailTooltip.DrawList[i].nOffSetX = 5;
	DetailTooltip.DrawList[i].nOffSetY = -17;
	DetailTooltip.DrawList[i].t_bDrawOneLine = true;
	if(myAdena > itemNum)
		DetailTooltip.DrawList[i].t_color = getInstanceL2Util().Blue;
	else
	{
		DetailTooltip.DrawList[i].t_color = getInstanceL2Util().Red;
		m_UnRefineryBtn.DisableWindow();
	}
	DetailTooltip.DrawList[i].t_strText = " (" $ MakeCostString( string( myAdena ) ) $ ")";

	return DetailTooltip;

}

defaultproperties
{
}
