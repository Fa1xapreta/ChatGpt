class CCFxXmasCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxXmas_t00 FILE=..\CCFxXmasCloak\Textures\FxXmas_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxXmas_t01 FILE=..\CCFxXmasCloak\Textures\FxXmas_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FDarkElf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FDwarf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FElf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FElf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FElf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FFighter_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FFighter_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FFighter_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FMagic_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FMagic_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FMagic_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FOrc_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FOrc_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FOrc_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FShaman_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\FShaman_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=FShaman_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MDarkElf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MDwarf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MElf_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MElf_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MElf_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MFighter_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MFighter_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MFighter_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MMagic_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MMagic_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MMagic_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MOrc_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MOrc_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MOrc_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MShaman_FxXmas_m_ad00 MODELFILE=..\CCFxXmasCloak\Models\MShaman_FxXmas_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxXmas_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxXmas_m_ad00 NUM=0 TEXTURE=FxXmas_t00
#exec MESH SETTEXTURE MESH=MShaman_FxXmas_m_ad00 NUM=1 TEXTURE=FxXmas_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FFighter_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FDarkElf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FDwarf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FElf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FMagic_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FOrc_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FShaman_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MDarkElf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MDwarf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MElf_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MFighter_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MMagic_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MOrc_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MShaman_DynCover_FxXmas.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxXmas NUM=0 TEXTURE=FxXmas_t01
#exec MESH MODELIMPORT MESH=MFighter_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MMagic_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MElf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FElf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MDarkElf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MDwarf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FDwarf_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MOrc_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FOrc_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=MShaman_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\MShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
#exec MESH MODELIMPORT MESH=FShaman_FestivalCloth_FxXmas MODELFILE=..\CCFxXmasCloak\Models\FShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FestivalCloth_FxXmas X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FestivalCloth_FxXmas NUM=0 TEXTURE=FxXmas_t00
