class CCMFighterPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCMFighter\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCMFighter\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=MFighter_DynCloth MODELFILE=..\CCMFighter\Models\MFighter_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=MFighter_DynCover MODELFILE=..\CCMFighter\Models\MFighter_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover NUM=0 TEXTURE=Dyn_Cover

