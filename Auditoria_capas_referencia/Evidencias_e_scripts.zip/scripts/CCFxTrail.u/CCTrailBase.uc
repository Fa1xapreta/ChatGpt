class CCTrailBase extends Emitter;

// Rastro preso ao osso do personagem. Quando o emissor principal some (troca/remocao da capa) o rastro so se ESCONDE: destruir um TrailEmitter em atividade
// derruba o jogo (GPF em UTrailEmitter::UpdateParticles).
var Actor FxMain;
var bool bFxDone;

event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);
	if (!bFxDone && (FxMain == None || FxMain.bDeleteMe || Owner == None))
	{
		bFxDone = true;
		bHidden = true;
	}
}

