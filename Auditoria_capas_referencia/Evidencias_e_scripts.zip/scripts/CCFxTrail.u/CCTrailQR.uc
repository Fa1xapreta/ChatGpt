//=============================================================================
// CCTrailQR - efeito do Essence (b_anta_cloth_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCTrailQR extends CCTrailBase;

#exec TEXTURE IMPORT NAME=fxwing_wh_00 FILE=..\CCFxTrail\Textures\fxwing_wh_00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

