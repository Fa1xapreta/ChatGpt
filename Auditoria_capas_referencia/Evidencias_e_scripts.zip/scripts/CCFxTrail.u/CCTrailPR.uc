//=============================================================================
// CCTrailPR - efeito do Essence (h_new_clothB_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCTrailPR extends CCTrailBase;

#exec TEXTURE IMPORT NAME=TAILLOOP1_000 FILE=..\CCFxTrail\Textures\TAILLOOP1_000.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

