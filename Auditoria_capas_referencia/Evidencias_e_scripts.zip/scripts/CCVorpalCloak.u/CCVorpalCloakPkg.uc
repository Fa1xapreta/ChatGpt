class CCVorpalCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Vorpal_t00 FILE=..\CCVorpalCloak\Textures\Vorpal_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Vorpal_t01 FILE=..\CCVorpalCloak\Textures\Vorpal_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FDarkElf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FDarkElf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FDwarf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FDwarf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FDwarf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FElf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FElf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FElf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FFighter_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FFighter_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FFighter_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FMagic_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FMagic_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FMagic_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FOrc_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FOrc_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FOrc_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FShaman_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\FShaman_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=FShaman_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MDarkElf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MDarkElf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MDarkElf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MDwarf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MDwarf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MDwarf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MElf_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MElf_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MElf_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MFighter_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MFighter_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MFighter_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MMagic_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MMagic_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MMagic_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MOrc_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MOrc_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MOrc_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MShaman_Vorpal_m_ad00 MODELFILE=..\CCVorpalCloak\Models\MShaman_Vorpal_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_Vorpal_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_Vorpal_m_ad00 NUM=0 TEXTURE=Vorpal_t00
#exec MESH SETTEXTURE MESH=MShaman_Vorpal_m_ad00 NUM=1 TEXTURE=Vorpal_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FFighter_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FDarkElf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FDwarf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FElf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FMagic_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FOrc_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\FShaman_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MDarkElf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MDwarf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MElf_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MFighter_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MMagic_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MOrc_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Vorpal MODELFILE=..\CCVorpalCloak\Models\MShaman_DynCover_Vorpal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Vorpal NUM=0 TEXTURE=Vorpal_t01
