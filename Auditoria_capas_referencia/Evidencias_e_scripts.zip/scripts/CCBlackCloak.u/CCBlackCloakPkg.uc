class CCBlackCloakPkg extends Object;

// ==== BROCHE-AUTO (gerado por add_cover_pkgs.py) ====
#exec TEXTURE IMPORT NAME=Black_br FILE=..\CCBlackCloak\Textures\Black_br.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
// ==== FIM BROCHE-AUTO ====

#exec TEXTURE IMPORT NAME=BlackCloak_t00 FILE=..\CCBlackCloak\Textures\NewMantle00_t00_ori.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=BlackCloak_t01 FILE=..\CCBlackCloak\Textures\BlackCloak_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FDarkElf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FDarkElf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FDwarf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FDwarf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FDwarf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FElf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FElf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FElf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FFighter_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FFighter_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FFighter_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FMagic_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FMagic_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FMagic_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FOrc_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FOrc_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FOrc_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FShaman_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\FShaman_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=FShaman_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MDarkElf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MDarkElf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MDarkElf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MDwarf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MDwarf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MDwarf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MElf_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MElf_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MElf_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MFighter_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MFighter_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MFighter_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MMagic_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MMagic_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MMagic_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MOrc_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MOrc_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MOrc_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=MShaman_BlackCloak_m_ad00 MODELFILE=..\CCBlackCloak\Models\MShaman_BlackCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_BlackCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_BlackCloak_m_ad00 NUM=0 TEXTURE=BlackCloak_t00
#exec MESH SETTEXTURE MESH=MShaman_BlackCloak_m_ad00 NUM=1 TEXTURE=BlackCloak_t01
#exec MESH MODELIMPORT MESH=FFighter_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FFighter_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Black NUM=0 TEXTURE=Black_br

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FDarkElf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FDwarf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=FElf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FElf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FMagic_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FOrc_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Black MODELFILE=..\CCBlackCloak\Models\FShaman_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MDarkElf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MDwarf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MElf_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MElf_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MFighter_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MMagic_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MOrc_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Black NUM=0 TEXTURE=Black_br
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Black MODELFILE=..\CCBlackCloak\Models\MShaman_DynCover_Black.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Black NUM=0 TEXTURE=Black_br
