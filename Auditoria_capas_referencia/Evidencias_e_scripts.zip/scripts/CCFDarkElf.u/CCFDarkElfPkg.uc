class CCFDarkElfPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCFDarkElf\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCFDarkElf\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_DynCloth MODELFILE=..\CCFDarkElf\Models\FDarkElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=FDarkElf_DynCover MODELFILE=..\CCFDarkElf\Models\FDarkElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover NUM=0 TEXTURE=Dyn_Cover

