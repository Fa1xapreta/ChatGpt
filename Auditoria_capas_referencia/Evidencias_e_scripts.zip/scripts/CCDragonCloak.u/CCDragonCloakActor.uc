//=============================================================================
// CCDragonCloakActor - capa Dragon do Essence (malha NewMantle02, esqueleto proprio de 28 ossos + <Raca>_cape_anim).
// COMO O ESSENCE FAZ (medido nos dados e no Engine.dll do Essence): a malha da capa e modelada no ESPACO DO CORPO
// (osso raiz Cape_dummy_00 em (0; -1,86; 33,35), origem da malha = origem do corpo) e desenhada com o MESMO transform do
// personagem; a inclinacao do tronco (correr, sentar...) vem da propria animacao <Raca>_cape_anim, que tem os mesmos nomes
// das animacoes do corpo. Por isso NAO se prende em osso e nao ha deslocamento: o ator copia Location/Rotation/escala do pawn.
// A DLL CapasClassic cria este ator (dono = pawn) quando o pawn veste as capas Dragon 31320-31323.
//=============================================================================
class CCDragonCloakActor extends InventoryAttachment;

var string DragonTag;          // val / ant / fafu / lind (definido nas subclasses)
var bool bInit;
var int InitTries;
var float InitWait;
var name CurAnim;
var MeshAnimation LinkedAnim;
var name DbgBody, DbgCape;   // diagnostico: ultima sequencia do corpo / da capa mostrada no chat
var int DbgLines;
var float DbgTime;

function string RacePrefix()
{
	local string N;

	N = string(Owner.Class.Name);
	if (Right(N, 8) ~= "FDarkElf") return "FDarkElf";
	if (Right(N, 6) ~= "FDwarf")   return "FDwarf";
	if (Right(N, 4) ~= "FElf")     return "FElf";
	if (Right(N, 8) ~= "FFighter") return "FFighter";
	if (Right(N, 6) ~= "FMagic")   return "FMagic";
	if (Right(N, 4) ~= "FOrc")     return "FOrc";
	if (Right(N, 7) ~= "FShaman")  return "FShaman";
	if (Right(N, 8) ~= "MDarkElf") return "MDarkElf";
	if (Right(N, 6) ~= "MDwarf")   return "MDwarf";
	if (Right(N, 4) ~= "MElf")     return "MElf";
	if (Right(N, 8) ~= "MFighter") return "MFighter";
	if (Right(N, 6) ~= "MMagic")   return "MMagic";
	if (Right(N, 4) ~= "MOrc")     return "MOrc";
	if (Right(N, 7) ~= "MShaman")  return "MShaman";
	return "MFighter";
}

// Nome da sequencia da capa por tipo (0 espera, 1 andar, 2 correr, 3 sentado) e raca: literais (este UnrealScript nao converte string em name)
function name AnimFor(int Kind, string Pfx)
{
	if (Pfx ~= "MFighter")
	{
		if (Kind == 0) return 'wait_Hand_MFighter';
		if (Kind == 1) return 'walk_Hand_MFighter';
		if (Kind == 2) return 'run_Hand_MFighter';
		if (Kind == 3) return 'SitWait_MFighter';
	}
	if (Pfx ~= "FFighter")
	{
		if (Kind == 0) return 'wait_Hand_FFighter';
		if (Kind == 1) return 'walk_Hand_FFighter';
		if (Kind == 2) return 'run_Hand_FFighter';
		if (Kind == 3) return 'SitWait_FFighter';
	}
	if (Pfx ~= "MMagic")
	{
		if (Kind == 0) return 'wait_Hand_MMagic';
		if (Kind == 1) return 'walk_Hand_MMagic';
		if (Kind == 2) return 'run_Hand_MMagic';
		if (Kind == 3) return 'SitWait_MMagic';
	}
	if (Pfx ~= "FMagic")
	{
		if (Kind == 0) return 'wait_Hand_FMagic';
		if (Kind == 1) return 'walk_Hand_FMagic';
		if (Kind == 2) return 'run_Hand_FMagic';
		if (Kind == 3) return 'SitWait_FMagic';
	}
	if (Pfx ~= "MElf")
	{
		if (Kind == 0) return 'wait_Hand_MElf';
		if (Kind == 1) return 'walk_Hand_MElf';
		if (Kind == 2) return 'run_Hand_MElf';
		if (Kind == 3) return 'SitWait_MElf';
	}
	if (Pfx ~= "FElf")
	{
		if (Kind == 0) return 'wait_Hand_FElf';
		if (Kind == 1) return 'walk_Hand_FElf';
		if (Kind == 2) return 'run_Hand_FElf';
		if (Kind == 3) return 'SitWait_FElf';
	}
	if (Pfx ~= "MDarkElf")
	{
		if (Kind == 0) return 'wait_Hand_MDarkElf';
		if (Kind == 1) return 'walk_Hand_MDarkElf';
		if (Kind == 2) return 'run_Hand_MDarkElf';
		if (Kind == 3) return 'SitWait_MDarkElf';
	}
	if (Pfx ~= "FDarkElf")
	{
		if (Kind == 0) return 'wait_Hand_FDarkElf';
		if (Kind == 1) return 'walk_Hand_FDarkElf';
		if (Kind == 2) return 'run_Hand_FDarkElf';
		if (Kind == 3) return 'SitWait_FDarkElf';
	}
	if (Pfx ~= "MDwarf")
	{
		if (Kind == 0) return 'wait_Hand_MDwarf';
		if (Kind == 1) return 'walk_Hand_MDwarf';
		if (Kind == 2) return 'run_Hand_MDwarf';
		if (Kind == 3) return 'SitWait_MDwarf';
	}
	if (Pfx ~= "FDwarf")
	{
		if (Kind == 0) return 'wait_Hand_FDwarf';
		if (Kind == 1) return 'walk_Hand_FDwarf';
		if (Kind == 2) return 'run_Hand_FDwarf';
		if (Kind == 3) return 'SitWait_FDwarf';
	}
	if (Pfx ~= "MOrc")
	{
		if (Kind == 0) return 'wait_Hand_MOrc';
		if (Kind == 1) return 'walk_Hand_MOrc';
		if (Kind == 2) return 'run_Hand_MOrc';
		if (Kind == 3) return 'SitWait_MOrc';
	}
	if (Pfx ~= "FOrc")
	{
		if (Kind == 0) return 'wait_Hand_FOrc';
		if (Kind == 1) return 'walk_Hand_FOrc';
		if (Kind == 2) return 'run_Hand_FOrc';
		if (Kind == 3) return 'SitWait_FOrc';
	}
	if (Pfx ~= "MShaman")
	{
		if (Kind == 0) return 'wait_Hand_MShaman';
		if (Kind == 1) return 'walk_Hand_MShaman';
		if (Kind == 2) return 'run_Hand_MShaman';
		if (Kind == 3) return 'SitWait_MShaman';
	}
	if (Pfx ~= "FShaman")
	{
		if (Kind == 0) return 'wait_Hand_FShaman';
		if (Kind == 1) return 'walk_Hand_FShaman';
		if (Kind == 2) return 'run_Hand_FShaman';
		if (Kind == 3) return 'SitWait_FShaman';
	}
	if (Kind == 1) return 'walk_Hand_MFighter';
	if (Kind == 2) return 'run_Hand_MFighter';
	if (Kind == 3) return 'SitWait_MFighter';
	return 'wait_Hand_MFighter';
}

function bool IsSitting(Pawn P)
{
	return (InStr(Caps(string(P.AnimAction)), "SIT") >= 0);
}

// mesmo transform do corpo: posicao, rotacao e escala do pawn (a malha ja vem no espaco do corpo)
function CopyBodyTransform(Pawn P)
{
	SetLocation(P.Location);
	SetRotation(P.Rotation);
	SetDrawScale(P.DrawScale);
	SetDrawScale3D(P.DrawScale3D);
	PrePivot = P.PrePivot;
}

function bool TryInit()
{
	local Pawn P;
	local string Pfx, Path;
	local Mesh M;
	local MeshAnimation A;

	P = Pawn(Owner);
	if (P == None)
		return false;
	Pfx = RacePrefix();
	Path = "RaccoonNewMantles_R." $ Pfx $ "_NewMantle02_" $ DragonTag $ "_m_ad00";
	M = Mesh(DynamicLoadObject(Path, class'Mesh', true));
	if (M == None)
		M = Mesh(DynamicLoadObject(Path, class'SkeletalMesh', true));
	if (M == None)
		return false;
	// as animacoes ficam no pacote RaccoonNewMantles (o RaccoonNewMantles_R so importa delas)
	A = MeshAnimation(DynamicLoadObject("RaccoonNewMantles." $ Pfx $ "_cape_anim", class'MeshAnimation', true));
	if (A == None && Pfx ~= "FDarkElf")
		A = MeshAnimation(DynamicLoadObject("RaccoonNewMantles.FdarkElf_cape_anim", class'MeshAnimation', true));
	if (A == None)
		A = MeshAnimation(DynamicLoadObject("RaccoonNewMantles_R." $ Pfx $ "_cape_anim", class'MeshAnimation', true));
	if (A == None)
		A = MeshAnimation(DynamicLoadObject("RaccoonNewMantles.MFighter_cape_anim", class'MeshAnimation', true));

	bHidden = false;
	bUseLightingFromBase = false;
	SetDrawType(DT_Mesh);
	LinkMesh(M);
	CopyBodyTransform(P);
	if (A != None)
	{
		LinkSkelAnim(A);
		LinkedAnim = A;
	}
	return true;
}

// Diagnostico (temporario): mostra no chat o que o corpo toca e o que a capa recebe, so quando muda (max. 60 linhas).
function DebugLine(Pawn P, name BodySeq, float BodyFrame, float BodyRate, name Cape)
{
	local Color C;
	local string S;

	if (DbgLines >= 60)
		return;
	if (BodySeq == DbgBody && Cape == DbgCape)
		return;
	if (Level.TimeSeconds - DbgTime < 0.25)
		return;
	DbgBody = BodySeq;
	DbgCape = Cape;
	DbgTime = Level.TimeSeconds;
	DbgLines++;
	C.R = 255;
	C.G = 200;
	C.B = 0;
	C.A = 255;
	S = "[Dragon] corpo=" $ string(BodySeq) $ " f=" $ int(BodyFrame) $ " r=" $ BodyRate $ " | capa=" $ string(Cape) $ " anim=" $ string(IsAnimating()) $ " | vel=" $ int(VSize(P.Velocity)) $ " AA=" $ string(P.AnimAction);
	class'NWindow.UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.NormalChat", S, C);
}

// Como o Essence: a capa toca a MESMA sequencia que o corpo esta tocando (as cape_anim tem os mesmos nomes das animacoes do
// corpo: wait/walk/run/Sit/SitWait/Atk/Cast...), com a mesma velocidade. Se o corpo tocar algo que a capa nao tem, cai na
// escolha por estado (parado/andando/correndo/sentado).
function UpdateAnim(Pawn P)
{
	local string Pfx;
	local name T, BodySeq;
	local float Spd, Rate, BodyFrame, BodyRate;

	if (LinkedAnim == None)
		return;
	Pfx = RacePrefix();
	P.GetAnimParams(0, BodySeq, BodyFrame, BodyRate);
	if (BodySeq != 'None' && HasAnim(BodySeq))
	{
		T = BodySeq;
		Rate = BodyRate;
		if (Rate < 0.1)
			Rate = 1.0;
		if (Rate > 3.0)
			Rate = 3.0;
	}
	else
	{
		Spd = VSize(P.Velocity);
		Rate = 1.0;
		if (IsSitting(P))
			T = AnimFor(3, Pfx);
		else if (Spd >= 220.0)
			T = AnimFor(2, Pfx);
		else if (Spd >= 22.0)
		{
			T = AnimFor(1, Pfx);
			Rate = 0.9;
		}
		else
		{
			T = AnimFor(0, Pfx);
			Rate = 0.85;
		}
		if (!HasAnim(T))
			T = AnimFor(0, "MFighter");
		if (!HasAnim(T))
			return;
	}
	if (T != CurAnim || !IsAnimating())
	{
		CurAnim = T;
		LoopAnim(T, Rate, 0.15);
	}
	DebugLine(P, BodySeq, BodyFrame, BodyRate, CurAnim);
}

event Tick(float DeltaTime)
{
	local Pawn P;

	Super.Tick(DeltaTime);
	P = Pawn(Owner);
	if (P == None || P.bDeleteMe)
	{
		Destroy();
		return;
	}
	if (!bInit)
	{
		InitWait += DeltaTime;
		if (InitWait > 0.2 && InitTries < 40)
		{
			InitWait = 0.0;
			InitTries++;
			if (TryInit())
				bInit = true;
		}
		return;
	}
	CopyBodyTransform(P);
	UpdateAnim(P);
}

