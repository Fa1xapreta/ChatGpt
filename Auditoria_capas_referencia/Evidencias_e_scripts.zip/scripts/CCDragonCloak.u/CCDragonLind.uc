class CCDragonLind extends CCDragonCloakActor;

