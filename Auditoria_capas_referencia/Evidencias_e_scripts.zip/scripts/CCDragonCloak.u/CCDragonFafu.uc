class CCDragonFafu extends CCDragonCloakActor;

