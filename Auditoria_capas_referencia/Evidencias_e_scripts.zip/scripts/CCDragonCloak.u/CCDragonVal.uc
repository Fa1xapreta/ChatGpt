class CCDragonVal extends CCDragonCloakActor;

