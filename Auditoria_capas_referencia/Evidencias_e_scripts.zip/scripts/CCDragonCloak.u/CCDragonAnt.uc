class CCDragonAnt extends CCDragonCloakActor;

