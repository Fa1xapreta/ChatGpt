class CCFDwarfPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCFDwarf\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCFDwarf\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDwarf_DynCloth MODELFILE=..\CCFDwarf\Models\FDwarf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=FDwarf_DynCover MODELFILE=..\CCFDwarf\Models\FDwarf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover NUM=0 TEXTURE=Dyn_Cover

