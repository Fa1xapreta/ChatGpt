class CCVesperCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Vesper_t00 FILE=..\CCVesperCloak\Textures\Vesper_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Vesper_t01 FILE=..\CCVesperCloak\Textures\Vesper_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FDarkElf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FDarkElf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FDwarf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FDwarf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FDwarf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FElf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FElf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FElf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FFighter_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FFighter_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FFighter_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FMagic_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FMagic_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FMagic_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FOrc_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FOrc_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FOrc_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FShaman_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\FShaman_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=FShaman_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MDarkElf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MDarkElf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MDarkElf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MDwarf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MDwarf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MDwarf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MElf_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MElf_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MElf_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MFighter_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MFighter_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MFighter_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MMagic_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MMagic_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MMagic_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MOrc_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MOrc_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MOrc_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MShaman_Vesper_m_ad00 MODELFILE=..\CCVesperCloak\Models\MShaman_Vesper_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_Vesper_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_Vesper_m_ad00 NUM=0 TEXTURE=Vesper_t00
#exec MESH SETTEXTURE MESH=MShaman_Vesper_m_ad00 NUM=1 TEXTURE=Vesper_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FFighter_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FDarkElf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FDwarf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FElf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FMagic_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FOrc_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\FShaman_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MDarkElf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MDwarf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MElf_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MFighter_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MMagic_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MOrc_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Vesper MODELFILE=..\CCVesperCloak\Models\MShaman_DynCover_Vesper.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Vesper NUM=0 TEXTURE=Vesper_t01
