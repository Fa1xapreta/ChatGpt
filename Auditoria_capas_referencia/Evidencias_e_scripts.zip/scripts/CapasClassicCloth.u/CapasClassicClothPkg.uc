class CapasClassicClothPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CapasClassicCloth\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_DynCloth MODELFILE=..\CapasClassicCloth\Models\FFighter_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCloth NUM=0 TEXTURE=Dyn_Cloth

