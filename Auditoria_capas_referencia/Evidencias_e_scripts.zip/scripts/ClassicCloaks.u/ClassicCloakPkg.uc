//=============================================================================
// ClassicCloakPkg - Classic/Essence NewMantle01 (coroa dourada) para o CloakMesh nativo da Engine.dll
//=============================================================================
class ClassicCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=NewMantle01_t00 FILE=..\ClassicCloaks\Textures\NewMantle01_t00.tga MIPS=1 LODSET=2 DXT=-1
#exec TEXTURE IMPORT NAME=NewMantle01_t01 FILE=..\ClassicCloaks\Textures\NewMantle01_t01.tga MIPS=1 LODSET=2 DXT=-1

// --- MFighter_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MFighter_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MFighter_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MFighter_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FFighter_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FFighter_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FFighter_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FFighter_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MMagic_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MMagic_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MMagic_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MMagic_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FMagic_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FMagic_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FMagic_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FMagic_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MElf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MElf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MElf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MElf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FElf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FElf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FElf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FElf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MDarkElf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MDarkElf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MDarkElf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MDarkElf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FDarkElf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FDarkElf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FDarkElf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FDarkElf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MOrc_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MOrc_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MOrc_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MOrc_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FOrc_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FOrc_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FOrc_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FOrc_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MShaman_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MShaman_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MShaman_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MShaman_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FShaman_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FShaman_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FShaman_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FShaman_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- MDwarf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=MDwarf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\MDwarf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=MDwarf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

// --- FDwarf_NewMantle01_m_ad00 ---
#exec MESH MODELIMPORT MESH=FDwarf_NewMantle01_m_ad00 MODELFILE=..\ClassicCloaks\Models\FDwarf_NewMantle01_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_NewMantle01_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_NewMantle01_m_ad00 NUM=0 TEXTURE=NewMantle01_t00
#exec MESH SETTEXTURE MESH=FDwarf_NewMantle01_m_ad00 NUM=1 TEXTURE=NewMantle01_t01

