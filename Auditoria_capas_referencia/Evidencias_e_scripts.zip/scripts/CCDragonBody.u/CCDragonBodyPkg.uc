class CCDragonBodyPkg extends Object;

#exec TEXTURE IMPORT NAME=DragonPH FILE=..\CCDragonBody\Textures\DragonPH.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1

#exec MESH MODELIMPORT MESH=FDarkElf_DragonAnt MODELFILE=..\CCDragonBody\Models\FDarkElf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDarkElf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDarkElf_DragonFafu MODELFILE=..\CCDragonBody\Models\FDarkElf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDarkElf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDarkElf_DragonLind MODELFILE=..\CCDragonBody\Models\FDarkElf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDarkElf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDarkElf_DragonVal MODELFILE=..\CCDragonBody\Models\FDarkElf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDarkElf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDarkElf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDwarf_DragonAnt MODELFILE=..\CCDragonBody\Models\FDwarf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDwarf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDwarf_DragonFafu MODELFILE=..\CCDragonBody\Models\FDwarf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDwarf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDwarf_DragonLind MODELFILE=..\CCDragonBody\Models\FDwarf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDwarf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FDwarf_DragonVal MODELFILE=..\CCDragonBody\Models\FDwarf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDwarf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FDwarf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FElf_DragonAnt MODELFILE=..\CCDragonBody\Models\FElf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FElf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FElf_DragonFafu MODELFILE=..\CCDragonBody\Models\FElf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FElf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FElf_DragonLind MODELFILE=..\CCDragonBody\Models\FElf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FElf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FElf_DragonVal MODELFILE=..\CCDragonBody\Models\FElf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FElf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FElf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FFighter_DragonAnt MODELFILE=..\CCDragonBody\Models\FFighter_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FFighter_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FFighter_DragonFafu MODELFILE=..\CCDragonBody\Models\FFighter_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FFighter_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FFighter_DragonLind MODELFILE=..\CCDragonBody\Models\FFighter_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FFighter_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FFighter_DragonVal MODELFILE=..\CCDragonBody\Models\FFighter_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FFighter_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FFighter_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FMagic_DragonAnt MODELFILE=..\CCDragonBody\Models\FMagic_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FMagic_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FMagic_DragonFafu MODELFILE=..\CCDragonBody\Models\FMagic_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FMagic_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FMagic_DragonLind MODELFILE=..\CCDragonBody\Models\FMagic_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FMagic_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FMagic_DragonVal MODELFILE=..\CCDragonBody\Models\FMagic_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FMagic_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FMagic_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FOrc_DragonAnt MODELFILE=..\CCDragonBody\Models\FOrc_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FOrc_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FOrc_DragonFafu MODELFILE=..\CCDragonBody\Models\FOrc_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FOrc_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FOrc_DragonLind MODELFILE=..\CCDragonBody\Models\FOrc_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FOrc_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FOrc_DragonVal MODELFILE=..\CCDragonBody\Models\FOrc_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FOrc_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FOrc_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FShaman_DragonAnt MODELFILE=..\CCDragonBody\Models\FShaman_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FShaman_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FShaman_DragonFafu MODELFILE=..\CCDragonBody\Models\FShaman_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FShaman_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FShaman_DragonLind MODELFILE=..\CCDragonBody\Models\FShaman_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FShaman_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=FShaman_DragonVal MODELFILE=..\CCDragonBody\Models\FShaman_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FShaman_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=FShaman_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDarkElf_DragonAnt MODELFILE=..\CCDragonBody\Models\MDarkElf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDarkElf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDarkElf_DragonFafu MODELFILE=..\CCDragonBody\Models\MDarkElf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDarkElf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDarkElf_DragonLind MODELFILE=..\CCDragonBody\Models\MDarkElf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDarkElf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDarkElf_DragonVal MODELFILE=..\CCDragonBody\Models\MDarkElf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDarkElf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDarkElf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDwarf_DragonAnt MODELFILE=..\CCDragonBody\Models\MDwarf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDwarf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDwarf_DragonFafu MODELFILE=..\CCDragonBody\Models\MDwarf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDwarf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDwarf_DragonLind MODELFILE=..\CCDragonBody\Models\MDwarf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDwarf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MDwarf_DragonVal MODELFILE=..\CCDragonBody\Models\MDwarf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDwarf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MDwarf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MElf_DragonAnt MODELFILE=..\CCDragonBody\Models\MElf_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MElf_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MElf_DragonFafu MODELFILE=..\CCDragonBody\Models\MElf_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MElf_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MElf_DragonLind MODELFILE=..\CCDragonBody\Models\MElf_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MElf_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MElf_DragonVal MODELFILE=..\CCDragonBody\Models\MElf_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MElf_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MElf_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MFighter_DragonAnt MODELFILE=..\CCDragonBody\Models\MFighter_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MFighter_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MFighter_DragonFafu MODELFILE=..\CCDragonBody\Models\MFighter_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MFighter_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MFighter_DragonLind MODELFILE=..\CCDragonBody\Models\MFighter_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MFighter_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MFighter_DragonVal MODELFILE=..\CCDragonBody\Models\MFighter_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MFighter_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MFighter_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MMagic_DragonAnt MODELFILE=..\CCDragonBody\Models\MMagic_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MMagic_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MMagic_DragonFafu MODELFILE=..\CCDragonBody\Models\MMagic_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MMagic_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MMagic_DragonLind MODELFILE=..\CCDragonBody\Models\MMagic_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MMagic_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MMagic_DragonVal MODELFILE=..\CCDragonBody\Models\MMagic_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MMagic_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MMagic_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MOrc_DragonAnt MODELFILE=..\CCDragonBody\Models\MOrc_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MOrc_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MOrc_DragonFafu MODELFILE=..\CCDragonBody\Models\MOrc_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MOrc_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MOrc_DragonLind MODELFILE=..\CCDragonBody\Models\MOrc_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MOrc_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MOrc_DragonVal MODELFILE=..\CCDragonBody\Models\MOrc_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MOrc_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MOrc_DragonVal NUM=2 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MShaman_DragonAnt MODELFILE=..\CCDragonBody\Models\MShaman_DragonAnt.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DragonAnt X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DragonAnt NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MShaman_DragonAnt NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MShaman_DragonFafu MODELFILE=..\CCDragonBody\Models\MShaman_DragonFafu.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DragonFafu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DragonFafu NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MShaman_DragonFafu NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MShaman_DragonLind MODELFILE=..\CCDragonBody\Models\MShaman_DragonLind.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DragonLind X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DragonLind NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MShaman_DragonLind NUM=1 TEXTURE=DragonPH

#exec MESH MODELIMPORT MESH=MShaman_DragonVal MODELFILE=..\CCDragonBody\Models\MShaman_DragonVal.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DragonVal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DragonVal NUM=0 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MShaman_DragonVal NUM=1 TEXTURE=DragonPH
#exec MESH SETTEXTURE MESH=MShaman_DragonVal NUM=2 TEXTURE=DragonPH
