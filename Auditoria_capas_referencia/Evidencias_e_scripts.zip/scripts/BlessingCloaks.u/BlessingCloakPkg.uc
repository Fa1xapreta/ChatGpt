//=============================================================================
// BlessingCloakPkg ï¿½ Sayha NewMantle00 meshes/anims/tex for IL CloakMesh
//=============================================================================
class BlessingCloakPkg extends Object;

// --- Textures ---
#exec TEXTURE IMPORT NAME=NewMantle00_t00 FILE=..\BlessingCloaks\Textures\NewMantle00_t00.tga GROUP=Skins MIPS=1 LODSET=2 DXT=-1
#exec TEXTURE IMPORT NAME=NewMantle00_t01 FILE=..\BlessingCloaks\Textures\NewMantle00_t01.tga GROUP=Skins MIPS=1 LODSET=2 DXT=-1
#exec TEXTURE IMPORT NAME=NewMantle00_red_t00 FILE=..\BlessingCloaks\Textures\NewMantle00_red_t00.tga GROUP=Skins MIPS=1 LODSET=2 DXT=-1

// --- MFighter_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MFighter_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MFighter_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MFighter_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FFighter_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FFighter_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FFighter_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FFighter_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MMagic_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MMagic_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MMagic_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MMagic_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FMagic_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FMagic_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FMagic_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FMagic_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MElf_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MElf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MElf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MElf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FElf_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FElf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FElf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FElf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MDarkElf_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MDarkElf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MDarkElf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MDarkElf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FDarkElf_NewMantle00_m_ad00 ---
// TEMP diagnostic: this mesh is currently the genuine Essence (NCsoft)
// 28-bone cloth-sim rig, unmodified. Testing whether a compiled
// SkeletalMesh needs a DefaultAnim bound (via #exec MESH DEFAULTANIM) for
// this client's engine.dll to actually draw it -- the older BlessingMounts
// cloak attempt did this and BlessingCloaks currently does not.
#exec MESH MODELIMPORT MESH=FDarkElf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FDarkElf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec ANIM IMPORT ANIM=FDarkElf_cape_anim ANIMFILE=..\BlessingMounts\Models\FdarkElf_cape_anim.psa COMPRESS=1
#exec MESH DEFAULTANIM MESH=FDarkElf_NewMantle00_m_ad00 ANIM=FDarkElf_cape_anim
#exec MESH SETTEXTURE MESH=FDarkElf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FDarkElf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MDwarf_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MDwarf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MDwarf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MDwarf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FDwarf_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FDwarf_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FDwarf_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FDwarf_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MOrc_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MOrc_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MOrc_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MOrc_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FOrc_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FOrc_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FOrc_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FOrc_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- MShaman_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=MShaman_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\MShaman_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=MShaman_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

// --- FShaman_NewMantle00_m_ad00 ---
#exec MESH MODELIMPORT MESH=FShaman_NewMantle00_m_ad00 MODELFILE=..\BlessingCloaks\Models\FShaman_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_NewMantle00_m_ad00 NUM=0 TEXTURE=NewMantle00_t00
#exec MESH SETTEXTURE MESH=FShaman_NewMantle00_m_ad00 NUM=1 TEXTURE=NewMantle00_t01

