class CCFxMeshPkg extends Object;

#exec TEXTURE IMPORT NAME=ray_offset FILE=..\CCFxMesh\Textures\ray_offset.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t_3216 FILE=..\CCFxMesh\Textures\fx_m_t_3216.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
