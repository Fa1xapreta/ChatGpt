class CCRedCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Red_br FILE=..\CCRedCloak\Textures\Red_br.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Red MODELFILE=..\CCRedCloak\Models\FDarkElf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Red MODELFILE=..\CCRedCloak\Models\FDwarf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FElf_DynCover_Red MODELFILE=..\CCRedCloak\Models\FElf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FFighter_DynCover_Red MODELFILE=..\CCRedCloak\Models\FFighter_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Red MODELFILE=..\CCRedCloak\Models\FMagic_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Red MODELFILE=..\CCRedCloak\Models\FOrc_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Red MODELFILE=..\CCRedCloak\Models\FShaman_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Red MODELFILE=..\CCRedCloak\Models\MDarkElf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Red MODELFILE=..\CCRedCloak\Models\MDwarf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MElf_DynCover_Red MODELFILE=..\CCRedCloak\Models\MElf_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Red MODELFILE=..\CCRedCloak\Models\MFighter_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Red MODELFILE=..\CCRedCloak\Models\MMagic_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Red MODELFILE=..\CCRedCloak\Models\MOrc_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Red NUM=0 TEXTURE=Red_br
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Red MODELFILE=..\CCRedCloak\Models\MShaman_DynCover_Red.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Red X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Red NUM=0 TEXTURE=Red_br
