class CCFxSiegeBlkCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxSiegeBlk_t00 FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_t01 FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_sp2 FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_sp2.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_wave FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_wave.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_gray FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_gray.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ring FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ring.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1 UCLAMPMODE=CLAMP VCLAMPMODE=CLAMP
#exec TEXTURE IMPORT NAME=FxSiegeBlk_core FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_core.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1 UCLAMPMODE=CLAMP VCLAMPMODE=CLAMP
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringA FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringA.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringB FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringC FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringC.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringD FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringD.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringA FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringA.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringB FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringC FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringC.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringA FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringA.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringB FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringC FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringC.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringA FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringA.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringB FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeBlk_ringC FILE=..\CCFxSiegeBlkCloak\Textures\FxSiegeBlk_ringC.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FDarkElf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FDwarf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FElf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FElf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FElf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FFighter_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FFighter_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FFighter_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FMagic_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FMagic_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FMagic_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FOrc_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FOrc_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FOrc_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FShaman_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\FShaman_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=FShaman_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MDarkElf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MDwarf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MElf_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MElf_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MElf_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MFighter_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MFighter_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MFighter_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MMagic_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MMagic_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MMagic_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MOrc_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MOrc_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MOrc_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MShaman_FxSiegeBlk_m_ad00 MODELFILE=..\CCFxSiegeBlkCloak\Models\MShaman_FxSiegeBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxSiegeBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxSiegeBlk_m_ad00 NUM=0 TEXTURE=FxSiegeBlk_t00
#exec MESH SETTEXTURE MESH=MShaman_FxSiegeBlk_m_ad00 NUM=1 TEXTURE=FxSiegeBlk_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FFighter_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FDarkElf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FDwarf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FElf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FMagic_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FOrc_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\FShaman_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MDarkElf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MDwarf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MElf_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MFighter_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MMagic_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MOrc_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxSiegeBlk MODELFILE=..\CCFxSiegeBlkCloak\Models\MShaman_DynCover_FxSiegeBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxSiegeBlk NUM=0 TEXTURE=FxSiegeBlk_t01
