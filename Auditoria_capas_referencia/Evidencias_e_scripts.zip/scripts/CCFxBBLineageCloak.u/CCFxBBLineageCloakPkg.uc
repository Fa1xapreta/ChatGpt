class CCFxBBLineageCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxBBLineage_t00 FILE=..\CCFxBBLineageCloak\Textures\FxBBLineage_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxBBLineage_t01 FILE=..\CCFxBBLineageCloak\Textures\FxBBLineage_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FDarkElf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FDwarf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FElf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FElf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FElf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FFighter_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FFighter_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FFighter_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FMagic_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FMagic_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FMagic_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FOrc_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FOrc_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FOrc_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=FShaman_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\FShaman_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=FShaman_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MDarkElf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MDwarf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MElf_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MElf_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MElf_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MFighter_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MFighter_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MFighter_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MMagic_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MMagic_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MMagic_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MOrc_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MOrc_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MOrc_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01
#exec MESH MODELIMPORT MESH=MShaman_FxBBLineage_m_ad00 MODELFILE=..\CCFxBBLineageCloak\Models\MShaman_FxBBLineage_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxBBLineage_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxBBLineage_m_ad00 NUM=0 TEXTURE=FxBBLineage_t00
#exec MESH SETTEXTURE MESH=MShaman_FxBBLineage_m_ad00 NUM=1 TEXTURE=FxBBLineage_t01


// ==== BROCHE-AUTO (gerado por add_cover_pkgs.py) ====
#exec TEXTURE IMPORT NAME=FxBBLineage_br FILE=..\CCFxBBLineageCloak\Textures\FxBBLineage_br.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FDarkElf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FDwarf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FElf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FFighter_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FMagic_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FOrc_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\FShaman_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MDarkElf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MDwarf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MElf_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MFighter_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MMagic_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MOrc_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxBBLineage MODELFILE=..\CCFxBBLineageCloak\Models\MShaman_DynCover_FxBBLineage.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxBBLineage NUM=0 TEXTURE=FxBBLineage_br
// ==== FIM BROCHE-AUTO ====
