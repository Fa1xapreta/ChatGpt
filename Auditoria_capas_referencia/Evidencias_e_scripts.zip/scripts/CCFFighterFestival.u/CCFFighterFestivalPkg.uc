class CCFFighterFestivalPkg extends Object;

#exec TEXTURE IMPORT NAME=Festival_Cloth FILE=..\CCFFighterFestival\Textures\Festival_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth NUM=0 TEXTURE=Festival_Cloth

#exec TEXTURE IMPORT NAME=Festival_Cloth_White FILE=..\CCFFighterFestival\Textures\Festival_Cloth_White.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_White MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_White X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_White NUM=0 TEXTURE=Festival_Cloth_White

#exec TEXTURE IMPORT NAME=Festival_Cloth_Black FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Black.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Black MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Black NUM=0 TEXTURE=Festival_Cloth_Black

#exec TEXTURE IMPORT NAME=Festival_Cloth_Draconic FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Draconic.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Draconic MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Draconic NUM=0 TEXTURE=Festival_Cloth_Draconic

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vesper FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Vesper.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Vesper MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Vesper NUM=0 TEXTURE=Festival_Cloth_Vesper

#exec TEXTURE IMPORT NAME=Festival_Cloth_Elegia FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Elegia.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Elegia MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Elegia NUM=0 TEXTURE=Festival_Cloth_Elegia

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vorpal FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Vorpal.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Vorpal MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Vorpal NUM=0 TEXTURE=Festival_Cloth_Vorpal

#exec TEXTURE IMPORT NAME=Festival_Cloth_Moirai FILE=..\CCFFighterFestival\Textures\Festival_Cloth_Moirai.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_Moirai MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_Moirai NUM=0 TEXTURE=Festival_Cloth_Moirai
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxWarr FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxWarr.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxWarr MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxWarr X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxWarr NUM=0 TEXTURE=Festival_Cloth_FxWarr
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeWht FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxSiegeWht.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxSiegeWht MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxSiegeWht NUM=0 TEXTURE=Festival_Cloth_FxSiegeWht
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeBlk FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxSiegeBlk.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxSiegeBlk MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxSiegeBlk NUM=0 TEXTURE=Festival_Cloth_FxSiegeBlk
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRus2024 FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxRus2024.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxRus2024 MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxRus2024 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxRus2024 NUM=0 TEXTURE=Festival_Cloth_FxRus2024
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyS FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxOlyS.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxOlyS MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxOlyS X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxOlyS NUM=0 TEXTURE=Festival_Cloth_FxOlyS
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyG FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxOlyG.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxOlyG MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxOlyG X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxOlyG NUM=0 TEXTURE=Festival_Cloth_FxOlyG
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyB FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxOlyB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxOlyB MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxOlyB X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxOlyB NUM=0 TEXTURE=Festival_Cloth_FxOlyB
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxKnig FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxKnig.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxKnig MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxKnig X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxKnig NUM=0 TEXTURE=Festival_Cloth_FxKnig
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEnch FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxEnch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxEnch MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxEnch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxEnch NUM=0 TEXTURE=Festival_Cloth_FxEnch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxArch FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxArch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxArch MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxArch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxArch NUM=0 TEXTURE=Festival_Cloth_FxArch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdDark FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxSwrdDark.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxSwrdDark MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxSwrdDark X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxSwrdDark NUM=0 TEXTURE=Festival_Cloth_FxSwrdDark
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdBlue FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxSwrdBlue.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxSwrdBlue MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxSwrdBlue X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxSwrdBlue NUM=0 TEXTURE=Festival_Cloth_FxSwrdBlue
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRogu FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxRogu.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxRogu MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxRogu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxRogu NUM=0 TEXTURE=Festival_Cloth_FxRogu
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFrintessa FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxFrintessa.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxFrintessa MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxFrintessa NUM=0 TEXTURE=Festival_Cloth_FxFrintessa
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFreya FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxFreya.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxFreya MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxFreya NUM=0 TEXTURE=Festival_Cloth_FxFreya
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxZaken FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxZaken.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxZaken MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxZaken NUM=0 TEXTURE=Festival_Cloth_FxZaken
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxGTChase FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxGTChase.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxGTChase MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxGTChase X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxGTChase NUM=0 TEXTURE=Festival_Cloth_FxGTChase
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEMGuard FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxEMGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxEMGuard MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxEMGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxEMGuard NUM=0 TEXTURE=Festival_Cloth_FxEMGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxDMStranger FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxDMStranger.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxDMStranger MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxDMStranger NUM=0 TEXTURE=Festival_Cloth_FxDMStranger
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBTGuard FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxBTGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxBTGuard MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxBTGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxBTGuard NUM=0 TEXTURE=Festival_Cloth_FxBTGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBBLineage FILE=..\CCFFighterFestival\Textures\Festival_Cloth_FxBBLineage.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxBBLineage MODELFILE=..\CCFFighterFestival\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxBBLineage NUM=0 TEXTURE=Festival_Cloth_FxBBLineage


#exec MESH MODELIMPORT MESH=FFighter_NewMantle00_m_ad00 MODELFILE=..\CCFFighterFestival\Models\FFighter_NewMantle00_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_NewMantle00_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_NewMantle00_m_ad00 NUM=0 TEXTURE=Festival_Cloth_Black
