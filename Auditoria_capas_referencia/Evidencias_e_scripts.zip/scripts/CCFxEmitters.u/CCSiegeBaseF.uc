//=============================================================================
// CCSiegeBaseF - efeito do Essence (h_worldSiege_clothC_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseF extends Emitter;

#exec TEXTURE IMPORT NAME=fx_m_t0105 FILE=..\CCFxEmitters\Textures\fx_m_t0105.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0127 FILE=..\CCFxEmitters\Textures\fx_m_t0127.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t8228 FILE=..\CCFxEmitters\Textures\fx_m_t8228.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

