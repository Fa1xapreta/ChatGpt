//=============================================================================
// CCSiegeFxA - efeito da capa Siege Black, nivel A do Essence (h_worldSiege +4 ou mais: tudo ligado).
// A DLL CapasClassic cria este ator com Owner = pawn. Aqui ele se prende ao osso do tronco
// (bip01_spine2) no deslocamento do broche, com a rotacao relativa do Essence
// (Pitch 0, Yaw 16383, Roll -16383): a normal do anel (eixo X do emissor) fica sobre o eixo Y do osso,
// que no Essence e horizontal (para tras). Nos esqueletos do Interlude o osso e inclinado, entao o Yaw
// relativo e recalculado medindo o eixo real (2 sondagens) para a normal ficar na horizontal.
//=============================================================================
class CCSiegeFxA extends CCSiegeBaseA;

var bool bFxAttached;
var bool bFxCalibrated;
var int FxCalTries;
var float FxStill;
var int FxTries;
var float FxWait;
var float FxLevelWait;
var int FxState;
var int FxFrames;
var vector FxA, FxB;


function vector FxOffset()
{
	local string N;

	N = string(Owner.Class.Name);
	if (Right(N, 8) == "FDarkElf") return vect(4.71, 6.20, 0.0);
	if (Right(N, 6) == "FDwarf")   return vect(4.87, 4.87, 0.0);
	if (Right(N, 4) == "FElf")     return vect(5.31, 5.70, 0.0);
	if (Right(N, 8) == "FFighter") return vect(5.84, 5.51, 0.0);
	if (Right(N, 6) == "FMagic")   return vect(4.97, 5.32, 0.0);
	if (Right(N, 4) == "FOrc")     return vect(8.36, 7.35, 0.0);
	if (Right(N, 7) == "FShaman")  return vect(6.19, 5.98, 0.0);
	if (Right(N, 8) == "MDarkElf") return vect(6.35, 6.54, 0.0);
	if (Right(N, 6) == "MDwarf")   return vect(8.20, 9.49, 0.0);
	if (Right(N, 4) == "MElf")     return vect(5.73, 6.79, 0.0);
	if (Right(N, 8) == "MFighter") return vect(5.0, 8.5, 0.0);
	if (Right(N, 6) == "MMagic")   return vect(5.52, 5.78, 0.0);
	if (Right(N, 4) == "MOrc")     return vect(10.07, 12.01, 0.0);
	if (Right(N, 7) == "MShaman")  return vect(8.04, 6.65, 0.0);
	return vect(5.5, 6.5, 0.0);
}

// Aplica Yaw relativo (Pitch 0, Roll -16383). A rotacao do ator no mundo so e atualizada pelo motor entre
// quadros (medido: ler `Rotation` logo apos SetRelativeRotation devolve o valor antigo), entao a calibracao e uma
// maquina de estados: cada passo espera alguns quadros antes de ler.
function FxSetYaw(int Yaw)
{
	local rotator R;

	R.Pitch = 0;
	R.Yaw = Yaw;
	R.Roll = -16383;
	SetRelativeRotation(R);
}

// Com X(theta) = cos(theta)*Bx + sin(theta)*By medido em dois angulos (FxA, FxB), resolve os eixos x/y do osso no
// mundo e devolve o theta (em unidades de rotator) em que o eixo X do emissor fica horizontal (componente Z = 0).
function int FxSolveYaw()
{
	local vector Bx, By, V;
	local float th0, th1, c0, s0, c1, s1, det, th;
	local int Y;

	th0 = 16383 * 6.2831853 / 65536.0;
	th1 = (16383 + 4096) * 6.2831853 / 65536.0;
	c0 = Cos(th0);
	s0 = Sin(th0);
	c1 = Cos(th1);
	s1 = Sin(th1);
	det = c0 * s1 - s0 * c1;
	Bx = (FxA * s1 - FxB * s0) / det;
	By = (FxB * c0 - FxA * c1) / det;
	th = Atan(-Bx.Z, By.Z);
	V = Cos(th) * Bx + Sin(th) * By;
	if ((V dot FxA) < 0.0)
		th += 3.1415927;
	Y = int(th * 65536.0 / 6.2831853);
	if (Y < 0)
		Y += 65536;
	return Y;
}

// Mesma conta do Essence (APawn::GetEquipmentScale com flag 0): sqrt(raio*altura da colisao do personagem) / 14,3875,
// onde 14,3875 = sqrt(9*23) e a colisao de referencia (humano MFighter) -> escala 1,0 nele.
// O cliente Interlude devolve a colisao do modelo masculino tambem para as personagens femininas (medido: FFighter = 1,0),
// entao a escala vem de uma tabela por raca/genero com a colisao dos templates do servidor (radius/height e radiusFemale/
// heightFemale de data/xml/classes): escala = sqrt(raio*altura)/14,3875.
function float FxRaceScale()
{
	local string N;

	N = string(Owner.Class.Name);
	if (Right(N, 8) == "FDarkElf") return 0.891;
	if (Right(N, 6) == "FDwarf")   return 0.677;
	if (Right(N, 4) == "FElf")     return 0.913;
	if (Right(N, 8) == "FFighter") return 0.953;
	if (Right(N, 6) == "FMagic")   return 0.841;
	if (Right(N, 4) == "FOrc")     return 0.956;
	if (Right(N, 7) == "FShaman")  return 0.993;
	if (Right(N, 8) == "MDarkElf") return 0.933;
	if (Right(N, 6) == "MDwarf")   return 0.885;
	if (Right(N, 4) == "MElf")     return 0.933;
	if (Right(N, 8) == "MFighter") return 1.0;
	if (Right(N, 6) == "MMagic")   return 0.909;
	if (Right(N, 4) == "MOrc")     return 1.22;
	if (Right(N, 7) == "MShaman")  return 0.964;
	return -1.0;
}

function FxApplySizeScale()
{
	local float Sc;

	Sc = FxRaceScale();
	if (Sc < 0.0)
	{
		Sc = Sqrt(Owner.CollisionRadius * Owner.CollisionHeight) / 14.3875;
		if (Sc < 0.3 || Sc > 3.0)
			Sc = 1.0;
	}
	SetSizeScale(Sc);
}

function FxExtraAttach() {}
function FxExtraSync() {}
function FxExtraDestroy() {}

function FxTryAttach()
{
	if (bFxAttached || Owner == None)
		return;
	if (Owner.AttachToBone(self, 'bip01_spine2'))
	{
		SetRelativeLocation(FxOffset());
		FxApplySizeScale();
		FxSetYaw(16383);
		FxState = 0;
		FxLevelWait = 5.0;
		bFxAttached = true;
		FxExtraAttach();
	}
}

event Destroyed()
{
	FxExtraDestroy();
	Super.Destroyed();
}

event PostBeginPlay()
{
	Super.PostBeginPlay();
	FxTryAttach();
}

event Tick(float DeltaTime)
{
	Super.Tick(DeltaTime);
	FxExtraSync();
	if (Owner == None)
	{
		Destroy();
		return;
	}
	if (!bFxAttached)
	{
		FxWait += DeltaTime;
		if (FxWait > 0.2 && FxTries < 40)
		{
			FxWait = 0.0;
			FxTries++;
			FxTryAttach();
		}
		return;
	}
	// Calibracao UMA SO VEZ (refazer periodicamente girava o anel a cada ciclo e ele piscava/inclinava): so com o
	// personagem parado ha 0,5 s, em etapas: 1 = Yaw0 aplicado (le A); 2 = Yaw1 aplicado (le B e aplica o Yaw final).
	if (bFxCalibrated)
		return;
	if (FxState == 0)
	{
		if (VSize(Owner.Velocity) < 5.0)
			FxStill += DeltaTime;
		else
			FxStill = 0.0;
		if (FxStill > 0.5)
		{
			FxFrames = 0;
			FxSetYaw(16383);
			FxState = 1;
		}
		return;
	}
	if (VSize(Owner.Velocity) > 5.0)
	{
		// o personagem se mexeu no meio da medicao: descarta e volta ao Yaw padrao
		FxSetYaw(16383);
		FxState = 0;
		FxStill = 0.0;
		return;
	}
	FxFrames++;
	if (FxFrames < 4)
		return;
	FxFrames = 0;
	if (FxState == 1)
	{
		FxA = vector(Rotation);
		FxSetYaw(16383 + 4096);
		FxState = 2;
	}
	else
	{
		FxB = vector(Rotation);
		FxState = 0;
		FxStill = 0.0;
		if (VSize(FxA - FxB) > 0.05)
		{
			FxSetYaw(FxSolveYaw());
			bFxCalibrated = true;
		}
		else
		{
			FxSetYaw(16383);
			FxCalTries++;
			if (FxCalTries >= 5)
				bFxCalibrated = true;
		}
	}
}
