//=============================================================================
// CCSiegeBaseC - efeito do Essence (h_worldSiege_clothC_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseC extends Emitter;


