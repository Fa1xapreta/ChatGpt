//=============================================================================
// CCSiegeBaseE - efeito do Essence (d_cloth_deco_a) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseE extends Emitter;

#exec TEXTURE IMPORT NAME=FX_M_T4128 FILE=..\CCFxEmitters\Textures\FX_M_T4128.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0135 FILE=..\CCFxEmitters\Textures\fx_m_t0135.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0137 FILE=..\CCFxEmitters\Textures\fx_m_t0137.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

#exec TEXTURE IMPORT NAME=fx_ray_yz FILE=..\CCFxEmitters\Textures\fx_ray_yz.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_ray_xz FILE=..\CCFxEmitters\Textures\fx_ray_xz.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_ray_xy FILE=..\CCFxEmitters\Textures\fx_ray_xy.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

