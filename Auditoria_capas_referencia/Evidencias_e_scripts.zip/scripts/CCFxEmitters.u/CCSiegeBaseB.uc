//=============================================================================
// CCSiegeBaseB - efeito do Essence (h_worldSiege_clothB_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseB extends Emitter;


