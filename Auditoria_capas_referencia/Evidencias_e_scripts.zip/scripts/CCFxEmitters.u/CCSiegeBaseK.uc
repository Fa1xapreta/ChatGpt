//=============================================================================
// CCSiegeBaseK - efeito do Essence (h_new_clothB_deco) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseK extends Emitter;

#exec TEXTURE IMPORT NAME=FX_M_T_10033 FILE=..\CCFxEmitters\Textures\FX_M_T_10033.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0085 FILE=..\CCFxEmitters\Textures\fx_m_t0085.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0127 FILE=..\CCFxEmitters\Textures\fx_m_t0127.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0137 FILE=..\CCFxEmitters\Textures\fx_m_t0137.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t4029 FILE=..\CCFxEmitters\Textures\fx_m_t4029.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t6078 FILE=..\CCFxEmitters\Textures\fx_m_t6078.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t8228 FILE=..\CCFxEmitters\Textures\fx_m_t8228.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t_9016 FILE=..\CCFxEmitters\Textures\fx_m_t_9016.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t_9112 FILE=..\CCFxEmitters\Textures\fx_m_t_9112.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

