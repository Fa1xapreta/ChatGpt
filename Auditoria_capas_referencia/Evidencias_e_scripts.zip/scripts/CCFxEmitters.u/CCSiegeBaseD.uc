//=============================================================================
// CCSiegeBaseD - efeito do Essence (d_cloth_deco_b) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseD extends Emitter;

#exec TEXTURE IMPORT NAME=fx_m_t0137 FILE=..\CCFxEmitters\Textures\fx_m_t0137.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t2017 FILE=..\CCFxEmitters\Textures\fx_m_t2017.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t5129 FILE=..\CCFxEmitters\Textures\fx_m_t5129.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t7142 FILE=..\CCFxEmitters\Textures\fx_m_t7142.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

#exec TEXTURE IMPORT NAME=fx_m_t7142c FILE=..\CCFxEmitters\Textures\fx_m_t7142c.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

#exec TEXTURE IMPORT NAME=fx_ray_yz FILE=..\CCFxEmitters\Textures\fx_ray_yz.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_ray_xz FILE=..\CCFxEmitters\Textures\fx_ray_xz.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_ray_xy FILE=..\CCFxEmitters\Textures\fx_ray_xy.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t7142c FILE=..\CCFxEmitters\Textures\fx_m_t7142c.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

