class CCFxFrintessaCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxFrintessa_t00 FILE=..\CCFxFrintessaCloak\Textures\FxFrintessa_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxFrintessa_t01 FILE=..\CCFxFrintessaCloak\Textures\FxFrintessa_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FDarkElf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FDwarf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FElf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FElf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FElf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FFighter_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FFighter_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FFighter_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FMagic_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FMagic_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FMagic_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FOrc_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FOrc_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FOrc_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FShaman_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\FShaman_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=FShaman_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MDarkElf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MDwarf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MElf_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MElf_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MElf_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MFighter_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MFighter_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MFighter_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MMagic_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MMagic_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MMagic_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MOrc_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MOrc_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MOrc_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MShaman_FxFrintessa_m_ad00 MODELFILE=..\CCFxFrintessaCloak\Models\MShaman_FxFrintessa_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxFrintessa_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxFrintessa_m_ad00 NUM=0 TEXTURE=FxFrintessa_t00
#exec MESH SETTEXTURE MESH=MShaman_FxFrintessa_m_ad00 NUM=1 TEXTURE=FxFrintessa_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FFighter_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FDarkElf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FDwarf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FElf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FMagic_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FOrc_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\FShaman_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MDarkElf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MDwarf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MElf_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MFighter_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MMagic_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MOrc_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxFrintessa MODELFILE=..\CCFxFrintessaCloak\Models\MShaman_DynCover_FxFrintessa.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxFrintessa NUM=0 TEXTURE=FxFrintessa_t01
