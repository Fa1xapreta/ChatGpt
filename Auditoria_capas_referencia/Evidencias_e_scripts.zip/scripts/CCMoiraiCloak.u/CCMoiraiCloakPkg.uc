class CCMoiraiCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Moirai_t00 FILE=..\CCMoiraiCloak\Textures\Moirai_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Moirai_t01 FILE=..\CCMoiraiCloak\Textures\Moirai_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FDarkElf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FDarkElf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FDwarf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FDwarf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FDwarf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FElf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FElf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FElf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FFighter_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FFighter_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FFighter_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FMagic_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FMagic_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FMagic_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FOrc_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FOrc_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FOrc_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FShaman_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\FShaman_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=FShaman_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MDarkElf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MDarkElf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MDarkElf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MDwarf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MDwarf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MDwarf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MElf_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MElf_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MElf_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MFighter_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MFighter_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MFighter_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MMagic_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MMagic_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MMagic_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MOrc_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MOrc_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MOrc_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MShaman_Moirai_m_ad00 MODELFILE=..\CCMoiraiCloak\Models\MShaman_Moirai_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_Moirai_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_Moirai_m_ad00 NUM=0 TEXTURE=Moirai_t00
#exec MESH SETTEXTURE MESH=MShaman_Moirai_m_ad00 NUM=1 TEXTURE=Moirai_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FFighter_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FDarkElf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FDwarf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FElf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FMagic_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FOrc_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\FShaman_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MDarkElf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MDwarf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MElf_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MFighter_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MMagic_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MOrc_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Moirai MODELFILE=..\CCMoiraiCloak\Models\MShaman_DynCover_Moirai.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Moirai NUM=0 TEXTURE=Moirai_t01
