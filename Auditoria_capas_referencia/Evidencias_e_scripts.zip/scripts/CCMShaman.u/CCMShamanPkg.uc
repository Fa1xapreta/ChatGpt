class CCMShamanPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCMShaman\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCMShaman\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=MShaman_DynCloth MODELFILE=..\CCMShaman\Models\MShaman_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=MShaman_DynCover MODELFILE=..\CCMShaman\Models\MShaman_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover NUM=0 TEXTURE=Dyn_Cover

