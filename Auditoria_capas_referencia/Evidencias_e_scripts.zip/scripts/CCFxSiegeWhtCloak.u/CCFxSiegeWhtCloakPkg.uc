class CCFxSiegeWhtCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxSiegeWht_t00 FILE=..\CCFxSiegeWhtCloak\Textures\FxSiegeWht_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxSiegeWht_t01 FILE=..\CCFxSiegeWhtCloak\Textures\FxSiegeWht_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FDarkElf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FDwarf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FElf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FElf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FElf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FFighter_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FFighter_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FFighter_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FMagic_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FMagic_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FMagic_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FOrc_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FOrc_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FOrc_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FShaman_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\FShaman_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=FShaman_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MDarkElf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MDwarf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MElf_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MElf_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MElf_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MFighter_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MFighter_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MFighter_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MMagic_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MMagic_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MMagic_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MOrc_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MOrc_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MOrc_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MShaman_FxSiegeWht_m_ad00 MODELFILE=..\CCFxSiegeWhtCloak\Models\MShaman_FxSiegeWht_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxSiegeWht_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxSiegeWht_m_ad00 NUM=0 TEXTURE=FxSiegeWht_t00
#exec MESH SETTEXTURE MESH=MShaman_FxSiegeWht_m_ad00 NUM=1 TEXTURE=FxSiegeWht_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FFighter_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FDarkElf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FDwarf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FElf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FMagic_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FOrc_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\FShaman_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MDarkElf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MDwarf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MElf_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MFighter_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MMagic_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MOrc_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxSiegeWht MODELFILE=..\CCFxSiegeWhtCloak\Models\MShaman_DynCover_FxSiegeWht.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxSiegeWht NUM=0 TEXTURE=FxSiegeWht_t01
