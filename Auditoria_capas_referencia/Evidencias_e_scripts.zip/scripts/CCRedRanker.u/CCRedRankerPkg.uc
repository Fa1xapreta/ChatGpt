class CCRedRankerPkg extends Object;

#exec TEXTURE IMPORT NAME=br_JDK_7anni_cloak_red_t00_ori FILE=..\CCRedRanker\Textures\br_JDK_7anni_cloak_red_t00_ori.tga MIPS=1 LODSET=2 DXT=-1

#exec MESH MODELIMPORT MESH=FDarkElf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FDarkElf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FDwarf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FDwarf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FElf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FElf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FFighter_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FFighter_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FMagic_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FMagic_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FOrc_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FOrc_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=FShaman_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\FShaman_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MDarkElf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MDarkElf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MDwarf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MDwarf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MElf_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MElf_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MFighter_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MFighter_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MMagic_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MMagic_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MOrc_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MOrc_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

#exec MESH MODELIMPORT MESH=MShaman_RankerCloak_m_ad00 MODELFILE=..\CCRedRanker\Models\MShaman_RankerCloak_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_RankerCloak_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_RankerCloak_m_ad00 NUM=0 TEXTURE=br_JDK_7anni_cloak_red_t00_ori

