class CCVesperBlkCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=VesperBlk_t00 FILE=..\CCVesperBlkCloak\Textures\VesperBlk_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=VesperBlk_t01 FILE=..\CCVesperBlkCloak\Textures\VesperBlk_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FDarkElf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FDarkElf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FDwarf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FDwarf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FDwarf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FElf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FElf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FElf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FFighter_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FFighter_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FFighter_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FMagic_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FMagic_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FMagic_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FOrc_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FOrc_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FOrc_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FShaman_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\FShaman_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=FShaman_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MDarkElf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MDarkElf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MDarkElf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MDwarf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MDwarf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MDwarf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MElf_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MElf_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MElf_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MFighter_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MFighter_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MFighter_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MMagic_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MMagic_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MMagic_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MOrc_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MOrc_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MOrc_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MShaman_VesperBlk_m_ad00 MODELFILE=..\CCVesperBlkCloak\Models\MShaman_VesperBlk_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_VesperBlk_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_VesperBlk_m_ad00 NUM=0 TEXTURE=VesperBlk_t00
#exec MESH SETTEXTURE MESH=MShaman_VesperBlk_m_ad00 NUM=1 TEXTURE=VesperBlk_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FFighter_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FDarkElf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FDwarf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FElf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FMagic_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FOrc_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FShaman_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MDarkElf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MDwarf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MElf_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MFighter_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MMagic_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MOrc_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MShaman_DynCover_VesperBlk.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_VesperBlk NUM=0 TEXTURE=VesperBlk_t01
#exec MESH MODELIMPORT MESH=MFighter_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MMagic_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MElf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FElf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MDarkElf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MDwarf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FDwarf_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MOrc_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FOrc_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=MShaman_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\MShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
#exec MESH MODELIMPORT MESH=FShaman_FestivalCloth_VesperBlk MODELFILE=..\CCVesperBlkCloak\Models\FShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FestivalCloth_VesperBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FestivalCloth_VesperBlk NUM=0 TEXTURE=VesperBlk_t00
