class CCFMagicFestivalPkg extends Object;

#exec TEXTURE IMPORT NAME=Festival_Cloth FILE=..\CCFMagicFestival\Textures\Festival_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth NUM=0 TEXTURE=Festival_Cloth

#exec TEXTURE IMPORT NAME=Festival_Cloth_White FILE=..\CCFMagicFestival\Textures\Festival_Cloth_White.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_White MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_White X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_White NUM=0 TEXTURE=Festival_Cloth_White

#exec TEXTURE IMPORT NAME=Festival_Cloth_Black FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Black.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Black MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Black NUM=0 TEXTURE=Festival_Cloth_Black

#exec TEXTURE IMPORT NAME=Festival_Cloth_Draconic FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Draconic.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Draconic MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Draconic NUM=0 TEXTURE=Festival_Cloth_Draconic

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vesper FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Vesper.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Vesper MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Vesper NUM=0 TEXTURE=Festival_Cloth_Vesper

#exec TEXTURE IMPORT NAME=Festival_Cloth_Elegia FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Elegia.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Elegia MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Elegia NUM=0 TEXTURE=Festival_Cloth_Elegia

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vorpal FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Vorpal.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Vorpal MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Vorpal NUM=0 TEXTURE=Festival_Cloth_Vorpal

#exec TEXTURE IMPORT NAME=Festival_Cloth_Moirai FILE=..\CCFMagicFestival\Textures\Festival_Cloth_Moirai.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_Moirai MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_Moirai NUM=0 TEXTURE=Festival_Cloth_Moirai
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxWarr FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxWarr.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxWarr MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxWarr X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxWarr NUM=0 TEXTURE=Festival_Cloth_FxWarr
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeWht FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxSiegeWht.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxSiegeWht MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxSiegeWht NUM=0 TEXTURE=Festival_Cloth_FxSiegeWht
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeBlk FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxSiegeBlk.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxSiegeBlk MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxSiegeBlk NUM=0 TEXTURE=Festival_Cloth_FxSiegeBlk
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRus2024 FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxRus2024.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxRus2024 MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxRus2024 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxRus2024 NUM=0 TEXTURE=Festival_Cloth_FxRus2024
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyS FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxOlyS.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxOlyS MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxOlyS X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxOlyS NUM=0 TEXTURE=Festival_Cloth_FxOlyS
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyG FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxOlyG.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxOlyG MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxOlyG X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxOlyG NUM=0 TEXTURE=Festival_Cloth_FxOlyG
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyB FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxOlyB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxOlyB MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxOlyB X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxOlyB NUM=0 TEXTURE=Festival_Cloth_FxOlyB
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxKnig FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxKnig.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxKnig MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxKnig X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxKnig NUM=0 TEXTURE=Festival_Cloth_FxKnig
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEnch FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxEnch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxEnch MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxEnch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxEnch NUM=0 TEXTURE=Festival_Cloth_FxEnch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxArch FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxArch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxArch MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxArch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxArch NUM=0 TEXTURE=Festival_Cloth_FxArch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdDark FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxSwrdDark.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxSwrdDark MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxSwrdDark X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxSwrdDark NUM=0 TEXTURE=Festival_Cloth_FxSwrdDark
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdBlue FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxSwrdBlue.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxSwrdBlue MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxSwrdBlue X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxSwrdBlue NUM=0 TEXTURE=Festival_Cloth_FxSwrdBlue
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRogu FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxRogu.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxRogu MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxRogu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxRogu NUM=0 TEXTURE=Festival_Cloth_FxRogu
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFrintessa FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxFrintessa.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxFrintessa MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxFrintessa NUM=0 TEXTURE=Festival_Cloth_FxFrintessa
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFreya FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxFreya.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxFreya MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxFreya NUM=0 TEXTURE=Festival_Cloth_FxFreya
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxZaken FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxZaken.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxZaken MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxZaken NUM=0 TEXTURE=Festival_Cloth_FxZaken
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxGTChase FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxGTChase.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxGTChase MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxGTChase X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxGTChase NUM=0 TEXTURE=Festival_Cloth_FxGTChase
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEMGuard FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxEMGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxEMGuard MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxEMGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxEMGuard NUM=0 TEXTURE=Festival_Cloth_FxEMGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxDMStranger FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxDMStranger.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxDMStranger MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxDMStranger NUM=0 TEXTURE=Festival_Cloth_FxDMStranger
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBTGuard FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxBTGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxBTGuard MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxBTGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxBTGuard NUM=0 TEXTURE=Festival_Cloth_FxBTGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBBLineage FILE=..\CCFMagicFestival\Textures\Festival_Cloth_FxBBLineage.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxBBLineage MODELFILE=..\CCFMagicFestival\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxBBLineage NUM=0 TEXTURE=Festival_Cloth_FxBBLineage

