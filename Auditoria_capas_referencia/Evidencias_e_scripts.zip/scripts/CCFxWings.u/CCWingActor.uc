//=============================================================================
// CCWingActor - asas da Aden Cloak do Essence como MALHA 3D ANIMADA (vertice -> osso; 70 quadros a 30 fps = ciclo nativo).
// Criada pelo CCSiegeFxF e presa ao mesmo osso do emissor.
//=============================================================================
class CCWingActor extends Actor;

#exec TEXTURE IMPORT NAME=CCWingTex FILE=..\CCFxWings\Textures\CCWingTex.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=CCWing MODELFILE=..\CCFxWings\Models\CCWing.psk LODSTYLE=10
#exec MESH ORIGIN MESH=CCWing X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=CCWing NUM=0 TEXTURE=CCWingTex
#exec ANIM IMPORT ANIM=CCWingAnim ANIMFILE=..\CCFxWings\Models\CCWingAnim.psa
#exec MESH DEFAULTANIM MESH=CCWing ANIM=CCWingAnim

