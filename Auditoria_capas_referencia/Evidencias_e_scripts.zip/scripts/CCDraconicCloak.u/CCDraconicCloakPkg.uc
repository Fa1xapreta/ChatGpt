class CCDraconicCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Draconic_t00 FILE=..\CCDraconicCloak\Textures\Draconic_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Draconic_t01 FILE=..\CCDraconicCloak\Textures\Draconic_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FDarkElf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FDarkElf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FDwarf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FDwarf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FDwarf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FElf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FElf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FElf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FFighter_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FFighter_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FFighter_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FMagic_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FMagic_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FMagic_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FOrc_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FOrc_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FOrc_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FShaman_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\FShaman_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=FShaman_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MDarkElf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MDarkElf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MDarkElf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MDwarf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MDwarf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MDwarf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MElf_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MElf_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MElf_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MFighter_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MFighter_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MFighter_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MMagic_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MMagic_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MMagic_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MOrc_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MOrc_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MOrc_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MShaman_Draconic_m_ad00 MODELFILE=..\CCDraconicCloak\Models\MShaman_Draconic_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_Draconic_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_Draconic_m_ad00 NUM=0 TEXTURE=Draconic_t00
#exec MESH SETTEXTURE MESH=MShaman_Draconic_m_ad00 NUM=1 TEXTURE=Draconic_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FFighter_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FDarkElf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FDwarf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FElf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FMagic_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FOrc_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\FShaman_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MDarkElf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MDwarf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MElf_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MFighter_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MMagic_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MOrc_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Draconic MODELFILE=..\CCDraconicCloak\Models\MShaman_DynCover_Draconic.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Draconic NUM=0 TEXTURE=Draconic_t01
