//=============================================================================
// DynastyCloakPkg - Dynasty Cloak
//=============================================================================
class DynastyCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\DynastyCloak\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\DynastyCloak\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1

// --- MFighter_DynCloth ---
#exec MESH MODELIMPORT MESH=MFighter_DynCloth MODELFILE=..\DynastyCloak\Models\MFighter_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MFighter_DynCover ---
#exec MESH MODELIMPORT MESH=MFighter_DynCover MODELFILE=..\DynastyCloak\Models\MFighter_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FFighter_DynCloth ---
#exec MESH MODELIMPORT MESH=FFighter_DynCloth MODELFILE=..\DynastyCloak\Models\FFighter_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FFighter_DynCover ---
#exec MESH MODELIMPORT MESH=FFighter_DynCover MODELFILE=..\DynastyCloak\Models\FFighter_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover X=0 Y=0 Z=26.5 YAW=192 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MDarkElf_DynCloth ---
#exec MESH MODELIMPORT MESH=MDarkElf_DynCloth MODELFILE=..\DynastyCloak\Models\MDarkElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MDarkElf_DynCover ---
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover MODELFILE=..\DynastyCloak\Models\MDarkElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FDarkElf_DynCloth ---
#exec MESH MODELIMPORT MESH=FDarkElf_DynCloth MODELFILE=..\DynastyCloak\Models\FDarkElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FDarkElf_DynCover ---
#exec MESH MODELIMPORT MESH=FDarkElf_DynCover MODELFILE=..\DynastyCloak\Models\FDarkElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MDwarf_DynCloth ---
#exec MESH MODELIMPORT MESH=MDwarf_DynCloth MODELFILE=..\DynastyCloak\Models\MDwarf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MDwarf_DynCover ---
#exec MESH MODELIMPORT MESH=MDwarf_DynCover MODELFILE=..\DynastyCloak\Models\MDwarf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FDwarf_DynCloth ---
#exec MESH MODELIMPORT MESH=FDwarf_DynCloth MODELFILE=..\DynastyCloak\Models\FDwarf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FDwarf_DynCover ---
#exec MESH MODELIMPORT MESH=FDwarf_DynCover MODELFILE=..\DynastyCloak\Models\FDwarf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MElf_DynCloth ---
#exec MESH MODELIMPORT MESH=MElf_DynCloth MODELFILE=..\DynastyCloak\Models\MElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MElf_DynCover ---
#exec MESH MODELIMPORT MESH=MElf_DynCover MODELFILE=..\DynastyCloak\Models\MElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FElf_DynCloth ---
#exec MESH MODELIMPORT MESH=FElf_DynCloth MODELFILE=..\DynastyCloak\Models\FElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FElf_DynCover ---
#exec MESH MODELIMPORT MESH=FElf_DynCover MODELFILE=..\DynastyCloak\Models\FElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MMagic_DynCloth ---
#exec MESH MODELIMPORT MESH=MMagic_DynCloth MODELFILE=..\DynastyCloak\Models\MMagic_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MMagic_DynCover ---
#exec MESH MODELIMPORT MESH=MMagic_DynCover MODELFILE=..\DynastyCloak\Models\MMagic_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FMagic_DynCloth ---
#exec MESH MODELIMPORT MESH=FMagic_DynCloth MODELFILE=..\DynastyCloak\Models\FMagic_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FMagic_DynCover ---
#exec MESH MODELIMPORT MESH=FMagic_DynCover MODELFILE=..\DynastyCloak\Models\FMagic_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MOrc_DynCloth ---
#exec MESH MODELIMPORT MESH=MOrc_DynCloth MODELFILE=..\DynastyCloak\Models\MOrc_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MOrc_DynCover ---
#exec MESH MODELIMPORT MESH=MOrc_DynCover MODELFILE=..\DynastyCloak\Models\MOrc_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FOrc_DynCloth ---
#exec MESH MODELIMPORT MESH=FOrc_DynCloth MODELFILE=..\DynastyCloak\Models\FOrc_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FOrc_DynCover ---
#exec MESH MODELIMPORT MESH=FOrc_DynCover MODELFILE=..\DynastyCloak\Models\FOrc_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- MShaman_DynCloth ---
#exec MESH MODELIMPORT MESH=MShaman_DynCloth MODELFILE=..\DynastyCloak\Models\MShaman_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- MShaman_DynCover ---
#exec MESH MODELIMPORT MESH=MShaman_DynCover MODELFILE=..\DynastyCloak\Models\MShaman_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover NUM=0 TEXTURE=Dyn_Cover

// --- FShaman_DynCloth ---
#exec MESH MODELIMPORT MESH=FShaman_DynCloth MODELFILE=..\DynastyCloak\Models\FShaman_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCloth NUM=0 TEXTURE=Dyn_Cloth

// --- FShaman_DynCover ---
#exec MESH MODELIMPORT MESH=FShaman_DynCover MODELFILE=..\DynastyCloak\Models\FShaman_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover NUM=0 TEXTURE=Dyn_Cover

