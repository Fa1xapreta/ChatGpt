class CCFxFreyaCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxFreya_t00 FILE=..\CCFxFreyaCloak\Textures\FxFreya_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxFreya_t01 FILE=..\CCFxFreyaCloak\Textures\FxFreya_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FDarkElf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FDwarf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FElf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FElf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FElf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FFighter_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FFighter_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FFighter_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FMagic_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FMagic_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FMagic_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FOrc_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FOrc_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FOrc_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FShaman_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\FShaman_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=FShaman_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MDarkElf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MDwarf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MElf_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MElf_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MElf_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MFighter_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MFighter_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MFighter_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MMagic_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MMagic_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MMagic_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MOrc_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MOrc_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MOrc_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MShaman_FxFreya_m_ad00 MODELFILE=..\CCFxFreyaCloak\Models\MShaman_FxFreya_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxFreya_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxFreya_m_ad00 NUM=0 TEXTURE=FxFreya_t00
#exec MESH SETTEXTURE MESH=MShaman_FxFreya_m_ad00 NUM=1 TEXTURE=FxFreya_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FFighter_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FDarkElf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FDwarf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FElf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FMagic_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FOrc_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\FShaman_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MDarkElf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MDwarf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MElf_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MFighter_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MMagic_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MOrc_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxFreya MODELFILE=..\CCFxFreyaCloak\Models\MShaman_DynCover_FxFreya.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxFreya NUM=0 TEXTURE=FxFreya_t01
