class CCFxDMStrangerCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxDMStranger_t00 FILE=..\CCFxDMStrangerCloak\Textures\FxDMStranger_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxDMStranger_t01 FILE=..\CCFxDMStrangerCloak\Textures\FxDMStranger_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FDarkElf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FDwarf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FElf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FElf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FElf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FFighter_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FFighter_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FFighter_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FMagic_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FMagic_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FMagic_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FOrc_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FOrc_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FOrc_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=FShaman_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\FShaman_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=FShaman_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MDarkElf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MDwarf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MElf_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MElf_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MElf_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MFighter_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MFighter_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MFighter_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MMagic_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MMagic_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MMagic_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MOrc_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MOrc_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MOrc_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01
#exec MESH MODELIMPORT MESH=MShaman_FxDMStranger_m_ad00 MODELFILE=..\CCFxDMStrangerCloak\Models\MShaman_FxDMStranger_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxDMStranger_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxDMStranger_m_ad00 NUM=0 TEXTURE=FxDMStranger_t00
#exec MESH SETTEXTURE MESH=MShaman_FxDMStranger_m_ad00 NUM=1 TEXTURE=FxDMStranger_t01


// ==== BROCHE-AUTO (gerado por add_cover_pkgs.py) ====
#exec TEXTURE IMPORT NAME=FxDMStranger_br FILE=..\CCFxDMStrangerCloak\Textures\FxDMStranger_br.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FDarkElf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FDwarf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FElf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FFighter_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FMagic_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FOrc_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\FShaman_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MDarkElf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MDwarf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MElf_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MFighter_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MMagic_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MOrc_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxDMStranger MODELFILE=..\CCFxDMStrangerCloak\Models\MShaman_DynCover_FxDMStranger.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxDMStranger NUM=0 TEXTURE=FxDMStranger_br
// ==== FIM BROCHE-AUTO ====
