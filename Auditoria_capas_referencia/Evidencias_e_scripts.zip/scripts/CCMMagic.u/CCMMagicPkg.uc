class CCMMagicPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCMMagic\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCMMagic\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=MMagic_DynCloth MODELFILE=..\CCMMagic\Models\MMagic_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=MMagic_DynCover MODELFILE=..\CCMMagic\Models\MMagic_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover NUM=0 TEXTURE=Dyn_Cover

