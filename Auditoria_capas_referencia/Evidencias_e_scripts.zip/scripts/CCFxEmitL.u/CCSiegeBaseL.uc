//=============================================================================
// CCSiegeBaseL - efeito do Essence (d_cloth_deco_e) convertido dos dados originais (LineageEffect*.u).
//=============================================================================
class CCSiegeBaseL extends Emitter;

#exec TEXTURE IMPORT NAME=fx_m_t0105 FILE=..\CCFxEmitL\Textures\fx_m_t0105.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0135 FILE=..\CCFxEmitL\Textures\fx_m_t0135.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t0137 FILE=..\CCFxEmitL\Textures\fx_m_t0137.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t4029 FILE=..\CCFxEmitL\Textures\fx_m_t4029.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t_9112 FILE=..\CCFxEmitL\Textures\fx_m_t_9112.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1
#exec TEXTURE IMPORT NAME=fx_m_t6078 FILE=..\CCFxEmitL\Textures\fx_m_t6078.tga MIPS=1 LODSET=2 DXT=-1 MASKED=0 ALPHA=1

