class CCFShamanPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCFShaman\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCFShaman\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FShaman_DynCloth MODELFILE=..\CCFShaman\Models\FShaman_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=FShaman_DynCover MODELFILE=..\CCFShaman\Models\FShaman_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover NUM=0 TEXTURE=Dyn_Cover

