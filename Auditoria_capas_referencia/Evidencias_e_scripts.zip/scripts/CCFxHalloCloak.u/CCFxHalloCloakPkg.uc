class CCFxHalloCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxHallo_t00 FILE=..\CCFxHalloCloak\Textures\FxHallo_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxHallo_t01 FILE=..\CCFxHalloCloak\Textures\FxHallo_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FDarkElf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FDwarf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FElf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FElf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FElf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FFighter_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FFighter_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FFighter_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FMagic_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FMagic_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FMagic_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FOrc_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FOrc_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FOrc_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FShaman_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\FShaman_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=FShaman_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MDarkElf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MDwarf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MElf_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MElf_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MElf_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MFighter_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MFighter_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MFighter_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MMagic_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MMagic_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MMagic_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MOrc_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MOrc_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MOrc_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MShaman_FxHallo_m_ad00 MODELFILE=..\CCFxHalloCloak\Models\MShaman_FxHallo_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxHallo_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxHallo_m_ad00 NUM=0 TEXTURE=FxHallo_t00
#exec MESH SETTEXTURE MESH=MShaman_FxHallo_m_ad00 NUM=1 TEXTURE=FxHallo_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FFighter_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FDarkElf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FDwarf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FElf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FMagic_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FOrc_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FShaman_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MDarkElf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MDwarf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MElf_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MFighter_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MMagic_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MOrc_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MShaman_DynCover_FxHallo.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxHallo NUM=0 TEXTURE=FxHallo_t01
#exec MESH MODELIMPORT MESH=MFighter_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FFighter_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FFighter_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MMagic_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FMagic_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FMagic_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MElf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FElf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MDarkElf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MDwarf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FDwarf_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FDwarf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MOrc_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FOrc_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FOrc_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=MShaman_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\MShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
#exec MESH MODELIMPORT MESH=FShaman_FestivalCloth_FxHallo MODELFILE=..\CCFxHalloCloak\Models\FShaman_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FestivalCloth_FxHallo X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FestivalCloth_FxHallo NUM=0 TEXTURE=FxHallo_t00
