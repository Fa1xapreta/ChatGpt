class CCMDwarfPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCMDwarf\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCMDwarf\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=MDwarf_DynCloth MODELFILE=..\CCMDwarf\Models\MDwarf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=MDwarf_DynCover MODELFILE=..\CCMDwarf\Models\MDwarf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover NUM=0 TEXTURE=Dyn_Cover

