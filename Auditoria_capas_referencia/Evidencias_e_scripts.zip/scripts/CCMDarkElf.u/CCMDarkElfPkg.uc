class CCMDarkElfPkg extends Object;

#exec TEXTURE IMPORT NAME=Dyn_Cloth FILE=..\CCMDarkElf\Textures\Dyn_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Dyn_Cover FILE=..\CCMDarkElf\Textures\Dyn_Cover.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=MDarkElf_DynCloth MODELFILE=..\CCMDarkElf\Models\MDarkElf_DynCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCloth NUM=0 TEXTURE=Dyn_Cloth
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover MODELFILE=..\CCMDarkElf\Models\MDarkElf_DynCover.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover NUM=0 TEXTURE=Dyn_Cover

