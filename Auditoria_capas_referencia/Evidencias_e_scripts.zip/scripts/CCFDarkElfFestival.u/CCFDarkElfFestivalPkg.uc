class CCFDarkElfFestivalPkg extends Object;

#exec TEXTURE IMPORT NAME=Festival_Cloth FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth NUM=0 TEXTURE=Festival_Cloth

#exec TEXTURE IMPORT NAME=Festival_Cloth_White FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_White.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_White MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_White X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_White NUM=0 TEXTURE=Festival_Cloth_White

#exec TEXTURE IMPORT NAME=Festival_Cloth_Black FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Black.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Black MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Black X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Black NUM=0 TEXTURE=Festival_Cloth_Black

#exec TEXTURE IMPORT NAME=Festival_Cloth_Draconic FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Draconic.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Draconic MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Draconic X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Draconic NUM=0 TEXTURE=Festival_Cloth_Draconic

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vesper FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Vesper.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Vesper MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Vesper X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Vesper NUM=0 TEXTURE=Festival_Cloth_Vesper

#exec TEXTURE IMPORT NAME=Festival_Cloth_Elegia FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Elegia.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Elegia MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Elegia NUM=0 TEXTURE=Festival_Cloth_Elegia

#exec TEXTURE IMPORT NAME=Festival_Cloth_Vorpal FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Vorpal.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Vorpal MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Vorpal X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Vorpal NUM=0 TEXTURE=Festival_Cloth_Vorpal

#exec TEXTURE IMPORT NAME=Festival_Cloth_Moirai FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_Moirai.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_Moirai MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_Moirai X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_Moirai NUM=0 TEXTURE=Festival_Cloth_Moirai
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxWarr FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxWarr.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxWarr MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxWarr X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxWarr NUM=0 TEXTURE=Festival_Cloth_FxWarr
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeWht FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxSiegeWht.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxSiegeWht MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxSiegeWht X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxSiegeWht NUM=0 TEXTURE=Festival_Cloth_FxSiegeWht
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSiegeBlk FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxSiegeBlk.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxSiegeBlk MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxSiegeBlk X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxSiegeBlk NUM=0 TEXTURE=Festival_Cloth_FxSiegeBlk
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRus2024 FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxRus2024.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxRus2024 MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxRus2024 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxRus2024 NUM=0 TEXTURE=Festival_Cloth_FxRus2024
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyS FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxOlyS.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxOlyS MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxOlyS X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxOlyS NUM=0 TEXTURE=Festival_Cloth_FxOlyS
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyG FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxOlyG.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxOlyG MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxOlyG X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxOlyG NUM=0 TEXTURE=Festival_Cloth_FxOlyG
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxOlyB FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxOlyB.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxOlyB MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxOlyB X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxOlyB NUM=0 TEXTURE=Festival_Cloth_FxOlyB
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxKnig FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxKnig.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxKnig MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxKnig X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxKnig NUM=0 TEXTURE=Festival_Cloth_FxKnig
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEnch FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxEnch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxEnch MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxEnch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxEnch NUM=0 TEXTURE=Festival_Cloth_FxEnch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxArch FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxArch.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxArch MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxArch X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxArch NUM=0 TEXTURE=Festival_Cloth_FxArch
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdDark FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxSwrdDark.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxSwrdDark MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxSwrdDark X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxSwrdDark NUM=0 TEXTURE=Festival_Cloth_FxSwrdDark
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxSwrdBlue FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxSwrdBlue.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxSwrdBlue MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxSwrdBlue X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxSwrdBlue NUM=0 TEXTURE=Festival_Cloth_FxSwrdBlue
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxRogu FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxRogu.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxRogu MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxRogu X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxRogu NUM=0 TEXTURE=Festival_Cloth_FxRogu
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFrintessa FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxFrintessa.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxFrintessa MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxFrintessa X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxFrintessa NUM=0 TEXTURE=Festival_Cloth_FxFrintessa
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxFreya FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxFreya.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxFreya MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxFreya X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxFreya NUM=0 TEXTURE=Festival_Cloth_FxFreya
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxZaken FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxZaken.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxZaken MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxZaken NUM=0 TEXTURE=Festival_Cloth_FxZaken
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxGTChase FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxGTChase.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxGTChase MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxGTChase X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxGTChase NUM=0 TEXTURE=Festival_Cloth_FxGTChase
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxEMGuard FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxEMGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxEMGuard MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxEMGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxEMGuard NUM=0 TEXTURE=Festival_Cloth_FxEMGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxDMStranger FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxDMStranger.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxDMStranger MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxDMStranger X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxDMStranger NUM=0 TEXTURE=Festival_Cloth_FxDMStranger
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBTGuard FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxBTGuard.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxBTGuard MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxBTGuard X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxBTGuard NUM=0 TEXTURE=Festival_Cloth_FxBTGuard
#exec TEXTURE IMPORT NAME=Festival_Cloth_FxBBLineage FILE=..\CCFDarkElfFestival\Textures\Festival_Cloth_FxBBLineage.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FestivalCloth_FxBBLineage MODELFILE=..\CCFDarkElfFestival\Models\FDarkElf_FestivalCloth.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FestivalCloth_FxBBLineage X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FestivalCloth_FxBBLineage NUM=0 TEXTURE=Festival_Cloth_FxBBLineage

