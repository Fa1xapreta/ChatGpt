class CCFxZakenCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=FxZaken_t00 FILE=..\CCFxZakenCloak\Textures\FxZaken_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=FxZaken_t01 FILE=..\CCFxZakenCloak\Textures\FxZaken_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FDarkElf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FDarkElf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FDwarf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FDwarf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FDwarf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FElf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FElf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FElf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FFighter_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FFighter_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FFighter_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FMagic_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FMagic_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FMagic_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FOrc_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FOrc_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FOrc_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FShaman_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\FShaman_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=FShaman_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MDarkElf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MDarkElf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MDarkElf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MDwarf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MDwarf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MDwarf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MElf_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MElf_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MElf_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MFighter_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MFighter_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MFighter_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MMagic_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MMagic_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MMagic_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MOrc_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MOrc_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MOrc_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MShaman_FxZaken_m_ad00 MODELFILE=..\CCFxZakenCloak\Models\MShaman_FxZaken_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_FxZaken_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_FxZaken_m_ad00 NUM=0 TEXTURE=FxZaken_t00
#exec MESH SETTEXTURE MESH=MShaman_FxZaken_m_ad00 NUM=1 TEXTURE=FxZaken_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FFighter_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FDarkElf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FDwarf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FElf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FMagic_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FOrc_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\FShaman_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MDarkElf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MDwarf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MElf_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MFighter_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MMagic_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MOrc_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_FxZaken MODELFILE=..\CCFxZakenCloak\Models\MShaman_DynCover_FxZaken.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_FxZaken X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_FxZaken NUM=0 TEXTURE=FxZaken_t01
