class CCElegiaCloakPkg extends Object;

#exec TEXTURE IMPORT NAME=Elegia_t00 FILE=..\CCElegiaCloak\Textures\Elegia_t00.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec TEXTURE IMPORT NAME=Elegia_t01 FILE=..\CCElegiaCloak\Textures\Elegia_t01.tga MIPS=1 LODSET=2 DXT=-1 MASKED=1 ALPHA=1
#exec MESH MODELIMPORT MESH=FDarkElf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FDarkElf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FDarkElf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FDwarf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FDwarf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FDwarf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FElf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FElf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FElf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FFighter_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FFighter_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FFighter_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FMagic_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FMagic_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FMagic_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FOrc_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FOrc_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FOrc_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FShaman_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\FShaman_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=FShaman_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MDarkElf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MDarkElf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MDarkElf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MDwarf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MDwarf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MDwarf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MElf_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MElf_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MElf_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MFighter_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MFighter_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MFighter_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MMagic_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MMagic_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MMagic_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MOrc_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MOrc_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MOrc_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MShaman_Elegia_m_ad00 MODELFILE=..\CCElegiaCloak\Models\MShaman_Elegia_m_ad00.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_Elegia_m_ad00 X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_Elegia_m_ad00 NUM=0 TEXTURE=Elegia_t00
#exec MESH SETTEXTURE MESH=MShaman_Elegia_m_ad00 NUM=1 TEXTURE=Elegia_t01

#exec MESH MODELIMPORT MESH=FFighter_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FFighter_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FFighter_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FFighter_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01

#exec MESH MODELIMPORT MESH=FDarkElf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FDarkElf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDarkElf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDarkElf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FDwarf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FDwarf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FDwarf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FDwarf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FElf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FElf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FElf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FElf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FMagic_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FMagic_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FMagic_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FMagic_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FOrc_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FOrc_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FOrc_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FOrc_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=FShaman_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\FShaman_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=FShaman_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=FShaman_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MDarkElf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MDarkElf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDarkElf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDarkElf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MDwarf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MDwarf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MDwarf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MDwarf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MElf_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MElf_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MElf_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MElf_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MFighter_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MFighter_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MFighter_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MFighter_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MMagic_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MMagic_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MMagic_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MMagic_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MOrc_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MOrc_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MOrc_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MOrc_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
#exec MESH MODELIMPORT MESH=MShaman_DynCover_Elegia MODELFILE=..\CCElegiaCloak\Models\MShaman_DynCover_Elegia.psk LODSTYLE=10
#exec MESH ORIGIN MESH=MShaman_DynCover_Elegia X=0 Y=0 Z=0 YAW=0 PITCH=0 ROLL=0
#exec MESH SETTEXTURE MESH=MShaman_DynCover_Elegia NUM=0 TEXTURE=Elegia_t01
