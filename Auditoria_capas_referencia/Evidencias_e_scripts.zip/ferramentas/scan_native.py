from pathlib import Path
import json,re,collections
root=Path(__file__).resolve().parent;src=root/'extracted/system'
keywords=re.compile(r'(?i)(capas|cloak|lucdev|cloth|ccfx|cctx|ccwg|h5_|spine|bip01|anchor|ancora|attach|skelet|pano_|fx_|mount_|strider|diag_)')
rows=[]
for p in sorted(src.iterdir()):
 with p.open('rb') as f:magic=f.read(2)
 if magic!=b'MZ':continue
 b=p.read_bytes();found=[]
 for encoding,pattern in [('ascii',rb'[\x20-\x7e]{5,2048}'),('utf16le',rb'(?:[\x20-\x7e]\x00){5,2048}')]:
  for m in re.finditer(pattern,b):
   s=m.group().decode('ascii' if encoding=='ascii' else 'utf-16le',errors='replace')
   if keywords.search(s):found.append({'offset':m.start(),'encoding':encoding,'text':s})
 rows.append({'file':p.name,'matches':found})
 (root/'reports/native').mkdir(exist_ok=True)
 (root/'reports/native'/f'{p.name}.json').write_text(json.dumps(found,indent=2))
 if p.name in ['CapasClassic.dll','dsetup.dll','d3d9.dll','engine.dll','nwindow.dll','entry.dll']:
  print('\n'+p.name,len(found),'matches')
  for d in found[:100]:print(hex(d['offset']),d['text'])
(root/'reports/native-string-summary.json').write_text(json.dumps([{'file':d['file'],'matches':len(d['matches'])} for d in rows],indent=2))
