from pathlib import Path
import json,struct,zlib,collections
from PIL import Image
from catalog_unreal import Reader
ROOT=Path(__file__).resolve().parent

def ci(b,p):
 n=b[p];p+=1;v=n&63;neg=n&128;more=n&64;shift=6
 while more:
  n=b[p];p+=1;v|=(n&127)<<shift;more=n&128;shift+=7
  if shift>40:raise ValueError('compact integer overflow')
 return -v if neg else v,p

def props(b,names):
 p=0;out={}
 for _ in range(200):
  n,p=ci(b,p);name=names[n]
  if name=='None':return p,out
  info=b[p];p+=1;typ=info&15;sizes=[1,2,4,12,16];code=(info>>4)&7
  if typ==10:_,p=ci(b,p)
  if code<5:size=sizes[code]
  elif code==5:size=b[p];p+=1
  elif code==6:size=struct.unpack_from('<H',b,p)[0];p+=2
  else:size=struct.unpack_from('<I',b,p)[0];p+=4
  if info&128 and typ!=3:_,p=ci(b,p)
  assert size<1000000 and p+size<=len(b)
  out[name]=b[p:p+size].hex();p+=size
 raise ValueError('property loop')

def mipmaps(b,end,absolute):
 for begin in range(end,min(end+1400,len(b)-16)):
  try:
   n,p=ci(b,begin)
   if not 1<=n<=16:continue
   result=[]
   for _ in range(n):
    pointer=struct.unpack_from('<I',b,p)[0];p+=4;size,p=ci(b,p)
    if not 0<size<=len(b)-p-10:raise ValueError()
    raw=b[p:p+size];p+=size
    if pointer!=absolute+p:raise ValueError('lazy-array end mismatch')
    w,h,ub,vb=struct.unpack_from('<IIBB',b,p);p+=10
    if not 1<=w<=4096 or not 1<=h<=4096 or (1<<ub)!=w or (1<<vb)!=h:raise ValueError('size')
    result.append((w,h,raw))
   if p==len(b):return result,begin
  except (ValueError,IndexError,struct.error):pass
 raise ValueError('native mip layout not identified')

def image_for(fmt,w,h,raw):
 if fmt==5:
  assert len(raw)==w*h*4
  return Image.frombytes('RGBA',(w,h),raw,'raw','BGRA')
 if fmt in [3,7,8]:
  # Pillow's BCN decoder reads the same DXT blocks; no pixel redesign.
  import io
  fourcc={3:b'DXT1',7:b'DXT3',8:b'DXT5'}[fmt]
  header=struct.pack('<7I',124,0x81007,h,w,len(raw),0,1)+bytes(44)+struct.pack('<II4s5I',32,4,fourcc,0,0,0,0,0)+struct.pack('<5I',0x1000,0,0,0,0)
  assert len(header)==124
  return Image.open(io.BytesIO(b'DDS '+header+raw)).convert('RGBA')
 raise ValueError('format '+str(fmt))

if __name__=='__main__':
 dst=ROOT/'organized/03_texturas_extraidas';dst.mkdir(parents=True,exist_ok=True);rows=[]
 for p in sorted((ROOT/'reports/packages').glob('*.u.json')):
  d=json.loads(p.read_text());name=d['file']
  if not(name.startswith(('CC','CapasClassic')) or name in ['ClassicCloaks.u','BlessingCloaks.u','DynastyCloak.u']):continue
  r=Reader(ROOT/'extracted/system'/name)
  for e in d['exports']:
   if e['class']!='Engine.Texture':continue
   row={'package':name,'object':e['path'],'offset':e['offset']}
   try:
    b=r.read(e['offset'],e['size']);end,pr=props(b,d['names']);fmt=int.from_bytes(bytes.fromhex(pr.get('Format','00')),'little');mips,begin=mipmaps(b,end,e['offset']);w,h,raw=mips[0]
    im=image_for(fmt,w,h,raw);folder=dst/name;folder.mkdir(exist_ok=True);q=folder/(e['path']+'.png');im.save(q)
    row.update(status='exported',format=fmt,width=w,height=h,mips=len(mips),file=str(q.relative_to(ROOT)),native_mip_offset=begin)
   except Exception as ex:row.update(status='not_exported',error=str(ex))
   rows.append(row)
  r.close()
 (ROOT/'reports/texture-export.json').write_text(json.dumps(rows,indent=2))
 print('Textures:',collections.Counter(d['status'] for d in rows))
 for d in rows[:5]:print(d)
 for d in [d for d in rows if d['status']!='exported'][:8]:print('ERROR',d)
