from pathlib import Path
import json
from catalog_unreal import Reader
ROOT=Path(__file__).resolve().parent
out=ROOT/'reports/scripts';out.mkdir(exist_ok=True)
summary=[]
for p in sorted((ROOT/'reports/packages').glob('*.u.json')):
 d=json.loads(p.read_text());rows=[e for e in d['exports'] if e['class']=='Core.TextBuffer']
 if not rows:continue
 r=Reader(ROOT/'extracted/system'/d['file'])
 for e in rows:
  try:
   pos=e['offset'];prop,pos=r.ci(pos);assert d['names'][prop]=='None';pos+=8;n,pos=r.ci(pos)
   assert abs(n)<5000000 and pos-e['offset']+abs(n)*(2 if n<0 else 1)<=e['size']
   s=r.read(pos,abs(n)*(2 if n<0 else 1)).decode('utf-16le' if n<0 else 'latin1').rstrip('\0')
   dest=out/d['file']/((e['path'].replace('.ScriptText',''))+'.uc');dest.parent.mkdir(exist_ok=True);dest.write_text(s,encoding='utf-8')
   owner=e['outer'];methods=[f['name'] for f in d['exports'] if f['outer']==owner and f['class']=='Core.Function']
   summary.append({'package':d['file'],'path':e['path'],'file':str(dest.relative_to(ROOT)),'chars':len(s),'compiled_methods':methods})
  except Exception as ex:summary.append({'package':d['file'],'path':e['path'],'error':str(ex)})
 r.close()
(ROOT/'reports/scripts-summary.json').write_text(json.dumps(summary,indent=2))
print('ScriptText buffers extracted',sum('file'in r for r in summary),'errors',sum('error'in r for r in summary))
for row in json.loads((ROOT/'reports/package-summary.json').read_text()):
 if row['status']!='parsed':print(row['file'],row.get('reason'))
