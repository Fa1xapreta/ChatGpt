from pathlib import Path
import struct,json,re
ROOT=Path(__file__).resolve().parent;b=(ROOT/'decoded/armorgrp.dat').read_bytes()
items=json.loads((ROOT/'reports/cloak-itemnames.json').read_text());items=[r for r in items if r['id']>=31300 and ('cloak' in r['name'].lower() or 'capa' in r['name'].lower())]
rows=[]
for item in items:
 id=item['id'];start=b.find(struct.pack('<II',1,id))
 if start<0:continue
 p=start
 def u32():
  global p
  n=struct.unpack_from('<I',b,p)[0];p+=4;return n
 def text():
  global p
  n=u32();assert n<20000 and n%2==0,(id,p,n)
  s=b[p:p+n].decode('utf-16le').rstrip('\0');p+=n;return s
 d={'id':id,'name':item['name'],'add_name':item['add_name'],'offset':start}
 for key in ['tag','armor_id','drop_type','drop_anim_type','drop_radius','drop_height','UNK_0']:d[key]=u32()
 for key in ['drop_mesh1','drop_mesh2','drop_mesh3','drop_tex1','drop_tex2','drop_tex3']:d[key]=text()
 d['icons']=[text() for _ in range(5)]
 for key in ['durability','weight','material','crystallizable','UNK_1','body_part']:d[key]=u32()
 d['mesh_section_offset']=p
 rows.append(d)
rows.sort(key=lambda r:r['offset'])
for i,d in enumerate(rows):
 end=rows[i+1]['offset'] if i+1<len(rows) else len(b)-13
 raw=b[d['mesh_section_offset']:end]
 # These are reference strings, not a claimed complete parse of the MTX layout.
 refs=[]
 for m in re.finditer(rb'(?:[A-Za-z0-9_.\\/-]\x00){5,}',raw):
  s=m.group().decode('utf-16le')
  if '.' in s and s not in refs:refs.append(s)
 d['mtx_reference_strings']=refs
(ROOT/'reports/cloak-armor-records.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('Parsed exact armor headers for',len(rows),'cloak items')
for d in rows:
 if d['id']>=31300:print(d['id'],d['name'],'body_part',d['body_part'],'icons',d['icons'][:1],'refs',d['mtx_reference_strings'][:4])
