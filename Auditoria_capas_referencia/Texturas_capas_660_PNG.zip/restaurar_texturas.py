from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).resolve().parent
for g in json.loads((r/'mapa_texturas.json').read_text()):
 src=r/'unicas'/(g['sha256']+'.png')
 assert hashlib.sha256(src.read_bytes()).hexdigest()==g['sha256']
 for name in g['files']:
  dst=r/'texturas'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
print('660 texturas restauradas na pasta texturas.')
