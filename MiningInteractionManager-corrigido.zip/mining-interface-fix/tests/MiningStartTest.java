import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.model.actor.instance.*;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.*;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;

public class MiningStartTest {
 private static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);System.out.println("PASS: "+text);}
 @SuppressWarnings("unchecked") private static void offer(MiningInteractionManager manager,L2PcInstance player,StoneMinerInstance stone)throws Exception{
  Class<?> type=Class.forName(MiningInteractionManager.class.getName()+"$Offer");
  Constructor<?> constructor=type.getDeclaredConstructor(L2PcInstance.class,int.class);constructor.setAccessible(true);
  Field f=MiningInteractionManager.class.getDeclaredField("offers");f.setAccessible(true);
  ((Map<Integer,Object>)f.get(manager)).put(player.getObjectId(),constructor.newInstance(player,stone.getObjectId()));
 }
 private static void online(L2PcInstance player){net.sf.l2j.gameserver.model.L2World.PLAYERS.put(player.getObjectId(),player);}
 private static boolean sent(L2PcInstance player,String action){
  for(Object packet:player.sent)if(packet instanceof net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage)
   if(((net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage)packet).text.contains("|"+action+"|"))return true;
  return false;
 }
 public static void main(String[] args)throws Exception{
  Files.createDirectories(Paths.get("data"));Files.write(Paths.get("data/treasurehunt-used-locations.log"),"# history\n".getBytes(StandardCharsets.UTF_8));
  TreasureHunt def=new TreasureHunt(0,"24_15",52000,30139,100,"Ketra");
  CustomTreasureHunt hunt=new CustomTreasureHunt(def);check(hunt.spawnNpc(Collections.emptyList()),"real mod creates test stone");
  StoneMinerInstance stone=hunt.getNpc();MiningInteractionManager manager=MiningInteractionManager.getInstance();manager.register(stone);
  L2PcInstance player=new L2PcInstance();player.setXYZ(stone.getX(),stone.getY(),stone.getZ());online(player);
  ItemInstance weapon=new ItemInstance(501,57);weapon.equipped=true;player.inventory.items.put(501,weapon);player.inventory.right=weapon;
  String start="MiningStart "+stone.getObjectId()+" 1";
  manager.handle(player,start);check(player.inventory.right==weapon&&!sent(player,"Start"),"missing UI offer does not start mining");
  offer(manager,player,stone);check(manager.handle(player,start),"start command is handled");
  check(player.getTarget()==stone,"start selects the actual stone");
  check(player.getTreasureHuntSession().isEquippedFor(stone),"real session equips and validates temporary tool");
  check(player.getAI().intention==CtrlIntention.ATTACK&&player.getAI().target==stone,"attack begins only after tool/session success");
  check(sent(player,"Start")&&manager.permitsDamage(player,stone),"successful start creates live attempt and sends Start");
  int tool=player.inventory.right.getObjectId();int calls=player.getAI().calls;manager.handle(player,start);
  check(player.inventory.right.getObjectId()==tool&&player.getAI().calls==calls,"duplicate Start does not create another tool or attack");
  manager.handle(player,"MiningCancel "+stone.getObjectId()+" 1");
  check(!manager.permitsDamage(player,stone)&&player.inventory.getItemByObjectId(tool)==null,"cancel removes attempt and temporary tool");
  check(player.inventory.right==weapon&&weapon.isEquipped()&&player.getAI().intention==CtrlIntention.IDLE,"cancel restores original weapon and stops attack");
  check(!Files.exists(Paths.get("data/treasurehunt-sessions/7.properties")),"cancel completes real recovery-journal cleanup");
  L2PcInstance refused=new L2PcInstance(){@Override public boolean isInStoreMode(){return true;}};
  refused.setXYZ(stone.getX(),stone.getY(),stone.getZ());online(refused);offer(manager,refused,stone);
  manager.handle(refused,"MiningStart "+stone.getObjectId()+" 2");
  check(refused.inventory.items.isEmpty()&&!sent(refused,"Start")&&!manager.permitsDamage(refused,stone),"session rejection does not equip a tool or report Start");
  check(refused.getAI().intention!=CtrlIntention.ATTACK,"session rejection never starts attack");
  L2PcInstance far=new L2PcInstance();far.setXYZ(stone.getX()+201,stone.getY(),stone.getZ());online(far);offer(manager,far,stone);
  manager.handle(far,"MiningStart "+stone.getObjectId()+" 3");
  check(far.getTarget()==null&&far.inventory.items.isEmpty()&&far.getAI().calls==0,"out-of-range player cannot start mining");
  net.sf.l2j.gameserver.model.L2World.PLAYERS.clear();far.setXYZ(stone.getX(),stone.getY(),stone.getZ());offer(manager,far,stone);
  manager.handle(far,"MiningStart "+stone.getObjectId()+" 4");
  check(far.inventory.items.isEmpty()&&far.getAI().calls==0,"offline player cannot start mining");
  online(far);offer(manager,far,stone);stone.deleteMe();manager.handle(far,"MiningStart "+stone.getObjectId()+" 5");
  check(far.inventory.items.isEmpty()&&far.getAI().calls==0,"invisible stone cannot start mining");
 }
}
