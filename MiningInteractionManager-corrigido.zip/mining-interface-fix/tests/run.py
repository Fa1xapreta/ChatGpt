#!/usr/bin/env python3
"""Compiles the supplied controller with real mod classes and explicit core doubles."""
from pathlib import Path
import shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
JAVA=shutil.which('java')
ns={};exec(compile((ROOT/'tests/core_doubles.py').read_text(),'core_doubles.py','exec'),ns);S=ns['S'];stub=ns['stub']
stub('net.sf.l2j.gameserver.ai','CtrlIntention','public enum CtrlIntention { IDLE, ATTACK }')
stub('net.sf.l2j.gameserver.model','L2World','''public class L2World {
 public static final java.util.Map<Integer,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance> PLAYERS=new java.util.HashMap<>();
 private static final L2World I=new L2World();public static L2World getInstance(){return I;}
 public net.sf.l2j.gameserver.model.actor.instance.L2PcInstance getPlayer(int id){return PLAYERS.get(id);}
}''')
stub('net.sf.l2j.gameserver.network.serverpackets','ExShowScreenMessage','public class ExShowScreenMessage { public final String text; public ExShowScreenMessage(String text,int type){this.text=text;} }')
k='net/sf/l2j/gameserver/model/actor/L2Character.java'
S[k]=S[k].replace('public double hp=100;','public double hp=100; public double getCurrentHp(){return hp;} public double getMaxHp(){return 100;}')
k='net/sf/l2j/gameserver/model/actor/instance/L2PcInstance.java'
S[k]=S[k].replace('public boolean isMounted()', '''public static class FakeAI {
 public net.sf.l2j.gameserver.ai.CtrlIntention intention;public Object target;public int calls;
 public void setIntention(net.sf.l2j.gameserver.ai.CtrlIntention i){intention=i;target=null;calls++;}
 public void setIntention(net.sf.l2j.gameserver.ai.CtrlIntention i,Object t){intention=i;target=t;calls++;}
 }
 public final java.util.List<Object> sent=new java.util.ArrayList<>();
 private final FakeAI ai=new FakeAI();public FakeAI getAI(){return ai;}
 @Override public void sendPacket(Object packet){sent.add(packet);}
 public boolean isMounted()''')
with tempfile.TemporaryDirectory(prefix='mining-start-tests-') as tmp:
 t=Path(tmp);src=t/'src';classes=t/'classes';classes.mkdir()
 for name,body in S.items():
  p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 paths=list(src.rglob('*.java'))+list((ROOT/'src').rglob('*.java'))+list((ROOT/'tests/fixtures').rglob('*.java'))+[ROOT/'tests/MiningStartTest.java']
 subprocess.run([JAVA,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*map(str,paths)],check=True)
 subprocess.run([JAVA,'-cp',str(classes),'MiningStartTest'],cwd=t,check=True)
print('PASS: Java 8-level compilation and real-session lifecycle with simulated core APIs; no full GameServer build.')
