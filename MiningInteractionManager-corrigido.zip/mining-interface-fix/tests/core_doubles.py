S={}
def stub(pkg,name,body):
 S[pkg.replace('.','/')+'/'+name+'.java']='package '+pkg+';\n'+body
stub('net.sf.l2j','Config','public class Config { public static boolean ENABLE_TREASURE_HUNT=true,TREASURE_HUNT_AUTO_LOOT=true; public static int TREASURE_HUNT_INTERVAL=1800,GEODATA=1; }')
stub('net.sf.l2j.util','Rnd','public class Rnd { public static int fixed=-1; private static final java.util.Random random=new java.util.Random(47); public static int get(int n){return fixed>=0?Math.min(fixed,n-1):random.nextInt(n);} public static int get(int a,int b){return a+get(b-a+1);} }')
stub('net.sf.l2j.gameserver','ThreadPoolManager','public class ThreadPoolManager { private static final ThreadPoolManager I=new ThreadPoolManager(); public static ThreadPoolManager getInstance(){return I;} public void scheduleGeneral(Runnable r,long delay){} }')
stub('net.sf.l2j.gameserver.model','L2Object','public class L2Object { public int id,x,y,z; public int getObjectId(){return id;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;} public boolean isVisible(){return true;} }')
stub('net.sf.l2j.gameserver.model','L2Skill','public class L2Skill {}')
stub('net.sf.l2j.gameserver.model','Location','public class Location { private final int x,y,z; public Location(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;} }')
stub('net.sf.l2j.gameserver.geoengine','GeoData','''public class GeoData {
 public static final GeoData I=new GeoData(); public static boolean available=true,cornerBlocked=false,ledge=false,slope=false; public static int base=-4408,nswe=15,calls;
 public static GeoData getInstance(){return I;} public boolean hasGeo(int x,int y){calls++;return available;}
 public int getHeight(int x,int y,int z){return base+(slope?Math.floorMod(x,512)/2:0)+(ledge&&x>147256?100:0);}
 public int getGeoX(int x){return x;} public int getGeoY(int y){return y;}
 public byte getNsweNearest(int x,int y,int z){return (byte)(cornerBlocked&&x==147288&&y==-90456?0:nswe);}
}''')
stub('net.sf.l2j.gameserver.geoengine','PathFinding','''public class PathFinding {
 public static boolean clipped=false,missing=false,approachBlocked=false; public static PathFinding getInstance(){return new PathFinding();}
 public net.sf.l2j.gameserver.model.Location canMoveToTargetLoc(int a,int b,int c,int d,int e,int f){boolean blocked=clipped||(approachBlocked&&(Math.abs(d-a)>64||Math.abs(e-b)>64));return missing?null:new net.sf.l2j.gameserver.model.Location(blocked?a:d,blocked?b:e,blocked?c:f);}
}''')
stub('net.sf.l2j.gameserver.model.item.kind','Item','public class Item { public static final int SLOT_L_HAND=1; public int getBodyPart(){return 0;} }')
stub('net.sf.l2j.gameserver.model.item.kind','Weapon','public class Weapon extends Item {}')
stub('net.sf.l2j.gameserver.model.item.instance','ItemInstance','''public class ItemInstance extends net.sf.l2j.gameserver.model.L2Object {
 public int itemId,owner=7; public boolean equipped,leftHand; public ItemInstance(int id,int itemId){this.id=id;this.itemId=itemId;}
 public int getItemId(){return itemId;} public int getOwnerId(){return owner;} public boolean isEquipped(){return equipped;}
 public net.sf.l2j.gameserver.model.item.kind.Item getItem(){return new net.sf.l2j.gameserver.model.item.kind.Weapon();}
 public void dropMe(net.sf.l2j.gameserver.model.L2Object o,int x,int y,int z){}
}''')
stub('net.sf.l2j.gameserver.model.item','DropData','''public class DropData {
 public static final int MAX_CHANCE=1000000; public int chance=1000000;
 public boolean isQuestDrop(){return false;} public int getItemId(){return 9501;}
 public int getMinDrop(){return 1;} public int getMaxDrop(){return 1;} public int getChance(){return chance;}
}''')
stub('net.sf.l2j.gameserver.model.item','DropCategory','''public class DropCategory {
 public final java.util.List<DropData> drops=new java.util.ArrayList<>(); public boolean isSweep(){return false;}
 public java.util.List<DropData> getAllDrops(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor.template','NpcTemplate','''public class NpcTemplate {
 public final java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> drops=new java.util.ArrayList<>();
 public double getCollisionRadius(){return 14;} public int npcId; public NpcTemplate(){} public NpcTemplate(int id){npcId=id;} public String getType(){return "StoneMiner";}
 public java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> getDropData(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Character','''public class L2Character extends net.sf.l2j.gameserver.model.L2Object {
 public double getCollisionRadius(){return 14;} public double hp=100; public void setCurrentHp(double value){hp=value;} public static boolean deleteOnDeath; public int damageCalls; public boolean dead; public boolean isDead(){return dead;} public boolean isAlikeDead(){return dead;}
 public void reduceCurrentHp(double d,L2Character a,boolean b,boolean c,net.sf.l2j.gameserver.model.L2Skill s){damageCalls++;}
 public boolean doDie(L2Character killer){if(dead)return false;dead=true;if(deleteOnDeath && this instanceof L2Npc)((L2Npc)this).deleteMe();return true;}
 public boolean isAutoAttackable(L2Character a){return false;} public void setIsImmobilized(boolean b){}
 public static final java.util.List<Object> packets=new java.util.ArrayList<>(); public void broadcastPacket(Object o){packets.add(o);} public void sendPacket(Object o){} public void abortAttack(){}
 public void setXYZ(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public boolean isTeleporting(){return false;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Npc','''public class L2Npc extends L2Character {
 private final net.sf.l2j.gameserver.model.actor.template.NpcTemplate template;
 public boolean deleted; public L2Npc(int id,net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){this.id=id;template=t;}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(){return template;}
 public boolean isAggressive(){return false;} public void onAction(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p){}
 public String getName(){return "Stone";} public net.sf.l2j.gameserver.model.L2Spawn getSpawn(){return null;}
 public boolean isVisible(){return !deleted;} public void deleteMe(){deleted=true;} public Known getKnownList(){return new Known();}
 public static class Known { public <T> java.util.List<T> getKnownType(Class<T> c){return new java.util.ArrayList<>();} }
}''')
stub('net.sf.l2j.gameserver.model','L2Spawn','''public class L2Spawn {
 public static int zShift; public static final java.util.List<net.sf.l2j.gameserver.model.actor.L2Npc> spawned=new java.util.ArrayList<>();
 private final net.sf.l2j.gameserver.model.actor.template.NpcTemplate template; private int x,y,z;
 public L2Spawn(net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){template=t;}
 public void setLocx(int x){this.x=x;} public void setLocy(int y){this.y=y;} public void setLocz(int z){this.z=z;} public void setHeading(int h){} public void stopRespawn(){}
 public net.sf.l2j.gameserver.model.actor.L2Npc doSpawn(boolean b){net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance n=new net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance(template.npcId,template);n.setXYZ(x,y,z+zShift);spawned.add(n);return n;}
}''')
stub('net.sf.l2j.gameserver.model.itemcontainer','Inventory','''public class Inventory {
 public static final int PAPERDOLL_RHAND=0,PAPERDOLL_LHAND=1;
 public final java.util.Map<Integer,net.sf.l2j.gameserver.model.item.instance.ItemInstance> items=new java.util.HashMap<>();
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance right,left;
 public boolean validateCapacity(int n,boolean q){return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getItemByObjectId(int id){return items.get(id);}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getPaperdollItem(int slot){return slot==0?right:left;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){items.put(i.id,i);return i;}
}''')
stub('net.sf.l2j.gameserver.model.actor.instance','L2PcInstance','''public class L2PcInstance extends net.sf.l2j.gameserver.model.actor.L2Character {
 public final net.sf.l2j.gameserver.model.itemcontainer.Inventory inventory=new net.sf.l2j.gameserver.model.itemcontainer.Inventory();
 private final net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession session=new net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession(this);
 public net.sf.l2j.gameserver.model.L2Object target; public int rewards; public boolean failDestroy;
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(){return new net.sf.l2j.gameserver.model.actor.template.NpcTemplate();} public L2PcInstance(){id=7;} public net.sf.l2j.gameserver.model.itemcontainer.Inventory getInventory(){return inventory;}
 public net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession getTreasureHuntSession(){return session;}
 public net.sf.l2j.gameserver.model.L2Object getTarget(){return target;} public void setTarget(net.sf.l2j.gameserver.model.L2Object t){session.onTargetChanged(t);target=t;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getActiveWeaponInstance(){return inventory.right;}
 public void useEquippableItem(net.sf.l2j.gameserver.model.item.instance.ItemInstance i,boolean b){
 if(i.equipped){i.equipped=false;if(inventory.right==i)inventory.right=null;if(inventory.left==i)inventory.left=null;}
 else{ i.equipped=true; if(i.leftHand){if(inventory.left!=null)inventory.left.equipped=false;inventory.left=i;}else{if(inventory.right!=null)inventory.right.equipped=false;if(i.itemId==30139 && inventory.left!=null){inventory.left.equipped=false;inventory.left=null;}inventory.right=i;}}}
 public boolean destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.L2Object r,boolean b){if(failDestroy)return false;inventory.items.remove(i.id);return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,int id,int count,net.sf.l2j.gameserver.model.L2Object r,boolean b){rewards+=count;return null;}
 public void broadcastUserInfo(){} public void sendMessage(String s){} public void standUp(){}
 public boolean isMounted(){return false;} public boolean isInStoreMode(){return false;} public boolean isProcessingTransaction(){return false;}
 public boolean isInOlympiadMode(){return false;} public boolean isCursedWeaponEquipped(){return false;} public boolean isFishing(){return false;} public boolean isInBoat(){return false;}
}''')
stub('net.sf.l2j.gameserver.datatables','NpcTable','''public class NpcTable {
 public static NpcTable getInstance(){return new NpcTable();}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(int id){return id>=52000&&id<=52003?new net.sf.l2j.gameserver.model.actor.template.NpcTemplate(id):null;}
}''')
stub('net.sf.l2j.gameserver.datatables','ItemTable','''public class ItemTable {
 private static int next=1000; public static ItemTable getInstance(){return new ItemTable();}
 public net.sf.l2j.gameserver.model.item.kind.Item getTemplate(int id){return id==30139?new net.sf.l2j.gameserver.model.item.kind.Weapon():null;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance createItem(String p,int id,int count,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){return new net.sf.l2j.gameserver.model.item.instance.ItemInstance(next++,id);}
 public void destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){}
}''')
for name,ctor in [('Earthquake','int a,int b,int c,int d,int e'),('PlaySound','String s'),('SocialAction','net.sf.l2j.gameserver.model.L2Object o,int a'),('ItemList','net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p,boolean b'),('ValidateLocation','net.sf.l2j.gameserver.model.actor.L2Character c')]:
 stub('net.sf.l2j.gameserver.network.serverpackets',name,'public class '+name+' { public '+name+'('+ctor+'){} }')
stub('net.sf.l2j.gameserver.network.serverpackets','Earthquake','public class Earthquake { public int intensity,duration; public Earthquake(int x,int y,int z,int intensity,int duration){this.intensity=intensity;this.duration=duration;} }')
stub('net.sf.l2j.gameserver.network.serverpackets','SocialAction','public class SocialAction { public int action; public SocialAction(net.sf.l2j.gameserver.model.L2Object o,int action){this.action=action;} }')
stub('net.sf.l2j.gameserver.network.serverpackets','ActionFailed','public class ActionFailed { public static final ActionFailed STATIC_PACKET=new ActionFailed(); }')
stub('net.sf.l2j.gameserver.network.serverpackets','FlyToLocation','public class FlyToLocation { public enum FlyType {THROW_UP} public FlyToLocation(net.sf.l2j.gameserver.model.actor.L2Character c,int x,int y,int z,FlyType t){} }')
stub('net.sf.l2j.gameserver.util','Broadcast','public class Broadcast { public static void gameAnnounceToOnlinePlayers(String s){} }')
