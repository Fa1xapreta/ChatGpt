// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Current-server-run journal: A adds a living stone, D retires a broken one.
 * Old stones are discarded once when this store is opened at GameServer startup.
 */
public final class TreasureHuntActiveStore implements AutoCloseable
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntActiveStore.class.getName());
    private final Map<String, Record> active = new LinkedHashMap<>();
    private FileChannel channel;
    private FileLock lock;
    private boolean ready;

    public static final class Record
    {
        private final String id;
        private final TreasureHunt definition;
        private final int x, y, z;
        private Record(String id, TreasureHunt definition, int x, int y, int z)
        { this.id = id; this.definition = definition; this.x = x; this.y = y; this.z = z; }
        public String getId() { return id; }
        public TreasureHunt getDefinition() { return definition; }
        public int getX() { return x; }
        public int getY() { return y; }
        public int getZ() { return z; }
    }

    public TreasureHuntActiveStore(Path file, TreasureHuntSpawnHistory history)
    {
        try
        {
            if (!history.isReady()) throw new IllegalStateException("Location history unavailable");
            Path path = file.toAbsolutePath();
            Files.createDirectories(path.getParent());
            // Do not truncate before taking the lock: another GameServer may own it.
            channel = FileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE);
            lock = channel.tryLock();
            if (lock == null) throw new IllegalStateException("Active stones file is locked by another server");
            // A new GameServer run starts without old stones, even after a crash.
            // Reload uses the same singleton and never executes this constructor again.
            channel.truncate(0);
            channel.position(0);
            channel.force(true);
            if (!history.initializeActiveStore()) throw new IllegalStateException("Active-stones marker could not be saved");
            ready = true;
            LOG.info("TreasureHunt: previous-run stones cleared; old stones will not be restored.");
        }
        catch (Exception e)
        {
            close();
            LOG.log(Level.SEVERE, "TreasureHunt: active-stones journal unavailable; spawning and restoration blocked.", e);
        }
    }

    public static TreasureHuntActiveStore getInstance() { return Holder.INSTANCE; }
    public synchronized boolean isReady() { return ready; }
    public synchronized List<Record> snapshot() { return new ArrayList<>(active.values()); }

    public synchronized String add(TreasureHunt definition, int x, int y, int z)
    {
        if (!ready || !insideRegion(definition, x, y, z)) return null;
        String id = UUID.randomUUID().toString();
        String name = Base64.getUrlEncoder().withoutPadding().encodeToString(definition.getTerritoryName().getBytes(StandardCharsets.UTF_8));
        try
        {
            append("A " + id + " " + definition.getId() + " " + definition.getRegion() + " " + definition.getNpcId() + " " +
                definition.getWeaponId() + " " + definition.getChance() + " " + name + " " + x + " " + y + " " + z + "\n");
            active.put(id, new Record(id, definition, x, y, z));
            return id;
        }
        catch (Exception e)
        {
            ready = false;
            LOG.log(Level.SEVERE, "TreasureHunt: living stone cannot be persisted; creation blocked.", e);
            return null;
        }
    }

    /** Persist retirement before giving a reward, preventing broken stones from returning. */
    public synchronized boolean remove(String id)
    {
        if (id == null || !active.containsKey(id)) return true;
        if (!ready) return false;
        try
        {
            append("D " + id + "\n");
            active.remove(id);
            return true;
        }
        catch (Exception e)
        {
            ready = false;
            LOG.log(Level.SEVERE, "TreasureHunt: broken stone cannot be saved; reward/death blocked.", e);
            return false;
        }
    }

    private void append(String line) throws java.io.IOException
    {
        ByteBuffer record = ByteBuffer.wrap(line.getBytes(StandardCharsets.UTF_8));
        channel.position(channel.size());
        while (record.hasRemaining()) channel.write(record);
        channel.force(true);
    }

    private static boolean insideRegion(TreasureHunt definition, int x, int y, int z)
    {
        return x >= definition.getMinX() && x < definition.getMinX() + 32768 &&
            y >= definition.getMinY() && y < definition.getMinY() + 32768 && z >= Short.MIN_VALUE && z <= Short.MAX_VALUE;
    }

    @Override public synchronized void close()
    {
        ready = false;
        try { if (lock != null) lock.release(); }
        catch (Exception e) { LOG.log(Level.WARNING, "TreasureHunt active journal lock release failed", e); }
        try { if (channel != null) channel.close(); }
        catch (Exception e) { LOG.log(Level.WARNING, "TreasureHunt active journal close failed", e); }
    }

    private static final class Holder
    {
        private static final TreasureHuntActiveStore INSTANCE = new TreasureHuntActiveStore(
            Paths.get("./data/treasurehunt-active-stones.log"), TreasureHuntSpawnHistory.getInstance());
    }
}
