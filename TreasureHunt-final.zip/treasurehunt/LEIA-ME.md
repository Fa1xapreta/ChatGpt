# Treasure Hunt — versão com posições aprovadas

Adaptação para o core `net.sf.l2j` fornecido. O modo de teste foi removido do
código, das configurações ativas e do agendamento. Esta versão utiliza somente
posições cadastradas no XML; nunca sorteia coordenadas em um bloco inteiro.

## Instalar ou atualizar

O pacote completo contém:

- `src/`: sete classes do mod, incluindo `TreasureHuntSpawnPoint`.
- `core-editados/`: seis classes completas do core original já integradas.
- `datapack/`: XML de posições, NPCs e ferramenta.
- `patches/core.patch`: integração para as classes originais, antes do mod.
- `patches/atualizar-local-para-final.patch`: atualização Java a partir da última
  versão instalada, `TreasureHunt-teste-local.zip`.
- `l2jmod.properties.append`: somente as três propriedades de produção.
- `tests/run.py`: testes isolados; não faz parte do gameserver.

1. Faça backup das classes, XMLs e propriedades antes da atualização.
2. Copie/mescle `src/net/` para a raiz de fontes da pack e as classes de
   `core-editados/` para os mesmos caminhos. Se editou suas classes depois dos
   arquivos enviados, faça merge; não substitua seu trabalho posterior.
3. Como alternativa para quem instalou a última versão de teste, aplique o patch
   incremental na raiz de fontes que contém `net/`:

   ```sh
   git apply --check --ignore-space-change /caminho/patches/atualizar-local-para-final.patch
   git apply --ignore-space-change /caminho/patches/atualizar-local-para-final.patch
   ```

   Esse patch inclui a classe nova. Use o patch OU a cópia das classes, não ambos.
   `core.patch` é apenas para a instalação sobre as classes originais sem o mod.
4. Substitua obrigatoriamente `data/xml/treasurehunt.xml` pelo novo XML. O formato
   antigo com `geodata="24_15"` não é aceito; a recarga o rejeita, sem fallback.
5. Para NPCs e ferramenta, mescle os outros XMLs apenas se necessário. Quem já
   instalou os pacotes anteriores não precisa duplicar essas definições.
   IDs 52000–52003 e item 30139 devem ter uma única definição no datapack.
6. No arquivo existente `config/custom/l2jmod.properties`, mantenha somente:

   ```properties
   EnableTreasureHunt = True
   TreasureHuntInterval = 1800
   AllowTreasureHuntAutoLoot = True
   ```

   Remova as chaves antigas `TreasureHuntTestMode`, `TreasureHuntTestX`,
   `TreasureHuntTestY`, `TreasureHuntTestZ`. Não substitua suas outras propriedades
   nem deixe chaves duplicadas.
7. Recompile pelo build normal da sua pack e reinicie o servidor. Recarga de XML
   ou configuração não instala as mudanças Java.
8. **Geodata real deve estar habilitada e conter a região dos pontos.** Confira
   `config/main/geoengine.properties`: `GeoData` deve ser maior que zero (por
   exemplo, `1`), e a região `24_15` deve existir em `GeoDataPath`, no formato
   configurado. O padrão do caminho no core enviado é `./data/geodata/`. Sem ela,
   ou se as validações falharem, a pedra não nasce. O console registra o motivo
   geral; não há spawn forçado para contornar a falha.

## Onde as pedras aparecem

O XML inicial contém os quatro pontos que você confirmou no jogo, próximos de
`147256 -90488 -4367`, na região configurada como Ketra Orc Outpost:

| X | Y | Z esperado | Acesso de referência |
|---:|---:|---:|---|
| 147256 | -90488 | -4367 | 147376 -90488 -4367 |
| 147376 | -90488 | -4367 | 147256 -90488 -4367 |
| 147256 | -90368 | -4367 | 147376 -90368 -4367 |
| 147376 | -90368 | -4367 | 147256 -90368 -4367 |

Cada cor sorteia um desses pontos; posições ocupadas por outra pedra são
rejeitadas. Não são criados deslocamentos aleatórios ao redor desses pontos.
As regiões anteriores de Talking Island e Crystal Island não estão ativas:
nenhuma posição dessas regiões foi confirmada. Para expandir, cadastre pontos
conferidos no jogo e os seus acessos, seguindo o formato abaixo.

O evento tem quatro entradas, uma por cor, com chances de spawn de 80%, 80%, 80%
e 20%, correspondentes às entradas antigas de Ketra. Não é garantido que as
quatro cores nasçam na mesma rodada. O primeiro sorteio ocorre no ciclo seguinte
à inicialização/recarga, aproximadamente um segundo; depois usa o intervalo em
segundos, por padrão 1800. Isso evita esperar 30 minutos para a primeira rodada.

Se uma entrada for sorteada, uma posição de substituição é validada antes de
remover a pedra existente. Sem candidato válido, a pedra anterior é preservada.
Uma falha posterior na criação pelo core pode deixar essa entrada sem pedra e
será registrada. Quando a entrada não é sorteada, sua pedra atual permanece.
O intervalo é o tempo entre rodadas, não um prazo separado de desaparecimento.

Os efeitos continuam: SocialAction 1, Earthquake intensidade 5/duração 3, som
`SkillSound5.target_magic_circle_01` e lançamento de jogadores próximos. O destino
do lançamento também exige espaço livre e geodata; se não for válido, aquele
jogador não é movido. O tremor, SocialAction e som não dependem desse movimento.

## Regras de validação

Antes do spawn, o código exige:

- Ponto e acesso dentro dos limites do mundo, com geodata presente.
- Altura próxima do Z aprovado, evitando procurar o chão a partir de Z=10000.
- Espaço livre em todas as células da área de colisão da pedra, com margem
  adicional: NSWE aberto nas quatro direções e variação de altura limitada.
- Área livre no ponto de acesso e caminho completo de ida e volta, conferindo
  se o destino retornado realmente chegou ao ponto. Caminho cortado é rejeitado.
- Distância mínima das outras pedras ativas, evitando sobreposição.
- Coordenadas efetivas do L2Spawn compatíveis com as coordenadas aprovadas,
  seguidas de nova validação da área antes dos efeitos e da ativação da mineração.

Não há recursão, posição inventada ou tentativa ilimitada. Cada entrada tenta
no máximo os pontos cadastrados. Configuração inválida é rejeitada antes de
substituir os eventos em funcionamento.

Essas proteções dependem de geodata correta. Ela não identifica de forma
confiável toda água, zona proibida ou recurso gráfico do cliente. Por isso,
posições novas precisam ser aprovadas caminhando pelo local no jogo; o código
não promete segurança para coordenadas arbitrárias. Com dados ausentes ou
inconsistentes, a opção adotada é não criar a pedra.

## Adicionar posições aprovadas

Exemplo de entrada:

```xml
<treasure id="0" npcId="52000" weaponId="30139" chance="80" territoryName="Ketra Orc Outpost">
    <spawn x="147256" y="-90488" z="-4367"
           approachX="147376" approachY="-90488" approachZ="-4367" />
</treasure>
```

`x/y/z` é o local exato da pedra. `approachX/Y/Z` é um ponto próximo, conferido
como acessível, no mesmo piso. O acesso precisa estar entre 64 e 1024 unidades
horizontalmente do spawn. Pode haver vários `<spawn>` na mesma entrada, sem
repetir coordenadas nela. IDs de `<treasure>` são únicos e independentes dos
IDs dos itens e NPCs. A lista de pontos é imutável após a carga.

Use `//reload treasurehunt` para recarregar posições e reiniciar a rodada.
Para mudanças nas propriedades, use `//reload config` e depois
`//reload treasurehunt`, ou reinicie. Desabilitar o evento limpa suas pedras.

## Mineração e recompensas

O primeiro clique seleciona a pedra e equipa a ferramenta temporária 30139;
o seguinte segue o ataque normal do core. Apenas ataques físicos diretos com
a ferramenta daquela sessão causam dano. Skills, DOT, pets e summons não causam
dano. O controle usa o ID exato do objeto criado, preservando itens legítimos.

Ao cancelar/trocar alvo, morrer, teleportar, sair ou despawnar, a ferramenta é
removida e as duas mãos são restauradas quando os itens ainda estão no inventário.
Preserve `data/treasurehunt-sessions/` junto com os backups do banco: seus registros
servem para recuperação após reinício e não devem ser apagados enquanto pendentes.

Recompensas e XMLs dos NPCs/ferramenta não foram alterados nesta atualização.
A pedra verde continua com chance de drop 100 em 1000000 (**0,01%**). São sorteios
independentes por item, sem multiplicador de rates normais, como no mod enviado.
Com autoloot desativado, os itens caem no chão sem reserva exclusiva do matador.

## Validação e limites

Passaram **77 verificações isoladas**, com substitutos explícitos do core,
exercitando geodata
inexistente, parede no centro/canto, desnível, altura errada, caminhos cortados,
sobreposição, alteração de altura no L2Spawn, preservação da pedra existente,
efeitos, recarga, chance, ferramenta temporária e restauração de equipamentos.
Os patches são aplicados e comparados às classes esperadas; a sintaxe Java é
analisada. Esses testes não substituem o build nem o servidor real.

O usuário confirmou os efeitos e mineração no spawn fixo anterior. **A nova
validação de posições ainda precisa ser conferida com a geodata real da pack.**
O projeto completo, dependências e classe PathFinding não foram fornecidos para
build e inspeção integral. A API usada já aparece no L2Character enviado.

Confira também os handlers customizados de transferência/venda/warehouse e o
reconhecimento das flags de restrição do item na sua pack; essas classes não
foram fornecidas integralmente. Não houve alteração de sistemas alheios ao mod.
