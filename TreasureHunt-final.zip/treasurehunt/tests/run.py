#!/usr/bin/env python3
"""Isolated behavior tests with explicit core doubles; not a gameserver build."""
from pathlib import Path
import os, shutil, subprocess, tempfile
ROOT=Path(__file__).resolve().parents[1]
JAVA=shutil.which('java') or '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
S={}
def stub(pkg,name,body):
 S[pkg.replace('.','/')+'/'+name+'.java']='package '+pkg+';\n'+body
stub('net.sf.l2j','Config','public class Config { public static boolean ENABLE_TREASURE_HUNT=true,TREASURE_HUNT_AUTO_LOOT=true; public static int TREASURE_HUNT_INTERVAL=1800,GEODATA=1; }')
stub('net.sf.l2j.util','Rnd','public class Rnd { public static int value=0; public static int get(int n){ return Math.min(value,n-1); } public static int get(int a,int b){return a;} }')
stub('net.sf.l2j.gameserver','ThreadPoolManager','public class ThreadPoolManager { private static final ThreadPoolManager I=new ThreadPoolManager(); public static ThreadPoolManager getInstance(){return I;} public void scheduleGeneral(Runnable r,long delay){} }')
stub('net.sf.l2j.gameserver.model','L2Object','public class L2Object { public int id,x,y,z; public int getObjectId(){return id;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;} public boolean isVisible(){return true;} }')
stub('net.sf.l2j.gameserver.model','L2Skill','public class L2Skill {}')
stub('net.sf.l2j.gameserver.model','Location','public class Location { private final int x,y,z; public Location(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;} }')
stub('net.sf.l2j.gameserver.geoengine','GeoData','''public class GeoData {
 public static final GeoData I=new GeoData(); public static boolean available=true,cornerBlocked=false,ledge=false; public static int heightOffset=0,nswe=15,calls;
 public static GeoData getInstance(){return I;} public boolean hasGeo(int x,int y){calls++;return available;}
 public int getHeight(int x,int y,int z){return z+heightOffset+(ledge&&x>147256?100:0);}
 public int getGeoX(int x){return x;} public int getGeoY(int y){return y;}
 public byte getNsweNearest(int x,int y,int z){return (byte)(cornerBlocked&&x==147288&&y==-90456?0:nswe);}
}''')
stub('net.sf.l2j.gameserver.geoengine','PathFinding','''public class PathFinding {
 public static boolean clipped=false,missing=false; public static PathFinding getInstance(){return new PathFinding();}
 public net.sf.l2j.gameserver.model.Location canMoveToTargetLoc(int a,int b,int c,int d,int e,int f){return missing?null:new net.sf.l2j.gameserver.model.Location(clipped?a:d,clipped?b:e,clipped?c:f);}
}''')
stub('net.sf.l2j.gameserver.model.item.kind','Item','public class Item { public static final int SLOT_L_HAND=1; public int getBodyPart(){return 0;} }')
stub('net.sf.l2j.gameserver.model.item.kind','Weapon','public class Weapon extends Item {}')
stub('net.sf.l2j.gameserver.model.item.instance','ItemInstance','''public class ItemInstance extends net.sf.l2j.gameserver.model.L2Object {
 public int itemId,owner=7; public boolean equipped,leftHand; public ItemInstance(int id,int itemId){this.id=id;this.itemId=itemId;}
 public int getItemId(){return itemId;} public int getOwnerId(){return owner;} public boolean isEquipped(){return equipped;}
 public net.sf.l2j.gameserver.model.item.kind.Item getItem(){return new net.sf.l2j.gameserver.model.item.kind.Weapon();}
 public void dropMe(net.sf.l2j.gameserver.model.L2Object o,int x,int y,int z){}
}''')
stub('net.sf.l2j.gameserver.model.item','DropData','''public class DropData {
 public static final int MAX_CHANCE=1000000; public int chance=1000000;
 public boolean isQuestDrop(){return false;} public int getItemId(){return 9501;}
 public int getMinDrop(){return 1;} public int getMaxDrop(){return 1;} public int getChance(){return chance;}
}''')
stub('net.sf.l2j.gameserver.model.item','DropCategory','''public class DropCategory {
 public final java.util.List<DropData> drops=new java.util.ArrayList<>(); public boolean isSweep(){return false;}
 public java.util.List<DropData> getAllDrops(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor.template','NpcTemplate','''public class NpcTemplate {
 public final java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> drops=new java.util.ArrayList<>();
 public double getCollisionRadius(){return 14;} public int npcId; public NpcTemplate(){} public NpcTemplate(int id){npcId=id;} public String getType(){return "StoneMiner";}
 public java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> getDropData(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Character','''public class L2Character extends net.sf.l2j.gameserver.model.L2Object {
 public double getCollisionRadius(){return 14;} public int damageCalls; public boolean dead; public boolean isDead(){return dead;} public boolean isAlikeDead(){return dead;}
 public void reduceCurrentHp(double d,L2Character a,boolean b,boolean c,net.sf.l2j.gameserver.model.L2Skill s){damageCalls++;}
 public boolean doDie(L2Character killer){if(dead)return false;dead=true;return true;}
 public boolean isAutoAttackable(L2Character a){return false;} public void setIsImmobilized(boolean b){}
 public static final java.util.List<Object> packets=new java.util.ArrayList<>(); public void broadcastPacket(Object o){packets.add(o);} public void sendPacket(Object o){} public void abortAttack(){}
 public void setXYZ(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public boolean isTeleporting(){return false;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Npc','''public class L2Npc extends L2Character {
 private final net.sf.l2j.gameserver.model.actor.template.NpcTemplate template;
 public boolean deleted; public L2Npc(int id,net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){this.id=id;template=t;}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(){return template;}
 public boolean isAggressive(){return false;} public void onAction(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p){}
 public String getName(){return "Stone";} public net.sf.l2j.gameserver.model.L2Spawn getSpawn(){return null;}
 public boolean isVisible(){return !deleted;} public void deleteMe(){deleted=true;} public Known getKnownList(){return new Known();}
 public static class Known { public <T> java.util.List<T> getKnownType(Class<T> c){return new java.util.ArrayList<>();} }
}''')
stub('net.sf.l2j.gameserver.model','L2Spawn','''public class L2Spawn {
 public static int zShift; public static final java.util.List<net.sf.l2j.gameserver.model.actor.L2Npc> spawned=new java.util.ArrayList<>();
 private final net.sf.l2j.gameserver.model.actor.template.NpcTemplate template; private int x,y,z;
 public L2Spawn(net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){template=t;}
 public void setLocx(int x){this.x=x;} public void setLocy(int y){this.y=y;} public void setLocz(int z){this.z=z;} public void setHeading(int h){} public void stopRespawn(){}
 public net.sf.l2j.gameserver.model.actor.L2Npc doSpawn(boolean b){net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance n=new net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance(template.npcId,template);n.setXYZ(x,y,z+zShift);spawned.add(n);return n;}
}''')
stub('net.sf.l2j.gameserver.model.itemcontainer','Inventory','''public class Inventory {
 public static final int PAPERDOLL_RHAND=0,PAPERDOLL_LHAND=1;
 public final java.util.Map<Integer,net.sf.l2j.gameserver.model.item.instance.ItemInstance> items=new java.util.HashMap<>();
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance right,left;
 public boolean validateCapacity(int n,boolean q){return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getItemByObjectId(int id){return items.get(id);}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getPaperdollItem(int slot){return slot==0?right:left;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){items.put(i.id,i);return i;}
}''')
stub('net.sf.l2j.gameserver.model.actor.instance','L2PcInstance','''public class L2PcInstance extends net.sf.l2j.gameserver.model.actor.L2Character {
 public final net.sf.l2j.gameserver.model.itemcontainer.Inventory inventory=new net.sf.l2j.gameserver.model.itemcontainer.Inventory();
 private final net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession session=new net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession(this);
 public net.sf.l2j.gameserver.model.L2Object target; public int rewards; public boolean failDestroy;
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(){return new net.sf.l2j.gameserver.model.actor.template.NpcTemplate();} public L2PcInstance(){id=7;} public net.sf.l2j.gameserver.model.itemcontainer.Inventory getInventory(){return inventory;}
 public net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession getTreasureHuntSession(){return session;}
 public net.sf.l2j.gameserver.model.L2Object getTarget(){return target;} public void setTarget(net.sf.l2j.gameserver.model.L2Object t){session.onTargetChanged(t);target=t;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getActiveWeaponInstance(){return inventory.right;}
 public void useEquippableItem(net.sf.l2j.gameserver.model.item.instance.ItemInstance i,boolean b){
 if(i.equipped){i.equipped=false;if(inventory.right==i)inventory.right=null;if(inventory.left==i)inventory.left=null;}
 else{ i.equipped=true; if(i.leftHand){if(inventory.left!=null)inventory.left.equipped=false;inventory.left=i;}else{if(inventory.right!=null)inventory.right.equipped=false;if(i.itemId==30139 && inventory.left!=null){inventory.left.equipped=false;inventory.left=null;}inventory.right=i;}}}
 public boolean destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.L2Object r,boolean b){if(failDestroy)return false;inventory.items.remove(i.id);return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,int id,int count,net.sf.l2j.gameserver.model.L2Object r,boolean b){rewards+=count;return null;}
 public void broadcastUserInfo(){} public void sendMessage(String s){} public void standUp(){}
 public boolean isMounted(){return false;} public boolean isInStoreMode(){return false;} public boolean isProcessingTransaction(){return false;}
 public boolean isInOlympiadMode(){return false;} public boolean isCursedWeaponEquipped(){return false;} public boolean isFishing(){return false;} public boolean isInBoat(){return false;}
}''')
stub('net.sf.l2j.gameserver.datatables','NpcTable','''public class NpcTable {
 public static NpcTable getInstance(){return new NpcTable();}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(int id){return id>=52000&&id<=52003?new net.sf.l2j.gameserver.model.actor.template.NpcTemplate(id):null;}
}''')
stub('net.sf.l2j.gameserver.datatables','ItemTable','''public class ItemTable {
 private static int next=1000; public static ItemTable getInstance(){return new ItemTable();}
 public net.sf.l2j.gameserver.model.item.kind.Item getTemplate(int id){return id==30139?new net.sf.l2j.gameserver.model.item.kind.Weapon():null;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance createItem(String p,int id,int count,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){return new net.sf.l2j.gameserver.model.item.instance.ItemInstance(next++,id);}
 public void destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){}
}''')
for name,ctor in [('Earthquake','int a,int b,int c,int d,int e'),('PlaySound','String s'),('SocialAction','net.sf.l2j.gameserver.model.L2Object o,int a'),('ItemList','net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p,boolean b'),('ValidateLocation','net.sf.l2j.gameserver.model.actor.L2Character c')]:
 stub('net.sf.l2j.gameserver.network.serverpackets',name,'public class '+name+' { public '+name+'('+ctor+'){} }')
stub('net.sf.l2j.gameserver.network.serverpackets','Earthquake','public class Earthquake { public int intensity,duration; public Earthquake(int x,int y,int z,int intensity,int duration){this.intensity=intensity;this.duration=duration;} }')
stub('net.sf.l2j.gameserver.network.serverpackets','SocialAction','public class SocialAction { public int action; public SocialAction(net.sf.l2j.gameserver.model.L2Object o,int action){this.action=action;} }')
stub('net.sf.l2j.gameserver.network.serverpackets','ActionFailed','public class ActionFailed { public static final ActionFailed STATIC_PACKET=new ActionFailed(); }')
stub('net.sf.l2j.gameserver.network.serverpackets','FlyToLocation','public class FlyToLocation { public enum FlyType {THROW_UP} public FlyToLocation(net.sf.l2j.gameserver.model.actor.L2Character c,int x,int y,int z,FlyType t){} }')
stub('net.sf.l2j.gameserver.util','Broadcast','public class Broadcast { public static void gameAnnounceToOnlinePlayers(String s){} }')
S['TreasureHuntTests.java']=r'''

import java.nio.file.*;
import java.util.*;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.*;
import net.sf.l2j.gameserver.model.actor.instance.*;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.*;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.geoengine.*;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.L2Spawn;
public class TreasureHuntTests {
 static int count;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);count++;}
 interface Checked {void run() throws Exception;}
 static void rejects(Checked c,String s)throws Exception{boolean bad=false;try{c.run();}catch(Exception e){bad=true;}check(bad,s);}
 static TreasureHuntSpawnPoint point(){return new TreasureHuntSpawnPoint(147256,-90488,-4367,147376,-90488,-4367);}
 static TreasureHunt definition(){return new TreasureHunt(0,52000,30139,80,"Ketra",Arrays.asList(point()));}
 static StoneMinerInstance stone(){StoneMinerInstance n=new StoneMinerInstance(55,new NpcTemplate());n.setTreasureHunt(new CustomTreasureHunt(definition()));return n;}
 static void xml(Path p,String s)throws Exception{Files.write(p,s.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
 public static void main(String[] args)throws Exception {
  check(definition().getPoints().size()==1,"approved point retained");
  rejects(()->definition().getPoints().clear(),"immutable point list");
  rejects(()->new TreasureHunt(0,52000,30139,101,"Ketra",Arrays.asList(point())),"reject invalid chance");
  rejects(()->new TreasureHunt(0,52000,30139,80,"Ketra",Collections.emptyList()),"reject missing approved points");
  rejects(()->new TreasureHuntSpawnPoint(147256,-90488,-4367,147256,-90488,-4367),"reject trivial approach");
  rejects(()->new TreasureHuntSpawnPoint(Integer.MAX_VALUE,0,0,0,0,0),"reject world overflow");
  List<TreasureHunt> loaded=TreasureHuntData.load();check(loaded.size()==4,"four event definitions loaded");
  for(TreasureHunt d:loaded)check(d.getPoints().size()==4,"four approved positions per stone");
  Path xml=Paths.get("data/xml/treasurehunt.xml");String valid=new String(Files.readAllBytes(xml),java.nio.charset.StandardCharsets.UTF_8);
  xml(xml,valid.replace("id=\"1\"","id=\"0\""));rejects(()->TreasureHuntData.load(),"reject duplicate IDs");
  xml(xml,valid.replace("npcId=\"52000\"","npcId=\"999\""));rejects(()->TreasureHuntData.load(),"reject missing NPC");
  xml(xml,valid.replace("weaponId=\"30139\"","weaponId=\"999\""));rejects(()->TreasureHuntData.load(),"reject missing tool");
  xml(xml,valid.replace("id=\"0\"","id=\"0\" geodata=\"24_15\""));rejects(()->TreasureHuntData.load(),"reject old full-region fallback");
  xml(xml,valid.replaceAll("(?s)<spawn[^>]*/>",""));rejects(()->TreasureHuntData.load(),"reject XML without approved positions");
  xml(xml,valid);
  check(point().resolveSafeZ(32)==-4367,"accept clear point with complete two-way paths");
  Config.GEODATA=0;check(point().resolveSafeZ(32)==null,"reject disabled geo even if driver reports open cells");Config.GEODATA=1;
  GeoData.available=false;check(point().resolveSafeZ(32)==null,"reject absent geodata");GeoData.available=true;
  GeoData.nswe=0;check(point().resolveSafeZ(32)==null,"reject blocked NSWE");GeoData.nswe=15;
  GeoData.cornerBlocked=true;check(point().resolveSafeZ(32)==null,"reject wall at footprint corner");GeoData.cornerBlocked=false;
  GeoData.heightOffset=100;check(point().resolveSafeZ(32)==null,"reject roof or wrong height layer");GeoData.heightOffset=0;
  GeoData.ledge=true;check(point().resolveSafeZ(32)==null,"reject edge within footprint");GeoData.ledge=false;
  PathFinding.clipped=true;check(point().resolveSafeZ(32)==null,"reject clipped paths, not merely null");PathFinding.clipped=false;
  PathFinding.missing=true;check(point().resolveSafeZ(32)==null,"reject absent path");PathFinding.missing=false;
  CustomTreasureHunt direct=new CustomTreasureHunt(definition());
  GeoData.available=false;int before=L2Spawn.spawned.size();check(!direct.spawnNpc(Collections.emptyList())&&L2Spawn.spawned.size()==before,"unsafe point never creates NPC");GeoData.available=true;
  check(direct.spawnNpc(Collections.emptyList()),"spawn at validated point");StoneMinerInstance existing=direct.getNpc();
  GeoData.available=false;check(!direct.spawnNpc(Collections.emptyList())&&direct.getNpc()==existing&&!existing.deleted,"failed candidate preserves working stone");GeoData.available=true;
  CustomTreasureHunt overlapping=new CustomTreasureHunt(definition());check(!overlapping.spawnNpc(Arrays.<L2Npc>asList(existing)),"reject overlap with another stone");
  direct.despawnNpc();L2Spawn.zShift=100;
  net.sf.l2j.gameserver.model.actor.L2Character.packets.clear();
  check(!direct.spawnNpc(Collections.emptyList()),"reject spawn-time height change");
  check(L2Spawn.spawned.get(L2Spawn.spawned.size()-1).deleted,"delete changed-floor NPC");
  check(net.sf.l2j.gameserver.model.actor.L2Character.packets.isEmpty(),"no success effects for rejected spawn");L2Spawn.zShift=0;
  L2PcInstance p=new L2PcInstance();StoneMinerInstance n=stone();p.setTarget(n);
  ItemInstance original=new ItemInstance(20,500);original.equipped=true;p.inventory.items.put(20,original);p.inventory.right=original;
  ItemInstance shield=new ItemInstance(22,600);shield.leftHand=true;shield.equipped=true;p.inventory.items.put(22,shield);p.inventory.left=shield;
  ItemInstance legitimate=new ItemInstance(21,30139);p.inventory.items.put(21,legitimate);
  check(p.getTreasureHuntSession().begin(n),"start mining");
  n.reduceCurrentHp(1,p,true,false,new net.sf.l2j.gameserver.model.L2Skill());check(n.damageCalls==0,"reject skill damage");
  n.reduceCurrentHp(1,new net.sf.l2j.gameserver.model.actor.L2Character(),true,false,null);check(n.damageCalls==0,"reject non-player damage");
  n.reduceCurrentHp(1,p,true,false,null);check(n.damageCalls==1,"accept tool melee damage");
  int tool=p.getActiveWeaponInstance().id;
  check(tool!=21 && p.getTreasureHuntSession().ownsTemporary(tool),"exact temporary identity");
  check(p.getTreasureHuntSession().blocksUse(legitimate),"block equipment changes");
  p.failDestroy=true;check(!p.getTreasureHuntSession().finish(),"retain failed cleanup");
  check(Files.exists(Paths.get("data/treasurehunt-sessions/7.properties")),"retain recovery journal");
  p.failDestroy=false;p.setTarget(null);
  check(p.inventory.items.containsKey(21),"preserve legitimate tool");
  check(!p.inventory.items.containsKey(tool) && p.getActiveWeaponInstance()==original && original.equipped,"destroy temporary and restore original");
  check(p.inventory.left==shield && shield.equipped,"restore previous shield");
  check(p.getTreasureHuntSession().finish(),"idempotent cleanup");
  p.setTarget(n);Config.ENABLE_TREASURE_HUNT=false;check(!p.getTreasureHuntSession().begin(n),"disabled event cannot equip");Config.ENABLE_TREASURE_HUNT=true;
  check(p.getTreasureHuntSession().begin(n),"restart session");tool=p.getActiveWeaponInstance().id;
  L2PcInstance relog=new L2PcInstance();relog.inventory.items.putAll(p.inventory.items);relog.inventory.right=p.inventory.right;relog.inventory.left=p.inventory.left;
  relog.getTreasureHuntSession().recover();check(!relog.inventory.items.containsKey(tool),"recover exact tool after restart");
  check(relog.getActiveWeaponInstance()==original,"recover previous weapon after restart");
  // Death pays once, and releases the killer's tool even without a known-list entry.
  p=new L2PcInstance();n=stone();p.setTarget(n);check(p.getTreasureHuntSession().begin(n),"reward session");
  DropCategory cat=new DropCategory();cat.drops.add(new DropData());n.getTemplate().drops.add(cat);
  check(n.doDie(p),"stone dies");check(p.rewards==1,"reward delivered");check(!n.doDie(p) && p.rewards==1,"no duplicate death reward");
  check(p.getActiveWeaponInstance()==null,"cleanup killer without known-list entry");
  p=new L2PcInstance();n=stone();p.setTarget(n);check(p.getTreasureHuntSession().begin(n),"despawn session");
  tool=p.getActiveWeaponInstance().id;n.deleteMe();check(!p.inventory.items.containsKey(tool),"despawn cleanup outside known list");

  L2Spawn.spawned.clear();net.sf.l2j.gameserver.model.actor.L2Character.packets.clear();
  TreasureHuntManager manager=TreasureHuntManager.getInstance();check(manager.reload(),"manager valid reload");manager.run();
  check(L2Spawn.spawned.size()==4,"first normal round starts without waiting thirty minutes");
  Set<String> positions=new HashSet<>();Set<Integer> templates=new HashSet<>();
  for(L2Npc spawned:L2Spawn.spawned){positions.add(spawned.getX()+":"+spawned.getY());templates.add(spawned.getTemplate().npcId);}
  check(positions.size()==4&&templates.size()==4,"normal stones occupy distinct approved positions");
  int social=0,quakes=0,sounds=0;
  for(Object packet:net.sf.l2j.gameserver.model.actor.L2Character.packets){
   if(packet instanceof net.sf.l2j.gameserver.network.serverpackets.SocialAction){check(((net.sf.l2j.gameserver.network.serverpackets.SocialAction)packet).action==1,"social action ID");social++;}
   if(packet instanceof net.sf.l2j.gameserver.network.serverpackets.Earthquake){net.sf.l2j.gameserver.network.serverpackets.Earthquake q=(net.sf.l2j.gameserver.network.serverpackets.Earthquake)packet;check(q.intensity==5&&q.duration==3,"earthquake parameters");quakes++;}
   if(packet instanceof net.sf.l2j.gameserver.network.serverpackets.PlaySound)sounds++;
  }
  check(social==4&&quakes==4&&sounds==4,"all normal spawns preserve effects");
  java.lang.reflect.Field list=TreasureHuntManager.class.getDeclaredField("hunts");list.setAccessible(true);Object previous=list.get(manager);
  xml(xml,valid.replace("id=\"1\"","id=\"0\""));check(!manager.reload()&&list.get(manager)==previous,"invalid reload preserves live events");
  check(L2Spawn.spawned.stream().noneMatch(npc->npc.deleted),"invalid reload does not despawn live stones");xml(xml,valid);
  Config.TREASURE_HUNT_INTERVAL=30;manager.run();
  java.lang.reflect.Field interval=TreasureHuntManager.class.getDeclaredField("interval");interval.setAccessible(true);check(interval.getInt(manager)==30,"apply interval change");
  Config.ENABLE_TREASURE_HUNT=false;manager.run();check(L2Spawn.spawned.stream().allMatch(npc->npc.deleted),"disable removes stones");
  L2Spawn.spawned.clear();Config.ENABLE_TREASURE_HUNT=true;
  xml(xml,valid.replace("chance=\"80\"","chance=\"0\"").replace("chance=\"20\"","chance=\"0\""));check(manager.reload(),"load zero chance");manager.run();check(L2Spawn.spawned.isEmpty(),"normal mode respects chance without forced spawns");
  for(java.lang.reflect.Field f:Config.class.getFields())check(!f.getName().contains("TEST"),"no test configuration remains");
  System.out.println("PASS: "+count+" behavior assertions with core doubles. Full core build not tested.");
 }
}

'''
with tempfile.TemporaryDirectory(prefix='treasurehunt-tests-') as tmp:
 t=Path(tmp);src=t/'src';classes=t/'classes';classes.mkdir()
 for name,body in S.items():
  p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 paths=list(src.rglob('*.java'))+list((ROOT/'src').rglob('*.java'))
 subprocess.run([JAVA,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*map(str,paths)],check=True)
 (t/'data/xml').mkdir(parents=True)
 shutil.copyfile(ROOT/'datapack/data/xml/treasurehunt.xml',t/'data/xml/treasurehunt.xml')
 subprocess.run([JAVA,'-cp',str(classes),'TreasureHuntTests'],cwd=t,check=True)
