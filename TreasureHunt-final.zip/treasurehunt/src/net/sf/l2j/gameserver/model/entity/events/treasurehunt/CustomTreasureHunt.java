// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.network.serverpackets.Earthquake;
import net.sf.l2j.gameserver.network.serverpackets.PlaySound;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Rnd;

public final class CustomTreasureHunt
{
    private static final Logger LOG = Logger.getLogger(CustomTreasureHunt.class.getName());
    private final TreasureHunt definition;
    private volatile StoneMinerInstance npc;

    public CustomTreasureHunt(TreasureHunt definition) { this.definition = definition; }
    public TreasureHunt getDefinition() { return definition; }
    public StoneMinerInstance getNpc() { return npc; }

    /** Only the manager calls this, serially; never invent or offset a coordinate. */
    public boolean spawnNpc(List<L2Npc> occupied)
    {
        try
        {
            NpcTemplate template = NpcTable.getInstance().getTemplate(definition.getNpcId());
            if (template == null)
                throw new IllegalStateException("Missing NPC template " + definition.getNpcId());
            int clearance = Math.max(32, (int) Math.ceil(template.getCollisionRadius()) + 16);
            List<TreasureHuntSpawnPoint> points = definition.getPoints();
            int start = Rnd.get(points.size());
            for (int index = 0; index < points.size(); index++)
            {
                TreasureHuntSpawnPoint point = points.get((start + index) % points.size());
                Integer groundZ = point.resolveSafeZ(clearance);
                if (groundZ == null || !hasRoom(point.getX(), point.getY(), groundZ, clearance, occupied))
                    continue;
                // Validate the candidate before removing a working existing stone.
                L2Spawn spawn = new L2Spawn(template);
                spawn.setLocx(point.getX());
                spawn.setLocy(point.getY());
                spawn.setLocz(groundZ);
                spawn.setHeading(0);
                spawn.stopRespawn();
                despawnNpc();
                L2Npc created = spawn.doSpawn(false);
                if (!(created instanceof StoneMinerInstance) || !created.isVisible())
                {
                    if (created != null) created.deleteMe();
                    throw new IllegalStateException("StoneMiner spawn failed for " + definition.getId());
                }
                // L2Spawn performs its own height adjustment. Reject a changed floor/location.
                if (created.getX() != point.getX() || created.getY() != point.getY() || Math.abs(created.getZ() - groundZ) > 16 ||
                    !TreasureHuntSpawnPoint.isClearArea(GeoData.getInstance(), created.getX(), created.getY(), created.getZ(), clearance))
                {
                    created.deleteMe();
                    LOG.warning("TreasureHunt " + definition.getId() + ": L2Spawn changed the validated position; rejected.");
                    continue;
                }
                npc = (StoneMinerInstance) created;
                npc.setTreasureHunt(this);
                npc.broadcastPacket(new SocialAction(npc, 1));
                npc.broadcastPacket(new Earthquake(npc.getX(), npc.getY(), npc.getZ(), 5, 3));
                npc.broadcastPacket(new PlaySound("SkillSound5.target_magic_circle_01"));
                npc.throwUpNearbyPlayers();
                LOG.info("TreasureHunt: NPC " + definition.getNpcId() + " spawned at " + npc.getX() + " " + npc.getY() + " " + npc.getZ());
                Broadcast.gameAnnounceToOnlinePlayers(npc.getName() + " apareceu em " + definition.getTerritoryName() + ".");
                return true;
            }
            LOG.warning("TreasureHunt " + definition.getId() + ": none of " + points.size() +
                " approved points is available. Check geodata, NSWE, height, approach paths and occupied stones. No fallback spawn.");
        }
        catch (Exception e)
        {
            LOG.log(Level.WARNING, "TreasureHunt spawn failed: " + definition.getId(), e);
        }
        return false;
    }

    private static boolean hasRoom(int x, int y, int z, int clearance, List<L2Npc> occupied)
    {
        for (L2Npc other : occupied)
        {
            if (other == null || other.isDead() || !other.isVisible())
                continue;
            long dx = (long) x - other.getX(), dy = (long) y - other.getY();
            int gap = Math.max(96, clearance + (int) Math.ceil(other.getCollisionRadius()) + 16);
            if (Math.abs(z - other.getZ()) < 128 && dx * dx + dy * dy < (long) gap * gap)
                return false;
        }
        return true;
    }

    public void despawnNpc()
    {
        StoneMinerInstance old = npc;
        npc = null;
        if (old == null) return;
        old.setTreasureHunt(null);
        old.releaseMiners();
        if (old.getSpawn() != null) old.getSpawn().stopRespawn();
        old.deleteMe();
    }
}
