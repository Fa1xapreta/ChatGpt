// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable configuration. Random selection is limited to manually approved points. */
public final class TreasureHunt
{
    private final int id, npcId, weaponId, chance;
    private final String territoryName;
    private final List<TreasureHuntSpawnPoint> points;

    public TreasureHunt(int id, int npcId, int weaponId, int chance, String territoryName, List<TreasureHuntSpawnPoint> points)
    {
        if (id < 0 || npcId <= 0 || weaponId <= 0 || chance < 0 || chance > 100 || territoryName.trim().isEmpty() || points.isEmpty())
            throw new IllegalArgumentException("Invalid treasure configuration or missing approved spawns: " + id);
        this.id = id; this.npcId = npcId; this.weaponId = weaponId; this.chance = chance;
        this.territoryName = territoryName;
        this.points = Collections.unmodifiableList(new ArrayList<>(points));
    }

    public int getId() { return id; }
    public int getNpcId() { return npcId; }
    public int getWeaponId() { return weaponId; }
    public int getChance() { return chance; }
    public String getTerritoryName() { return territoryName; }
    public List<TreasureHuntSpawnPoint> getPoints() { return points; }
}
