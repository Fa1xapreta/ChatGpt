// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.model.Location;

/** A manually approved point and a nearby walkable approach, on the intended floor. */
public final class TreasureHuntSpawnPoint
{
    private final int x, y, z, approachX, approachY, approachZ;

    public TreasureHuntSpawnPoint(int x, int y, int z, int approachX, int approachY, int approachZ)
    {
        if (!inWorld(x, y, z) || !inWorld(approachX, approachY, approachZ))
            throw new IllegalArgumentException("Spawn outside Interlude world bounds");
        long dx = (long) x - approachX, dy = (long) y - approachY;
        if (dx * dx + dy * dy < 64L * 64 || dx * dx + dy * dy > 1024L * 1024 || Math.abs(z - approachZ) > 128)
            throw new IllegalArgumentException("Approach must be 64..1024 units away on the same floor");
        this.x = x; this.y = y; this.z = z;
        this.approachX = approachX; this.approachY = approachY; this.approachZ = approachZ;
    }

    private static boolean inWorld(int x, int y, int z)
    {
        return x >= -327680 && x <= 229375 && y >= -262144 && y <= 262143 && z >= -32768 && z <= 32767;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }

    /** No geo, wrong layer, walls or clipped approach => no spawn. No fallback. */
    public Integer resolveSafeZ(int clearance)
    {
        GeoData geo = GeoData.getInstance();
        if (Config.GEODATA <= 0 || geo == null || !geo.hasGeo(x, y) || !geo.hasGeo(approachX, approachY))
            return null;
        int groundZ = geo.getHeight(x, y, z);
        int groundApproachZ = geo.getHeight(approachX, approachY, approachZ);
        if (Math.abs(groundZ - z) > 24 || Math.abs(groundApproachZ - approachZ) > 24 ||
            !isClearArea(geo, x, y, groundZ, clearance) || !isClearArea(geo, approachX, approachY, groundApproachZ, 32))
            return null;
        PathFinding paths = PathFinding.getInstance();
        if (paths == null)
            return null;
        Location forward = paths.canMoveToTargetLoc(approachX, approachY, groundApproachZ, x, y, groundZ);
        Location reverse = paths.canMoveToTargetLoc(x, y, groundZ, approachX, approachY, groundApproachZ);
        if (!reaches(forward, x, y, groundZ) || !reaches(reverse, approachX, approachY, groundApproachZ))
            return null;
        return groundZ;
    }

    private static boolean reaches(Location result, int x, int y, int z)
    {
        // A non-null but clipped path does not establish reachability.
        return result != null && Math.abs(result.getX() - x) <= 8 && Math.abs(result.getY() - y) <= 8 && Math.abs(result.getZ() - z) <= 24;
    }

    public static boolean isClearArea(GeoData geo, int x, int y, int z, int clearance)
    {
        if (Config.GEODATA <= 0 || geo == null || clearance < 16 || clearance > 256)
            return false;
        int radius = ((clearance + 15) / 16) * 16;
        for (int dx = -radius; dx <= radius; dx += 16)
            for (int dy = -radius; dy <= radius; dy += 16)
            {
                int px = x + dx, py = y + dy;
                if (!geo.hasGeo(px, py) || Math.abs(geo.getHeight(px, py, z) - z) > 24 ||
                    (geo.getNsweNearest(geo.getGeoX(px), geo.getGeoY(py), z) & 15) != 15)
                    return false;
            }
        return true;
    }
}
