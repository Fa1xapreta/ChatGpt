# Standalone UnrealScript metadata/bytecode builder for the isolated Gear Score bridge.
from pathlib import Path
import sys,json,struct,copy,ast
R=Path(__file__).resolve().parent;B=R.parent;sys.path[:0]=[str(B/'inventory-preview'),str(B/'cloak-audit')];from xdat import Reader;from catalog_unreal import catalog
P=R/'output/system/interface.u';D=catalog(P);U=P.read_bytes();EX=copy.deepcopy(D['exports']);IM=copy.deepcopy(D['imports']);N=list(D['names']);NI={x.lower():i for i,x in enumerate(N)};LOOK={e['path'].lower():e['index'] for e in EX};PAY={}
def ci(v):
 neg=v<0;v=abs(v);a=[(v&63)|(128 if neg else 0)];v>>=6
 if v:a[0]|=64
 while v:a.append((v&127)|(128 if v>>7 else 0));v>>=7
 return bytes(a)
def nm(s):
 if s.lower() not in NI:NI[s.lower()]=len(N);N.append(s)
 return NI[s.lower()]
def idx(s):return LOOK[s.lower()]
def imp(path):
 def resolve(v):
  if not v:return ''
  e=IM[-v-1];p=resolve(e['outer']);return (p+'.' if p else '')+e['name']
 matches=[-i-1 for i in range(len(IM)) if resolve(-i-1).lower()==path.lower()]
 if not matches:matches=[-i-1 for i,e in enumerate(IM) if e['name'].lower()==path.rsplit('.',1)[-1].lower()]
 assert len(matches)==1,(path,matches)
 return matches[0]
def raw(e):return U[e['offset']:e['offset']+e['size']]
def core(t):return imp('Core.'+t)
def export(path,typ,outer,superref=0):
 assert path.lower() not in LOOK,path
 j=len(EX)+1;e={'index':j,'name':path.rsplit('.',1)[-1],'path':path,'outer':outer,'class_ref':core(typ),'super_ref':superref,'flags':0x00070004,'size':0,'offset':0,'class':'Core.'+typ};EX.append(e);LOOK[path.lower()]=j;nm(e['name']);return j
NEXT={};CHILD={};API=idx('MileniumGearScore')
def type_spec(t):
 if t in ['int','bool','string','float','name']:return {'int':'IntProperty','bool':'BoolProperty','string':'StrProperty','float':'FloatProperty','name':'NameProperty'}[t],None
 if t.startswith('array:'):return 'ArrayProperty',t[6:]
 if t.startswith('object:'):return 'ObjectProperty',LOOK.get(t[7:].lower()) or imp(t[7:])
 if t.startswith('struct:'):return 'StructProperty',LOOK.get(t[7:].lower()) or imp(t[7:])
 raise ValueError(t)
def prop(path,t,flags=0):
 owner=idx(path.rsplit('.',1)[0]);typ,other=type_spec(t);j=export(path,typ,owner)
 extra=b''
 if typ=='ArrayProperty':inner=prop(path+'.Inner',other);extra=ci(inner)
 elif other is not None:extra=ci(other)
 PAY[j]=b'\0'+ci(0)+ci(0)+struct.pack('<HHI',1,0,flags)+ci(nm('None'))+extra
 CHILD.setdefault(owner,[]).append(j);NEXT[j]=0
 return j
FN={}
def function(name,params=(),returns=None,locals=(),owner='MileniumGearScore'):
 path=owner+'.'+name;j=export(path,'Function',idx(owner));FN[path]={'index':j,'params':params,'returns':returns};CHILD.setdefault(idx(owner),[]).append(j);NEXT[j]=0
 for n,t in params:prop(path+'.'+n,t[4:] if t.startswith('out:') else t,0x80|(0x100 if t.startswith('out:') else 0))
 if returns:prop(path+'.ReturnValue',returns,0x580)
 for n,t in locals:prop(path+'.'+n,t)
 return path
class E:
 def __init__(self,b,n=None):self.b=b;self.n=len(b) if n is None else n
 def __add__(self,v):return E(self.b+v.b,self.n+v.n)
def seq(*args):
 x=E(b'')
 for a in args:x=x+a
 return x
def ref(op,j):return E(bytes([op])+ci(j),5)
def integer(v):return E(b'\x1d'+struct.pack('<i',v))
def string(v):return E(b'\x1f'+v.encode('cp1252')+b'\0')
def name(v):return ref(0x21,nm(v))
def var(path):return ref(0 if path.rsplit('.',1)[0].lower() in {x.lower() for x in FN} else 1,idx(path))
def native(code,*args):
 b=bytes([code]) if code>=0x70 else bytes([0x60+code//256,code%256]);return seq(E(b),*args,E(b'\x16'))
def call(fn,*args):return seq(ref(0x1b,nm(fn)),*args,E(b'\x16'))
def final(j,*args):return seq(ref(0x1c,j),*args,E(b'\x16'))
def ctx(obj,fn,size=0,static=False):return seq(E(b'\x12' if static else b'\x19'),obj,E(struct.pack('<HB',fn.n,size)),fn)
def obj(cl):return seq(E(b'\x2e'),ref(0,idx(cl)),call('GetScript',string(cl))) # replaced below: dynamic cast uses opcode+class ref, not local variable token
# DynamicCast encodes a compact class ref followed by an expression.
def obj(cl):return seq(ref(0x2e,idx(cl)),call('GetScript',string(cl)))
def method(cl,fn,*args,size=0):return ctx(obj(cl),call(fn,*args),size)
def length(v):return seq(E(b'\x37'),v)
def element(v,i):return seq(E(b'\x10'),i,v)
def member(v,path):return seq(ref(0x36,LOOK.get(path.lower()) or imp(path)),v)
def assign(target,value,bool=False):return seq(E(b'\x14' if bool else b'\x0f'),target,value)
def boolean(v):return E(b'\x27' if v else b'\x28')
def bvar(path):return seq(E(b'\x2d'),var(path))
def convert(tag,v):return seq(E(bytes([0x39,tag])),v)
def cast_int(v):return convert(0x4a,v)
def gethandle(path,typ='WindowHandle'):return seq(ref(0x2e,imp('NWindow.'+typ)),call('GetHandle',string(path))) if typ!='WindowHandle' else call('GetHandle',string(path))
def handle(path,fn,*args,typ='WindowHandle',size=0):return ctx(gethandle(path,typ),call(fn,*args),size)
RET=E(b'\x04\x0b')
class Code:
 def __init__(self):self.n=0;self.parts=[];self.labels={};self.fix=[]
 def put(self,e):self.parts.append(e);self.n+=e.n
 def label(self,s):self.labels[s]=self.n
 def jf(self,e,label):self.fix.append((len(self.parts),label));self.put(seq(E(b'\x07\0\0'),e))
 def jump(self,label):self.fix.append((len(self.parts),label));self.put(E(b'\x06\0\0'))
 def guard(self,e,label='end'):self.jf(e,label)
 def done(self):
  for i,l in self.fix:
   e=self.parts[i];b=bytearray(e.b);struct.pack_into('<H',b,1,self.labels[l]);self.parts[i]=E(bytes(b),e.n)
  return seq(*self.parts)
def implement(path,c):
 e=c.done() if isinstance(c,Code) else c;j=idx(path);kids=CHILD.get(j,[])
 # Standard non-native defined function flags, matching the live interface.
 PAY[j]=b'\0'+ci(0)+ci(0)+ci(0)+ci(kids[0] if kids else 0)+ci(nm(path.rsplit('.',1)[-1]))+ci(0)+struct.pack('<III',0,0,e.n)+e.b+struct.pack('<HBI',0,0,0x00020002)
# Patch existing function bytecode by insertion with absolute branch relocation.
def getscript(e):
 r=Reader(raw(e))
 for _ in range(7):r.ci()
 sp=r.p+8;size=struct.unpack_from('<I',r.b,sp)[0];return r.b,sp,sp+4,size
class_meta={}
def finish():
 # Link new function parameters/locals and new API fields without changing existing members.
 for owner,kids in CHILD.items():
  for a,b in zip(kids,kids[1:]+[0]):NEXT[a]=b
 for j,nxt in NEXT.items():
  if j not in PAY:continue
  b=PAY[j];r=Reader(b);r.ci();r.ci();a=r.p;r.ci();PAY[j]=b[:a]+ci(nxt)+b[r.p:]
 for owner,kids in CHILD.items():
  if owner in FN.values():continue
 # Only the isolated API and ToolTip receive new fields/functions; preserve their old chains.
 for owner in [API,idx('ToolTip'),idx('RankingWnd'),idx('SideBarWnd'),idx('TimeZoneWnd'),idx('InstanciasInfoExitWnd')]:
  kids=CHILD.get(owner,[])
  if not kids:continue
  e=EX[owner-1];b=raw(e);r=Reader(b)
  # UClass has no leading property terminator.
  for _ in range(3):r.ci()
  at=r.p;oldchild=r.ci();PAY[owner]=b[:at]+ci(kids[0])+b[r.p:]
  last=kids[-1];q=Reader(PAY[last]);q.ci();q.ci();a=q.p;q.ci();PAY[last]=PAY[last][:a]+ci(oldchild)+PAY[last][q.p:]
 u=bytearray(U)
 for e in EX:
  if e['index'] in PAY:e['offset']=len(u);e['size']=len(PAY[e['index']]);u+=PAY[e['index']]
 no=len(u)
 for s in N:
  b=s.encode('latin1')+b'\0';u+=ci(len(b))+b+struct.pack('<I',0x00070010)
 io=len(u)
 for e in IM:u+=ci(nm(e['package_class']))+ci(nm(e['class']))+struct.pack('<i',e['outer'])+ci(nm(e['name']))
 eo=len(u)
 for e in EX:
  u+=ci(e['class_ref'])+ci(e['super_ref'])+struct.pack('<i',e['outer'])+ci(nm(e['name']))+struct.pack('<I',e['flags'])+ci(e['size'])
  if e['size']:u+=ci(e['offset'])
 struct.pack_into('<6I',u,12,len(N),no,len(EX),eo,len(IM),io);g=struct.unpack_from('<I',u,52)[0]
 if g:struct.pack_into('<II',u,56+8*(g-1),len(EX),len(N))
 P.write_bytes(u);(R/'synthetic-map.json').write_text(json.dumps({'functions':list(FN),'new_exports':len(EX)-len(D['exports']),'new_names':len(N)-len(D['names']),'changed_exports':[EX[j-1]['path'] for j in PAY]},indent=2))
def blank_class(path):
 import uuid
 parent=idx('UICommonAPI');j=export(path,'Class',0,parent);EX[j-1]['class_ref']=0
 # Follow the existing helper class schema but remove members/dependencies/defaults.
 b=raw(D['exports'][API-1]);r=Reader(b)
 for _ in range(6):r.ci()
 r.p+=8;sz=struct.unpack_from('<I',b,r.p)[0];r.p+=4;assert sz==0
 state=b[r.p:r.p+22];r.p+=22;flags=b[r.p:r.p+4];r.p+=4+16
 for _ in range(r.ci()):r.ci();r.p+=8
 for _ in range(r.ci()):r.ci()
 within=r.ci();config=r.ci()
 PAY[j]=ci(parent)+ci(0)+ci(0)+ci(0)+ci(nm(path))+ci(0)+struct.pack('<iiI',-1,-1,0)+state+flags+uuid.uuid4().bytes_le+ci(0)+ci(0)+ci(within)+ci(config)+ci(0)+ci(nm('None'))
 return j
