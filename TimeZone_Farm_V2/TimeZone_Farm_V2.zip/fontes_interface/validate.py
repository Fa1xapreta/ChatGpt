from pathlib import Path
import sys,json,struct,ast,hashlib
R=Path(__file__).parent;B=R.parent;sys.path[:0]=[str(B/'inventory-preview'),str(B/'cloak-audit')];from xdat import Reader;from catalog_unreal import catalog
D=catalog(R/'output/system/interface.u');V=(R/'output/system/interface.u').read_bytes();C=catalog(B/'timezone79/output/system/interface.u');U=(B/'timezone79/output/system/interface.u').read_bytes();changed=[]
for a,b in zip(C['exports'],D['exports']):
 assert {k:a[k] for k in ['index','name','outer','class_ref','super_ref','flags']}=={k:b[k] for k in ['index','name','outer','class_ref','super_ref','flags']},a['path']
 if U[a['offset']:a['offset']+a['size']]!=V[b['offset']:b['offset']+b['size']]:changed.append(a['path'])
assert all(x=='TimeZoneWnd' or x.startswith('TimeZoneWnd.') for x in changed),changed
for e in D['exports']:
 for k in ['outer','class_ref','super_ref']:assert -len(D['imports'])<=e[k]<=len(D['exports'])
t=ast.parse((B/'inventory-preview/verify_test4.py').read_text());ns={'Reader':Reader,'struct':struct,'D':D,'refs':len(D['exports']),'imports':len(D['imports'])};exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Decoder'],type_ignores=[]),'decoder','exec'),ns)
class Verify(ns['Decoder']):
 def token(self):
  op=self.b[self.p]
  if op==0x11:
   self.starts.add(self.v);self.take(1)
   for _ in range(4):self.token()
   return
  if op in [0x40,0x41,0x42]:
   self.starts.add(self.v);self.take(1);self.token();self.token();self.token();return
  if op==0x43:self.starts.add(self.v);self.take(1);self.ci();self.ci(True);self.args();return
  if op==0x44:self.starts.add(self.v);self.take(1);self.ci(True);return
  if op==0x45:self.starts.add(self.v);self.take(1);self.token();self.token();return
  return super().token()
checks={}
for e in D['exports']:
 if e['class']!='Core.Function' or (e['index']<=len(C['exports']) and e['path'] not in changed):continue
 raw=V[e['offset']:e['offset']+e['size']];r=Reader(raw)
 for _ in range(7):r.ci()
 r.p+=8;size=struct.unpack_from('<I',raw,r.p)[0];r.p+=4;b=raw[r.p:-7];v=Verify(b)
 while v.p<len(b):v.token()
 assert v.v==size,(e['path'],v.v,size)
 assert set(v.jumps)<=v.starts,(e['path'],set(v.jumps)-v.starts)
 checks[e['path']]={'runtime_size':size,'branch_targets':len(v.jumps),'contexts':len(v.skips)}

print('PASS: isolated existing exports and',len(checks),'function bodies; branch targets valid')
(R/'output/VALIDACAO_BYTECODE.json').write_text(json.dumps({'changed_existing_exports':changed,'functions':checks,'other_existing_export_payloads_unchanged':True,'real_Windows_engine_run':False},indent=2))
