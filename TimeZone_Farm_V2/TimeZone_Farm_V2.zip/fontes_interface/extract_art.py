from pathlib import Path
import sys,json,zipfile
R=Path(__file__).parent;B=R.parent;sys.path[:0]=[str(B/'server-build34'),str(B/'cloak-audit')];from splitzip import SplitReader
s=SplitReader(json.loads((B/'timezone79/new-model-parts.json').read_text()));s.normalize_directory()
with zipfile.ZipFile(s) as z:data=z.read(next(p for p in z.infolist() if p.filename.endswith('/L2UI_CH3.u')))
source=(B/'timezone77/textures.py').read_text();a=source.index('data=Path(');z=source.index('# Tagged object/class references',a)
init='''
class Memory(catalog_unreal.Reader):
 def __init__(self,p):self.m=data;self.skip=0;self.key=None;self.format='raw'
 def close(self):pass
D=json.loads((R/'L2UI_CH3.u.catalog.json').read_text());m=Memory(None);E=D['exports'];names=D['names'];selected={e['index'] for e in E if e['class']=='Engine.Texture' and e['path'].startswith('TimeZoneWnd.')}
assert len(selected)==78
'''
source=source[:a]+init+source[z:];source=source.replace("p=R/'output/system/MUI_TZONE.u'","p=R/'output/system/MUI_TZART.u'");source=source.replace("R/'textures-report.json'","R/'art-extraction.json'")
(R/'output/system').mkdir(parents=True,exist_ok=True);exec(compile(source,str(R/'art_worker.py'),'exec'),{'__file__':str(R/'art_worker.py'),'data':data});s.close()
