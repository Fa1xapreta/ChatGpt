from pathlib import Path
import difflib,json
R=Path(__file__).parent;B=R.parent;O=R/'output/java';patches=[]
def read(p):
 try:return p.read_text()
 except UnicodeDecodeError:return p.read_text(encoding='cp1252')
def write(source,rel,change):
 old=read(source);new=change(old);assert new!=old,rel;p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);patches.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/java/'+rel,tofile='b/java/'+rel))
base='net/sf/l2j/gameserver/'
write(B/'gearscore54/output/java'/ (base+'GameServer.java'),base+'GameServer.java',lambda s:s.replace('net.sf.l2j.gameserver.gearscore.GearScoreService.getInstance().start();','net.sf.l2j.gameserver.gearscore.GearScoreService.getInstance().start();\n        net.sf.l2j.gameserver.timezone.TimeZoneFarm.getInstance();',1))
write(B/'target-hpcp75/output/java'/(base+'model/actor/instance/L2PcInstance.java'),base+'model/actor/instance/L2PcInstance.java',lambda s:s.replace('public void deleteMe()\n\t{','public void deleteMe()\n\t{\n        net.sf.l2j.gameserver.timezone.TimeZoneFarm.playerLogout(this);',1))
write(B/'timezone77/output/java'/(base+'custom/TimeZoneUI.java'),base+'custom/TimeZoneUI.java',lambda s:s.replace('if (command==null) return false;','if (command==null) return false;\n        if (net.sf.l2j.gameserver.timezone.TimeZoneFarm.getInstance().handle(player,command)) return true;',1))
zone=B/'gearscore54/current/java'/(base+'model/zone/type/L2TimeInstanceZone.java')
def protect(s):
 for signature in ['protected void onEnter(L2Character character)','protected void onExit(L2Character character)']:
  needle=signature+'\n\t{';assert needle in s;s=s.replace(needle,needle+'\n        if (character instanceof L2PcInstance && net.sf.l2j.gameserver.timezone.TimeZoneFarm.managesLocation(character.getX(),character.getY(),character.getZ())) return;',1)
 return s
write(zone,base+'model/zone/type/L2TimeInstanceZone.java',protect)
def protectManager(s):
 needle='public static void broadcastTimer(L2PcInstance player)\n    {';assert needle in s;s=s.replace(needle,needle+'\n        if (net.sf.l2j.gameserver.timezone.TimeZoneFarm.managesLocation(player.getX(),player.getY(),player.getZ())) return;',1)
 needle='.filter(player -> player.isInsideZone(ZoneId.TIME_INSTANCE_ZONE))';assert needle in s;s=s.replace(needle,'.filter(player -> player.isInsideZone(ZoneId.TIME_INSTANCE_ZONE) && !net.sf.l2j.gameserver.timezone.TimeZoneFarm.managesLocation(player.getX(),player.getY(),player.getZ()))',1);return s
write(B/'timezone77/output/java'/(base+'instancemanager/custom/TimeInstanceManager.java'),base+'instancemanager/custom/TimeInstanceManager.java',protectManager)
# This exact routing already shipped in the first TimeZone integration. Keep it for complete installation.
p=O/(base+'network/clientpackets/RequestBypassToServer.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(read(B/'timezone77/output/java'/(base+'network/clientpackets/RequestBypassToServer.java')))
write(R/'java-base/current/java'/(base+'network/clientpackets/EnterWorld.java'),base+'network/clientpackets/EnterWorld.java',lambda s:s.replace('activeChar.getTreasureHuntSession().recover();','net.sf.l2j.gameserver.timezone.TimeZoneFarm.playerLogin(activeChar);\n\t\tactiveChar.getTreasureHuntSession().recover();',1))
(R/'output/INTEGRACAO_CORE.patch').write_text(''.join(patches))
print('Core initialization/logout hooks, existing bridge and legacy-zone compatibility merged; HP/CP source preserved')
