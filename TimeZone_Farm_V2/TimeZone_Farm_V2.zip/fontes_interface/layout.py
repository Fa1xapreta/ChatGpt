from pathlib import Path
import sys,ast,struct,copy,json
R=Path(__file__).parent;B=R.parent;sys.path.insert(0,str(B/'inventory-preview'));from xdat import Reader,schema
exclude=['TabElement','ListElement','ComboBoxElement','Shortcut','WndDefPos','Action'];tree=ast.parse((B/'gearscore51/layout.py').read_text());exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['ci','st','value','node']],type_ignores=[]),'writer','exec'))
def parse(b):
 r=Reader(b);roots=[r.node('Window') for _ in range(r.i())];return roots,b[r.p:]
b=(B/'timezone79/output/system/interface.xdat').read_bytes();roots,tail=parse(b);main=copy.deepcopy(next(n for n in roots if n['fields']['name']=='TimeZoneWnd'));scroll=next(n for n in main['fields']['children'] if n['fields']['name']=='ScrollAreaWnd')
for i,renderer in enumerate(scroll['fields']['children']):
 f=renderer['fields'];children=f['children'];count=next(n for n in children if n['fields']['name']=='ItemCountText');name=next(n for n in children if n['fields']['name']=='ItemNameText');balance=copy.deepcopy(count)
 for n in [count,name,balance]:
  n['fields'].update(anchor=1,anchor_parent=1,anchor_this=1,anchor_ctrl='',size_absolute_values=1,offsetY=0,fontType=0,backTex='',textAlign=1,autosize=0,text='',unk7=1)
 name['fields'].update(anchor_x=46,anchor_y=280,size_absolute_width=196,size_absolute_height=16)
 count['fields'].update(anchor_x=46,anchor_y=298,size_absolute_width=74,size_absolute_height=15)
 balance['fields'].update(name='TZBalanceText',anchor_x=122,anchor_y=298,size_absolute_width=120,size_absolute_height=15,textColor=-9982721)
 children.append(balance)
 for n in children:
  q=n['fields'];k=q['name']
  if k=='ZoneImg_Tex':q.update(type=0,u=0.0,v=0.0,uSize=240.0,vSize=196.0,file='MUI_TZART.TimeZoneWnd.Normal_Special_field_17')
  if k=='TimeZoneTimeEditBox_Tex':q.update(file='L2UI_CH3.InventoryWnd.GroupBox_DF_Text',type=0,u=0.0,v=0.0,uSize=140.0,vSize=16.0,size_absolute_width=140,size_absolute_height=16,unk7=0)
  if k=='ZoneOpenTitle_Tex':q['file']='MUI_TZART.TimeZoneWnd.TitleBg'
  if k=='NeedItemSlotBG_Tex':q['file']='MUI_TZART.TimeZoneWnd.BigSlot'
  if k=='ItemNeedW':q.update(anchor_parent=1,anchor_this=1,anchor_ctrl='',anchor_x=7,anchor_y=279,noItemDrag=1,noSelectItem=1)
  if k=='TZHelp'+str(i+1):q.update(popupType='Text',popupValue=-9999,unk7=1,unk22=-1,unk23=0,unk24=0)
  if k=='ItemNameText':q['textColor']=-1
  if k=='TimeZoneTimeNow_Txt':q.update(text='00:00',fontType=0,offsetY=0,unk7=1)
  if k=='ZonePlayType_Text':q['unk7']=1
  if k=='ZoneOpenTitle_Text':q['text']='Daily'
# Keep the item row inside its existing strip, above the bottom buttons.
for renderer in scroll['fields']['children']:
 c={n['fields']['name']:n['fields'] for n in renderer['fields']['children']}
 assert c['ItemNeedW']['anchor_y']+34 < 319
 assert c['ItemCountText']['anchor_y']+15 < 319
 assert c['TZBalanceText']['anchor_y']+15 < 319
 assert c['ZoneImg_Tex']['uSize']==240 and c['ZoneImg_Tex']['vSize']==196
 assert c['TimeZoneTimeEditBox_Tex']['size_absolute_height']==16
 assert c['TZHelp'+str(int(renderer['fields']['name'][-1])+1)]['popupType']=='Text'
result=bytearray(struct.pack('<i',len(roots)))
for n in roots:result+=node(main,'Window') if n['fields']['name']=='TimeZoneWnd' else b[n['start']:n['end']]
result+=tail;(R/'output/system/interface.xdat').write_bytes(result);fresh,nt=parse(result);assert nt==tail
for a,z in zip(roots,fresh):
 if a['fields']['name']!='TimeZoneWnd':assert b[a['start']:a['end']]==result[z['start']:z['end']]
report={'basis':'first donor model structure and supplied reference video','only_changed_root':'TimeZoneWnd','unchanged_other_roots':len(roots)-1,'original_tail_preserved':True,'native_NWindow_texture_enum':{'Stretch':0,'Normal':1},'timer_bar_source_uv':[140,16],'scene_source_uv':[240,196],'cost_item_uses_native_inventory_tooltip':True,'four_drop_tooltip_buttons':True,'raw_original_scene_art':'MUI_TZART.u','HUD_original_anchor_and_sidebar_preserved':True,'windows_client_executed':False}
(R/'output/VALIDACAO_LAYOUT.json').write_text(json.dumps(report,indent=2));print('V2 card layout, explicit native Stretch enum, readable item amount/balance and original scene art installed')
