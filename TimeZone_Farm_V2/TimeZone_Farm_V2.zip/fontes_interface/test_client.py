from pathlib import Path
import sys,ast,json,copy,re,struct
R=Path(__file__).parent;B=R.parent;sys.path[:0]=[str(B/'hunting-audit30'),str(B/'cloak-audit')];import dump;from catalog_unreal import catalog
D=catalog(R/'output/system/interface.u');dump.D=D;dump.U=(R/'output/system/interface.u').read_bytes();CACHE={}
t=ast.parse((B/'gearscore69/test_bridge.py').read_text());exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='VM'],type_ignores=[]),'vm','exec'),globals());Base=VM
LOOK={e['path'].lower():e for e in D['exports']};PARAMS={}
sys.path.insert(0,str(B/'inventory-preview'));from xdat import Reader
for e in D['exports']:
 if e['class']!='Core.Function':continue
 r=Reader(dump.U[e['offset']:e['offset']+e['size']]);[r.ci() for _ in range(4)];first=r.ci();params=[]
 while first:
  q=D['exports'][first-1];z=Reader(dump.U[q['offset']:q['offset']+q['size']]);z.ci();z.ci();nxt=z.ci();flags=int.from_bytes(z.b[z.p+4:z.p+8],'little')
  if flags&0x80 and not flags&0x400:params.append(q['name'])
  first=nxt
 PARAMS[e['path']]=params
class VM(Base):
 def __init__(self):
  super().__init__();self.owner='TimeZoneWnd';self.characterId=500;self.tooltips={};self.objects.update(['TimeZoneWnd','SideBarWnd','InstanciasInfoExitWnd']);self.props['InstanciasInfoExitWnd.MainWnd']='InstanciasInfoExitWnd'
  for e in D['exports']:
   if e['class']=='Core.ArrayProperty' and e['path'].count('.')==1 and e['path'].startswith('TimeZoneWnd.'):self.props[e['path']]=[]
 def run(self,path,**params):
  old=self.owner;self.owner=path.split('.')[0]
  for e in D['exports']:
   if e['outer']==LOOK[path.lower()]['index'] and e['class']=='Core.StructProperty':self.props[e['path']]={}
  try:return super().run(path,**params)
  finally:self.owner=old
 def set(self,t,v):
  if t[0]=='0x37':
   a=self.ev(t[1]);a[v:]=[];kind='struct'
   if t[1][0] in ['0x0','0x1']:
    inner=LOOK.get((t[1][1]+'.Inner').lower());kind=inner['class'] if inner else 'struct'
   while len(a)<v:a.append(0 if kind=='Core.IntProperty' else '' if kind=='Core.StrProperty' else {'DrawList':[],'MinimumWidth':0} if t[1][0] in ['0x0','0x1'] and t[1][1].endswith('.TZTips') else {})
   return
  return super().set(t,copy.deepcopy(v) if isinstance(v,dict) else v)
 def ev(self,t,obj=None):
  if t[0]=='native' and int(t[1],16) in [0x90,0x91]:
   a,b=[self.ev(x) for x in t[2]];return a*b if int(t[1],16)==0x90 else int(a/b)
  if t[0]=='call':
   n=t[1]
   if n=='GetPlayerInfo':
    if self.characterId is None:return False
    self.set(t[2][0],{'nID':self.characterId});return True
   if n=='GearSplit':self.set(t[2][2],self.ev(t[2][0]).split(self.ev(t[2][1])));return
   if n=='FormatSeconds':v=int(self.ev(t[2][0]));return '%02d:%02d'%(v//60,v%60)
   if n=='Right':s,k=[self.ev(a) for a in t[2]];return s[-k:]
   if n=='GetItemInfo' and obj=='UIDATA_ITEM':self.set(t[2][1],{'ClassID':self.ev(t[2][0]),'IconName':'icon.test_'+str(self.ev(t[2][0]))});return True
   if n=='SetTooltipCustomType':self.tooltips[obj]=copy.deepcopy(self.ev(t[2][0]));return
   if n=='SetButtonName':self.ui[str(obj)+'.label']=self.ev(t[2][0]);return
   if n in ['EnableWindow','DisableWindow']:self.ui[str(obj)+'.enabled']=n=='EnableWindow';return
   if n=='SetTextColor':
    assert obj=='UIAPI_TEXTBOX';args=[self.ev(a) for a in t[2]];self.ui[args[0]+'.color']=copy.deepcopy(args[1]);return
   if n=='xxTimeLeft':self.calls.append((n,[self.ev(a) for a in t[2]]));self.ui['InstanciasInfoExitWnd.visible']=True;return
   if n=='ExecuteEvent':args=[self.ev(a) for a in t[2]];self.calls.append((n,args));return self.run('InstanciasInfoExitWnd.OnEvent',EventID=args[0],param=args[1])
   if n in ['TZOriginalLoad']:self.calls.append((n,[]));return
   path=(str(obj) if obj in self.objects else self.owner)+'.'+n
   if path.lower() in LOOK and LOOK[path.lower()]['class']=='Core.Function':
    path=LOOK[path.lower()]['path'];return self.run(path,**dict(zip(PARAMS[path],[self.ev(a) for a in t[2]])))
  return super().ev(t,obj)
 def packet(self,body,transport=140):self.run('TimeZoneWnd.OnEvent',EventID=transport,param=('Msg' if transport==140 else 'Payload')+'="CustomEvent=TimeZoneV2|'+body+'"')
 def ready(self):self.run('TimeZoneWnd.OnLoad');self.run('TimeZoneWnd.OnEnterState',PrevState='LoginState');self.run('InstanciasInfoExitWnd.OnLoad')

def row(token,slot,id,name,remaining=3600000):return 'Row|%s|%d|%d|%s|PVE|Media|1|80|%d|3600000|57|1000|Adena|20000|MUI_TZART.TimeZoneWnd.Normal_Special_field_17|Farm diario'%(token,slot,id,name,remaining)
def page(v,token='a',current=1,pages=1,ids=(11,12,13,14),version=1):
 v.packet('Begin|%s|%d|%d|%d|0|Time Zone|1|500|s1|%d'%(token,current,pages,4 if pages==1 else 5,version))
 for slot,id in enumerate(ids):
  v.packet(row(token,slot,id,'Farm '+str(id)));v.packet('Drop|%s|%d|57|Adena|1|100|Drop dos monstros'%(token,slot))
 v.packet('End|'+token)
tests=[]
v=VM();v.ready();page(v)
assert v.get('TimeZoneWnd.TZIds')==[11,12,13,14];assert not v.ui['TimeZoneWnd.PageNaviControl.visible']
for i in range(4):
 root='TimeZoneWnd.ScrollAreaWnd.itemRenderer0'+str(i);tip=v.tooltips[root+'.TZHelp'+str(i+1)]
 assert tip['MinimumWidth']==280 and len(tip['DrawList'])==6
 assert any(t.get('t_strText')=='Adena' for t in tip['DrawList']) and any(t.get('eType')==2 and t['u_strTexture']=='icon.test_57' for t in tip['DrawList'])
 assert v.ui[root+'.ItemCountText']=='x1,000' and v.ui[root+'.TZBalanceText']=='(20,000)'
 assert v.ui[root+'.TZEnter'+str(i+1)+'.enabled'] and v.ui[root+'.TZEnter'+str(i+1)+'.label']==423 and v.ui[root+'.TZExit'+str(i+1)+'.label']==1459;v.run('TimeZoneWnd.OnClickButton',BtnName='TZHelp'+str(i+1))
assert not any(n in ['LoadHtmlFromString','RequestBypassToServer','ShowWindowWithFocus'] for n,a in v.calls)
tests.append('actual row/drop native structs: four distinct zone ids, original item icons, description and 6 draw entries per tooltip, cost and inventory formatting, no HTML or charge on ?')
for i,id in enumerate([11,12,13,14]):
 v=VM();v.ready();page(v);v.run('TimeZoneWnd.OnClickButton',BtnName='TZEnter'+str(i+1));v.run('TimeZoneWnd.OnClickButtonWithHandle',aButtonHandle='TZEnter'+str(i+1));assert [a for n,a in v.calls if n=='RequestBypassToServer']==[['tz enter '+str(id)]]
tests.append('real callbacks use stable server zone IDs rather than visual slot indexes; duplicate callbacks blocked')
v=VM();v.ready();page(v,pages=2);assert v.ui['TimeZoneWnd.PageNaviControl.visible'];assert v.ui['TimeZoneWnd.PageNaviControl.ControlNavi_NextPageText']=='2';assert not v.ui['TimeZoneWnd.Prev_Btn.enabled']
v.run('TimeZoneWnd.OnClickButton',BtnName='Next_Btn');assert ('RequestBypassToServer',['tz page 2']) in v.calls
page(v,'b',2,2,(99,),2);assert v.get('TimeZoneWnd.TZIds')==[99,0,0,0];assert not v.ui['TimeZoneWnd.ScrollAreaWnd.itemRenderer01.visible'];assert not v.ui['TimeZoneWnd.Next_Btn.enabled'];assert v.ui['TimeZoneWnd.Prev_Btn.enabled']
tests.append('real pagination: 5 zones -> 2 pages; next request, only final-card renderer visible, boundaries disabled')
v=VM();v.ready();v.packet('Begin|new|1|1|4|0|Time Zone|1|500|s1|3');v.packet(row('old',0,999,'STALE'));v.packet('Drop|old|0|57|STALE|1|1|X');v.packet('End|old');assert v.get('TimeZoneWnd.TZLoading');assert v.get('TimeZoneWnd.TZIds')==[0,0,0,0]
v.packet(row('new',8,999,'INVALID SLOT'));assert v.get('TimeZoneWnd.TZIds')==[0,0,0,0]
v.packet('Begin|wrongOwner|1|1|1|0|X|1|501|s2|9');assert v.get('TimeZoneWnd.TZToken')=='new'
tests.append('stale row/drop/end tokens, invalid slots and another character owner are rejected before native rendering')
v=VM();v.ready();page(v,version=10);v.packet('Timer|11|125000|Farm 11|500|s1|11');assert v.ui['InstanciasInfoExitWnd.visible'];assert v.get('TimeZoneWnd.TZRemaining')[0]==125000;assert v.ui['TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TimeZoneTimeNow_Txt']=='02:05'
v.packet('Timer|0|0|Time Zone|500|s1|12');assert not v.ui['InstanciasInfoExitWnd.visible'];v.packet('Timer|11|124000|OLD|500|s1|11');assert not v.ui['InstanciasInfoExitWnd.visible'];assert v.get('TimeZoneWnd.TZActiveId')==0
v.packet('Timer|11|120000|Wrong session|500|s9|99');assert not v.ui['InstanciasInfoExitWnd.visible'];v.packet('Timer|11|120000|Wrong owner|501|s1|99');assert not v.ui['InstanciasInfoExitWnd.visible']
v.packet('Timer|12|119000|Farm 12|500|s1|13');assert v.ui['InstanciasInfoExitWnd.visible'];v.run('TimeZoneWnd.OnEvent',EventID=160,param='');assert not v.ui['InstanciasInfoExitWnd.visible'];v.packet('Timer|12|118000|Late after logout|500|s1|14');assert not v.ui['InstanciasInfoExitWnd.visible']
tests.append('actual timer consumes only matching zone UI; monotonic message versions prevent stale resurrection, wrong session/owner rejected, logout gates all late frames')
v=VM();v.ready();v.run('SideBarWnd.OnClickButton',param='btnRandomCraft');assert v.ui['TimeZoneWnd.visible'];v.run('SideBarWnd.OnClickButton',param='btnRandomCraft');assert not v.ui['TimeZoneWnd.visible'];v.run('InstanciasInfoExitWnd.OnClickButton',BtnName='BtnEspadas');v.run('InstanciasInfoExitWnd.OnClickButton',BtnName='BtnExit');assert not any(n=='RequestBypassToServer' for n,a in v.calls)
tests.append('original sidebar toggle remains; HUD clock has no click or teleport action')
(R/'output/TESTES_CLIENTE.json').write_text(json.dumps({'actual_bytecode_interpreted':True,'native_engine_inventory_lookups_and_tooltip_renderer_mocked':True,'scenarios':tests},indent=2));print('PASS:',len(tests),'V2 client behavior groups')
