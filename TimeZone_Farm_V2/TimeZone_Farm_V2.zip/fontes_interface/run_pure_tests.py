from pathlib import Path
import subprocess,json
R=Path(__file__).parent;B=R.parent
p=subprocess.run(['java','-jar',str(B/'gearscore50/tools/ecj.jar'),'-8','-encoding','UTF-8','-proc:none','-warn:none','-cp',str(R/'classes'),'-d',str(R/'classes'),str(R/'tests/TimeZoneLedgerRegression.java')],capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0
p=subprocess.run(['java','-cp',str(R/'classes'),'net.sf.l2j.gameserver.timezone.TimeZoneLedgerRegression',str(R/'output')],capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0
(R/'output/TESTES_CONTAGEM.json').write_text(json.dumps({'real_ledger_and_config_executed':True,'injected_wall_and_monotonic_timestamps':True,'result':p.stdout.strip(),'mysql_and_game_world_not_used_in_this_test':True},indent=2))
