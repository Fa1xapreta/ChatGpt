CREATE TABLE IF NOT EXISTS timezone_daily_usage (
  char_id INT NOT NULL,
  zone_id INT NOT NULL,
  period_start BIGINT NOT NULL,
  remaining_ms BIGINT NOT NULL,
  paid_period BIGINT NOT NULL DEFAULT 0,
  admitted TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (char_id, zone_id)
);
