package net.sf.l2j.gameserver.model.zone.type;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.L2ZoneType;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.timezone.TimeZoneDefinition;
import net.sf.l2j.gameserver.timezone.TimeZoneFarm;

/** Native region callbacks stop accounting at the actual area boundary. */
public final class L2TimeZoneFarmZone extends L2ZoneType
{
    private final TimeZoneDefinition definition;private final TimeZoneFarm manager;
    private final Set<Integer> flagged=ConcurrentHashMap.newKeySet();
    public L2TimeZoneFarmZone(int id,TimeZoneDefinition definition,TimeZoneFarm manager){super(id);this.definition=definition;this.manager=manager;}
    @Override protected void onEnter(L2Character character)
    {
        if(!(character instanceof L2PcInstance))return;L2PcInstance p=(L2PcInstance)character;
        if(manager.zoneEntered(p,definition.id)&&definition.pvp&&flagged.add(p.getObjectId()))p.setInsideZone(ZoneId.PVP,true);
    }
    @Override protected void onExit(L2Character character)
    {
        if(!(character instanceof L2PcInstance))return;L2PcInstance p=(L2PcInstance)character;
        if(flagged.remove(p.getObjectId()))p.setInsideZone(ZoneId.PVP,false);manager.zoneLeft(p,definition.id);
    }
    @Override public void onDieInside(L2Character character) { }
    @Override public void onReviveInside(L2Character character) { }
}
