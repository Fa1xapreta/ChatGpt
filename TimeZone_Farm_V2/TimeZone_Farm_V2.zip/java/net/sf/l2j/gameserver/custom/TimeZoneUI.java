package net.sf.l2j.gameserver.custom;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.instancemanager.custom.TimeInstanceManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;

/** UI transport for the pack's existing Time Instance; no new instance or reward system. */
public final class TimeZoneUI
{
    private TimeZoneUI() { }
    public static boolean handle(L2PcInstance player,String command)
    {
        if (command==null) return false;
        if (net.sf.l2j.gameserver.timezone.TimeZoneFarm.getInstance().handle(player,command)) return true;
        if (command.equals("lotusdk RefreshPassInfo")) { refresh(player);return true; }
        if (command.equals("lotusdk LotusEx")) { exit(player);return true; }
        if (command.equals("timezone_toggle"))
        {
            if (inside(player)) exit(player); else enter(player,1);
            return true;
        }
        if (command.startsWith("lotusdk LotusIN "))
        {
            String spot=command.substring("lotusdk LotusIN ".length());
            if (spot.matches("[1-4]")) enter(player,Integer.parseInt(spot));
            return true;
        }
        return false;
    }
    private static boolean inside(L2PcInstance player) { return player.isInsideZone(ZoneId.TIME_INSTANCE_ZONE); }
    private static void send(L2PcInstance player,String text) { player.sendPacket(new ExShowScreenMessage(text,1)); }
    public static void timer(L2PcInstance player,long millis,boolean inZone)
    {
        send(player,"CustomEvent=TimeZoneTimer|"+Math.min(Integer.MAX_VALUE,Math.max(0,millis))+"|"+(inZone?1:0));
    }
    public static void refresh(L2PcInstance player)
    {
        long millis=TimeInstanceManager.getRemainingMillis(player);
        Item item=ItemTable.getInstance().getTemplate(Config.TIME_INSTANCE_ITEM_ID_TO_ACESS);
        String itemName=item==null?"Item #"+Config.TIME_INSTANCE_ITEM_ID_TO_ACESS:item.getName().replace('|',' ');
        send(player,"CustomEvent=77750Refresh|"+(millis/1000)+"|"+Config.TIME_INSTANCE_ITEM_ID_TO_ACESS+"|"+Config.TIME_INSTANCE_ITEM_ID_TO_ACESS_COUNT+"|"+(inside(player)?1:0)+"|"+itemName+"|Spot 1|Spot 2|Spot 3|Spot 4");
        if (inside(player)) timer(player,millis,true);
    }
    private static boolean canMove(L2PcInstance player)
    {
        if (player.isAlikeDead() || player.isTeleporting() || player.isInCombat() || player.isInDuel()
            || player.isInOlympiadMode() || player.isInStoreMode() || player.isInObserverMode()
            || player.getActiveTradeList()!=null)
        { player.sendMessage("Voce nao pode usar o TimeZone neste momento.");return false; }
        return true;
    }
    private static void enter(L2PcInstance player,int spot)
    {
        synchronized(player)
        {
            if (!Config.TIME_INSTANCE_ENABLED) { player.sendMessage("O TimeZone esta desativado.");return; }
            if (!canMove(player)) return;
            if (!inside(player) && !player.isInsideZone(ZoneId.PEACE))
            { player.sendMessage("Entre no TimeZone a partir de uma cidade ou zona de paz.");return; }
            if (Config.TIME_INSTANCE_BLOCK_CLASS_LIST.contains(player.getClassId().getId()))
            { player.sendMessage("Sua classe nao pode entrar no TimeZone.");return; }
            // Existing daily counter and existing expiration remain authoritative.
            player.loadTimeInstanceData();
            boolean valid=TimeInstanceManager.checkPlayerTime(player);
            if (!valid)
            {
                if (player.getTimeInstanceCount()>=Config.TIME_INSTANCE_ENTER_LIMIT_COUNT)
                { player.sendMessage("Voce atingiu o limite diario de entradas.");return; }
                int count=Config.TIME_INSTANCE_ITEM_ID_TO_ACESS_COUNT;
                if (count<0 || Config.TIME_INSTANCE_ITEM_ID_TO_ACESS<=0)
                { player.sendMessage("Configuracao do ingresso TimeZone invalida.");return; }
                if (count>0 && !player.destroyItemByItemId("TimeZone",Config.TIME_INSTANCE_ITEM_ID_TO_ACESS,count,player,true))
                { player.sendMessage("Voce nao possui os itens necessarios para entrar.");return; }
                TimeInstanceManager.updatePlayerTime(player);
                if (!TimeInstanceManager.checkPlayerTime(player))
                {
                    if (count>0) player.addItem("TimeZoneRefund",Config.TIME_INSTANCE_ITEM_ID_TO_ACESS,count,player,true);
                    player.sendMessage("Nao foi possivel registrar o acesso ao TimeZone.");return;
                }
                player.setTimeInstanceCount(player.getTimeInstanceCount()+1);
                player.updateTimeInstanceData();
            }
            player.setInstanceEnter(true);
            switch (spot)
            {
                case 1:player.teleToLocation(Config.TIME_INSTANCE_AREA_LOC_1,0);break;
                case 2:player.teleToLocation(Config.TIME_INSTANCE_AREA_LOC_2,0);break;
                case 3:player.teleToLocation(Config.TIME_INSTANCE_AREA_LOC_3,0);break;
                case 4:player.teleToLocation(Config.TIME_INSTANCE_AREA_LOC_4,0);break;
                default:return;
            }
            refresh(player);
        }
    }
    private static void exit(L2PcInstance player)
    {
        synchronized(player)
        {
            if (!inside(player) || !canMove(player)) return;
            player.teleToLocation(81337,148093,-3473,0);
            player.setIsInTimeInstance(false);
            timer(player,TimeInstanceManager.getRemainingMillis(player),false);
            refresh(player);
        }
    }
}
