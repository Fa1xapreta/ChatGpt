package net.sf.l2j.gameserver.timezone;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.l2j.L2DatabaseFactory;

/** This module owns only timezone_daily_usage. No existing event table is modified. */
public final class TimeZoneStore
{
    public void initialize(boolean create) throws Exception
    {
        try(Connection c=L2DatabaseFactory.getInstance().getConnection();Statement s=c.createStatement())
        {
            if(create)s.executeUpdate("CREATE TABLE IF NOT EXISTS timezone_daily_usage (char_id INT NOT NULL,zone_id INT NOT NULL,period_start BIGINT NOT NULL,remaining_ms BIGINT NOT NULL,paid_period BIGINT NOT NULL DEFAULT 0,admitted TINYINT NOT NULL DEFAULT 0,PRIMARY KEY(char_id,zone_id))");
            try(ResultSet ignored=s.executeQuery("SELECT char_id,zone_id,period_start,remaining_ms,paid_period,admitted FROM timezone_daily_usage WHERE 1=0")) { }
        }
    }
    public List<TimeZoneLedger.Snapshot> load(int charId) throws Exception
    {
        List<TimeZoneLedger.Snapshot> rows=new ArrayList<>();
        try(Connection c=L2DatabaseFactory.getInstance().getConnection();PreparedStatement s=c.prepareStatement("SELECT zone_id,period_start,remaining_ms,paid_period,admitted FROM timezone_daily_usage WHERE char_id=?"))
        {
            s.setInt(1,charId);try(ResultSet r=s.executeQuery()){while(r.next())rows.add(new TimeZoneLedger.Snapshot(r.getInt(1),r.getLong(2),r.getLong(3),r.getLong(4),r.getBoolean(5)));}
        }
        return rows;
    }
    public void save(int charId,Collection<TimeZoneLedger.Snapshot> rows) throws Exception
    {
        if(rows.isEmpty())return;
        try(Connection c=L2DatabaseFactory.getInstance().getConnection())
        {
            boolean auto=c.getAutoCommit();c.setAutoCommit(false);
            try(PreparedStatement s=c.prepareStatement("INSERT INTO timezone_daily_usage (char_id,zone_id,period_start,remaining_ms,paid_period,admitted) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE period_start=VALUES(period_start),remaining_ms=VALUES(remaining_ms),paid_period=VALUES(paid_period),admitted=VALUES(admitted)"))
            {
                for(TimeZoneLedger.Snapshot r:rows){s.setInt(1,charId);s.setInt(2,r.zoneId);s.setLong(3,r.period);s.setLong(4,r.remainingMillis);s.setLong(5,r.paidPeriod);s.setBoolean(6,r.admitted);s.addBatch();}
                s.executeBatch();c.commit();
            }
            catch(Exception e){c.rollback();throw e;}
            finally{c.setAutoCommit(auto);}
        }
    }
}
