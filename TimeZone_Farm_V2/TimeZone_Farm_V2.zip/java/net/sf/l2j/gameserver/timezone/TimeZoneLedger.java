package net.sf.l2j.gameserver.timezone;

import java.util.LinkedHashMap;
import java.util.Map;

/** Pure accounting: daily budget per character/zone, monotonic time only while active. */
public final class TimeZoneLedger
{
    public static final class Snapshot
    {
        public final int zoneId;public final long period,remainingMillis,paidPeriod;public final boolean admitted;
        public Snapshot(int zoneId,long period,long remaining,long paidPeriod,boolean admitted)
        { this.zoneId=zoneId;this.period=period;remainingMillis=remaining;this.paidPeriod=paidPeriod;this.admitted=admitted; }
    }
    private static final class Budget
    {
        long period,remaining,paid;boolean admitted;
        Budget(Snapshot s){period=s.period;remaining=s.remainingMillis;paid=s.paidPeriod;admitted=s.admitted;}
    }
    private final TimeZoneConfig config;
    private final Map<Integer,Budget> budgets=new LinkedHashMap<>();
    private int active;
    private long lastNanos,revision;
    public TimeZoneLedger(TimeZoneConfig config,Iterable<Snapshot> saved)
    { this.config=config;for(Snapshot s:saved)budgets.put(s.zoneId,new Budget(s)); }
    private Budget budget(TimeZoneDefinition zone,long wall)
    {
        Budget b=budgets.get(zone.id);long period=config.periodStart(wall);
        if(b==null){b=new Budget(new Snapshot(zone.id,period,zone.dailyMillis(),0,false));budgets.put(zone.id,b);revision++;}
        if(period>b.period)
        {
            b.period=period;b.remaining=zone.dailyMillis();b.paid=0;b.admitted=active==zone.id;revision++;
        }
        if(b.remaining<0||b.remaining>zone.dailyMillis()){b.remaining=Math.min(zone.dailyMillis(),Math.max(0,b.remaining));revision++;}
        return b;
    }
    public synchronized void update(long wall,long nanos)
    {
        if(active==0)return;TimeZoneDefinition z=config.byId.get(active);if(z==null)return;
        Budget old=budgets.get(active);long oldPeriod=old.period;
        long elapsed=Math.max(0L,nanos-lastNanos),millis=elapsed/1000000L;
        Budget b=budget(z,wall);
        if(b.period>oldPeriod)
        {
            millis=Math.min(millis,Math.max(0L,wall-b.period));lastNanos=nanos;
        }
        else lastNanos+=millis*1000000L;
        if(millis>0&&b.remaining>0){b.remaining=Math.max(0,b.remaining-millis);revision++;}
    }
    public synchronized Snapshot view(TimeZoneDefinition zone,long wall,long nanos)
    { update(wall,nanos);Budget b=budget(zone,wall);return copy(zone.id,b); }
    public synchronized boolean needsPayment(TimeZoneDefinition zone,long wall,long nanos)
    { Snapshot s=view(zone,wall,nanos);return zone.costCount>0&&(zone.chargeOnReentry||s.paidPeriod!=s.period); }
    public synchronized void admit(TimeZoneDefinition zone,long wall,long nanos)
    {
        if(view(zone,wall,nanos).remainingMillis<=0)throw new IllegalStateException("No daily time remaining");
        Budget b=budget(zone,wall);b.admitted=true;b.paid=b.period;revision++;
    }
    public synchronized boolean start(TimeZoneDefinition zone,long wall,long nanos)
    {
        Snapshot s=view(zone,wall,nanos);if(!s.admitted||s.remainingMillis<=0)return false;
        if(active!=0&&active!=zone.id)return false;
        if(active==0){active=zone.id;lastNanos=nanos;revision++;}return true;
    }
    public synchronized void stop(long wall,long nanos,boolean keepAdmission)
    {
        update(wall,nanos);if(active!=0){Budget b=budgets.get(active);if(!keepAdmission)b.admitted=false;active=0;revision++;}
    }
    public synchronized void revoke(int zoneId)
    { Budget b=budgets.get(zoneId);if(b!=null&&b.admitted){b.admitted=false;revision++;} }
    public synchronized void restore(Snapshot s)
    { if(active==s.zoneId)active=0;budgets.put(s.zoneId,new Budget(s));revision++; }
    public synchronized int activeId(){return active;}
    public synchronized long revision(){return revision;}
    public synchronized Map<Integer,Snapshot> snapshots(long wall,long nanos)
    {
        update(wall,nanos);Map<Integer,Snapshot> out=new LinkedHashMap<>();
        for(Map.Entry<Integer,Budget> e:budgets.entrySet())out.put(e.getKey(),copy(e.getKey(),e.getValue()));return out;
    }
    private static Snapshot copy(int id,Budget b){return new Snapshot(id,b.period,b.remaining,b.paid,b.admitted);}
}
