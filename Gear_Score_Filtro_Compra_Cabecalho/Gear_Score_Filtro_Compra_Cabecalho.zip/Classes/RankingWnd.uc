class RankingWnd extends MileniumGearScore;
var bool GSDragging;
var int GSWindowX, GSWindowY, GSMouseX, GSMouseY;

const TREE_BTN_WIDTH = 731;
const TREE_BTN_HEIGHT = 48;

var WindowHandle zz_Me;

var TextureHandle zz_RaceTex;
var TextureHandle zz_ClassTex;
var TextureHandle zz_ClanTex;

var TextBoxHandle zz_NickName;
var TextBoxHandle zz_ClassName;
var TextBoxHandle zz_ClanName;

var EditBoxHandle zz_SearchBox;
var ButtonHandle zz_SearchButton;

var TextBoxHandle zz_GearScoreRank;
var TextBoxHandle zz_GearScoreRankDiff;
var TextureHandle zz_GearScoreRankDiffTex;

var TextBoxHandle zz_PvPScoreRank;
var TextBoxHandle zz_PvPScoreRankDiff;
var TextureHandle zz_PvPScoreRankDiffTex;

var TreeHandle GearScoreTree;

var int zz_PlayerGearRank;
var int zz_PlayerGearRankingDiff;
var array<PlayerRankingInfo> GearScoreList;

var TreeHandle PvPScoreTree;

var int zz_PlayerPvPRank;
var int zz_PlayerPvPRankingDiff;
var array<PlayerRankingInfo> PvPScoreList;

var string zz_InspectPlayerName;

function array<int> GetGearScoreTableOffsets() {
    local array<int> arr;

    arr[0] = 0;
    arr[1] = 101;
    arr[2] = 321;
    arr[3] = 451;
    arr[4] = 586;
    arr[5] = 731;
    arr[6] = 731;

    return arr;
}

function OnLoad() {
    zz_Me = xxGetWindowHandle("RankingWnd");

    zz_RaceTex = xxGetTextureHandle("RankingWnd.top_info.player_race_tex");
    zz_ClassTex = xxGetTextureHandle("RankingWnd.top_info.player_class_tex");
    zz_ClanTex = xxGetTextureHandle("RankingWnd.top_info.player_clan_tex");

    zz_NickName = xxGetTextBoxHandle("RankingWnd.top_info.player_name");
    zz_ClassName = xxGetTextBoxHandle("RankingWnd.top_info.player_class");
    zz_ClanName = xxGetTextBoxHandle("RankingWnd.top_info.player_clan_name");

    zz_SearchBox = xxGetEditBoxHandle("RankingWnd.boxSearch");
    zz_SearchButton = xxGetButtonHandle("RankingWnd.btnSearch");

    zz_GearScoreRank = xxGetTextBoxHandle("RankingWnd.gear_score_wnd.gear_score_self_info.self_global_rank");
    zz_GearScoreRankDiff = xxGetTextBoxHandle("RankingWnd.gear_score_wnd.gear_score_self_info.self_global_rank_diff");
    zz_GearScoreRankDiffTex = xxGetTextureHandle("RankingWnd.gear_score_wnd.gear_score_self_info.self_global_rank_diff_tex");

    zz_PvPScoreRank = xxGetTextBoxHandle("RankingWnd.pvp_score_wnd.pvp_score_self_info.self_global_rank");
    zz_PvPScoreRankDiff = xxGetTextBoxHandle("RankingWnd.pvp_score_wnd.pvp_score_self_info.self_global_rank_diff");
    zz_PvPScoreRankDiffTex = xxGetTextureHandle("RankingWnd.pvp_score_wnd.pvp_score_self_info.self_global_rank_diff_tex");

    GearScoreTree = class'TreeHandle'.static.Inst();
    PvPScoreTree = class'TreeHandle'.static.Inst();

    GearScoreTree.Init("RankingWnd.gear_score_wnd.gear_score_list", "tree_gear", TREE_BTN_WIDTH, TREE_BTN_HEIGHT, GetGearScoreTableOffsets());
    PvPScoreTree.Init("RankingWnd.pvp_score_wnd.pvp_score_list", "tree_pvp", TREE_BTN_WIDTH, TREE_BTN_HEIGHT, GetGearScoreTableOffsets());
}

function OnClickButtonWithHandle(ButtonHandle zz_Handle) {
    if (zz_Handle!=None && Right(zz_Handle.GetWindowName(),8)=="btnClose") { HideWindow("InspectWnd"); HideWindow("RankingWnd"); return; }

    switch( zz_Handle ) {
        case zz_SearchButton:
            xxInspectPlayer();
            break;
    }
}

function OnHide() {
    StopGSDrag();

    HideWindow("InspectWnd");
}

function OnLButtonUp(WindowHandle zz_WindowHandle, int zz_X, int zz_Y)
{
    StopGSDrag();

    local Rect zz_RectMe, zz_RectList;

    switch( zz_WindowHandle.GetWindowName() )
    {
        case "gear_score_list":
        case "pvp_score_list":
            zz_RectMe = zz_Me.GetRect();
            zz_RectList = zz_WindowHandle.GetRect();

            if( zz_X - zz_RectMe.nX >= 727 && zz_X - zz_RectMe.nX <= 755 && zz_InspectPlayerName != "") {
                zz_SearchBox.SetString(zz_InspectPlayerName);
                xxInspectPlayer();
            }

            zz_InspectPlayerName = "";
            break;
    }
}

function OnClickButton(string zz_BtnName) {
    if (Right(zz_BtnName,8)=="btnClose") { HideWindow("InspectWnd"); HideWindow("RankingWnd"); return; }

    xxInspectPlayerByName(zz_BtnName);
}

function xxInspectAndOpenRankingByName(string zz_PlayerName) {
    if(zz_PlayerName != "") {
        zz_SearchBox.SetString(zz_PlayerName);
        xxInspectPlayer();
    }
}

function xxInspectPlayerByName(string zz_Param) {
    local int zz_Index;
    local string zz_PlayerName;

    zz_Index = InStr(zz_Param, "_PlayerName_");

    if(zz_Index > 0) {
        zz_PlayerName = Mid((zz_Param), zz_Index + len("_PlayerName_"), len(zz_Param));

        if(zz_PlayerName != "") {
            // zz_SearchBox.SetString(zz_PlayerName);
            // xxInspectPlayer();

            zz_InspectPlayerName = zz_PlayerName;
        }
    }
}

function xxInspectPlayer() {
    local string zz_InspectName;

    zz_InspectName = zz_SearchBox.GetString();

    if(zz_InspectName != "")
        xxtoServer("InspectPlayer?name=" $ zz_InspectName);
}

function OnGearScoreListAdd(int PlayerRank, int PlayerRankingDiff, array<PlayerRankingInfo> List) {
    zz_PlayerGearRank = PlayerRank;
    zz_PlayerGearRankingDiff = PlayerRankingDiff;
    GearScoreList = List;

    // GoToState('UpdateRanking'); // Todo Remover dessa parte, deixar apenas no ultimo pacote recebido
}

function OnPvPScoreListAdd(int PlayerRank, int PlayerRankingDiff, array<PlayerRankingInfo> List) {
    zz_PlayerPvPRank = PlayerRank;
    zz_PlayerPvPRankingDiff = PlayerRankingDiff;
    PvPScoreList = List;

    GoToState('UpdateRanking');
}

function bool xxSetRankingData() {
    local UserInfo zz_Player;
	local texture zz_CrestTexture;
    local int i;

    if(!GetPlayerInfo(zz_Player)) return false;

    // zz_RaceTex.SetTexture("MUI_GEAR.RankingWnd.RaceMark_Human");

    zz_NickName.SetText( zz_Player.Name );

    zz_ClassName.SetText( GetClassType( zz_Player.nSubClass ) );
    zz_ClassTex.SetTexture( xxGetDetailedClassIconName( zz_Player.nSubClass, 2 ) );

    if( zz_Player.nClanID > 0 ) {
        zz_ClanName.SetText( GetClanName( zz_Player.nClanID ) );

        if( class'UIDATA_CLAN'.static.GetCrestTexture(zz_Player.nClanID, zz_CrestTexture) )
            zz_ClanTex.SetTextureWithObject( zz_CrestTexture );
        else
            zz_ClanTex.SetTexture("MUI_GEAR.etc.textbackline");
    }else {
        zz_ClanName.SetText("");
        zz_ClanTex.SetTexture("");
    }

    xxSetSelfScoreRank( zz_PlayerGearRank, zz_PlayerGearRankingDiff, zz_GearScoreRank, zz_GearScoreRankDiff, zz_GearScoreRankDiffTex );
    xxSetSelfScoreRank( zz_PlayerPvPRank, zz_PlayerPvPRankingDiff, zz_PvPScoreRank, zz_PvPScoreRankDiff, zz_PvPScoreRankDiffTex );

    GearScoreTree.Reset();

    for( i = 0; i < GearScoreList.Length; i++ )
    {
        xxAddPlayerOnList(i, GearScoreTree, GearScoreList[i]);
    }

    PvPScoreTree.Reset();

    for( i = 0; i < PvPScoreList.Length; i++ )
    {
        xxAddPlayerOnList(i, PvPScoreTree, PvPScoreList[i]);
    }

    class'UIAPI_TREECTRL'.static.SetExpandedNode("RankingWnd.gear_score_wnd.gear_score_list", "tree_gear", true);
    class'UIAPI_TREECTRL'.static.SetExpandedNode("RankingWnd.pvp_score_wnd.pvp_score_list", "tree_pvp", true);
    return true;
}

function xxSetSelfScoreRank(int zz_PlayerRank, int zz_PlayerRankingDiff, TextBoxHandle zz_ScoreRank, TextBoxHAndle zz_ScoreRankDiff, TextureHandle zz_ScoreRankDiffTex) {
    local string BasePath;
    local color RankColor;
    local string Arrow;
    if (zz_ScoreRank == zz_GearScoreRank)
        BasePath = "RankingWnd.gear_score_wnd.gear_score_self_info.";
    else
        BasePath = "RankingWnd.pvp_score_wnd.pvp_score_self_info.";
    if (zz_PlayerRank > 0)
        class'UIAPI_TEXTBOX'.static.SetText(BasePath $ "self_global_rank", "Rank  " $ zz_PlayerRank);
    else
        class'UIAPI_TEXTBOX'.static.SetText(BasePath $ "self_global_rank", "Rank  -");
    if (zz_PlayerRankingDiff != 0)
        class'UIAPI_TEXTBOX'.static.SetText(BasePath $ "self_global_rank_diff", "Rank  " $ zz_PlayerRankingDiff);
    else
        class'UIAPI_TEXTBOX'.static.SetText(BasePath $ "self_global_rank_diff", "Rank  -");
    RankColor = GearColorRGBA(223, 215, 200, 255);
    if (zz_PlayerRankingDiff < 0) { RankColor = Red; Arrow = "MUI_GEAR.RankingWnd.RankingWnd_ArrowDown"; }
    else if (zz_PlayerRankingDiff > 0) { RankColor = Blue; Arrow = "MUI_GEAR.RankingWnd.RankingWnd_ArrowUp"; }
    class'UIAPI_TEXTBOX'.static.SetTextColor(BasePath $ "self_global_rank", RankColor);
    class'UIAPI_TEXTBOX'.static.SetTextColor(BasePath $ "self_global_rank_diff", RankColor);
    TextureHandle(GetHandle(BasePath $ "self_global_rank_diff_tex")).SetTexture(Arrow);
}
function xxAddPlayerOnList(int Index, TreeHandle TreeHandle, PlayerRankingInfo Player) {
    local string NodeName;

    NodeName = TreeHandle.InsertNode( Index + 1 $ "_PlayerName_" $ Player.Name);

    GearRowBackground(TreeHandle, NodeName, Index);

    // 1 - PosiÃ§Ãµes, Icone para os 5 primeiros do rank, NumeraÃ§Ã£o para o restante do rank
    if(Index < 5)
        TreeHandle.InsertTexture( NodeName, "MUI_GEAR.RankingWnd.RankingWnd_" $ Index + 1, "", 38, 33, 0, "CenterLeft", "CenterLeft", 10, 0, true, true);
    else
        TreeHandle.InsertText( NodeName, Index + 1, 0, "CenterLeft", "CenterLeft", 22, 0, getInstanceL2Util().Gold, true, true);

    // IndicaÃ§Ã£o do numero de posiÃ§Ãµes que o player caiu, subiu ou se manteve no rank
    if(Player.RankingDiff < 0) {
        TreeHandle.InsertTexture( NodeName, "MUI_GEAR.RankingWnd.RankingWnd_ArrowDown", "", 8, 7, 0, "CenterLeft", "CenterLeft", 7, 0);
        TreeHandle.InsertText( NodeName, Player.RankingDiff, 0, "CenterLeft", "CenterLeft", 5, 0, getInstanceL2Util().Red);
    }else if(Player.RankingDiff > 0) {
        TreeHandle.InsertTexture( NodeName, "MUI_GEAR.RankingWnd.RankingWnd_ArrowUp", "", 8, 7, 0, "CenterLeft", "CenterLeft", 7, 0);
        TreeHandle.InsertText( NodeName, Player.RankingDiff, 0, "CenterLeft", "CenterLeft", 5, 0, getInstanceL2Util().Blue);
    }else {
        TreeHandle.InsertText( NodeName, "-", 0, "CenterLeft", "CenterLeft", 5, 0, getInstanceL2Util().Gold);
    }

    // 2 - Nome e Classe
    TreeHandle.InsertText( NodeName, Player.Name, 1, "CenterLeft", "CenterLeft", 15, -9, GearColorRGBA(254, 215, 160, 255), true, true);

    TreeHandle.InsertText( NodeName, GetClassType(Player.ClassID), 1, "CenterLeft", "CenterLeft", 15, 9, GearColorRGBA(132, 132, 132, 255), true, true);


    // 3 - Ãcone de classe
    TreeHandle.InsertTexture( NodeName, xxGetDetailedClassIconName( Player.ClassID, 1 ), "", 32, 43, 2, "Center", "Center", 0, 0, true, true);


    // 4 - Nome do clan
    TreeHandle.InsertText( NodeName, Player.ClanName, 3, "CenterLeft", "CenterLeft", 15, 0, GearColorRGBA(182, 182, 182, 255), true, true);

    // 5 - Gear Score
    TreeHandle.InsertText( NodeName, Player.Score, 4, "Center", "Center", 0, 0, getInstanceL2Util().Yellow03, true, true);

    // 6 - BotÃ£o Inspect
    GearSearchButton(TreeHandle, NodeName);

}

state UpdateRanking {
	function OnTick() {
        if(xxSetRankingData())
            zz_Me.ShowWindow();

        GoToState('');
	}
}



function OnShow()
{
    GetHandle("RankingWnd.Container").SetWindowSize(796,20);
    GetHandle("RankingWnd.Container").ShowWindow();

    class'UIAPI_TABCTRL'.static.InitTabCtrl("RankingWnd.main_tab_score");
    class'UIAPI_TABCTRL'.static.SetTopOrder("RankingWnd.main_tab_score", 0, true);
    class'UIAPI_TABCTRL'.static.InitTabCtrl("RankingWnd.gear_score_wnd.gear_score_tab");
    class'UIAPI_TABCTRL'.static.SetTopOrder("RankingWnd.gear_score_wnd.gear_score_tab", 0, true);
    class'UIAPI_TABCTRL'.static.InitTabCtrl("RankingWnd.pvp_score_wnd.pvp_score_tab");
    class'UIAPI_TABCTRL'.static.SetTopOrder("RankingWnd.pvp_score_wnd.pvp_score_tab", 0, true);
    GetHandle("RankingWnd.GearLabel_main_tab_score_0").EnableWindow();
    GetHandle("RankingWnd.GearLabel_main_tab_score_0").SetAlpha(255);
    class'UIAPI_TEXTBOX'.static.SetTextColor("RankingWnd.GearLabel_main_tab_score_0", GearColorRGBA(223,215,200,255));
    GetHandle("RankingWnd.GearLabel_main_tab_score_1").EnableWindow();
    GetHandle("RankingWnd.GearLabel_main_tab_score_1").SetAlpha(255);
    class'UIAPI_TEXTBOX'.static.SetTextColor("RankingWnd.GearLabel_main_tab_score_1", GearColorRGBA(223,215,200,255));
    GetHandle("RankingWnd.gear_score_wnd.GearLabel_gear_score_tab_0").EnableWindow();
    GetHandle("RankingWnd.gear_score_wnd.GearLabel_gear_score_tab_0").SetAlpha(255);
    class'UIAPI_TEXTBOX'.static.SetTextColor("RankingWnd.gear_score_wnd.GearLabel_gear_score_tab_0", GearColorRGBA(223,215,200,255));
    GetHandle("RankingWnd.pvp_score_wnd.GearLabel_pvp_score_tab_0").EnableWindow();
    GetHandle("RankingWnd.pvp_score_wnd.GearLabel_pvp_score_tab_0").SetAlpha(255);
    class'UIAPI_TEXTBOX'.static.SetTextColor("RankingWnd.pvp_score_wnd.GearLabel_pvp_score_tab_0", GearColorRGBA(223,215,200,255));
}

function StopGSDrag()
{
    GSDragging = false;
    GetHandle("RankingWnd").KillTimer(9164001);
}
function OnLButtonDown(WindowHandle Handle, int X, int Y)
{
    local vector Pointer;
    local Rect Bounds;
    StopGSDrag();
    Pointer = class'HudPortraitNative'.static.GetPointerState();
    if (Pointer.Z < 0.5) return;
    Bounds = GetHandle("RankingWnd").GetRect();
    if (int(Pointer.X) < Bounds.nX || int(Pointer.X) >= Bounds.nX + Bounds.nWidth - 24
        || int(Pointer.Y) < Bounds.nY || int(Pointer.Y) >= Bounds.nY + 24) return;
    GSWindowX = Bounds.nX; GSWindowY = Bounds.nY;
    GSMouseX = int(Pointer.X); GSMouseY = int(Pointer.Y);
    GetHandle("RankingWnd").ClearAnchor();
    GetHandle("RankingWnd").MoveTo(Bounds.nX, Bounds.nY);
    GetHandle("RankingWnd").SetDraggable(false);
    GSDragging = true;
    GetHandle("RankingWnd").SetFocus();
    GetHandle("RankingWnd").SetTimer(9164001,16);
}
function OnTimer(int TimerID)
{
    local vector Pointer;
    if (TimerID != 9164001) return;
    if (!GSDragging || !GetHandle("RankingWnd").IsShowWindow()) { StopGSDrag(); return; }
    Pointer = class'HudPortraitNative'.static.GetPointerState();
    if (Pointer.Z < 0.5) { StopGSDrag(); return; }
    GetHandle("RankingWnd").MoveTo(GSWindowX + int(Pointer.X) - GSMouseX,
        GSWindowY + int(Pointer.Y) - GSMouseY);
}

defaultproperties
{
}
