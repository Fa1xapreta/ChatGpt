class TargetStatusWnd extends UICommonAPI;

const CONTRACT_HEIGHT = 58;
const EXPAND_HEIGHT = 102;

var bool m_bExpand;
var WindowHandle Me;
var WindowHandle TargetHeader;
var WindowHandle TargetHeaderPlayer;
var ButtonHandle btnExpand;
var ButtonHandle btnContract;
var int NpcHeaderRequestedId;
var int NpcHeaderResponseId;
var bool bHideTownNpcHeader;
var int m_TargetLevel;
var int m_targetID;
var bool m_bShow;
var bool testtar;
var int TargetClassId;
var int TargetLevel;
var int TargetFlag;
var int i_LastCurHP;
var int i_LastMaxHP;
var int i_LastCurCP;
var int i_LastMaxCP;
var bool zzshowHeader;
var Pawn TargetPawn;
var class<Emitter> zztargetEmitterClass;
var Emitter zzdecalEmitter;
var Texture targetTexture;
var Texture targetTexturenpc;
var string targetnpct;
var string targetplayert;
var string targetpkt;
var bool DragState;
var Rect GlobalClick;
var TargetHeaderPlayer zzscripttarget;

function OnLoad()
{
	GetINIString("PatchSettings", "TargetTextNpc", targetnpct, "PatchSettings");
	GetINIString("PatchSettings", "TargetTextPlayer", targetplayert, "PatchSettings");
	GetINIString("PatchSettings", "TargetTextPk", targetpkt, "PatchSettings");

    RegisterEvent(140);
    RegisterEvent(88521);
    RegisterEvent(980);
    RegisterEvent(990);
    RegisterEvent(230);
    RegisterEvent(190);
    RegisterEvent(210);
    RegisterEvent(240);
    RegisterEvent(200);
    RegisterEvent(220);
    RegisterEvent(300);
    Me = GetHandle("TargetStatusWnd");
	zzscripttarget = TargetHeaderPlayer(GetScript("TargetHeaderPlayer"));
    TargetHeader = GetHandle("TargetHeader");
	TargetHeaderPlayer = GetHandle("TargetHeaderPlayer");
    btnExpand = ButtonHandle(GetHandle("TargetStatusWnd.btnExpand"));
    btnContract = ButtonHandle(GetHandle("TargetStatusWnd.btnContract"));
    m_bShow = false;
    m_targetID = -1;
       zztargetEmitterClass = class<Emitter>(DynamicLoadObject("OMGzOMGEffect.target_region_decal", Class'Core.Class'));
	//	zztargetEmitterClass = class < Emitter > (DynamicLoadObject("LotusEffect.target_region_decal", class'Class'));
targetTexturenpc = Texture(DynamicLoadObject(targetnpct, class'Texture'));
    return;
}

function GetTexture(UserInfo info)
{
  //  GetPlayerInfo(info);

    targetTexture = Texture(DynamicLoadObject(targetplayert, class'Texture'));

    if (info.nLevel == 50)
    {
        targetTexture = Texture(DynamicLoadObject(targetplayert, class'Texture'));
    }

    if (info.nCriminalRate > 0)
    {
        targetTexture = Texture(DynamicLoadObject(targetpkt, class'Texture'));
    }

}

function OnShow()
{
    m_bShow = true;
    return;
}

function OnHide()
{
    m_bShow = false;

xxRemoveHPHeader();
        xxApplyEffectTarget(true);
		TargetPawn = none;
 
    return;
}

function OnExitState(name a_PreStateName)
{
    xxRemoveHPHeader();
    TargetPawn = none;
    return;
}

function HandleNpcHeaderResponse(string param)
{
    local string Message;
    local array<string> Fields;
    local int ResponseId;
    local UserInfo Info;

    ParseString(param, "Msg", Message);

    Split(Message, "|", Fields);

    if (Fields.Length != 3)
    {
        return;
    }

    if (Fields[0] != "CustomEvent=NpcHeaderV1")
    {
        return;
    }

    if (Fields[2] != "0" && Fields[2] != "1")
    {
        return;
    }

    ResponseId = int(Fields[1]);

    if (ResponseId <= 0
        || ResponseId != NpcHeaderRequestedId)
    {
        return;
    }

    if (ResponseId
        != class'NWindow.UIDATA_TARGET'.static.GetTargetID())
    {
        return;
    }

    if (!GetTargetInfo(Info))
    {
        return;
    }

    if (Info.nID != ResponseId || !Info.bNpc)
    {
        return;
    }

    NpcHeaderResponseId = ResponseId;
    bHideTownNpcHeader = Fields[2] == "1";

    AddHPHeader(Info);
}

function OnEvent(int Event_ID, string param)
{
    switch (Event_ID)
    {
        case 140:
        HandleNpcHeaderResponse(param);
        break;
        case 88521:
            ParseInt(param, "ClassId", TargetClassId);
            ParseInt(param, "Level", TargetLevel);
            ParseInt(param, "Flag", TargetFlag);

            AddHPHeaderPlayer();
            break;

        case 980:
            xxHandleTargetUpdate(true);

            // Abre o cabeçalho mesmo sem dados de CP.
            if (!TargetHeaderPlayer.IsShowWindow())
                AddHPHeaderPlayer();
            break;

        case 300:
            HandleReceiveTargetLevelDiff(param);

            if (!TargetHeaderPlayer.IsShowWindow())
                AddHPHeaderPlayer();
            break;

        case 230:
        case 190:
        case 210:
        case 240:
        case 200:
        case 220:
            HandleTargetStatusUpdate(param);

            if (m_bShow && !TargetHeaderPlayer.IsShowWindow())
                AddHPHeaderPlayer();
            break;
    }
}

function OnClickButton(string strID)
{
    switch(strID)
    {
        // End:0x1D
        case "btnClose":
            OnCloseButton();
            // End:0x52
            break;
        // End:0x35
        case "btnExpand":
            SetExpandMode(false);
            // End:0x52
            break;
        // End:0x4F
        case "btnContract":
            SetExpandMode(true);
            // End:0x52
            break;
        // End:0xFFFF
        default:
            break;
    }
    return;
}

/*function OnLButtonDown(WindowHandle a_WindowHandle, int X, int Y)
{
    local Rect rectWnd;

    rectWnd = Class'NWindow.UIAPI_WINDOW'.static.GetRect("TargetStatusWnd");
    // End:0x59

    // End:0xF8
    if(((X >= (rectWnd.nX + 30)) && X <= ((rectWnd.nX + rectWnd.nWidth) - 30)) && Y <= (rectWnd.nY + 25))
    {
        GlobalClick.nX = X - rectWnd.nX;
        GlobalClick.nY = Y - rectWnd.nY;
        GotoState('DragON');
        DragState = true;
    }
    return;
}*/

function OnLButtonDown(WindowHandle a_WindowHandle, int X, int Y)
{
    local Rect rectWnd;

    rectWnd = Class'NWindow.UIAPI_WINDOW'.static.GetRect("TargetStatusWnd");
    // End:0xD2
    if(((X >= (rectWnd.nX + 30)) && X <= ((rectWnd.nX + rectWnd.nWidth) - 30)) && Y <= (rectWnd.nY + 25))
    {
        // End:0xCA
        if(!IsInState('HeaderShow'))
        {
            GlobalClick.nX = X - rectWnd.nX;
            GlobalClick.nY = Y - rectWnd.nY;
            GotoState('DragON');
        }
        DragState = true;
    }
    return;
}

function OnDefaultPosition()
{
    GotoState('None');
    DragState = false;
    return;
}

function OnRButtonDown(int X, int Y)
{
    MileniumGearScore(GetScript("MileniumGearScore")).OpenTargetContext(X,Y);
}

function OnCloseButton()
{
    RequestTargetCancel();
    PlayConsoleSound(EInterfaceSoundType(6));
    return;
}

function SetExpandMode(bool bExpand)
{
    local int nWndWidth, nWndHeight;
    local UserInfo Info;

    GetTargetInfo(Info);
    Me.GetWindowSize(nWndWidth, nWndHeight);
    m_bExpand = bExpand;
    m_targetID = -1;
	testtar = true;
    xxHandleTargetUpdate(false);
    // End:0x82
    if(bExpand)
    {
        btnExpand.ShowWindow();
        btnContract.HideWindow();
        Me.SetWindowSize(nWndWidth, 102);        
    }
    else
    {
        btnExpand.HideWindow();
        btnContract.ShowWindow();
        Me.SetWindowSize(nWndWidth, 58);
    }
    MileniumGearScore(GetScript("MileniumGearScore")).CheckTarget();
    return;
}

function HandleTargetStatusUpdate(string param)
{
    local int ServerID;

    // End:0x38
    if(m_bShow)
    {
        ParseInt(param, "ServerID", ServerID);
        // End:0x38
        if(m_targetID == ServerID)
        {
            xxHandleTargetUpdate(false);
        }
    }
    return;
}

function HandleReceiveTargetLevelDiff(string param)
{
    ParseInt(param, "LevelDiff", m_TargetLevel);
    xxHandleTargetUpdate(false);
    return;
}

function xxHandleTargetUpdate(optional bool spawnTarget)
{
    local Rect rectWnd;
    local string strTmp;
    local int targetID, PlayerID, PetID, clanType, ClanNameValue;

    local bool bIsServerObject, bIsHPShowableNPC;
    local string Name, RankName;
    local Color TargetNameColor;
    local int ServerObjectNameID;
    local UIEventManager.EServerObjectType ServerObjectType;
    local bool bShowCPBar, bShowHPBar, bShowMPBar, bShowPledgeInfo, bShowPledgeTex, bShowPledgeAllianceTex;
local AutoSkillWnd scriptauto;
    local string PledgeName, PledgeAllianceName;
    local Texture PledgeCrestTexture, PledgeAllianceCrestTexture;
    local Color PledgeNameColor, PledgeAllianceNameColor;
    local bool bShowNpcInfo;
    local array<int> arrNpcInfo;
    local bool IsTargetChanged;
    local UserInfo Info, myInfo;
    local Color WhiteColor;

    WhiteColor.R = 0;
    WhiteColor.G = 0;
    WhiteColor.B = 0;
	scriptauto = AutoSkillWnd(GetScript("AutoSkillWnd"));
    targetID = Class'NWindow.UIDATA_TARGET'.static.GetTargetID();
    // End:0x69
    if(targetID < 1)
    {
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd");
        return;
    }
    // End:0x80
    if(m_targetID != targetID)
    {
        IsTargetChanged = true;
	
	//	spawnTarget = true;
    }
    m_targetID = targetID;
    GetTargetInfo(Info);
    GetPlayerInfo(myInfo);

		    if( IsTargetChanged && Info.nID > 0)
    {
	GetTexture(Info);
xxApplyEffectTarget(false, Info);

xxRemoveHPHeader();
       
    }
	

    rectWnd = Class'NWindow.UIAPI_WINDOW'.static.GetRect("TargetStatusWnd");
    PledgeName = GetSystemString(431);
    PledgeAllianceName = GetSystemString(591);
    PledgeNameColor.R = 128;
    PledgeNameColor.G = 128;
    PledgeNameColor.B = 128;
    PledgeAllianceNameColor.R = 128;
    PledgeAllianceNameColor.G = 128;
    PledgeAllianceNameColor.B = 128;
    TargetNameColor = GetTargetNameColor(m_TargetLevel);
    bIsServerObject = Class'NWindow.UIDATA_TARGET'.static.IsServerObject();
    // End:0x288
    if(bIsServerObject)
    {
        ServerObjectNameID = Class'NWindow.UIDATA_STATICOBJECT'.static.GetServerObjectNameID(m_targetID);
        // End:0x1DC
        if(ServerObjectNameID > 0)
        {
            Name = Class'NWindow.UIDATA_STATICOBJECT'.static.GetStaticObjectName(ServerObjectNameID);
			RankName = "";
        }
		Class'NWindow.UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.UserName", Name, NCT_Normal,TA_Center);
		if( Info.nMaxCP != 0 )
	
		{
			RankName = "";
		}
		Class'UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.RankName", RankName, NCT_Normal,TA_Center);
        
        ServerObjectType = Class'NWindow.UIDATA_STATICOBJECT'.static.GetServerObjectType(m_targetID);
        // End:0x285
        if(int(ServerObjectType) == 2)
        {
            // End:0x285
            if(Class'NWindow.UIDATA_STATICOBJECT'.static.GetStaticObjectShowHP(m_targetID))
            {
                bShowHPBar = true;
                UpdateHPBar(Class'NWindow.UIDATA_STATICOBJECT'.static.GetServerObjectHP(m_targetID), Class'NWindow.UIDATA_STATICOBJECT'.static.GetServerObjectMaxHP(m_targetID),Info);
            }
        }        
    }
    else
    {
        // End:0x2E9
        if(Len(Info.Name) < 1)
        {
            Name = Class'NWindow.UIDATA_PARTY'.static.GetMemberName(m_targetID);
            Class'NWindow.UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.UserName", Name, NCT_Normal,TA_Center);            
        }
        else
        {
            PlayerID = Class'NWindow.UIDATA_PLAYER'.static.GetPlayerID();
            PetID = Class'NWindow.UIDATA_PET'.static.GetPetID();
            bIsHPShowableNPC = Class'NWindow.UIDATA_TARGET'.static.IsHPShowableNPC();
            // End:0x536
            if(((((Info.bNpc && !Info.bPet) && Info.bCanBeAttacked) || (PlayerID > 0) && m_targetID == PlayerID) || (Info.bNpc && Info.bPet) && m_targetID == PetID) || Info.bNpc && bIsHPShowableNPC)
            {
			
			scriptauto.zzfweqaa = True;
			
                // End:0x458
                if(IsAllWhiteID(Info.nClassID))
                {
                    Name = Info.Name;
					RankName = "";
                    Class'NWindow.UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.UserName", Name, NCT_Normal,TA_Center);
					
								if( Info.nMaxCP != 0 )
	
			{
				RankName = "";
			}
			Class'UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.RankName", RankName, NCT_Normal,TA_Center);    
                    // End:0x455
                    if(!IsNoBarID(Info.nClassID))
                    {
                        bShowHPBar = true;
                        UpdateHPBar(Info.nCurHP, Info.nMaxHP,Info);
                        AddHPHeader(Info);
						AddHPHeaderPlayer(Info);
                    }                    
                }
                else
                {
                    Name = Info.Name;
					RankName = "";
                    Class'NWindow.UIAPI_NAMECTRL'.static.SetNameWithColor("TargetStatusWnd.UserName", Name, NCT_Normal,TA_Center, TargetNameColor);
										if( Info.nMaxCP != 0 )
	
					{
						RankName = "";
					}
					Class'UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.RankName", RankName,  NCT_Normal,TA_Center);
                    bShowHPBar = true;
					
										if( !(Info.bNpc && !Info.bPet) )
					{
						
						if( Info.nMaxCP == 0 )
						{                            
						}
						else
						{	
						
						
							bShowCPBar = True;
							UpdateCPBar(Info.nCurCP, Info.nMaxCP);
						}
					}
					
					
					
					
                    UpdateHPBar(Info.nCurHP, Info.nMaxHP,Info);
                    AddHPHeader(Info);
					AddHPHeaderPlayer(Info);
                    // End:0x51B
                    if(!(Info.bNpc && !Info.bPet) && Info.bCanBeAttacked)
                    {
                        bShowMPBar = true;
                        UpdateMPBar(Info.nCurMP, Info.nMaxMP);
                    }
                    // End:0x533
                    if(Info.nMaxMP < 1)
                    {
                        bShowMPBar = false;
                    }
                }                
            }
            else
            {
				Name = Info.Name;
                // End:0x5D3
				if( !Info.bNpc && !Info.bPet )
				{
					
					if( Info.nMaxCP == 0 )
					{
					
					}
					else
					{
						
					
						bShowCPBar = True;
						bShowHPBar = True;
						AddHPHeader(Info);
						AddHPHeaderPlayer(Info);
						UpdateCPBar(Info.nCurCP, Info.nMaxCP);
						UpdateHPBar(Info.nCurHP, Info.nMaxHP,Info);
					}
				}
				
				if( Info.bNpc )
				{
					RankName = xxgetInstanceL2Util().xxgetAD();
                			
				}
				else
				{
					
					RankName = GetUserRankString(Info.nUserRank);
				}
				Class'UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.UserName", Name, NCT_Normal,TA_Center);
				if( Info.nMaxCP != 0 )
	
				{
					RankName = "";
				}
				Class'UIAPI_NAMECTRL'.static.SetName("TargetStatusWnd.RankName", RankName, NCT_Normal,TA_Center);
            }
			
			scriptauto.zzfweqaa = bShowHPBar;
			
			
            // End:0x8AE
            if(m_bExpand)
            {
                // End:0x629
                if(Info.bNpc)
                {
                    // End:0x626
                    if(Class'NWindow.UIDATA_NPC'.static.GetNpcProperty(Info.nClassID, arrNpcInfo))
                    {
                        bShowNpcInfo = true;
                        // End:0x626
                        if(IsTargetChanged)
                        {
                            UpdateNpcInfoTree(arrNpcInfo);
                        }
                    }                    
                }
                else
                {
                    bShowPledgeInfo = true;
                    // End:0x8AE
                    if(Info.nClanID > 0)
                    {
                        PledgeName = Class'NWindow.UIDATA_CLAN'.static.GetName(Info.nClanID);
                        PledgeNameColor.R = 176;
                        PledgeNameColor.G = 152;
                        PledgeNameColor.B = 121;
                        // End:0x778
                        if(((PledgeName != "") && Class'NWindow.UIDATA_USER'.static.GetClanType(m_targetID, clanType)) && Class'NWindow.UIDATA_CLAN'.static.GetNameValue(Info.nClanID, ClanNameValue))
                        {
                            // End:0x70D
                            if(clanType == -1)
                            {
                                PledgeNameColor.R = 209;
                                PledgeNameColor.G = 167;
                                PledgeNameColor.B = 2;                                
                            }
                            else
                            {
                                // End:0x744
                                if(ClanNameValue > 0)
                                {
                                    PledgeNameColor.R = 0;
                                    PledgeNameColor.G = 130;
                                    PledgeNameColor.B = byte(255);                                    
                                }
                                else
                                {
                                    // End:0x778
                                    if(ClanNameValue < 0)
                                    {
                                        PledgeNameColor.R = byte(255);
                                        PledgeNameColor.G = 0;
                                        PledgeNameColor.B = 0;
                                    }
                                }
                            }
                        }
                        // End:0x7D8
                        if(Class'NWindow.UIDATA_CLAN'.static.GetCrestTexture(Info.nClanID, PledgeCrestTexture))
                        {
                            bShowPledgeTex = true;
                            Class'NWindow.UIAPI_TEXTURECTRL'.static.SetTextureWithObject("TargetStatusWnd.texPledgeCrest", PledgeCrestTexture);                            
                        }
                        else
                        {
                            bShowPledgeTex = false;
                        }
                        strTmp = Class'NWindow.UIDATA_CLAN'.static.GetAllianceName(Info.nClanID);
                        // End:0x8AE
                        if(Len(strTmp) > 0)
                        {
                            PledgeAllianceName = strTmp;
                            PledgeAllianceNameColor.R = 176;
                            PledgeAllianceNameColor.G = 155;
                            PledgeAllianceNameColor.B = 121;
                            // End:0x8A6
                            if(Class'NWindow.UIDATA_CLAN'.static.GetAllianceCrestTexture(Info.nClanID, PledgeAllianceCrestTexture))
                            {
                                bShowPledgeAllianceTex = true;
                                Class'NWindow.UIAPI_TEXTURECTRL'.static.SetTextureWithObject("TargetStatusWnd.texPledgeAllianceCrest", PledgeAllianceCrestTexture);                                
                            }
                            else
                            {
                                bShowPledgeAllianceTex = false;
                            }
                        }
                    }
                }
            }
        }
    }
    // End:0x8FF
    if(!Class'NWindow.UIAPI_WINDOW'.static.IsShowWindow("TargetStatusWnd"))
    {
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd");
        SetExpandMode(m_bExpand);
    }
    HandleStatusBar(bShowCPBar, "CP");
    HandleStatusBar(bShowHPBar, "HP");
    HandleStatusBar(bShowMPBar, "MP");
    HandleBarPos(bShowCPBar);
    // End:0xCF9
    if(bShowPledgeInfo)
    {
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.txtPledge");
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.txtAlliance");
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.txtPledgeName");
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.txtPledgeAllianceName");
        Class'NWindow.UIAPI_TEXTBOX'.static.SetText("TargetStatusWnd.txtPledgeName", PledgeName);
        Class'NWindow.UIAPI_TEXTBOX'.static.SetText("TargetStatusWnd.txtPledgeAllianceName", PledgeAllianceName);
        Class'NWindow.UIAPI_TEXTBOX'.static.SetTextColor("TargetStatusWnd.txtPledgeName", PledgeNameColor);
        Class'NWindow.UIAPI_TEXTBOX'.static.SetTextColor("TargetStatusWnd.txtPledgeAllianceName", PledgeAllianceNameColor);
        // End:0xB5F
        if(bShowPledgeTex)
        {
            Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.texPledgeCrest");
            Class'NWindow.UIAPI_WINDOW'.static.MoveTo("TargetStatusWnd.txtPledgeName", rectWnd.nX + 63, rectWnd.nY + 64);            
        }
        else
        {
            Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.texPledgeCrest");
            Class'NWindow.UIAPI_WINDOW'.static.MoveTo("TargetStatusWnd.txtPledgeName", rectWnd.nX + 45, rectWnd.nY + 64);
        }
        // End:0xC6D
        if(bShowPledgeAllianceTex)
        {
            Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.texPledgeAllianceCrest");
            Class'NWindow.UIAPI_WINDOW'.static.MoveTo("TargetStatusWnd.txtPledgeAllianceName", rectWnd.nX + 63, rectWnd.nY + 78);            
        }
        else
        {
            Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.texPledgeAllianceCrest");
            Class'NWindow.UIAPI_WINDOW'.static.MoveTo("TargetStatusWnd.txtPledgeAllianceName", rectWnd.nX + 45, rectWnd.nY + 78);
        }        
    }
    else
    {
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.txtPledge");
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.texPledgeCrest");
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.txtPledgeName");
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.txtAlliance");
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.texPledgeAllianceCrest");
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.txtPledgeAllianceName");
    }
    // End:0xE76
    if(bShowNpcInfo)
    {
        Class'NWindow.UIAPI_WINDOW'.static.ShowWindow("TargetStatusWnd.NpcInfo");
        Class'NWindow.UIAPI_TREECTRL'.static.ShowScrollBar("TargetStatusWnd.NpcInfo", false);        
    }
    else
    {
        Class'NWindow.UIAPI_WINDOW'.static.HideWindow("TargetStatusWnd.NpcInfo");
    }
    return;
}

function HandleBarPos(bool isCpBar)
{
    // End:0xAA
    if(!isCpBar)
    {
        GetHandle("TargetStatusWnd.barHP").SetAnchor("TargetStatusWnd", "TopLeft", "TopLeft", 13, 27);
        GetHandle("TargetStatusWnd.HP_BG").SetAnchor("TargetStatusWnd", "TopLeft", "TopLeft", 11, 27);        
    }
    else
    {
        GetHandle("TargetStatusWnd.barHP").SetAnchor("TargetStatusWnd", "TopLeft", "TopLeft", 13, 40);
        GetHandle("TargetStatusWnd.HP_BG").SetAnchor("TargetStatusWnd", "TopLeft", "TopLeft", 11, 40);
    }
    return;
}

function HandleStatusBar(bool Show, string wnd)
{
    // End:0x54
    if(Show)
    {
        ShowWindow("TargetStatusWnd.bar" $ wnd);
        ShowWindow(("TargetStatusWnd." $ wnd) $ "_BG");        
    }
    else
    {
        HideWindow("TargetStatusWnd.bar" $ wnd);
        HideWindow(("TargetStatusWnd." $ wnd) $ "_BG");
    }
    return;
}

function HandleUpdateCPHPMP(string param)
{
    local int ServerID, currentCP, maxCP, currentHP, MaxHP, currentMP,
	    MaxMP;

    // End:0x152
    if(m_bShow)
    {
        ParseInt(param, "ServerID", ServerID);
        // End:0x152
        if(m_targetID == ServerID)
        {
            // End:0x64
            if(ParseInt(param, "CurrentCP", currentCP))
            {
                UpdateBar("CP", currentCP, -1);
            }
            // End:0x92
            if(ParseInt(param, "MaxCP", maxCP))
            {
                UpdateBar("CP", -1, maxCP);
            }
            // End:0xC4
            if(ParseInt(param, "CurrentHP", currentHP))
            {
                UpdateBar("HP", currentHP, -1);
            }
            // End:0xF2
            if(ParseInt(param, "MaxHP", MaxHP))
            {
                UpdateBar("HP", -1, MaxHP);
            }
            // End:0x124
            if(ParseInt(param, "CurrentMP", currentMP))
            {
                UpdateBar("MP", currentMP, -1);
            }
            // End:0x152
            if(ParseInt(param, "MaxMP", MaxMP))
            {
                UpdateBar("MP", -1, MaxMP);
            }
        }
    }
    return;
}

function UpdateBar(string Str, int Current, int Max)
{
    local int tmpCur, tmpMax;

    Class'NWindow.UIAPI_BARCTRL'.static.GetValue("TargetStatusWnd.bar" $ Str, tmpMax, tmpCur);
    // End:0x78
    if(Current >= 0)
    {
        Class'NWindow.UIAPI_BARCTRL'.static.SetValue("TargetStatusWnd.bar" $ Str, tmpMax, Current);        
    }
    else
    {
        Class'NWindow.UIAPI_BARCTRL'.static.SetValue("TargetStatusWnd.bar" $ Str, Max, tmpCur);
    }
    return;
}

function UpdateCPBar(int CP, int maxCP)
{
    // End:0x1A
    if((CP < 0) || maxCP <= 0)
    {
        return;
    }
    Class'NWindow.UIAPI_BARCTRL'.static.SetValue("TargetStatusWnd.barCP", maxCP, CP);
	headersetacp(maxCP, CP);
    return;
}

function UpdateHPBar(int HP, int MaxHP, optional UserInfo zzinfo)
{
    // End:0x1A
    if((HP < 0) || MaxHP <= 0)
    {
        return;
    }
    Class'NWindow.UIAPI_BARCTRL'.static.SetValue("TargetStatusWnd.barHP", MaxHP, HP);
 if(zzinfo.bNpc)
 {
	
headerseta(MaxHP, HP);
}
else
{

headersetahpla(MaxHP, HP);

}
    return;
}

function UpdateMPBar(int MP, int MaxMP)
{
    // End:0x1A
    if((MP < 0) || MaxMP <= 0)
    {
        return;
    }
    Class'NWindow.UIAPI_BARCTRL'.static.SetValue("TargetStatusWnd.barMP", MaxMP, MP);
    return;
}

function headerseta(int zzMaxHp, int zzHp)
{
	local int zzNewSize;

	zzNewSize = 76;
    // End:0x30
	if ( zzHP < zzMaxHP )
	{
		zzNewSize = (zzHP * 76) / zzMaxHP;
	}
	GetHandle("TargetHeader.barHP").SetWindowSize(zzNewSize, 4);

	return;
}

function headersetahpla(int zzMaxHp, int zzHp)
{
	local int zzNewSize;

	zzNewSize = 70;
    // End:0x30
	if ( zzHP < zzMaxHP )
	{
		zzNewSize = (zzHP * 70) / zzMaxHP;
	}

	GetHandle("TargetHeaderPlayer.BarraHud.HPBar_HP").SetWindowSize(zzNewSize, 3);
	return;
}

function headersetacp(int zzMaxCp, int zzCp)
{
	local int zzNewSize;

	zzNewSize = 70;
    // End:0x30
	if ( zzCp < zzMaxCp )
	{
		zzNewSize = (zzCp * 70) / zzMaxCp;
	}
	GetHandle("TargetHeaderPlayer.BarraHud.HPBar_CP").SetWindowSize(zzNewSize, 6);
	return;
}

function UpdateNpcInfoTree(array<int> arrNpcInfo)
{
    local int i, SkillID, SkillLevel;
    local string strNodeName;
    local XMLTreeNodeInfo infNode;
    local XMLTreeNodeItemInfo infNodeItem;
    local XMLTreeNodeInfo infNodeClear;
    local XMLTreeNodeItemInfo infNodeItemClear;

    Class'NWindow.UIAPI_TREECTRL'.static.Clear("TargetStatusWnd.NpcInfo");
    infNode.strName = "root";
    strNodeName = Class'NWindow.UIAPI_TREECTRL'.static.InsertNode("TargetStatusWnd.NpcInfo", "", infNode);
    // End:0xB6
    if(Len(strNodeName) < 1)
    {
        Debug("ERROR: Can't insert root node. Name: " $ infNode.strName);
        return;
    }
    i = 0;
    J0xBD:

    // End:0x2FA [Loop If]
    if(i < arrNpcInfo.Length)
    {
        SkillID = arrNpcInfo[i];
        SkillLevel = arrNpcInfo[i + 1];
        infNode = infNodeClear;
        infNode.nOffSetX = int(float(i / 2) % float(8)) * 18;
        // End:0x162
        if((float(i / 2) % float(8)) == float(0))
        {
            // End:0x153
            if(i > 0)
            {
                infNode.nOffSetY = 3;                
            }
            else
            {
                infNode.nOffSetY = 0;
            }            
        }
        else
        {
            infNode.nOffSetY = -15;
        }
        infNode.strName = "" $ string(i / 2);
        infNode.bShowButton = 0;
        infNode.ToolTip = SetNpcInfoTooltip(SkillID, SkillLevel);
        strNodeName = Class'NWindow.UIAPI_TREECTRL'.static.InsertNode("TargetStatusWnd.NpcInfo", "root", infNode);
        // End:0x22B
        if(Len(strNodeName) < 1)
        {
            Log("ERROR: Can't insert node. Name: " $ infNode.strName);
            return;
        }
        infNode.ToolTip.DrawList.Remove(0, infNode.ToolTip.DrawList.Length);
        infNodeItem = infNodeItemClear;
        infNodeItem.eType = XTNITEM_TEXTURE;
        infNodeItem.u_nTextureWidth = 15;
        infNodeItem.u_nTextureHeight = 15;
        infNodeItem.u_nTextureUWidth = 32;
        infNodeItem.u_nTextureUHeight = 32;
        infNodeItem.u_strTexture = Class'NWindow.UIDATA_SKILL'.static.GetIconName(SkillID, SkillLevel);
        Class'NWindow.UIAPI_TREECTRL'.static.InsertNodeItem("TargetStatusWnd.NpcInfo", strNodeName, infNodeItem);
        i += 2;
        // [Loop Continue]
        goto J0xBD;
    }
    return;
}

function CustomTooltip SetNpcInfoTooltip(int Id, int Level)
{
    local CustomTooltip ToolTip;
    local DrawItemInfo Info, infoClear;
    local ItemInfo item;

    item.Name = Class'NWindow.UIDATA_SKILL'.static.GetName(Id, Level);
    item.Description = Class'NWindow.UIDATA_SKILL'.static.GetDescription(Id, Level);
    ToolTip.DrawList.Length = 1;
    Info = infoClear;
    Info.eType = DIT_TEXT;
    Info.t_bDrawOneLine = true;
    Info.t_strText = item.Name;
    ToolTip.DrawList[0] = Info;
    // End:0x171
    if(Len(item.Description) > 0)
    {
        ToolTip.MinimumWidth = 144;
        ToolTip.DrawList.Length = 2;
        Info = infoClear;
        Info.eType = DIT_TEXT;
        Info.nOffSetY = 6;
        Info.bLineBreak = true;
        Info.t_color.R = 178;
        Info.t_color.G = 190;
        Info.t_color.B = 207;
        Info.t_color.A = byte(255);
        Info.t_strText = item.Description;
        ToolTip.DrawList[1] = Info;
    }
    return ToolTip;

}

function bool IsAllWhiteID(int m_targetID)
{
    local bool bIsAllWhiteName;

    bIsAllWhiteName = false;
    switch(m_targetID)
    {
        // End:0x17
        case 12778:
        // End:0x1F
        case 13031:
        // End:0x27
        case 13032:
        // End:0x2F
        case 13033:
        // End:0x37
        case 13034:
        // End:0x3F
        case 13035:
        // End:0x52
        case 13036:
            bIsAllWhiteName = true;
            // End:0x55
            break;
        // End:0xFFFF
        default:
            break;
    }
    return bIsAllWhiteName;
 
}

function bool IsNoBarID(int m_targetID)
{
    local bool bIsNoBarName;

    bIsNoBarName = false;
    switch(m_targetID)
    {
        // End:0x22
        case 13036:
            bIsNoBarName = true;
            // End:0x25
            break;
        // End:0xFFFF
        default:
            break;
    }
    return bIsNoBarName;

}

function CustomTooltip SetTooltip(string Text)
{
    local CustomTooltip TooltipInfo;

    TooltipInfo.DrawList.Length = 4;
    TooltipInfo.DrawList[0].eType = DIT_TEXT;
    TooltipInfo.DrawList[0].nOffSetX = 1;
    TooltipInfo.DrawList[0].t_bDrawOneLine = true;
    TooltipInfo.DrawList[0].t_color.R = byte(255);
    TooltipInfo.DrawList[0].t_color.G = byte(255);
    TooltipInfo.DrawList[0].t_color.B = byte(255);
    TooltipInfo.DrawList[0].t_color.A = byte(255);
    TooltipInfo.DrawList[0].t_strText = Text;
    return TooltipInfo;

}
function xxApplyEffectTarget(bool isClear, optional UserInfo Info)
{
    local Pawn a_Pawn;
    local Vector V;
    local Actor tmpActor;

    // End:0x12
    if(!GetPlayerActor(tmpActor))
    {
        return;
    }
	
	    // Si el efecto ya está activo en el objetivo, no lo destruyas
    if (!isClear && zzdecalEmitter != none && zzdecalEmitter.Owner.CreatureID == info.nID)
    {
        // El efecto ya está aplicado en este target, no recrearlo
        return;
    }
	
    // End:0x33
    if(zzdecalEmitter != none)
    {
        zzdecalEmitter.NDestroy();
        zzdecalEmitter = none;
    }
    // End:0x3E
    if(isClear)
    {
        return;
    }
    V = Info.Loc;
    // End:0x7F
    if(tmpActor.CreatureID == Info.nID)
    {
        V = tmpActor.Location;
    }
    // End:0x11E
    foreach tmpActor.CollidingActors(Class'Engine.Pawn', a_Pawn, 100.0000000, V)
    {
        // End:0x11D
        if(Info.nID == a_Pawn.CreatureID)
        {
            V.X = 0.0000000;
            V.Y = 0.0000000;
            V.Z = a_Pawn.CollisionHeight + float(7);
            zzdecalEmitter = a_Pawn.Spawn(zztargetEmitterClass, a_Pawn);
            // End:0x11E
            break;
        }        
    }    
    return;
}

/*function xxApplyEffectTarget(bool isClear, optional UserInfo info )
{	
    local Actor tmpActor;
    local Pawn a_Pawn;
    local Vector V;
    
    // Verifica si se puede obtener el actor del jugador
    if (!GetPlayerActor(tmpActor))
    {
        return;
    }

    // Si el efecto ya está activo en el objetivo, no lo destruyas
    if (!isClear && zzdecalEmitter != none && zzdecalEmitter.Owner.CreatureID == info.nID)
    {
        // El efecto ya está aplicado en este target, no recrearlo
        return;
    }

    // Si zzdecalEmitter ya existe, destrúyelo antes de asignar uno nuevo
    if (zzdecalEmitter != none)
    {
        zzdecalEmitter.NDestroy();
        zzdecalEmitter = none;
    }

    // Si estamos limpiando, no hacer nada más
    if (isClear)
    {
        return;
    }

    // Asignar la localización del efecto
    V = info.Loc;

    // Si el Actor tiene el mismo ID que el objetivo, usa la ubicación de ese actor
    if (tmpActor.CreatureID == info.nID)
    {
        V = tmpActor.Location;
    }

    // Iterar sobre los actores colisionando
    foreach tmpActor.CollidingActors(Class'Engine.Pawn', a_Pawn, 100.0000000, V)
    {
        // Verifica si el actor es un montado (RidePawn), si es así, lo omite
        if (a_Pawn.CurRideType != 0 && a_Pawn.RidePawn != None)
        {
            continue;  // Si es un mount, saltamos este actor
        }

        // Si el Actor coincide con el ID del objetivo
        if (a_Pawn.CreatureID == Info.nID)
        {
            // Asigna una nueva posición para el efecto
            V.X = 0.0;
            V.Y = 0.0;
            V.Z = a_Pawn.CollisionHeight + 7;

            // Asegúrate de que a_Pawn no sea None antes de intentar spawnear
            if (a_Pawn != None)
            {
              
              zzdecalEmitter = a_Pawn.Spawn(zztargetEmitterClass, a_Pawn,,v,);
                // Verifica que zzdecalEmitter no sea None después de la asignación
                if (zzdecalEmitter != None)
                {
                    zzdecalEmitter.Emitters[0].Disabled = true;

                    // Asigna la textura dependiendo si el objetivo es NPC o no
                    if (Info.bNpc)
                    {
                        zzdecalEmitter.Emitters[0].Texture = targetTexturenpc;
                    }
                    else
                    {
                        zzdecalEmitter.Emitters[0].Texture = targetTexture;
                    }
                }
                else
                {
                    OMG("No se pudo crear zzdecalEmitter para el actor con ID: " $ string(Info.nID));
                }
            }
            else
            {
                OMG("a_Pawn es None, no se puede crear zzdecalEmitter.");
            }
        }
    }	
}*/
function AddHPHeader(UserInfo zzinfo)
{
    local int CurrentTargetId;

    if (!zzinfo.bNpc)
    {
        return;
    }

    if (!zzshowHeader)
    {
        TargetHeader.HideWindow();
        return;
    }

    CurrentTargetId =
        class'NWindow.UIDATA_TARGET'.static.GetTargetID();

    if (CurrentTargetId <= 0
        || zzinfo.nID != CurrentTargetId)
    {
        TargetHeader.HideWindow();
        return;
    }

    if (NpcHeaderRequestedId != CurrentTargetId)
    {
        NpcHeaderRequestedId = CurrentTargetId;
        NpcHeaderResponseId = 0;
        bHideTownNpcHeader = false;

        // Oculta antes de solicitar a classificacao.
        TargetHeader.HideWindow();

        RequestBypassToServer(
            "NpcHeaderInfo " $ string(CurrentTargetId)
        );

        return;
    }

    // Nao exibe enquanto aguarda a resposta do servidor.
    if (NpcHeaderResponseId != CurrentTargetId)
    {
        TargetHeader.HideWindow();
        return;
    }

    // NPC de servico dentro da cidade: permanece oculto.
    if (bHideTownNpcHeader)
    {
        TargetHeader.HideWindow();
        return;
    }

    // Monstros e bosses: exibe apos a confirmacao.
    GotoState('HeaderShow');
    TargetHeader.ShowWindow();
}

function AddHPHeaderPlayer(optional UserInfo zzinfo)
{
    local int CurrentTargetId;

    if (!zzshowHeader)
        return;

    CurrentTargetId = class'NWindow.UIDATA_TARGET'.static.GetTargetID();

    if (CurrentTargetId <= 0)
    {
        TargetHeaderPlayer.HideWindow();
        return;
    }

    if (class'NWindow.UIDATA_TARGET'.static.IsServerObject())
    {
        TargetHeaderPlayer.HideWindow();
        return;
    }

    // Busca os dados reais quando o metodo recebe um parametro vazio.
    if (zzinfo.nID <= 0 || zzinfo.nID != CurrentTargetId)
    {
        if (!GetTargetInfo(zzinfo))
            return;
    }

    if (zzinfo.nID != CurrentTargetId)
        return;

    // Este cabeçalho pertence apenas aos jogadores.
    if (zzinfo.bNpc || zzinfo.bPet)
    {
        TargetHeaderPlayer.HideWindow();
        return;
    }

    if (zzscripttarget == None)
    {
        zzscripttarget = TargetHeaderPlayer(
            GetScript("TargetHeaderPlayer")
        );
    }

    if (zzscripttarget == None)
        return;

    GotoState('HeaderShow');

    zzscripttarget.xxsetinico(
        TargetClassId,
        TargetLevel,
        TargetFlag,
        zzinfo
    );
}



function Color GetTargetNameColor(int TargetLevelDiff)
{
    local Color OutColor;
    local UserInfo UserInfo;
    local int myLevel;

    GetPlayerInfo(UserInfo);
    myLevel = UserInfo.nLevel;
    OutColor.A = byte(255);
    // End:0x216
    if(myLevel < 78)
    {
        // End:0x71
        if(TargetLevelDiff <= -11)
        {
            OutColor.R = byte(255);
            OutColor.G = 0;
            OutColor.B = 0;            
        }
        else
        {
            // End:0xBD
            if((TargetLevelDiff > -11) && TargetLevelDiff <= -6)
            {
                OutColor.R = byte(255);
                OutColor.G = 145;
                OutColor.B = 145;                
            }
            else
            {
                // End:0x107
                if((TargetLevelDiff > -6) && TargetLevelDiff <= -3)
                {
                    OutColor.R = 250;
                    OutColor.G = 254;
                    OutColor.B = 145;                    
                }
                else
                {
                    // End:0x154
                    if((TargetLevelDiff > -3) && TargetLevelDiff <= 2)
                    {
                        OutColor.R = byte(255);
                        OutColor.G = byte(255);
                        OutColor.B = byte(255);                        
                    }
                    else
                    {
                        // End:0x19A
                        if((TargetLevelDiff > 2) && TargetLevelDiff <= 5)
                        {
                            OutColor.R = 162;
                            OutColor.G = byte(255);
                            OutColor.B = 171;                            
                        }
                        else
                        {
                            // End:0x1DE
                            if((TargetLevelDiff > 5) && TargetLevelDiff <= 10)
                            {
                                OutColor.R = 162;
                                OutColor.G = 168;
                                OutColor.B = 252;                                
                            }
                            else
                            {
                                // End:0x213
                                if(TargetLevelDiff > 10)
                                {
                                    OutColor.R = 0;
                                    OutColor.G = 0;
                                    OutColor.B = byte(255);
                                }
                            }
                        }
                    }
                }
            }
        }        
    }
    else
    {
        // End:0x40E
        if((myLevel >= 78) && myLevel < 85)
        {
            // End:0x26B
            if(TargetLevelDiff <= -11)
            {
                OutColor.R = byte(255);
                OutColor.G = 0;
                OutColor.B = 0;                
            }
            else
            {
                // End:0x2B7
                if((TargetLevelDiff > -11) && TargetLevelDiff <= -4)
                {
                    OutColor.R = byte(255);
                    OutColor.G = 145;
                    OutColor.B = 145;                    
                }
                else
                {
                    // End:0x301
                    if((TargetLevelDiff > -4) && TargetLevelDiff <= -2)
                    {
                        OutColor.R = 250;
                        OutColor.G = 254;
                        OutColor.B = 145;                        
                    }
                    else
                    {
                        // End:0x34D
                        if((TargetLevelDiff > -2) && TargetLevelDiff <= 1)
                        {
                            OutColor.R = byte(255);
                            OutColor.G = byte(255);
                            OutColor.B = byte(255);                            
                        }
                        else
                        {
                            // End:0x392
                            if((TargetLevelDiff > 1) && TargetLevelDiff <= 3)
                            {
                                OutColor.R = 162;
                                OutColor.G = byte(255);
                                OutColor.B = 171;                                
                            }
                            else
                            {
                                // End:0x3D6
                                if((TargetLevelDiff > 3) && TargetLevelDiff <= 10)
                                {
                                    OutColor.R = 162;
                                    OutColor.G = 168;
                                    OutColor.B = 252;                                    
                                }
                                else
                                {
                                    // End:0x40B
                                    if(TargetLevelDiff > 10)
                                    {
                                        OutColor.R = 0;
                                        OutColor.G = 0;
                                        OutColor.B = byte(255);
                                    }
                                }
                            }
                        }
                    }
                }
            }            
        }
        else
        {
            // End:0x449
            if(TargetLevelDiff <= -11)
            {
                OutColor.R = byte(255);
                OutColor.G = 0;
                OutColor.B = 0;                
            }
            else
            {
                // End:0x495
                if((TargetLevelDiff > -11) && TargetLevelDiff <= -3)
                {
                    OutColor.R = byte(255);
                    OutColor.G = 145;
                    OutColor.B = 145;                    
                }
                else
                {
                    // End:0x4DF
                    if((TargetLevelDiff > -3) && TargetLevelDiff <= -2)
                    {
                        OutColor.R = 250;
                        OutColor.G = 254;
                        OutColor.B = 145;                        
                    }
                    else
                    {
                        // End:0x52B
                        if((TargetLevelDiff > -2) && TargetLevelDiff <= 1)
                        {
                            OutColor.R = byte(255);
                            OutColor.G = byte(255);
                            OutColor.B = byte(255);                            
                        }
                        else
                        {
                            // End:0x570
                            if((TargetLevelDiff > 1) && TargetLevelDiff <= 2)
                            {
                                OutColor.R = 162;
                                OutColor.G = byte(255);
                                OutColor.B = 171;                                
                            }
                            else
                            {
                                // End:0x5B4
                                if((TargetLevelDiff > 2) && TargetLevelDiff <= 10)
                                {
                                    OutColor.R = 162;
                                    OutColor.G = 168;
                                    OutColor.B = 252;                                    
                                }
                                else
                                {
                                    // End:0x5E9
                                    if(TargetLevelDiff > 10)
                                    {
                                        OutColor.R = 0;
                                        OutColor.G = 0;
                                        OutColor.B = byte(255);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return OutColor;

}

function xxRemoveHPHeader()
{
	GotoState('None');
	TargetHeader.HideWindow();
	TargetHeaderPlayer.HideWindow();
	xxresetnameposition();
	return;
}
function xxresetnameposition()
{
    local Actor zzactor;
    local Pawn zzpawnid;
    local UserInfo zzinfo;

    // End:0x12
    if(!GetPlayerActor(zzactor))
    {
        return;
    }
    // End:0xA7
    foreach zzactor.CollidingActors(Class'Engine.Pawn',zzpawnid, 2000.0000000, GetPlayerPosition())
    {
        // End:0x4C
        if(zzpawnid.bRide)
        {
            continue;            
        }

        // End:0x92
        if(zzinfo.bNpc && !zzinfo.bCanBeAttacked)
        {
            continue;            
        }
        zzpawnid.NameOffset = 0.0000000;        
    }    
    return;
}

state HeaderShow
{

 event OnTick()
{
    local float zzsdawe, zzweacaxaa;
    local int CurrentTargetId;

    if (TargetHeader.IsShowWindow())
    {
        xxheaderhp(zzsdawe, zzweacaxaa);

        TargetHeader.MoveTo(
            int(zzsdawe - float(42)),
            int(zzweacaxaa)
        );
    }

    if (TargetHeaderPlayer.IsShowWindow())
    {
        CurrentTargetId =
            class'NWindow.UIDATA_TARGET'.static.GetTargetID();

        if (CurrentTargetId > 0)
        {
            xxheaderhpplayerByID(
                CurrentTargetId,
                zzsdawe,
                zzweacaxaa,
                true
            );

            TargetHeaderPlayer.MoveTo(
                int(zzsdawe - float(42)),
                int(zzweacaxaa)
            );
        }
    }

    if (DragState)
    {
        xxdeaa();
    }
}

    function xxdeaa()
    {
        local Rect zzreaca;
        local int zzsdawehaa, zzwevvaa;
        local LineagePlayerController zzcdaa;

       if(!GetPlayerController(zzcdaa))
        {
            return;
        }
        zzreaca = Me.GetRect();
        zzsdawehaa = int(zzcdaa.Player.WindowsMouseX);
        zzwevvaa = int(zzcdaa.Player.WindowsMouseY);
        Me.MoveTo(zzsdawehaa - GlobalClick.nX, zzwevvaa - GlobalClick.nY);
        // End:0xAB
        if(!IsKeyDown(EInputKey(1)))
        {
            DragState = false;
        }
        return;
    }
    stop;
    stop;
}


state DragON
{
    function OnTick()
    {
        local LineagePlayerController Controller;
        local Rect Rect;
        local int MouseX, MouseY;

        Rect = Me.GetRect();
        // End:0x27
        if(!GetPlayerController(Controller))
        {
            return;
        }
        MouseX = int(Controller.Player.WindowsMouseX);
        MouseY = int(Controller.Player.WindowsMouseY);
        Me.MoveTo(MouseX - GlobalClick.nX, MouseY - GlobalClick.nY);
        // End:0xB2
        if(!IsKeyDown(EInputKey(1)))
        {
            GotoState('None');
            DragState = false;
        }
        return;
    }
    stop;
}
