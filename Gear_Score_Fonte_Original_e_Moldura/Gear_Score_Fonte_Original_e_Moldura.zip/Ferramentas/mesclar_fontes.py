from pathlib import Path
import re,sys,datetime
HEADER='Lineage2Ver111'.encode('utf-16le')
TARGETS={
 'benchmark':{'FontName':'complex','FontFile':'complex.ttf','FontWeight':'900','FontSize':'17','Italic':'False'},
 'broadcast1':{'FontName':'Metropolis','FontFile':'Metropolis.ttf','FontWeight':'400','FontSize':'13','Italic':'False'}}
def decode(data):
 if data.startswith(HEADER):return bytes(x^172 for x in data[28:]).decode('latin1'),True
 if data.startswith('Lineage2Ver'.encode('utf-16le')):raise ValueError('Formato de TTFontInfo.ini diferente de 111; arquivo nao foi alterado.')
 return data.decode('latin1'),False

def merge(data):
 text,encrypted=decode(data);lines=text.splitlines();newline='\r\n' if '\r\n' in text else '\n'
 def section(key):
  for i,line in enumerate(lines):
   if line.strip().lower()=='['+key.lower()+']':
    end=next((j for j in range(i+1,len(lines)) if lines[j].strip().startswith('[')),len(lines));return i,end
  return None,None
 def get(section_name,key):
  a,b=section(section_name)
  if a is None:return None
  for i in range(a+1,b):
   m=re.match(r'\s*'+re.escape(key)+r'\s*=\s*(.*?)\s*$',lines[i],re.I)
   if m:return m[1]
  return None
 def setvalue(section_name,key,value):
  a,b=section(section_name)
  if a is None:lines.extend(['','['+section_name+']',key+'='+value]);return
  for i in range(a+1,b):
   if re.match(r'\s*'+re.escape(key)+r'\s*=',lines[i],re.I):lines[i]=key+'='+value;return
  lines.insert(b,key+'='+value)
 used={n:get('FontUsage','Font'+str(n)) for n in range(1,65)};used={n:v for n,v in used.items() if v is not None}
 for usage,values in TARGETS.items():
  existing=next((n for n,v in used.items() if v.lower()==usage),None)
  slot=existing or next(n for n in range(1,65) if n not in used)
  key='Font'+str(slot);setvalue('FontUsage',key,usage);used[slot]=usage
  for group,value in values.items():
   # Keep existing benchmark customizations. broadcast1 is the model title font.
   if usage=='broadcast1' or get(group,key) is None:setvalue(group,key,value)
 result=(newline.join(lines)+newline).encode('latin1')
 return HEADER+bytes(x^172 for x in result) if encrypted else result

def main():
 if len(sys.argv)!=2:raise SystemExit('Uso: python mesclar_fontes.py "C:\\Lineage\\system"')
 root=Path(sys.argv[1]);p=root/'TTFontInfo.ini'
 for name in ['Metropolis.ttf','complex.ttf']:
  if not (root/name).is_file():raise SystemExit('Copie '+name+' para '+str(root)+' antes de executar.')
 data=p.read_bytes();result=merge(data);stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S');backup=p.with_name(p.name+'.gearscore-'+stamp+'.bak');backup.write_bytes(data);p.write_bytes(result);print('Fontes mescladas. Backup: '+str(backup))
if __name__=='__main__':main()
