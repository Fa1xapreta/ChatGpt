// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.util.Rnd;

public final class TreasureHuntManager implements Runnable
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntManager.class.getName());
    private List<CustomTreasureHunt> hunts = Collections.emptyList();
    private boolean started, enabled, testMode;
    private int interval;
    private long nextRun;

    private TreasureHuntManager() { }
    public static TreasureHuntManager getInstance() { return Holder.INSTANCE; }

    public synchronized void start()
    {
        if (started)
            return;
        reload();
        started = true;
        ThreadPoolManager.getInstance().scheduleGeneral(this, 1000);
    }

    /** Invalid XML leaves existing events untouched. */
    public synchronized boolean reload()
    {
        try
        {
            List<CustomTreasureHunt> replacement = new ArrayList<>();
            for (TreasureHunt definition : TreasureHuntData.load())
                replacement.add(new CustomTreasureHunt(definition));
            clear();
            hunts = replacement;
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
            testMode = Config.TREASURE_HUNT_TEST_MODE;
            nextRun = System.nanoTime() + (testMode ? 0 : TimeUnit.SECONDS.toNanos(interval));
            LOG.info("TreasureHunt: loaded " + hunts.size() + " entries; enabled=" + enabled + ", interval=" + interval + " seconds; testMode=" + testMode + ".");
            return true;
        }
        catch (Exception e)
        {
            LOG.log(Level.SEVERE, "TreasureHunt: configuration rejected; previous events preserved.", e);
            return false;
        }
    }

    @Override
    public void run()
    {
        try { tick(); }
        catch (Exception e) { LOG.log(Level.SEVERE, "TreasureHunt tick failed", e); }
        finally { ThreadPoolManager.getInstance().scheduleGeneral(this, 1000); }
    }

    private synchronized void tick()
    {
        long now = System.nanoTime();
        int configuredInterval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
        boolean modeChanged = testMode != Config.TREASURE_HUNT_TEST_MODE;
        if (enabled != Config.ENABLE_TREASURE_HUNT || interval != configuredInterval || modeChanged)
        {
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = configuredInterval;
            testMode = Config.TREASURE_HUNT_TEST_MODE;
            nextRun = now + (testMode ? 0 : TimeUnit.SECONDS.toNanos(interval));
            if (!enabled || modeChanged)
                clear();
        }
        if (!enabled || now - nextRun < 0)
            return;
        nextRun = now + TimeUnit.SECONDS.toNanos(interval);
        if (testMode)
        {
            clear();
            Set<Integer> spawnedNpcIds = new HashSet<>();
            int index = 0;
            for (CustomTreasureHunt hunt : hunts)
                if (spawnedNpcIds.add(hunt.getDefinition().getNpcId()))
                {
                    // One stone per NPC template, in a square around the test anchor.
                    int x = Config.TREASURE_HUNT_TEST_X + (index % 2) * 120;
                    int y = Config.TREASURE_HUNT_TEST_Y + (index / 2) * 120;
                    hunt.spawnTestNpc(x, y, Config.TREASURE_HUNT_TEST_Z);
                    index++;
                }
            return;
        }
        for (CustomTreasureHunt hunt : hunts)
            if (Rnd.get(100) < hunt.getDefinition().getChance())
            {
                hunt.despawnNpc();
                hunt.spawnNpc();
            }
    }

    private void clear()
    {
        for (CustomTreasureHunt hunt : hunts)
            hunt.despawnNpc();
    }

    private static final class Holder
    {
        private static final TreasureHuntManager INSTANCE = new TreasureHuntManager();
    }
}
