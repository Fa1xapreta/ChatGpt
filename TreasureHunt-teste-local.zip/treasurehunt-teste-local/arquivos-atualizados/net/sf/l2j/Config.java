/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import net.sf.l2j.commons.config.ExProperties;
import net.sf.l2j.gameserver.geoengine.geodata.GeoFormat;
import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.model.holder.IntIntHolder;
import net.sf.l2j.gameserver.model.holder.ItemHolder;
import net.sf.l2j.gameserver.model.holder.RewardHolder;
import net.sf.l2j.gameserver.model.item.type.CrystalType;
import net.sf.l2j.gameserver.util.FloodProtectorConfig;
import net.sf.l2j.util.StringUtil;

/**
 * This class contains global server configuration.<br>
 * It has static final fields initialized from configuration files.<br>
 * @author mkizub
 */
public final class Config
{
	public static volatile boolean ENABLE_TREASURE_HUNT;
	public static volatile int TREASURE_HUNT_INTERVAL;
	public static volatile boolean TREASURE_HUNT_AUTO_LOOT;
	public static volatile boolean TREASURE_HUNT_TEST_MODE;
	public static volatile int TREASURE_HUNT_TEST_X, TREASURE_HUNT_TEST_Y, TREASURE_HUNT_TEST_Z;

	protected static final Logger _log = Logger.getLogger(Config.class.getName());

	public static final String BANNED_IP_XML = "./config/banned.xml";
	public static final String CLANS_FILE = "./config/main/clans.properties";
	public static final String RATES_FILE = "./config/main/rates.properties";
	public static final String BOSS_FILE = "./config/main/boss.properties";
	public static final String VIP_FILE = "./config/custom/VipSettings.properties";
	public static final String AGATHION_FILE = "./config/custom/agathions.properties";
	public static final String COMMAND_FILE = "./config/custom/Commands.properties";
	public static final String EVENTS_FILE = "./config/main/events.properties";
	public static final String FLOOD_PROTECTOR_FILE = "./config/main/floodprotector.properties";
	public static final String GEOENGINE_FILE = "./config/main/geoengine.properties";
	public static final String HEXID_FILE = "./config/hexid.txt";
	public static final String SAY_FILTER_FILE = "./config/sayfilter.txt";
	public static final String LOGIN_CONFIGURATION_FILE = "./config/loginserver.properties";
	public static final String NPCS_FILE = "./config/main/npcs.properties";
	public static final String PLAYERS_FILE = "./config/main/players.properties";
	public static final String SERVER_FILE = "./config/server.properties";
	public static final String ADMIN_FILE = "./config/main/admin.properties";
	public static final String SIEGE_FILE = "./config/main/siege.properties";
	public static final String OLY_FILE = "./config/main/olympiad.properties";
	public static final String L2JMOD_FILE = "./config/custom/l2jmod.properties";
	public static final String L2JEVENT_FILE = "./config/custom/l2jevents.properties";
	public static final String PCBANG_FILE = "./config/custom/events/pcbang.properties";
	public static final String PARTYZONE_FILE = "./config/custom/events/partyzone.properties";
	public static final String LS_FILE = "./config/custom/events/Tyrannosaurus.properties";
	public static final String SOLOBOSS_FILE = "./config/custom/events/soloboss.properties";
	public static final String NFTBOSS_FILE = "./config/custom/events/nftboss.properties";
	public static final String MISSION_FILE = "./config/custom/events/mission.properties";
	public static final String BOOM_FILE = "./config/custom/events/boom.properties";
	public static final String TIME_ZONE_FILE = "./config/custom/events/timezone.properties";
	public static final String PVP_EVENT_FILE = "./config/custom/events/pvpevent.properties";
	public static final String ANNOUCEMENTS_FILE = "./config/custom/annoucements.properties";
	public static final String ENCHANT_FILE = "./config/main/enchant.properties";
	public static final String BALANCE_FILE = "./config/custom/balance/balance.properties";
	public static final String BALANCE_SKILLS_FILE = "./config/custom/balance/skills.properties";
	public static final String CLASS_DAMAGES_FILE = "./config/custom/balance/class_damages.properties";
	public static final String OLY_CLASS_DAMAGES_FILE = "./config/custom/balance/oly_class_damages.properties";
	public static final String PVP_BOSS_EVENT_FILE = "./config/custom/events/pvpboss.properties";
	public static final String SPOIL_INSTANCE_FILE = "./config/custom/events/SpoilInstance.properties";
	public static final String CERTIFICATION_FILE = "./config/custom/Certification.properties";

	  public static boolean ENABLE_AUCTION_SHOP;
	  public static boolean ENABLE_GRADE_ITEMS_SPAWNSHOP;
	  public static List<CrystalType> GRADE_ITEMS_PAWNSHOP = new ArrayList<>();
	  public static List<Integer> ITEMS_NO_RULES_PAWNSHOP;
	  public static String ITEMS_NO_RULES_PAWNSHOP_ID;
	  public static String NAME_MARKET_1;
	  public static int ID_MARKET_1;
	  public static String IMG_MARKET_1;
	  public static int TIME_SCREEN_SHOW;
	  public static boolean ALLOW_CBB_MARKETPLACE;
	  public static int[] MARKETPLACE_FEE = new int[2];
	  public static boolean MARKETPLACE_ALLOW_AUGMENTED_SALES;
	   
	public static boolean RAIDINFO_USE_GRAND_BOSS_LIST;
	public static boolean FREE_MULTISELL;
	public static boolean RESTART_BY_TIME_OF_DAY;
	public static int RESTART_SECONDS;
	public static String[] RESTART_INTERVAL_BY_TIME_OF_DAY;
	
	public static int LOG_DONATE_COIN_ID;
	public static boolean PVP_BOSS_EVENT;
	public static int PVPBOSS_EVENT_PVPS;
	public static int PVPBOSS_EVENT_ANNOUNCE_PROGRESS;
	public static String PVPBOSS_EVENT;
	public static List<Integer> PVPBOSS_EVENT_ID;
	public static int PVPBOSS_EVENT_LOCS_COUNT;
	public static int[][] PVPBOSS_EVENT_LOCS;
	
	public static boolean PVPKILL_IN_EVENTS;
	/** ThreadPool */
	public static int SCHEDULED_THREAD_POOL_COUNT;
	public static int THREADS_PER_SCHEDULED_THREAD_POOL;
	public static int INSTANT_THREAD_POOL_COUNT;
	public static int THREADS_PER_INSTANT_THREAD_POOL;

	//Password Secundary
	public static boolean SECONDARYPASS;
	public static boolean USE_NEW_AUTO_FARM;
	
	//Auto Farm Title
	public static String NEW_TITLE_AUTO_FARM;
	public static int AUTO_FARM_TITLE_COLOR;

	public static int MIN_RESPAWN;
	public static int MAX_RESPAWN;
	public static boolean RESPAWN_CUSTOM;
	public static String RESPAWN_IDS;
	public static List<Integer> RESPAWN_IDS_LIST;
	//Drop Anuncio Mod
	public static String ID_DROP;
	public static List<Integer> LISTID_DROP;
	//  Dolls Settings
	public static Map<Integer, Integer> LIST_RUNE_ITEMS;

	public static String ANNOUNCE_WORK_DAY;
	public static boolean ALLOW_WORK_DAY;
	public static String[] WORK_TIME;

	// Antilag Settings

	public static List<Integer> MSU_LIST_FOR_HIDE;


	public static int ITEM_IDBUFF;
	public static String SUBCLASS_TWO_OR_THREE;
	// ----------------------------------------
	// Skills_chance_modifier.properties
	// ----------------------------------------
	/** Chance modifier skills */
	public static boolean ENABLE_CUSTOM_CHANCE_SKILL;
	public static float VORTEX_TO_FIRE;
	public static float WIND_VORTEX;
	public static float DARK_VORTEX;
	public static float ICE_VORTEX;
	public static float LIGHT_VORTEX;
	public static float SILENCE;
	public static float TRICK;
	public static float SLEEP;
	public static float CURSE_FEAR;
	public static float ANCHOR;
	public static float CURSE_OF_DOOM;
	public static float CURSE_OF_ABYSS;
	public static float CANCELLATION;
	public static float MASS_SLOW;
	public static float MASS_FEAR;
	public static float MASS_GLOOM;
	public static float SLEEPING_CLOUD;
	public static float HEROIC_GRANDEUR;
	public static float HEROIC_DREAD;
	public static float STUNNING_SHOT;
	public static float HEX;
	public static float SHOCK_STOMP;
	public static float THUNDER_STORM;
	public static float SHIELD_STUN;
	public static float SHIELD_SLAM;
	public static float SHACKLE;
	public static float MASS_SHACKLING;
	public static float ARREST;
	public static float BLUFF;
	public static float SWITCH;
	public static float STUNNING_FIST;
	public static float FEAR_OVER;
	public static float SEAL_OF_SILENCE;
	public static float SEAL_OF_SUSPENSION;
	public static float STUN_ATTACK;
	public static float ARMOR_CRUSH;
	public static float SLOW;
	public static float SEAL_OF_DESPAIR;
	public static float DREAMING_SPIRIT;
	public static float SEAL_OF_BINDING;
	public static float MASS_WARRIOR_BANE;
	public static float MASS_MAGE_BANE;
	public static float SHIELD_BASH;
	public static float SHOCK_BLAST;
	public static float LIGHTNING_STRIKE;
	public static float TRANCE;
	public static float SOUL_BREAK;

	public static boolean CHECK_NOBLE_SKILLS;
	public static boolean CHECK_HERO_SKILLS;

	public static boolean TRADE_HISTORY_ENABLED;
	public static int TRADE_HISTORY_PAGE_LIMIT;

	public static boolean PREMIUM_SERVICES_ENABLED;
	public static boolean PREMIUM_SUB_DOMINATOR_ENABLED;
	public static int PREMIUM_SUB_DOMINATOR_CLASS_ID;
	public static int PREMIUM_SUB_DOMINATOR_MAX_SUBS;
	public static int PREMIUM_SUB_DOMINATOR_ITEM_ID;
	public static int PREMIUM_SUB_DOMINATOR_ITEM_COUNT;
	public static boolean PREMIUM_AUGMENT_TRANSFER_ENABLED;
	public static int PREMIUM_AUGMENT_TRANSFER_ITEM_ID;
	public static int PREMIUM_AUGMENT_TRANSFER_ITEM_COUNT;
	public static boolean PREMIUM_ENCHANT_TRANSFER_ENABLED;
	public static int PREMIUM_ENCHANT_TRANSFER_ITEM_ID;
	public static int PREMIUM_ENCHANT_TRANSFER_ITEM_COUNT;
	public static boolean PREMIUM_ENCHANT_TRANSFER_ALLOW_WEAPONS;
	public static boolean PREMIUM_ENCHANT_TRANSFER_ALLOW_ARMORS;
	public static boolean PREMIUM_ENCHANT_TRANSFER_ALLOW_JEWELS;
	public static boolean PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_TYPE;
	public static boolean PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_SLOT;
	public static boolean PREMIUM_ENCHANT_TRANSFER_TARGET_MUST_BE_ZERO;
	public static boolean PREMIUM_SKILL_ENCHANT_ENABLED;
	public static int PREMIUM_SKILL_ENCHANT_MAX;
	public static int PREMIUM_SKILL_ENCHANT_MIN_LEVEL;
	public static int PREMIUM_SKILL_ENCHANT_ITEM_ID;
	public static int PREMIUM_SKILL_ENCHANT_ITEM_COUNT;
	public static boolean PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL;

	/** Commands */
	public static boolean ALLOW_CMD_STATUS;
	public static boolean ALLOW_CMD_INVENTORY;
	public static boolean ALLOW_CMD_SKILLS;
	public static boolean ALLOW_CMD_INFO;
	public static boolean ALLOW_CMD_PASSWORD;
	public static boolean ALLOW_CMD_RANKING;
	public static boolean ALLOW_CMD_PVP;
	public static boolean ALLOW_CMD_PK;
	public static boolean ALLOW_CMD_CLAN;
	public static boolean ALLOW_CMD_CLANPOINT;
	public static boolean ALLOW_CMD_1X1;
	public static boolean ALLOW_CMD_3x3;
	public static boolean ALLOW_CMD_5x5;
	public static boolean ALLOW_CMD_9x9;
	public static boolean ALLOW_CMD_ELOPOINT;
	public static boolean ALLOW_CMD_ENCHANT;
	public static boolean ALLOW_CMD_CASTLE;	

	/** Certificaçoes */
	public static boolean CERTIFICATION_ENABLED;
	public static double CERTIFICATION_DEFAULT_CHANCE;
	public static int[] CERTIFICATION_ITEM_IDS;
	public static int[] CERTIFICATION_PASSIVE_SKILL_IDS;
	public static int[] CERTIFICATION_ACTIVE_SKILL_IDS;
	public static boolean CERTIFICATION_NOTIFY_ON_ACTIVATE;
		
	/** Items */
	public static boolean ALL_ITEMS_SELL_ZERO_ADENA;
	/** Infinity SS and Arrows */
	public static boolean INFINITY_SS;
	public static boolean INFINITY_ARROWS;

	public static boolean BOOM_REWARD_ITEM_ENABLED;
	public static List<int[]> LVL_1_REWARD = new ArrayList<>();
	public static List<int[]> LVL_2_REWARD = new ArrayList<>();
	public static List<int[]> LVL_3_REWARD = new ArrayList<>();
	public static List<int[]> LVL_4_REWARD = new ArrayList<>();
	public static List<int[]> LVL_5_REWARD = new ArrayList<>();
	public static int EVENT_KEY;
	public static int EVENT_KEY_AMOUNT_1;
	public static int EVENT_KEY_AMOUNT_2;
	public static int EVENT_KEY_AMOUNT_3;
	public static int EVENT_KEY_AMOUNT_4;
	public static int EVENT_KEY_AMOUNT_5;

	// --------------------------------------------------
	// Clans settings
	// --------------------------------------------------

	/** Clans */
	public static int MAX_CLAN_MEMBERS;
	public static int MAX_CLAN_MEMBERS_ROYALS;
	public static int MAX_CLAN_MEMBERS_KNIGHTS;
	public static boolean DISABLE_JOIN_IN_ALLY;
	public static int ALT_CLAN_JOIN_DAYS;
	public static int ALT_CLAN_CREATE_DAYS;
	public static int ALT_CLAN_DISSOLVE_DAYS;
	public static int ALT_ALLY_JOIN_DAYS_WHEN_LEAVED;
	public static int ALT_ALLY_JOIN_DAYS_WHEN_DISMISSED;
	public static int ALT_ACCEPT_CLAN_DAYS_WHEN_DISMISSED;
	public static int ALT_CREATE_ALLY_DAYS_WHEN_DISSOLVED;
	public static int ALT_MAX_NUM_OF_CLANS_IN_ALLY;
	public static int ALT_CLAN_MEMBERS_FOR_WAR;
	public static int ALT_CLAN_WAR_PENALTY_WHEN_ENDED;
	public static boolean ALT_MEMBERS_CAN_WITHDRAW_FROM_CLANWH;
	public static boolean REMOVE_CASTLE_CIRCLETS;

	public static boolean ENABLE_WINNNER_REWARD_SIEGE_CLAN;
	public static int[][] REWARD_WINNER_SIEGE_CLAN;
	public static int[][] LEADER_REWARD_WINNER_SIEGE_CLAN;
	public static int PLAYER_COUNT_KILLS_INSIEGE;

	/** Manor */
	public static int ALT_MANOR_REFRESH_TIME;
	public static int ALT_MANOR_REFRESH_MIN;
	public static int ALT_MANOR_APPROVE_TIME;
	public static int ALT_MANOR_APPROVE_MIN;
	public static int ALT_MANOR_MAINTENANCE_PERIOD;
	public static boolean ALT_MANOR_SAVE_ALL_ACTIONS;
	public static int ALT_MANOR_SAVE_PERIOD_RATE;

	//reward diario
	public static boolean ENBALE_DAILY_REWARD;
	public static int REWARD_PER_TIME_MODE_RESTRICTION;
	public static List<IntIntHolder> DAILY_REWARD = new ArrayList<>();
	public static Map<Integer, IntIntHolder> DAILY_REWARD_MAP = new HashMap<>();
	
	
	/** Clan Hall function */
	public static long CH_TELE_FEE_RATIO;
	public static int CH_TELE1_FEE;
	public static int CH_TELE2_FEE;
	public static long CH_ITEM_FEE_RATIO;
	public static int CH_ITEM1_FEE;
	public static int CH_ITEM2_FEE;
	public static int CH_ITEM3_FEE;
	public static long CH_MPREG_FEE_RATIO;
	public static int CH_MPREG1_FEE;
	public static int CH_MPREG2_FEE;
	public static int CH_MPREG3_FEE;
	public static int CH_MPREG4_FEE;
	public static int CH_MPREG5_FEE;
	public static long CH_HPREG_FEE_RATIO;
	public static int CH_HPREG1_FEE;
	public static int CH_HPREG2_FEE;
	public static int CH_HPREG3_FEE;
	public static int CH_HPREG4_FEE;
	public static int CH_HPREG5_FEE;
	public static int CH_HPREG6_FEE;
	public static int CH_HPREG7_FEE;
	public static int CH_HPREG8_FEE;
	public static int CH_HPREG9_FEE;
	public static int CH_HPREG10_FEE;
	public static int CH_HPREG11_FEE;
	public static int CH_HPREG12_FEE;
	public static int CH_HPREG13_FEE;
	public static long CH_EXPREG_FEE_RATIO;
	public static int CH_EXPREG1_FEE;
	public static int CH_EXPREG2_FEE;
	public static int CH_EXPREG3_FEE;
	public static int CH_EXPREG4_FEE;
	public static int CH_EXPREG5_FEE;
	public static int CH_EXPREG6_FEE;
	public static int CH_EXPREG7_FEE;
	public static long CH_SUPPORT_FEE_RATIO;
	public static int CH_SUPPORT1_FEE;
	public static int CH_SUPPORT2_FEE;
	public static int CH_SUPPORT3_FEE;
	public static int CH_SUPPORT4_FEE;
	public static int CH_SUPPORT5_FEE;
	public static int CH_SUPPORT6_FEE;
	public static int CH_SUPPORT7_FEE;
	public static int CH_SUPPORT8_FEE;
	public static long CH_CURTAIN_FEE_RATIO;
	public static int CH_CURTAIN1_FEE;
	public static int CH_CURTAIN2_FEE;
	public static long CH_FRONT_FEE_RATIO;
	public static int CH_FRONT1_FEE;
	public static int CH_FRONT2_FEE;

	// ----------------------------------------
	// Enchant.properties
	// ----------------------------------------
	/** Enchant */
	public static boolean ENABLE_VIP_ENCHANT_BONUS;
	public static int VIP_ENCHANT_BONUS;
	public static HashMap<Integer, Integer> NORMAL_WEAPON_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> BLESS_WEAPON_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> CRYSTAL_WEAPON_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> NORMAL_ARMOR_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> BLESS_ARMOR_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> CRYSTAL_ARMOR_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> NORMAL_JEWELRY_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> BLESS_JEWELRY_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> CRYSTAL_JEWELRY_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> EPIC_WEAPON_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> EPIC_ARMOR_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> EPIC_JEWELRY_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> DIAMOUND_WEAPON_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> DIAMOUND_ARMOR_ENCHANT_LEVEL = new HashMap<>();
	public static HashMap<Integer, Integer> DIAMOUND_JEWELRY_ENCHANT_LEVEL = new HashMap<>();
	public static boolean ENCHANT_HERO_WEAPON;
	public static boolean SCROLL_STACKABLE;
	public static int EPIC_WEAPON;
	public static int EPIC_ARMOR;
	public static int ENCHANT_SAFE_MAX;
	public static int ENCHANT_SAFE_MAX_FULL;
	public static int ENCHANT_WEAPON_MAX;
	public static int ENCHANT_ARMOR_MAX;
	public static int ENCHANT_JEWELRY_MAX;
	public static int BLESSED_ENCHANT_WEAPON_MAX;
	public static int BLESSED_ENCHANT_ARMOR_MAX;
	public static int BLESSED_ENCHANT_JEWELRY_MAX;
	public static int BREAK_ENCHANT;
	public static int CRYSTAL_BREAK_ENCHANT;
	public static boolean CRYSTAL_LOST_ENCHANT;
	public static boolean CRYSTAL_DECREASE_ENCHANT;
	public static int CRYSTAL_ENCHANT_MIN;
	public static int CRYSTAL_ENCHANT_WEAPON_MAX;
	public static int CRYSTAL_ENCHANT_ARMOR_MAX;
	public static int CRYSTAL_ENCHANT_JEWELRY_MAX;
	public static boolean EPIC_LOST_ENCHANT;
	public static boolean EPIC_DECREASE_ENCHANT;
	public static int EPIC_ENCHANT_MIN;
	public static int EPIC_ENCHANT_WEAPON_MAX;
	public static int EPIC_ENCHANT_ARMOR_MAX;
	public static int EPIC_ENCHANT_JEWELRY_MAX;
	public static int EPIC_BREAK_ENCHANT;
	public static int DIAMOUND_WEAPON;
	public static int DIAMOUND_ARMOR;
	public static boolean DIAMOUND_LOST_ENCHANT;
	public static boolean DIAMOUND_DECREASE_ENCHANT;
	public static int DIAMOUND_ENCHANT_MIN;
	public static int DIAMOUND_ENCHANT_WEAPON_MAX;
	public static int DIAMOUND_ENCHANT_ARMOR_MAX;
	public static int DIAMOUND_ENCHANT_JEWELRY_MAX;
	public static int DIAMOUND_BREAK_ENCHANT;
	public static boolean ENABLE_ENCHANT_ANNOUNCE;
	public static boolean ENABLE_ENCHANT_ANNOUNCE_FAIL;
	public static String ENCHANT_ANNOUNCE_LEVEL;
	public static ArrayList<Integer> LIST_ENCHANT_ANNOUNCE_LEVEL = new ArrayList<>();

	// --------------------------------------------------
	// Events settings
	// --------------------------------------------------

	/** Olympiad */
	public static int ALT_OLY_START_TIME;
	public static int ALT_OLY_MIN;
	public static long ALT_OLY_CPERIOD;
	public static long ALT_OLY_BATTLE;
	public static long ALT_OLY_WPERIOD;
	public static long ALT_OLY_VPERIOD;
	public static int ALT_OLY_WAIT_TIME;
	public static int ALT_OLY_WAIT_BATTLE;
	public static int ALT_OLY_WAIT_END;
	public static int ALT_OLY_START_POINTS;
	public static int ALT_OLY_WEEKLY_POINTS;
	public static int ALT_OLY_MIN_MATCHES;
	public static int ALT_OLY_CLASSED;
	public static int ALT_OLY_NONCLASSED;
	public static int[][] ALT_OLY_CLASSED_REWARD;
	public static int[][] ALT_OLY_NONCLASSED_REWARD;
	public static int ALT_OLY_COMP_RITEM;
	public static int ALT_OLY_GP_PER_POINT;
	public static int ALT_OLY_HERO_POINTS;
	public static int ALT_OLY_RANK1_POINTS;
	public static int ALT_OLY_RANK2_POINTS;
	public static int ALT_OLY_RANK3_POINTS;
	public static int ALT_OLY_RANK4_POINTS;
	public static int ALT_OLY_RANK5_POINTS;
	public static int ALT_OLY_DIVIDER_CLASSED;
	public static int ALT_OLY_DIVIDER_NON_CLASSED;
	public static boolean ALT_OLY_ANNOUNCE_GAMES;
	public static int ALT_OLY_ENCHANT_LIMIT;
	public static boolean ALT_OLY_USE_CUSTOM_PERIOD_SETTINGS;
	public static String ALT_OLY_PERIOD;
	public static int ALT_OLY_PERIOD_MULTIPLIER;
	public static boolean ALT_OLY_FIXED_WEEKLY_SCHEDULE;
	public static int ALT_OLY_FIXED_START_DAY;
	public static int ALT_OLY_FIXED_START_HOUR;
	public static int ALT_OLY_FIXED_START_MINUTE;
	public static int ALT_OLY_FIXED_HERO_DAY;
	public static int ALT_OLY_FIXED_HERO_HOUR;
	public static int ALT_OLY_FIXED_HERO_MINUTE;
	public static boolean OLY_FIGHT;
	public static boolean ALT_OLY_RECHARGE_SKILLS;
	public static boolean ALT_OLY_REMOVE_SKILL;
	public static List<Integer> ALT_OLY_REMOVE_SKILL_LIST = new ArrayList<>();
	public static boolean OLY_SKILL_PROTECT;
	public static ArrayList<Integer> OLY_PROTECT_ITEMS = new ArrayList<>();
	public static List<Integer> OLY_SKILL_LIST = new ArrayList<>();

	/** SevenSigns Festival */
	public static boolean ALT_GAME_REQUIRE_CLAN_CASTLE;
	public static boolean ALT_GAME_CASTLE_DAWN;
	public static boolean ALT_GAME_CASTLE_DUSK;
	public static int ALT_FESTIVAL_MIN_PLAYER;
	public static int ALT_MAXIMUM_PLAYER_CONTRIB;
	public static long ALT_FESTIVAL_MANAGER_START;
	public static long ALT_FESTIVAL_LENGTH;
	public static long ALT_FESTIVAL_CYCLE_LENGTH;
	public static long ALT_FESTIVAL_FIRST_SPAWN;
	public static long ALT_FESTIVAL_FIRST_SWARM;
	public static long ALT_FESTIVAL_SECOND_SPAWN;
	public static long ALT_FESTIVAL_SECOND_SWARM;
	public static long ALT_FESTIVAL_CHEST_SPAWN;
	public static boolean ALT_SEVENSIGNS_LAZY_UPDATE;

	/** PvpRankHud Interface */
	public static boolean SHOW_PVP_RANK_HUD;
	public static int SHOW_PVP_RANK_HUD_INTERVAL;
	public static int SHOW_PVP_RANK_HUD_RADIUS;
	public static int SHOW_PVP_RANK_HUD_TOP;
	public static int SHOW_PVP_RANK_HUD_REFRESH;
	public static boolean SHOW_KILL_FEED;
	public static int SHOW_KILL_FEED_RADIUS;
	public static boolean SHOW_KILL_FEED_GLOBAL;
	public static boolean SHOW_KILL_FEED_BOTS;
	public static boolean SHOW_ITEM_TIER;

	
	/** Four Sepulchers */
	public static int FS_TIME_ATTACK;
	public static int FS_TIME_COOLDOWN;
	public static int FS_TIME_ENTRY;
	public static int FS_TIME_WARMUP;
	public static int FS_PARTY_MEMBER_COUNT;

	/** dimensional rift */
	public static int RIFT_MIN_PARTY_SIZE;
	public static int RIFT_SPAWN_DELAY;
	public static int RIFT_MAX_JUMPS;
	public static int RIFT_AUTO_JUMPS_TIME_MIN;
	public static int RIFT_AUTO_JUMPS_TIME_MAX;
	public static int RIFT_ENTER_COST_RECRUIT;
	public static int RIFT_ENTER_COST_SOLDIER;
	public static int RIFT_ENTER_COST_OFFICER;
	public static int RIFT_ENTER_COST_CAPTAIN;
	public static int RIFT_ENTER_COST_COMMANDER;
	public static int RIFT_ENTER_COST_HERO;
	public static double RIFT_BOSS_ROOM_TIME_MUTIPLY;

	/** Wedding system */
	public static boolean ALLOW_WEDDING;
	public static int WEDDING_PRICE;
	public static boolean WEDDING_SAMESEX;
	public static boolean WEDDING_FORMALWEAR;

	/** Lottery */
	public static int ALT_LOTTERY_PRIZE;
	public static int ALT_LOTTERY_TICKET_PRICE;
	public static double ALT_LOTTERY_5_NUMBER_RATE;
	public static double ALT_LOTTERY_4_NUMBER_RATE;
	public static double ALT_LOTTERY_3_NUMBER_RATE;
	public static int ALT_LOTTERY_2_AND_1_NUMBER_PRIZE;

	//Hunter Mode
	public static boolean PVP_DROP_MODE_ENABLED;
	public static double PVP_DROP_MODE_BONUS;
	public static boolean PVP_DROP_MODE_HWID_PROTECTION;
	
	/** Fishing  */
	public static boolean ALT_FISH_CHAMPIONSHIP_ENABLED;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_ITEM;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_1;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_2;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_3;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_4;
	public static int ALT_FISH_CHAMPIONSHIP_REWARD_5;

	// --------------------------------------------------
	// GeoEngine
	// --------------------------------------------------

	/** Geodata */
	public static int GEODATA;
	public static String GEODATA_PATH;
	public static GeoFormat GEODATA_FORMAT;
	public static boolean GEODATA_DIAGONAL;
	public static int COORD_SYNCHRONIZE;
	public static boolean FALLEN_POSITION;

	/** Path checking */
	public static int PART_OF_CHARACTER_HEIGHT;
	public static int MAX_OBSTACLE_HEIGHT;

	/** Path finding */
	public static String PATHFIND_BUFFERS;
	public static int BASE_WEIGHT;
	public static int DIAGONAL_WEIGHT;
	public static int HEURISTIC_WEIGHT;
	public static int OBSTACLE_MULTIPLIER;
	public static int MAX_ITERATIONS;
	public static boolean DEBUG_PATH;

	// --------------------------------------------------
	// HexID
	// --------------------------------------------------

	public static int SERVER_ID;
	public static byte[] HEX_ID;

	// --------------------------------------------------
	// FloodProtectors
	// --------------------------------------------------

	public static FloodProtectorConfig FLOOD_PROTECTOR_ROLL_DICE;
	public static FloodProtectorConfig FLOOD_PROTECTOR_SHOUT_VOICE;
	public static FloodProtectorConfig FLOOD_PROTECTOR_TRADE_CHAT;
	public static FloodProtectorConfig FLOOD_PROTECTOR_HERO_VOICE;
	public static FloodProtectorConfig FLOOD_PROTECTOR_SUBCLASS;
	public static FloodProtectorConfig FLOOD_PROTECTOR_DROP_ITEM;
	public static FloodProtectorConfig FLOOD_PROTECTOR_SERVER_BYPASS;
	public static FloodProtectorConfig FLOOD_PROTECTOR_MULTISELL;
	public static FloodProtectorConfig FLOOD_PROTECTOR_MANUFACTURE;
	public static FloodProtectorConfig FLOOD_PROTECTOR_MANOR;
	public static FloodProtectorConfig FLOOD_PROTECTOR_SENDMAIL;
	public static FloodProtectorConfig FLOOD_PROTECTOR_CHARACTER_SELECT;
	public static FloodProtectorConfig FLOOD_PROTECTOR_USE_ENCHANT;

	// --------------------------------------------------
	// Loginserver
	// --------------------------------------------------

	public static String LOGIN_BIND_ADDRESS;
	public static int PORT_LOGIN;

	public static boolean ACCEPT_NEW_GAMESERVER;
	public static int REQUEST_ID;
	public static boolean ACCEPT_ALTERNATE_ID;
	public static String GAMESERVER_SESSION_KEY;

	public static int LOGIN_TRY_BEFORE_BAN;
	public static int LOGIN_BLOCK_AFTER_BAN;

	public static boolean LOG_LOGIN_CONTROLLER;
	public static boolean LOGIN_SERVER_SCHEDULE_RESTART;
	public static long LOGIN_SERVER_SCHEDULE_RESTART_TIME;

	public static boolean SHOW_LICENCE;
	public static int IP_UPDATE_TIME;
	public static boolean FORCE_GGAUTH;
	public static boolean L2ARTS_PROTECTION_ENABLED;

	public static boolean AUTO_CREATE_ACCOUNTS;

	public static boolean FLOOD_PROTECTION;
	public static int FAST_CONNECTION_LIMIT;
	public static int NORMAL_CONNECTION_TIME;
	public static int FAST_CONNECTION_TIME;
	public static int MAX_CONNECTION_PER_IP;

	// --------------------------------------------------
	// NPCs / Monsters
	// --------------------------------------------------

	/** Champion Mod */
	public static int CHAMPION_FREQUENCY;
	public static int CHAMP_MIN_LVL;
	public static int CHAMP_MAX_LVL;
	public static int CHAMPION_HP;
	public static int CHAMPION_REWARDS;
	public static int CHAMPION_ADENAS_REWARDS;
	public static double CHAMPION_HP_REGEN;
	public static double CHAMPION_ATK;
	public static double CHAMPION_SPD_ATK;
	public static int CHAMPION_REWARD;
	public static int CHAMPION_REWARD_ID;
	public static int CHAMPION_REWARD_QTY;

	/** Buffer */
	public static int BUFFER_MAX_SCHEMES;
	public static int BUFFER_STATIC_BUFF_COST;

	public static String FIGHTER_BUFF;
	public static ArrayList<Integer> FIGHTER_BUFF_LIST = new ArrayList<>();
	public static String MAGE_BUFF;
	public static ArrayList<Integer> MAGE_BUFF_LIST = new ArrayList<>();

	public static String EXCLUDE_SKILLS;
	public static ArrayList<Integer> EXCLUDE_SKILLS_LIST = new ArrayList<>();

	/** Misc */
	public static boolean ALLOW_CLASS_MASTERS;
	public static ClassMasterSettings CLASS_MASTER_SETTINGS;
	public static boolean ALLOW_ENTIRE_TREE;
	public static boolean ALTERNATE_CLASS_MASTER;
	public static boolean ANNOUNCE_MAMMON_SPAWN;
	public static boolean ALT_MOB_AGRO_IN_PEACEZONE;
	public static boolean ALT_GAME_FREE_TELEPORT;
	public static boolean SHOW_NPC_EFFECT_SUBCLASS;
	public static boolean SHOW_EFFECT_CLASS;
	public static boolean SHOW_NPC_LVL;
	public static boolean SHOW_NPC_CREST;
	public static boolean SHOW_SUMMON_CREST;

	/** Wyvern Manager */
	public static boolean WYVERN_ALLOW_UPGRADER;
	public static int WYVERN_REQUIRED_LEVEL;
	public static int WYVERN_REQUIRED_CRYSTALS;

	/** Raid Boss */
	public static double RAID_HP_REGEN_MULTIPLIER;
	public static double RAID_MP_REGEN_MULTIPLIER;
	public static double RAID_DEFENCE_MULTIPLIER;
	public static double RAID_MINION_RESPAWN_TIMER;

	public static boolean PLAYERS_CAN_HEAL_RB;
	public static boolean RAID_DISABLE_CURSE;
	public static int RAID_CHAOS_TIME;
	public static int GRAND_CHAOS_TIME;
	public static int MINION_CHAOS_TIME;

	/** Grand Boss */
	public static int SPAWN_INTERVAL_AQ;
	public static int RANDOM_SPAWN_TIME_AQ;

	public static int SPAWN_INTERVAL_ANTHARAS;
	public static int RANDOM_SPAWN_TIME_ANTHARAS;
	public static int WAIT_TIME_ANTHARAS;

	public static int SPAWN_INTERVAL_BAIUM;
	public static int RANDOM_SPAWN_TIME_BAIUM;

	public static int SPAWN_INTERVAL_CORE;
	public static int RANDOM_SPAWN_TIME_CORE;

	public static int SPAWN_INTERVAL_FRINTEZZA;
	public static int RANDOM_SPAWN_TIME_FRINTEZZA;
	public static int FRINTEZZA_TIME_CHALLENGE;
	public static int WAIT_TIME_FRINTEZZA;
	public static int DESPAWN_TIME_FRINTEZZA;
	public static boolean BYPASS_FRINTEZZA_PARTIES_CHECK;
	public static int FRINTEZZA_MIN_PARTIES;
	public static int FRINTEZZA_MAX_PARTIES;

	public static int SPAWN_INTERVAL_ORFEN;
	public static int RANDOM_SPAWN_TIME_ORFEN;

	public static int SPAWN_INTERVAL_SAILREN;
	public static int RANDOM_SPAWN_TIME_SAILREN;
	public static int WAIT_TIME_SAILREN;

	public static int SPAWN_INTERVAL_VALAKAS;
	public static int RANDOM_SPAWN_TIME_VALAKAS;
	public static int WAIT_TIME_VALAKAS;

	public static int SPAWN_INTERVAL_ALTAR;
	public static int RANDOM_SPAWN_TIME_ALTAR;
	
	// Zaken.
	public static int SPAWN_INTERVAL_ZAKEN;

	public static int[] ZAKEN_LOCATION = new int[3];
	public static int SEGUNDS_DURATION_OPEN_ZAKEN;
	public static int CUBIC_TIME_SPAWN_ZAKEN;
	public static int ZAKEN_PRESPAWN_DOOR_TIME;
	public static int SEGUNDS_DURATION_OPEN_ZAKEN_RANDOM;
	public static int[] ZAKEN_CUBIC_TELEPORT_LOC = new int[3];

	//new Config Time Epics
	public static boolean ANTQUEEN_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> ANTQUEEN_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int ANTQUEEN_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean ANTHARAS_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> ANTHARAS_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int ANTHARAS_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean CORE_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> CORE_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int CORE_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean ORFEN_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> ORFEN_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int ORFEN_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean ZAKEN_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> ZAKEN_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int ZAKEN_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean FRINTEZZA_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> FRINTEZZA_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int FRINTEZZA_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean BAIUM_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> BAIUM_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int BAIUM_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean VALAKAS_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> VALAKAS_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int VALAKAS_CUSTOM_SPAWN_RANDOM_INTERVAL;
	public static boolean ALTAR_CUSTOM_SPAWN_ENABLED;
	public static ArrayList<Calendar> ALTAR_CUSTOM_SPAWN_TIMES = new ArrayList<>();
	public static int ALTAR_CUSTOM_SPAWN_RANDOM_INTERVAL;

	/** IA */
	public static boolean GUARD_ATTACK_AGGRO_MOB;
	public static int MAX_DRIFT_RANGE;
	public static int MAX_DRIFT_RANGE_EPIC;
	public static long KNOWNLIST_UPDATE_INTERVAL;
	public static int MIN_NPC_ANIMATION;
	public static int MAX_NPC_ANIMATION;
	public static int MIN_MONSTER_ANIMATION;
	public static int MAX_MONSTER_ANIMATION;

	public static boolean GRIDS_ALWAYS_ON;
	public static int GRID_NEIGHBOR_TURNON_TIME;
	public static int GRID_NEIGHBOR_TURNOFF_TIME;

	public static boolean ENABLE_SKIPPING;
	public static int ITEM_ID_BUY_CLAN_HALL;

	// --------------------------------------------------
	// Players
	// --------------------------------------------------

	/** Misc */
	public static int STARTING_ADENA;

	public static boolean CUSTOM_STARTER_ITEMS_ENABLED;
	public static List<int[]> STARTING_CUSTOM_ITEMS_F = new ArrayList<>();
	public static List<int[]> STARTING_CUSTOM_ITEMS_M = new ArrayList<>();

	public static boolean EFFECT_CANCELING;
	public static double HP_REGEN_MULTIPLIER;
	public static double MP_REGEN_MULTIPLIER;
	public static double CP_REGEN_MULTIPLIER;
	public static int PLAYER_SPAWN_PROTECTION;
	public static int PLAYER_FAKEDEATH_UP_PROTECTION;
	public static double RESPAWN_RESTORE_HP;
	public static double RESPAWN_RESTORE_MP;
	public static double RESPAWN_RESTORE_CP;
	public static int MAX_PVTSTORE_SLOTS_DWARF;
	public static int MAX_PVTSTORE_SLOTS_OTHER;
	public static boolean DEEPBLUE_DROP_RULES;
	public static boolean ALT_GAME_DELEVEL;
	public static int DEATH_PENALTY_CHANCE;

	/** Inventory & WH */
	public static int INVENTORY_MAXIMUM_NO_DWARF;
	public static int INVENTORY_MAXIMUM_DWARF;
	public static int INVENTORY_MAXIMUM_QUEST_ITEMS;
	public static int INVENTORY_MAXIMUM_PET;
	public static int MAX_ITEM_IN_PACKET;
	public static double ALT_WEIGHT_LIMIT;
	public static int WAREHOUSE_SLOTS_NO_DWARF;
	public static int WAREHOUSE_SLOTS_DWARF;
	public static int WAREHOUSE_SLOTS_CLAN;
	public static int FREIGHT_SLOTS;
	public static boolean ALT_GAME_FREIGHTS;
	public static int ALT_GAME_FREIGHT_PRICE;

	/** Augmentations */
	public static int AUGMENTATION_NG_SKILL_CHANCE;
	public static int AUGMENTATION_NG_GLOW_CHANCE;
	public static int AUGMENTATION_NG_BASESTAT_CHANCE;

	public static int AUGMENTATION_MID_SKILL_CHANCE;
	public static int AUGMENTATION_MID_GLOW_CHANCE;
	public static int AUGMENTATION_MID_BASESTAT_CHANCE;

	public static int AUGMENTATION_HIGH_SKILL_CHANCE;
	public static int AUGMENTATION_HIGH_GLOW_CHANCE;
	public static int AUGMENTATION_HIGH_BASESTAT_CHANCE;

	public static int AUGMENTATION_TOP_SKILL_CHANCE;
	public static int AUGMENTATION_TOP_GLOW_CHANCE;
	public static int AUGMENTATION_TOP_BASESTAT_CHANCE;

	/** Karma & PvP */
	public static boolean KARMA_PLAYER_CAN_BE_KILLED_IN_PZ;
	public static boolean KARMA_PLAYER_CAN_SHOP;
	public static boolean KARMA_PLAYER_CAN_USE_GK;
	public static boolean KARMA_PLAYER_CAN_TELEPORT;
	public static boolean KARMA_PLAYER_CAN_TRADE;
	public static boolean KARMA_PLAYER_CAN_USE_WH;

	//new config
	public static boolean FLAG_PLAYER_CAN_USE_GK;
	public static boolean FLAG_PLAYER_CAN_TRADE;

	public static boolean KARMA_DROP_GM;
	public static boolean KARMA_AWARD_PK_KILL;
	public static int KARMA_PK_LIMIT;
	public static int KARMA_XP_DIVIDER;
	public static int KARMA_LOST_BASE;

	public static String KARMA_NONDROPPABLE_PET_ITEMS;
	public static String KARMA_NONDROPPABLE_ITEMS;
	public static int[] KARMA_LIST_NONDROPPABLE_PET_ITEMS;
	public static int[] KARMA_LIST_NONDROPPABLE_ITEMS;

	public static int PVP_NORMAL_TIME;
	public static int PVP_PVP_TIME;
	
	//EFEITO AOS PKS
	public static boolean PK_CONTOUR_ENABLED;
	public static int PK_CONTOUR_COLOR;
	public static int PK_CONTOUR_OPACITY;
	public static boolean PVP_CONTOUR_ENABLED;
	public static int PVP_CONTOUR_COLOR;
	
	
	/** Party */
	public static String PARTY_XP_CUTOFF_METHOD;
	public static int PARTY_XP_CUTOFF_LEVEL;
	public static double PARTY_XP_CUTOFF_PERCENT;
	public static int ALT_PARTY_RANGE;
	public static int ALT_PARTY_RANGE2;
	public static boolean ALT_LEAVE_PARTY_LEADER;

	/** GMs & Admin Stuff */
	public static boolean EVERYBODY_HAS_ADMIN_RIGHTS;
	public static int MASTERACCESS_LEVEL;
	public static int MASTERACCESS_NAME_COLOR;
	public static int MASTERACCESS_TITLE_COLOR;
	public static boolean GM_HERO_AURA;
	public static boolean GM_STARTUP_SUPER_HASTE;
	public static boolean GM_STARTUP_INVULNERABLE;
	public static boolean GM_STARTUP_INVISIBLE;
	public static boolean GM_STARTUP_SILENCE;
	public static boolean GM_STARTUP_AUTO_LIST;

	/** petitions */
	public static boolean PETITIONING_ALLOWED;
	public static int MAX_PETITIONS_PER_PLAYER;
	public static int MAX_PETITIONS_PENDING;

	/** Crafting **/
	public static boolean IS_CRAFTING_ENABLED;
	public static int DWARF_RECIPE_LIMIT;
	public static int COMMON_RECIPE_LIMIT;
	public static boolean ALT_BLACKSMITH_USE_RECIPES;

	/** Skills & Classes **/
	public static boolean ALT_SHOW_REUSE_MSG;
	public static boolean AUTO_LEARN_SKILLS;
	public static boolean ALT_GAME_MAGICFAILURES;
	public static boolean ALT_GAME_SHIELD_BLOCKS;
	public static int ALT_PERFECT_SHLD_BLOCK;
	public static boolean LIFE_CRYSTAL_NEEDED;
	public static boolean SP_BOOK_NEEDED;
	public static boolean ES_SP_BOOK_NEEDED;
	public static boolean AUTO_LEARN_DIVINE_INSPIRATION;
	public static boolean DIVINE_SP_BOOK_NEEDED;
	public static boolean ALT_GAME_SUBCLASS_WITHOUT_QUESTS;
	public static boolean ALT_GAME_SUBCLASS_EVERYWHERE;

	/** Buffs */
	public static boolean STORE_SKILL_COOLTIME;
	public static int BUFFS_MAX_AMOUNT;

	// --------------------------------------------------
	// L2Jmod
	// --------------------------------------------------
	public static boolean ALLOW_MOD_MENU;
	public static boolean ALLOW_COLOR_MANAGER;
	public static boolean RETAIL_EVENTS_STARTED;

	public static String WEAPONS_ENCHANT_LIST_ID;
	public static List<Integer> WEAPONS_ENCHANT_LIST;

	public static int RAID_BOSS_INFO_PAGE_LIMIT;
	public static int RAID_BOSS_DROP_PAGE_LIMIT;
	public static String RAID_BOSS_DATE_FORMAT;
	
	public static String RAID_LOW_IDS;
	public static String RAID_MID_IDS;
	public static String RAID_HIGH_IDS;


	public static List<Integer> LIST_RAID_LOW_IDS;
	public static List<Integer> LIST_RAID_MID_IDS;
	public static List<Integer> LIST_RAID_HIGH_IDS;

	public static String GRAND_BOSS_IDS;
	public static List<Integer> LIST_GRAND_BOSS_IDS;
	public static String LIST_ITENS_NOT_SHOW;
	public static List<Integer> NOT_SHOW_DROP_INFO;

	public static int BANKING_SYSTEM_GOLDBARS;
	public static int BANKING_SYSTEM_ADENA;
	public static int PVP_POINT_ID;
	public static int PVP_POINT_COUNT;

	public static boolean ALLOW_EVENTTIME_COMMANDS;
	public static boolean ALLOW_INFO_COMMANDS;
	public static boolean ALLOW_DONATE_COMMANDS;
	public static int DONATE_COIN_ID;
	public static int DONATE_COIN_COUNT;
	public static boolean ALLOW_WELCOME_TO_LINEAGE;
	public static boolean ALT_GIVE_PVP_IN_ARENA;
	public static boolean SHOW_HP_PVP;

	public static boolean NO_CARRIER_SYSTEM_ENABLED;
	public static String NO_CARRIER_TITLE;
	public static int NO_CARRIER_SYSTEM_TIMER;

	public static boolean TIME_TELEPORTER_ENABLE;
	public static ArrayList<Integer> TIME_TELEPORTERS = new ArrayList<>();

	public static boolean VOTE_FOR_PVPZONE;
	public static boolean OFFLINE_TRADE_ENABLE;
	public static boolean OFFLINE_CRAFT_ENABLE;
	public static boolean RESTORE_OFFLINERS;
	public static int OFFLINE_MAX_DAYS;
	public static boolean OFFLINE_DISCONNECT_FINISHED;
	public static boolean OFFLINE_MODE_IN_PEACE_ZONE;
	public static boolean OFFLINE_MODE_NO_DAMAGE;
	public static boolean OFFLINE_LOGOUT;
	public static boolean OFFLINE_SLEEP_EFFECT;
	/** Aio System */
	public static boolean ENABLE_AIO_SYSTEM;
	public static Map<Integer, Integer> AIO_SKILLS;
	public static boolean ALLOW_AIO_NCOLOR;
	public static int AIO_NCOLOR;
	public static boolean ALLOW_AIO_TCOLOR;
	public static int AIO_TCOLOR;
	public static boolean ALLOW_AIO_ITEM;
	public static int AIO_ITEMID;


	/** List Drop Vip */
	public static String DROP_ITEM_VIP;
	public static List<Integer> DROP_LIST_VIP;

	/** VIP System */
	public static boolean ENABLE_VIP_SYSTEM;
	public static boolean VIP_EFFECT;
	public static boolean ALLOW_SKIN_SYSTEM;
	public static Map<Integer, Integer> VIP_SKILLS;
	public static boolean ALLOW_VIP_NCOLOR;
	public static int VIP_NCOLOR;
	public static boolean ALLOW_VIP_TCOLOR;
	public static int VIP_TCOLOR;
	public static double VIP_XP_SP_RATE;
	public static double VIP_ADENA_RATE;
	public static double VIP_SPOIL_RATE;
	public static int VIP_DROP_RATE;
	public static boolean ALLOW_VIP_ITEM;
	public static int VIP_ITEMID;


	public static boolean NOBLESS_FROM_BOSS;
	public static int BOSS_ID;
	public static int RADIUS_TO_RAID;

	public static boolean ALLOW_FLAG_ONKILL_BY_ID;
	public static String NPCS_FLAG_IDS;
	public static List<Integer> NPCS_FLAG_LIST = new ArrayList<>();
	public static int NPCS_FLAG_RANGE;

	public static boolean LEAVE_BUFFS_ON_DIE;
	public static boolean CHAOTIC_LEAVE_BUFFS_ON_DIE;

	public static int ANNOUNCE_SELF_ID;
	public static String ANNOUNCE_SELF_NAME;
	public static boolean GET_SELF_ANNOUNCE;
	public static String GET_SELF_MSG;
	
	/** Starter Equip (auto-equip on character creation) */
	public static boolean STARTER_EQUIP_ENABLED;
	public static List<Integer> STARTER_EQUIP_FIGHTER = new ArrayList<>();
	public static List<Integer> STARTER_EQUIP_MAGE = new ArrayList<>();
	
	public static int STARTER_EQUIP_ENCHANT;

	/** Starter Buffs (applied on character creation) */
	public static boolean STARTER_BUFFS_ENABLED;
	public static List<int[]> STARTER_BUFFS_FIGHTER = new ArrayList<>();
	public static List<int[]> STARTER_BUFFS_MAGE = new ArrayList<>();
	
	public static boolean ENABLE_EFFECT_ON_DIE;
	public static int CUSTOM_START_LVL;
	public static int CUSTOM_SUBCLASS_LVL;

	public static boolean SPAWN_CHAR_START;
	public static int SPAWN_X_1;
	public static int SPAWN_Y_1;
	public static int SPAWN_Z_1;

	public static boolean CHAR_TITLE;
	public static String ADD_CHAR_TITLE;

	public static String[] FORBIDDEN_NAMES;
	public static String[] GM_NAMES;
	public static boolean ENABLE_GM_NAMES_LIST;

	public static boolean PRIVATE_STORE_NEED_PVPS;
	public static int MIN_PVP_TO_USE_STORE;

	public static boolean PRIVATE_STORE_NEED_LEVELS;
	public static int MIN_LEVEL_TO_USE_STORE;

	public static boolean EXPERTISE_PENALTY;

	public static boolean ALLOW_HERO_SUBSKILL;
	public static int HERO_COUNT;

	public static boolean ALT_RESTORE_EFFECTS_ON_SUBCLASS_CHANGE;

	public static boolean CHECK_SKILLS_ON_ENTER;
	public static String ALLOWED_SKILLS;
	public static ArrayList<Integer> ALLOWED_SKILLS_LIST = new ArrayList<>();

	public static boolean DISABLE_ATTACK_NPC_TYPE;
	public static String ALLOWED_NPC_TYPES;
	public static ArrayList<String> LIST_ALLOWED_NPC_TYPES = new ArrayList<>();

	public static boolean ALLOW_PVP_REWARD;
	public static boolean ALLOW_FARM_ZONE_PVP_REWARD;
	public static List<RewardHolder> PVP_REWARDS = new ArrayList<>();

	public static boolean ANTI_FARM_ENABLED;
	public static boolean ANTI_FARM_CLAN_ALLY_ENABLED;
	public static boolean ANTI_FARM_LVL_DIFF_ENABLED;
	public static int ANTI_FARM_MAX_LVL_DIFF;
	public static boolean ANTI_FARM_PARTY_ENABLED;
	public static boolean ANTI_FARM_IP_ENABLED;

	public static boolean FARM_PROTECT;
	public static boolean FARM_PROTECT_RADIUS;

	public static boolean SUMMON_MOUNT_PROTECTION;
	public static String ID_RESTRICT;
	public static List<Integer> LISTID_RESTRICT;

	public static boolean DELETE_AUGM_PASSIVE_ON_CHANGE;
	public static boolean DELETE_AUGM_ACTIVE_ON_CHANGE;
	public static boolean AUG_ITEM_DROP;
	public static boolean AUG_ITEM_TRADE;
	public static boolean AUG_ITEM_SELL;

	public static boolean ALLOW_DAILY_REWARD;
	public static List<RewardHolder> DAILY_LOG_REWARDS = new ArrayList<>();
	public static int DAILY_REWARDS_DELETE_TIME;

	public static String[] DAILY_REWARD_RESET_TIME;

	public static boolean DONATESYSTEM;
	public static boolean DONATE_HTML;

	public static int MAX_HEALER_ON_PARTY;
	public static int MAX_WL_ON_PARTY;
	public static int MAX_OVER_ON_PARTY;

	public static String NPC_WITH_EFFECT_RED;
	public static List<Integer> LIST_NPC_WITH_EFFECT_RED = new ArrayList<>();

	public static String NPC_WITH_EFFECT_BLUE;
	public static List<Integer> LIST_NPC_WITH_EFFECT_BLUE = new ArrayList<>();

	public static boolean ENABLE_SHIFT_CLICK_TO_NPCS;

	public static boolean SHOW_FAKE_ARMOR;
	public static boolean FAKE_OFFLINE;
	public static int NO_LOOT_PROTECTION_BOSSID;

	public static boolean ENABLE_UPDATE_JEWELRY;
	public static boolean ENABLE_REWARD_HEART_STONE;
	public static Map<Integer, Integer> HEART_STONE_REWARDS = new HashMap<>();

	public static boolean ENABLE_REWARD_EPIC_STONE;
	public static Map<Integer, Integer> EPIC_STONE_REWARDS = new HashMap<>();

	public static String PROTECT_WEAPONS;
	public static ArrayList<Integer> PROTECT_WEAPONS_LIST = new ArrayList<>();

	public static boolean TELEPORT_EFFECT;
	public static int ID_ESCAPE_SKILL;

	public static boolean AGATHIONS_ENABLED;
	public static int[] AGATHIONS_LIST_ID;
	public static boolean AGATHIONS_RESHP_ENABLED;
	public static Map<Integer, Integer> AGATHIONS_RESTORE_HP;
	public static int AGATHIONS_RES_HP_INTERVAL;
	public static boolean AGATHIONS_RESMP_ENABLED;
	public static Map<Integer, Integer> AGATHIONS_RESTORE_MP;
	public static int AGATHIONS_RES_MP_INTERVAL;
	public static boolean AGATHIONS_RESCP_ENABLED;
	public static Map<Integer, Integer> AGATHIONS_RESTORE_CP;
	public static int AGATHIONS_RES_CP_INTERVAL;
	public static boolean AGATHIONS_USESKILL_ENABLED;
	public static Map<Integer, Integer> AGATHIONS_USE_SKILL;
	public static int AGATHIONS_USE_SKILL_INTERVAL;
	public static boolean AGATHIONS_STOP_SKILL_ENABLED;
	public static List<Integer> AGATHIONS_STOP_SKILL_LIST = new ArrayList<>();

	public static boolean DAILY_ON_ENTER;
	public static boolean DAILY_COMMANDS_ENTER;


	// --------------------------------------------------
	// L2JEvents
	// --------------------------------------------------

	public static boolean CKM_ENABLED;
	public static long CKM_CYCLE_LENGTH;
	public static String CKM_PVP_NPC_TITLE;
	public static int CKM_PVP_NPC_TITLE_COLOR;
	public static int CKM_PVP_NPC_NAME_COLOR;
	public static String CKM_PK_NPC_TITLE;
	public static int CKM_PK_NPC_TITLE_COLOR;
	public static int CKM_PK_NPC_NAME_COLOR;
	public static int[][] CKM_PLAYER_REWARDS;

	public static int MIN_PLAYERS_CLANFULL_REWARD;
	public static int MIN_PLAYERS_CLANITEMS_REWARD;
	public static int[][] CLAN_ITEMS_REWARD;

	public static boolean TOP_KILLER_PLAYER_ROUND;
	public static int[][] TOP_1ST_KILLER_PLAYER_REWARDS;
	public static int[][] TOP_2ND_KILLER_PLAYER_REWARDS;
	public static int[][] TOP_3RD_KILLER_PLAYER_REWARDS;

	public static boolean PCB_ENABLE;
	public static int PCB_MIN_LEVEL;
	public static int PCB_POINT_MIN;
	public static int PCB_POINT_MAX;
	public static int PCB_CHANCE_DUAL_POINT;
	public static int PCB_INTERVAL;

	// ----------------------------------------
	// PartyZone.properties
	// ----------------------------------------
	/** Party zone */
	public static List<RewardHolder> PARTY_ZONE_REWARDS = new ArrayList<>();
	public static int RADIUS_TO_PARTYZONE;
	/** Party Farm Event */
	public static boolean START_PARTY;
	public static boolean START_AUTO_PARTY;
	public static int PARTYZONE_TIME;
	public static String[] PARTYZONE_INTERVAL_BY_TIME_OF_DAY;
	public static int PARTY_FARM_MONSTER_DALAY;
	public static int monsterId;
	public static int MONSTER_LOCS_COUNT;
	public static int[][] MONSTER_LOCS;
	public static String NAME_EVENT;
	public static int ANNOUNCE_ID_EVENT;
	public static boolean ENTER_PARTYZONE;
	// PartyFarm Raid boss
	public static boolean PARTY_FARM_RAID_ENABLED;
	public static int PARTY_FARM_RAID_ID;
	public static int[] PARTY_FARM_RAID_LOC = new int[3];

	// ----------------------------------------
	// Tyrannosaurus.properties
	// ----------------------------------------
	/** LS zone */
	public static List<RewardHolder> LS_ZONE_REWARDS = new ArrayList<>();
	public static int RADIUS_TO_LS;
	/** LS Event */
	public static boolean START_LS;
	public static boolean START_AUTO_LS;
	public static int LS_TIME;
	public static String[] LS_INTERVAL_BY_TIME_OF_DAY;
	public static int LS_MONSTER_DALAY;
	public static int LS_monsterId;
	public static int LS_MONSTER_LOCS_COUNT;
	public static int[][] LS_MONSTER_LOCS;
	public static String LS_NAME_EVENT;
	public static int LS_ANNOUNCE_ID_EVENT;
	public static boolean ENTER_LS;

	public static boolean ALLOW_RANKED_SYSTEM;
	public static boolean ALLOW_RANKED_SYSTEM_SKILL;
	public static int RANKED_REWARD_IRON;
	public static int RANKED_REWARD_BRONZE;
	public static int RANKED_REWARD_SILVER;
	public static int RANKED_REWARD_GOLD;
	public static int RANKED_REWARD_PLATINUM;
	public static int RANKED_REWARD_DIAMOND;

	public static String HUMAN_MAGE_BASE;
	public static List<Integer> LIST_HUMAN_MAGE_BASE = new ArrayList<>();

	public static String ORC_SHAMAN_BASE;
	public static List<Integer> LIST_ORC_SHAMAN_BASE = new ArrayList<>();

	public static boolean ALLOW_HIDE_ITEM_EVENT;
	public static List<RewardHolder> HIDE_ITEM_REWARDS = new ArrayList<>();
	public static int HIDE_EVENT_ITEM_TIME;
	public static int HIDE_EVENT_DISSAPEAR_TIME;
	public static int HIDE_EVENT_ITEM_COUNT;
	public static int[][] HIDE_EVENT_ITEM_LOCS;

	public static List<RewardHolder> PUZZLE_ITEM_REWARDS = new ArrayList<>();

	public static float RATE_MULTIPLER;
	public static int CRAZY_RATE_TIME;

	public static boolean RESET_MISSION_EVENT_ENABLED;
	public static String[] RESET_MISSION_INTERVAL_BY_TIME_OF_DAY;
	public static boolean ALLOW_MISSION_COMMANDS;

	public static boolean ACTIVE_MISSION_TVT;	
	public static int MISSION_TVT_COUNT;	
	public static int MISSION_TVT_REWARD_ID;
	public static int MISSION_TVT_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_CTF;	
	public static int MISSION_CTF_COUNT;	
	public static int MISSION_CTF_REWARD_ID;
	public static int MISSION_CTF_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_DM;	
	public static int MISSION_DM_COUNT;	
	public static int MISSION_DM_REWARD_ID;
	public static int MISSION_DM_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_KTB;	
	public static int MISSION_KTB_COUNT;	
	public static int MISSION_KTB_REWARD_ID;
	public static int MISSION_KTB_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_TOURNAMENT;	
	public static int MISSION_TOURNAMENT_COUNT;	
	public static int MISSION_TOURNAMENT_REWARD_ID;
	public static int MISSION_TOURNAMENT_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_1X1;	
	public static int MISSION_1X1_COUNT;	
	public static int MISSION_1X1_REWARD_ID;
	public static int MISSION_1X1_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_3X3;	
	public static int MISSION_3X3_COUNT;	
	public static int MISSION_3X3_REWARD_ID;
	public static int MISSION_3X3_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_5X5;	
	public static int MISSION_5X5_COUNT;	
	public static int MISSION_5X5_REWARD_ID;
	public static int MISSION_5X5_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_9X9;	
	public static int MISSION_9X9_COUNT;	
	public static int MISSION_9X9_REWARD_ID;
	public static int MISSION_9X9_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_FARM;	
	public static int MISSION_FARM_COUNT;	
	public static String MISSION_LIST_MOBS;
	public static ArrayList<Integer> MISSION_LIST_MONSTER = new ArrayList<>();
	public static int MISSION_FARM_REWARD_ID;
	public static int MISSION_FARM_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_CHAMPION;	
	public static int MISSION_CHAMPION_COUNT;	
	public static String MISSION_LIST_CHAMPION;
	public static ArrayList<Integer> MISSION_LIST_CHAMPION_MONSTER = new ArrayList<>();
	public static int MISSION_CHAMPION_REWARD_ID;
	public static int MISSION_CHAMPION_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_PVP;	
	public static int MISSION_PVP_COUNT;	
	public static int MISSION_PVP_REWARD_ID;
	public static int MISSION_PVP_REWARD_AMOUNT;

	public static boolean ACTIVE_MISSION_RAIDKILL;	
	public static int MISSION_RAIDKILL_CONT;	
	public static int RAIDKILL_ID_1;	
	public static int RAIDKILL_ID_2;	
	public static int RAIDKILL_ID_3;	
	public static int RAIDKILL_ID_4;	
	public static int RAIDKILL_ID_5;	
	public static int RAIDKILL_ID_6;	
	public static int MISSION_RAIDKILL_REWARD_ID;
	public static int MISSION_RAIDKILL_REWARD_AMOUNT;

	public static String WEAPON_ID_ENCHANT_RESTRICT;
	public static List<Integer> WEAPON_LIST_ID_ENCHANT_RESTRICT;

	public static String ARMOR_ID_ENCHANT_RESTRICT;
	public static List<Integer> ARMOR_LIST_ID_ENCHANT_RESTRICT;

	public static boolean PVP_ITEM_ENCHANT_EVENT;	
	public static float PVP_ITEM_ENCHANT_WEAPON_CHANCE;	
	public static float PVP_ITEM_ENCHANT_ARMOR_CHANCE;	

	public static int CHECK_MIN_ENCHANT_WEAPON;	
	public static int CHECK_MAX_ENCHANT_WEAPON;	
	public static int CHECK_MIN_ENCHANT_ARMOR_JEWELS;	
	public static int CHECK_MAX_ENCHANT_ARMOR_JEWELS;	

	public static int NFT_BOSS_EVENT_START;
	public static boolean NFT_BOSS_EVENT;
	public static String[] NFT_BOSS_EVENT_INTERVAL_BY_TIME_OF_DAY;
	public static int NFT_RAID_REWARDS_RANGE;

	public static int NFT_BOSS_ID;
	public static int NFT_BOSS_ID_SPAWN_X;
	public static int NFT_BOSS_ID_SPAWN_Y;
	public static int NFT_BOSS_ID_SPAWN_Z;
	public static boolean REWARD_ALL_PLAYERS;
	public static List<RewardHolder> NFT_RAID_REWARDS_LIST_FOR_ALL = new ArrayList<>();
	public static boolean REWARD_RANDOM_PLAYER;
	public static List<RewardHolder> NFT_RAID_REWARDS_LIST_FOR_ONE = new ArrayList<>();
	public static boolean REWARD_BY_HWID;

	public static int SOLO_BOSS_EVENT_START;
	public static boolean SOLO_BOSS_EVENT;
	public static String[] SOLO_BOSS_EVENT_INTERVAL_BY_TIME_OF_DAY;
	public static int SOLO_RAID_REWARDS_RANGE;

	public static int SOLO_BOSS_ID_ONE;
	public static int BOSS_ID_ONE_X;
	public static int BOSS_ID_ONE_Y;
	public static int BOSS_ID_ONE_Z;
	public static List<RewardHolder> SOLO_RAID_REWARDS_LIST_ONE = new ArrayList<>();

	public static int SOLO_BOSS_ID_TWO;
	public static int BOSS_ID_TWO_X;
	public static int BOSS_ID_TWO_Y;
	public static int BOSS_ID_TWO_Z;
	public static List<RewardHolder> SOLO_RAID_REWARDS_LIST_TWO = new ArrayList<>();

	public static int SOLO_BOSS_ID_TREE;
	public static int BOSS_ID_TREE_X;
	public static int BOSS_ID_TREE_Y;
	public static int BOSS_ID_TREE_Z;
	public static List<RewardHolder> SOLO_RAID_REWARDS_LIST_TREE = new ArrayList<>();

	public static int SOLO_BOSS_ID_FOUR;
	public static int BOSS_ID_FOUR_X;
	public static int BOSS_ID_FOUR_Y;
	public static int BOSS_ID_FOUR_Z;
	public static List<RewardHolder> SOLO_RAID_REWARDS_LIST_FOUR = new ArrayList<>();

	public static int SOLO_BOSS_ID_FIVE;
	public static int BOSS_ID_FIVE_X;
	public static int BOSS_ID_FIVE_Y;
	public static int BOSS_ID_FIVE_Z;
	public static List<RewardHolder> SOLO_RAID_REWARDS_LIST_FIVE = new ArrayList<>();

	// --------------------------------------------------
	// Balance
	// --------------------------------------------------

	public static int RUN_SPD_BOOST;
	public static int MAX_RUN_SPEED;
	public static int MAX_PCRIT_RATE;
	public static boolean ENABLE_MAX_MCRIT_RATE;
	public static double BASE_MCRITICAL_RATE;
	public static int MAX_MCRIT_RATE;
	public static int MAX_PATK_SPEED;
	public static int MAX_MATK_SPEED;
	public static int MAX_EVASION;
	public static int MAX_ACCURACY;

	public static boolean ENABLE_CUSTOM_MAGE_CRITICAL_POWER;
	public static float MAGIC_CRITICAL_POWER;
	public static float MCRIT_RATE_MUL;
	public static float AOE_DAMAGE;
	public static boolean ALT_SURRENDER_NO_FAIL;

	public static boolean ENABLE_CUSTOM_PHYSICAL_CRITICAL_POWER;
	public static float PHYSICAL_CRITICAL_POWER;

	public static boolean HERO_WEAPON_SKILLS_DEBUFF_CHANCE;
	public static float HERO_SKILL_WEAPON_DEBUFF_CHANCE_MODIFIER;
	public static String HERO_SKILL_MODIFIER;
	public static ArrayList<Integer> HERO_SKILL_MODIFIER_LIST = new ArrayList<>();

	public static boolean ENABLE_MODIFY_SKILL_DURATION;
	public static Map<Integer, Integer> SKILL_DURATION_LIST;
	public static int MODIFIED_SKILL_COUNT;

	public static boolean MASTERY_PENALTY;
	public static int LEVEL_TO_GET_PENALITY;
	public static int ARMOR_PENALTY_SKILL;

	public static boolean MASTERY_WEAPON_PENALTY;
	public static int LEVEL_TO_GET_WEAPON_PENALITY;
	public static int WEAPON_PENALTY_SKILL;

	public static int ANTI_SS_BUG_1;
	public static int ANTI_SS_BUG_2;	

	// Alternative damage for dagger skills VS heavy
	public static float ALT_DAGGER_DMG_VS_HEAVY;
	// Alternative damage for dagger skills VS robe
	public static float ALT_DAGGER_DMG_VS_ROBE;
	// Alternative damage for dagger skills VS light
	public static float ALT_DAGGER_DMG_VS_LIGHT;

	// Alternative damage for DUAL skills VS heavy
	public static float ALT_DUAL_DMG_VS_HEAVY;
	// Alternative damage for DUAL skills VS robe
	public static float ALT_DUAL_DMG_VS_ROBE;
	// Alternative damage for DUAL skills VS light
	public static float ALT_DUAL_DMG_VS_LIGHT;

	public static float ALT_DUALFISTS_DMG_VS_HEAVY;
	public static float ALT_DUALFISTS_DMG_VS_ROBE;
	public static float ALT_DUALFISTS_DMG_VS_LIGHT;
	public static float ALT_DUAL_DMG_VS_HEAVY_OLY;
	public static float ALT_DUAL_DMG_VS_ROBE_OLY;
	public static float ALT_DUAL_DMG_VS_LIGHT_OLY;
	public static float ALT_DUALFISTS_DMG_VS_HEAVY_OLY;
	public static float ALT_DUALFISTS_DMG_VS_ROBE_OLY;
	public static float ALT_DUALFISTS_DMG_VS_LIGHT_OLY;

	public static boolean ENABLE_CLASS_DAMAGES;
	public static boolean ENABLE_CLASS_DAMAGES_LOGGER;
	public static boolean ENABLE_OLY_CLASS_DAMAGES;
	public static boolean ENABLE_OLY_CLASS_DAMAGES_LOGGER;

	public static String PROTECTED_SKILLS;
	public static List<Integer> NOT_CANCELED_SKILLS;

	public static String BLOCK_BUFFS;
	public static List<Integer> NO_BLOCK_BUFFS;

	public static int CANCEL_BACK_TIME;


	// --------------------------------------------------
	// Annoucements
	// --------------------------------------------------
	public static boolean ANNOUNCE_DROP_ITEM;
	public static boolean ANNOUNCE_ZONE_PVP;
	public static List<String> LIST_OF_TYPES_PVP = new ArrayList<>();
	public static List<String> LIST_OF_TYPES_PK = new ArrayList<>();
	public static String ANNOUNCE_TYPE_MSG_PVP;
	public static String ANNOUNCE_TYPE_MSG_PK;

	public static boolean ANNOUNCE_CASTLE_LORDS;
	public static boolean ANNOUNCE_AIO_LOGIN;
	public static boolean ANNOUNCE_HERO_LOGIN;
	public static boolean ANNOUNCE_HERO_ON_CUSTOM;
	public static boolean ANNOUNCE_HALL_OWNERS;

	public static boolean ALLOW_QUAKE_SYSTEM;
	public static Map<Integer, String> QUAKE_VALUES = new HashMap<>();

	public static boolean ALLOW_QUAKE_REWARD;
	public static int QUAKE_REWARD_ITEM;

	public static String ANNOUNCE_QUAKE_PVP;
	public static int ANNOUNCE_ID_QUAKE;

	public static boolean WAR_LEGEND_AURA;
	public static int KILLS_TO_GET_WAR_LEGEND_AURA;

	public static boolean CHAT_SHOUT_NEED_PVPS;
	public static int PVPS_TO_USE_CHAT_SHOUT;
	public static boolean CHAT_TRADE_NEED_PVPS;
	public static int PVPS_TO_USE_CHAT_TRADE;
	public static boolean CHAT_HERO_NEED_PVPS;
	public static int PVPS_TO_USE_CHAT_HERO;

	public static boolean ALT_OLY_END_ANNOUNCE;

	public static boolean NPC_ITEM_ANNOUNCE;
	public static String NPC_ITEM_ANNOUNCE_SELL;
	public static List<Integer> NPC_ITEM_ANNOUNCE_SELL_LIST;

	public static int CHAT_FILTER_PUNISHMENT_PARAM1;
	public static int CHAT_FILTER_PUNISHMENT_PARAM2;
	public static int CHAT_FILTER_PUNISHMENT_PARAM3;
	public static boolean USE_SAY_FILTER;
	public static String CHAT_FILTER_CHARS;
	public static String CHAT_FILTER_PUNISHMENT;
	public static ArrayList<String> FILTER_LIST = new ArrayList<>();

	// --------------------------------------------------
	// PVP EVENT
	// --------------------------------------------------
	public static boolean CUSTOM_TELEGIRAN_ON_DIE;
	public static String PVPEVENT_NAME;
	public static String PVPEVENT_TITLE;
	public static boolean AUTO_PVP_ZONE_NAME;
	public static boolean PVP_EVENT_ENABLED;	  
	public static String[] PVP_EVENT_INTERVAL;	  
	public static int PVP_EVENT_RUNNING_TIME;
	public static int PVP_EVENT_REGISTER_TIME;
	public static boolean ALLOW_SPECIAL_PVP_REWARD;
	public static List<RewardHolder> PVP_SPECIAL_ITEMS_REWARD = new ArrayList<>();
	public static List<IntIntHolder> PVP_EVENT_WINNER_REWARDS = new ArrayList<>();
	public static int PVP_EVENT_RANKING_REWARD;

	// --------------------------------------------------
	// TIMEZONE
	// --------------------------------------------------
	public static boolean TIME_INSTANCE_ENABLED;
	public static int TIME_INSTANCE_PLAYER_TIME;
	public static boolean TIME_INSTANCE_SCREEN_MESSAGE;
	public static boolean TIME_INSTANCE_FLAG_ZONE;
	public static boolean TIME_INSTANCE_ALLOW_PARTY;
	public static List<Integer> TIME_INSTANCE_BLOCK_CLASS_LIST = new ArrayList<>();
	public static int TIME_INSTANCE_ITEM_ID_TO_ACESS;
	public static int TIME_INSTANCE_ITEM_ID_TO_ACESS_COUNT;
	public static int TIME_INSTANCE_ENTER_LIMIT_COUNT;
	public static String[] RESET_TIME_INSTANCE_INTERVAL_BY_TIME_OF_DAY;
	public static int TIME_INSTANCE_MOBS_TO_REWARD;
	public static Location TIME_INSTANCE_AREA_LOC_1;
	public static Location TIME_INSTANCE_AREA_LOC_2;
	public static Location TIME_INSTANCE_AREA_LOC_3;
	public static Location TIME_INSTANCE_AREA_LOC_4;
	public static ArrayList<Integer> TIME_INSTANCE_MOBS_IDS = new ArrayList<>();
	public static List<RewardHolder> TIME_INSTANCE_DROP_ITEMS_IDS = new ArrayList<>();

	// --------------------------------------------------
	// Server
	// --------------------------------------------------

	public static String GAMESERVER_HOSTNAME;
	public static int PORT_GAME;
	public static String LICENSE_KEY;
	public static String EXTERNAL_HOSTNAME;
	public static String INTERNAL_HOSTNAME;
	public static int GAME_SERVER_LOGIN_PORT;
	public static String GAME_SERVER_LOGIN_HOST;

	/** Access to database */
	public static String DATABASE_URL;
	public static String DATABASE_LOGIN;
	public static String DATABASE_PASSWORD;
	public static int DATABASE_MAX_CONNECTIONS;
	public static int DATABASE_MAX_IDLE_TIME;

	/** serverList & Test */
	public static boolean SERVER_LIST_BRACKET;
	public static boolean SERVER_LIST_CLOCK;
	public static boolean SERVER_LIST_TESTSERVER;
	public static boolean SERVER_GMONLY;
	public static boolean TEST_SERVER;

	/** clients related */
	public static int DELETE_DAYS;
	public static int MAXIMUM_ONLINE_USERS;
	public static int MIN_PROTOCOL_REVISION;
	public static int MAX_PROTOCOL_REVISION;

	/** Jail & Punishements **/
	public static boolean JAIL_IS_PVP;
	public static int DEFAULT_PUNISH;
	public static int DEFAULT_PUNISH_PARAM;

	/** Dual Box Limit */
	public static boolean ALLOW_DUALBOX;
	public static int ALLOWED_BOXES;
	public static boolean ALLOW_DUALBOX_OLY;

	public static boolean MULTIBOX_PROTECTION_ENABLED; 
	public static int MULTIBOX_PROTECTION_CLIENTS_PER_PC; 
	public static int MULTIBOX_PROTECTION_PUNISH; 
	public static List<String> MULTIBOX_PROTECTION_BYPASS_IPS; 

	/** by Hwid **/
	public static boolean HWID_MULTIBOX_PROTECTION_ENABLED; 
	public static int HWID_MULTIBOX_PROTECTION_CLIENTS_PER_PC; 
	public static int HWID_MULTIBOX_PROTECTION_PUNISH; 

	/** Auto-loot */
	public static boolean AUTO_LOOT;
	public static boolean AUTO_LOOT_HERBS;
	public static boolean AUTO_LOOT_RAID;
	public static boolean AUTO_LOOT_CHAMPION;
	public static boolean LAST_HIST_BOSS_LOOT;

	/** Items Management */
	public static boolean ALLOW_DISCARDITEM;
	public static boolean MULTIPLE_ITEM_DROP;
	public static int ITEM_AUTO_DESTROY_TIME;
	public static int HERB_AUTO_DESTROY_TIME;
	public static String PROTECTED_ITEMS;

	public static List<Integer> LIST_PROTECTED_ITEMS;

	public static boolean DESTROY_DROPPED_PLAYER_ITEM;
	public static boolean DESTROY_EQUIPABLE_PLAYER_ITEM;
	public static boolean SAVE_DROPPED_ITEM;
	public static boolean EMPTY_DROPPED_ITEM_TABLE_AFTER_LOAD;
	public static int SAVE_DROPPED_ITEM_INTERVAL;
	public static boolean CLEAR_DROPPED_ITEM_TABLE;

	/** Rate control */
	public static double RATE_XP;
	public static double RATE_SP;
	public static double RATE_PARTY_XP;
	public static double RATE_PARTY_SP;
	public static double RATE_DROP_ADENA;
	public static double RATE_CONSUMABLE_COST;
	public static double RATE_DROP_ITEMS;
	public static double RATE_DROP_SEAL_STONES;
	public static double RATE_DROP_ITEMS_BY_RAID;
	public static double RATE_DROP_SPOIL;
	public static int RATE_DROP_MANOR;

	public static double RATE_QUEST_DROP;
	public static double RATE_QUEST_REWARD;
	public static double RATE_QUEST_REWARD_XP;
	public static double RATE_QUEST_REWARD_SP;
	public static double RATE_QUEST_REWARD_ADENA;

	public static double RATE_KARMA_EXP_LOST;
	public static double RATE_SIEGE_GUARDS_PRICE;

	public static int PLAYER_DROP_LIMIT;
	public static int PLAYER_RATE_DROP;
	public static int PLAYER_RATE_DROP_ITEM;
	public static int PLAYER_RATE_DROP_EQUIP;
	public static int PLAYER_RATE_DROP_EQUIP_WEAPON;

	public static int KARMA_DROP_LIMIT;
	public static int KARMA_RATE_DROP;
	public static int KARMA_RATE_DROP_ITEM;
	public static int KARMA_RATE_DROP_EQUIP;
	public static int KARMA_RATE_DROP_EQUIP_WEAPON;

	public static double PET_XP_RATE;
	public static int PET_FOOD_RATE;
	public static double SINEATER_XP_RATE;

	public static double RATE_DROP_COMMON_HERBS;
	public static double RATE_DROP_HP_HERBS;
	public static double RATE_DROP_MP_HERBS;
	public static double RATE_DROP_SPECIAL_HERBS;

	/** Allow types */
	public static boolean ALLOW_FREIGHT;
	public static boolean ALLOW_WAREHOUSE;
	public static boolean ALLOW_WEAR;
	public static int WEAR_DELAY;
	public static int WEAR_PRICE;
	public static boolean ALLOW_LOTTERY;
	public static boolean ALLOW_RACE;
	public static boolean ALLOW_WATER;
	public static boolean ALLOWFISHING;
	public static boolean ALLOW_BOAT;
	public static boolean ALLOW_CURSED_WEAPONS;
	public static boolean ALLOW_MANOR;
	public static boolean ENABLE_FALLING_DAMAGE;

	/** Debug & Dev */
	public static boolean ALT_DEV_NO_SCRIPTS;
	public static boolean ALT_DEV_NO_SPAWNS;
	public static boolean DEBUG;
	public static boolean DEVELOPER;
	public static boolean PACKET_HANDLER_DEBUG;

	/** Deadlock Detector */
	public static boolean DEADLOCK_DETECTOR;
	public static int DEADLOCK_CHECK_INTERVAL;
	public static boolean RESTART_ON_DEADLOCK;

	/** Logs */
	public static boolean LOG_CHAT;
	public static boolean LOG_ITEMS;
	public static boolean GMAUDIT;

	/** Community Board */
	public static boolean ENABLE_COMMUNITY_BOARD;
	public static String BBS_DEFAULT;

	/** Misc */
	public static boolean L2WALKER_PROTECTION;
	public static boolean AUTODELETE_INVALID_QUEST_DATA;
	public static boolean GAMEGUARD_ENFORCE;
	public static boolean SERVER_NEWS;
	public static int ZONE_TOWN;
	public static boolean DISABLE_TUTORIAL;
	public static boolean LOAD_CUSTOM_MULTISELLS;

	/** Door Configs */
	public static boolean OPEN_DOORS_ACTIVE;
	public static ArrayList<Integer> OPEN_DOORS = new ArrayList<>();

	// --------------------------------------------------
	// Those "hidden" settings haven't configs to avoid admins to fuck their server
	// You still can experiment changing values here. But don't say I didn't warn you.
	// --------------------------------------------------

	/** Threads & Packets size */
	public static int THREAD_P_EFFECTS = 6; // default 6
	public static int THREAD_P_GENERAL = 15; // default 15
	public static int GENERAL_PACKET_THREAD_CORE_SIZE = 8; // default 4
	public static int IO_PACKET_THREAD_CORE_SIZE = 4; // default 2
	public static int GENERAL_THREAD_CORE_SIZE = 4; // default 4
	public static int AI_MAX_THREAD = 10; // default 10

	/** Packet information */
	public static boolean COUNT_PACKETS = false; // default false
	public static boolean DUMP_PACKET_COUNTS = false; // default false
	public static int DUMP_INTERVAL_SECONDS = 60; // default 60

	/** IA settings */
	public static int MINIMUM_UPDATE_DISTANCE = 50; // default 50
	public static int MINIMUN_UPDATE_TIME = 500; // default 500
	public static int KNOWNLIST_FORGET_DELAY = 10000; // default 10000

	/** Time after which a packet is considered as lost */
	public static int PACKET_LIFETIME = 0; // default 0 (unlimited)

	/** Reserve Host on LoginServerThread */
	public static boolean RESERVE_HOST_ON_LOGIN = false; // default false

	/** MMO settings */
	public static int MMO_SELECTOR_SLEEP_TIME = 20; // default 20
	public static int MMO_MAX_SEND_PER_PASS = 80; // default 12
	public static int MMO_MAX_READ_PER_PASS = 80; // default 12
	public static int MMO_HELPER_BUFFER_COUNT = 20; // default 20

	/** Client Packets Queue settings */
	public static int CLIENT_PACKET_QUEUE_SIZE = 80; // default MMO_MAX_READ_PER_PASS + 2
	public static int CLIENT_PACKET_QUEUE_MAX_BURST_SIZE = 70; // default MMO_MAX_READ_PER_PASS + 1
	public static int CLIENT_PACKET_QUEUE_MAX_PACKETS_PER_SECOND = 160; // default 80
	public static int CLIENT_PACKET_QUEUE_MEASURE_INTERVAL = 15; // default 5
	public static int CLIENT_PACKET_QUEUE_MAX_AVERAGE_PACKETS_PER_SECOND = 120; // default 40
	public static int CLIENT_PACKET_QUEUE_MAX_FLOODS_PER_MIN = 15; // default 2
	public static int CLIENT_PACKET_QUEUE_MAX_OVERFLOWS_PER_MIN = 5; // default 1
	public static int CLIENT_PACKET_QUEUE_MAX_UNDERFLOWS_PER_MIN = 5; // default 1
	public static int CLIENT_PACKET_QUEUE_MAX_UNKNOWN_PER_MIN = 25; // default 5

	// --------------------------------------------------

	/** Variaveis Spoil Instancia */
	public static boolean ENABLE_CLASS_ONLY_SPOIL;
	public static int SPOIL_ENTRANCE_TIME;
	public static int ITEM_SPOIL_ENTRANCE;
	public static int ITEM_SPOIL_ENTRANCE_AMOUNT;
	public static int SPOIL_COOLDOWN_MINUTES = 30; 
	public static int[] RETURN_SPOIL_LOCATION = new int[3];
	public static int[] RETURN_SPOIL_TOWN = new int[3];
	public static int[] LOC_SPOIL_SPAWN_1 = new int[3];
	public static int[] LOC_SPOIL_SPAWN_2 = new int[3];
	public static int[] LOC_SPOIL_SPAWN_3 = new int[3];
	public static boolean SPOIL_FARM_TITLE_ENABLED;
	public static String SPOIL_FARM_TITLE;
	public static int SPOIL_FARM_TITLE_COLOR;
	
	// PlayerKillsManager
	public static List<Integer> LIST_ALLOWED_ITEMS = new ArrayList<>();
	public static boolean BOUNTY_ENABLED;
	public static int PRICE_ITEMID;
	public static int PRICE_ITEMCOUNT;
	public static int TASKS_MAX_COUNT;
	public static int MAX_KILLS_COUNT;
	public static int TASKS_DELETE_INTERVAL;
	public static boolean ANNOUNCE_ON_ADD;
	public static boolean ANNOUNCE_ON_KILL;
	public static boolean BLOCK_SELF_HWID;
	public static String ADD_MESSAGE;
	public static String KILL_MESSAGE;
	public static String PRICE_ITEMNAME;

	// ---------FIM---------
	
	/**
	 * This class initializes all global variables for configuration.<br>
	 * If key doesn't appear in properties file, a default value is setting on by this class.
	 */
	public static void load()
	{
		if (Server.serverMode == Server.MODE_GAMESERVER)
		{
			_log.info("Loading flood protectors.");
			FLOOD_PROTECTOR_ROLL_DICE = new FloodProtectorConfig("RollDiceFloodProtector");
			FLOOD_PROTECTOR_SHOUT_VOICE = new FloodProtectorConfig("GlobalChatFloodProtector");
			FLOOD_PROTECTOR_TRADE_CHAT = new FloodProtectorConfig("TradeChatFloodProtector");
			FLOOD_PROTECTOR_HERO_VOICE = new FloodProtectorConfig("HeroVoiceFloodProtector");
			FLOOD_PROTECTOR_SUBCLASS = new FloodProtectorConfig("SubclassFloodProtector");
			FLOOD_PROTECTOR_DROP_ITEM = new FloodProtectorConfig("DropItemFloodProtector");
			FLOOD_PROTECTOR_SERVER_BYPASS = new FloodProtectorConfig("ServerBypassFloodProtector");
			FLOOD_PROTECTOR_MULTISELL = new FloodProtectorConfig("MultiSellFloodProtector");
			FLOOD_PROTECTOR_MANUFACTURE = new FloodProtectorConfig("ManufactureFloodProtector");
			FLOOD_PROTECTOR_MANOR = new FloodProtectorConfig("ManorFloodProtector");
			FLOOD_PROTECTOR_SENDMAIL = new FloodProtectorConfig("SendMailFloodProtector");
			FLOOD_PROTECTOR_CHARACTER_SELECT = new FloodProtectorConfig("CharacterSelectFloodProtector");
			FLOOD_PROTECTOR_USE_ENCHANT = new FloodProtectorConfig("UseEnchantFloodProtector");

			_log.info("Loading gameserver configuration files.");

			// Clans settings
			ExProperties clans = load(CLANS_FILE);

			MAX_CLAN_MEMBERS = clans.getProperty("MaxMembersMain", 80);
			MAX_CLAN_MEMBERS_ROYALS = clans.getProperty("MaxMembersForRoyals", 80);
			MAX_CLAN_MEMBERS_KNIGHTS = clans.getProperty("MaxMembersForKnights", 80);
			DISABLE_JOIN_IN_ALLY = clans.getProperty("DisableAllyInvite", false);

			ALT_CLAN_JOIN_DAYS = clans.getProperty("DaysBeforeJoinAClan", 5);
			ALT_CLAN_CREATE_DAYS = clans.getProperty("DaysBeforeCreateAClan", 10);
			ALT_MAX_NUM_OF_CLANS_IN_ALLY = clans.getProperty("AltMaxNumOfClansInAlly", 3);
			ALT_CLAN_MEMBERS_FOR_WAR = clans.getProperty("AltClanMembersForWar", 15);
			ALT_CLAN_WAR_PENALTY_WHEN_ENDED = clans.getProperty("AltClanWarPenaltyWhenEnded", 5);
			ALT_CLAN_DISSOLVE_DAYS = clans.getProperty("DaysToPassToDissolveAClan", 7);
			ALT_ALLY_JOIN_DAYS_WHEN_LEAVED = clans.getProperty("DaysBeforeJoinAllyWhenLeaved", 1);
			ALT_ALLY_JOIN_DAYS_WHEN_DISMISSED = clans.getProperty("DaysBeforeJoinAllyWhenDismissed", 1);
			ALT_ACCEPT_CLAN_DAYS_WHEN_DISMISSED = clans.getProperty("DaysBeforeAcceptNewClanWhenDismissed", 1);
			ALT_CREATE_ALLY_DAYS_WHEN_DISSOLVED = clans.getProperty("DaysBeforeCreateNewAllyWhenDissolved", 10);
			ALT_MEMBERS_CAN_WITHDRAW_FROM_CLANWH = clans.getProperty("AltMembersCanWithdrawFromClanWH", false);
			REMOVE_CASTLE_CIRCLETS = clans.getProperty("RemoveCastleCirclets", true);

			ENABLE_WINNNER_REWARD_SIEGE_CLAN = clans.getProperty("EnableRewardWinnerClan", false);
			REWARD_WINNER_SIEGE_CLAN = parseItemsList(clans.getProperty("PlayerRewardsID", "57,100"));
			LEADER_REWARD_WINNER_SIEGE_CLAN = parseItemsList(clans.getProperty("LeaderRewardsID", "57,400"));
			PLAYER_COUNT_KILLS_INSIEGE = clans.getProperty("KillsToReceiveReward", 0);

			ALT_MANOR_REFRESH_TIME = clans.getProperty("AltManorRefreshTime", 20);
			ALT_MANOR_REFRESH_MIN = clans.getProperty("AltManorRefreshMin", 0);
			ALT_MANOR_APPROVE_TIME = clans.getProperty("AltManorApproveTime", 6);
			ALT_MANOR_APPROVE_MIN = clans.getProperty("AltManorApproveMin", 0);
			ALT_MANOR_MAINTENANCE_PERIOD = clans.getProperty("AltManorMaintenancePeriod", 360000);
			ALT_MANOR_SAVE_ALL_ACTIONS = clans.getProperty("AltManorSaveAllActions", false);
			ALT_MANOR_SAVE_PERIOD_RATE = clans.getProperty("AltManorSavePeriodRate", 2);

			CH_TELE_FEE_RATIO = clans.getProperty("ClanHallTeleportFunctionFeeRatio", 86400000);
			CH_TELE1_FEE = clans.getProperty("ClanHallTeleportFunctionFeeLvl1", 7000);
			CH_TELE2_FEE = clans.getProperty("ClanHallTeleportFunctionFeeLvl2", 14000);
			CH_SUPPORT_FEE_RATIO = clans.getProperty("ClanHallSupportFunctionFeeRatio", 86400000);
			CH_SUPPORT1_FEE = clans.getProperty("ClanHallSupportFeeLvl1", 17500);
			CH_SUPPORT2_FEE = clans.getProperty("ClanHallSupportFeeLvl2", 35000);
			CH_SUPPORT3_FEE = clans.getProperty("ClanHallSupportFeeLvl3", 49000);
			CH_SUPPORT4_FEE = clans.getProperty("ClanHallSupportFeeLvl4", 77000);
			CH_SUPPORT5_FEE = clans.getProperty("ClanHallSupportFeeLvl5", 147000);
			CH_SUPPORT6_FEE = clans.getProperty("ClanHallSupportFeeLvl6", 252000);
			CH_SUPPORT7_FEE = clans.getProperty("ClanHallSupportFeeLvl7", 259000);
			CH_SUPPORT8_FEE = clans.getProperty("ClanHallSupportFeeLvl8", 364000);
			CH_MPREG_FEE_RATIO = clans.getProperty("ClanHallMpRegenerationFunctionFeeRatio", 86400000);
			CH_MPREG1_FEE = clans.getProperty("ClanHallMpRegenerationFeeLvl1", 14000);
			CH_MPREG2_FEE = clans.getProperty("ClanHallMpRegenerationFeeLvl2", 26250);
			CH_MPREG3_FEE = clans.getProperty("ClanHallMpRegenerationFeeLvl3", 45500);
			CH_MPREG4_FEE = clans.getProperty("ClanHallMpRegenerationFeeLvl4", 96250);
			CH_MPREG5_FEE = clans.getProperty("ClanHallMpRegenerationFeeLvl5", 140000);
			CH_HPREG_FEE_RATIO = clans.getProperty("ClanHallHpRegenerationFunctionFeeRatio", 86400000);
			CH_HPREG1_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl1", 4900);
			CH_HPREG2_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl2", 5600);
			CH_HPREG3_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl3", 7000);
			CH_HPREG4_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl4", 8166);
			CH_HPREG5_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl5", 10500);
			CH_HPREG6_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl6", 12250);
			CH_HPREG7_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl7", 14000);
			CH_HPREG8_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl8", 15750);
			CH_HPREG9_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl9", 17500);
			CH_HPREG10_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl10", 22750);
			CH_HPREG11_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl11", 26250);
			CH_HPREG12_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl12", 29750);
			CH_HPREG13_FEE = clans.getProperty("ClanHallHpRegenerationFeeLvl13", 36166);
			CH_EXPREG_FEE_RATIO = clans.getProperty("ClanHallExpRegenerationFunctionFeeRatio", 86400000);
			CH_EXPREG1_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl1", 21000);
			CH_EXPREG2_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl2", 42000);
			CH_EXPREG3_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl3", 63000);
			CH_EXPREG4_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl4", 105000);
			CH_EXPREG5_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl5", 147000);
			CH_EXPREG6_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl6", 163331);
			CH_EXPREG7_FEE = clans.getProperty("ClanHallExpRegenerationFeeLvl7", 210000);
			CH_ITEM_FEE_RATIO = clans.getProperty("ClanHallItemCreationFunctionFeeRatio", 86400000);
			CH_ITEM1_FEE = clans.getProperty("ClanHallItemCreationFunctionFeeLvl1", 210000);
			CH_ITEM2_FEE = clans.getProperty("ClanHallItemCreationFunctionFeeLvl2", 490000);
			CH_ITEM3_FEE = clans.getProperty("ClanHallItemCreationFunctionFeeLvl3", 980000);
			CH_CURTAIN_FEE_RATIO = clans.getProperty("ClanHallCurtainFunctionFeeRatio", 86400000);
			CH_CURTAIN1_FEE = clans.getProperty("ClanHallCurtainFunctionFeeLvl1", 2002);
			CH_CURTAIN2_FEE = clans.getProperty("ClanHallCurtainFunctionFeeLvl2", 2625);
			CH_FRONT_FEE_RATIO = clans.getProperty("ClanHallFrontPlatformFunctionFeeRatio", 86400000);
			CH_FRONT1_FEE = clans.getProperty("ClanHallFrontPlatformFunctionFeeLvl1", 3031);
			CH_FRONT2_FEE = clans.getProperty("ClanHallFrontPlatformFunctionFeeLvl2", 9331);

			// oly config
			ExProperties oly = load(OLY_FILE);
			ALT_OLY_START_TIME = oly.getProperty("AltOlyStartTime", 18);
			ALT_OLY_MIN = oly.getProperty("AltOlyMin", 0);
			ALT_OLY_CPERIOD = oly.getProperty("AltOlyCPeriod", 21600000);
			ALT_OLY_BATTLE = oly.getProperty("AltOlyBattle", 180000);
			ALT_OLY_WPERIOD = oly.getProperty("AltOlyWPeriod", 604800000);
			ALT_OLY_VPERIOD = oly.getProperty("AltOlyVPeriod", 86400000);
			ALT_OLY_WAIT_TIME = oly.getProperty("AltOlyWaitTime", 30);
			ALT_OLY_WAIT_BATTLE = oly.getProperty("AltOlyWaitBattle", 60);
			ALT_OLY_WAIT_END = oly.getProperty("AltOlyWaitEnd", 40);
			ALT_OLY_START_POINTS = oly.getProperty("AltOlyStartPoints", 18);
			ALT_OLY_WEEKLY_POINTS = oly.getProperty("AltOlyWeeklyPoints", 3);
			ALT_OLY_MIN_MATCHES = oly.getProperty("AltOlyMinMatchesToBeClassed", 5);
			ALT_OLY_CLASSED = oly.getProperty("AltOlyClassedParticipants", 5);
			ALT_OLY_NONCLASSED = oly.getProperty("AltOlyNonClassedParticipants", 9);
			ALT_OLY_CLASSED_REWARD = parseItemsList(oly.getProperty("AltOlyClassedReward", "6651,50"));
			ALT_OLY_NONCLASSED_REWARD = parseItemsList(oly.getProperty("AltOlyNonClassedReward", "6651,30"));
			ALT_OLY_COMP_RITEM = oly.getProperty("AltOlyCompRewItem", 6651);
			ALT_OLY_GP_PER_POINT = oly.getProperty("AltOlyGPPerPoint", 1000);
			ALT_OLY_HERO_POINTS = oly.getProperty("AltOlyHeroPoints", 300);
			ALT_OLY_RANK1_POINTS = oly.getProperty("AltOlyRank1Points", 100);
			ALT_OLY_RANK2_POINTS = oly.getProperty("AltOlyRank2Points", 75);
			ALT_OLY_RANK3_POINTS = oly.getProperty("AltOlyRank3Points", 55);
			ALT_OLY_RANK4_POINTS = oly.getProperty("AltOlyRank4Points", 40);
			ALT_OLY_RANK5_POINTS = oly.getProperty("AltOlyRank5Points", 30);
			ALT_OLY_DIVIDER_CLASSED = oly.getProperty("AltOlyDividerClassed", 3);
			ALT_OLY_DIVIDER_NON_CLASSED = oly.getProperty("AltOlyDividerNonClassed", 3);
			ALT_OLY_ANNOUNCE_GAMES = oly.getProperty("AltOlyAnnounceGames", true);
			ALT_OLY_ENCHANT_LIMIT = oly.getProperty("AltOlyMaxEnchant", -1);
			ALT_OLY_USE_CUSTOM_PERIOD_SETTINGS = oly.getProperty("AltOlyUseCustomPeriodSettings", false);
			ALT_OLY_PERIOD = oly.getProperty("AltOlyPeriod", "MONTH");
			ALT_OLY_PERIOD_MULTIPLIER = oly.getProperty("AltOlyPeriodMultiplier", 1);
			ALT_OLY_FIXED_WEEKLY_SCHEDULE = oly.getProperty("AltOlyFixedWeeklySchedule", false);
			ALT_OLY_FIXED_START_DAY = oly.getProperty("AltOlyFixedStartDay", Calendar.MONDAY);
			ALT_OLY_FIXED_START_HOUR = oly.getProperty("AltOlyFixedStartHour", 0);
			ALT_OLY_FIXED_START_MINUTE = oly.getProperty("AltOlyFixedStartMinute", 0);
			ALT_OLY_FIXED_HERO_DAY = oly.getProperty("AltOlyFixedHeroDay", Calendar.SATURDAY);
			ALT_OLY_FIXED_HERO_HOUR = oly.getProperty("AltOlyFixedHeroHour", 12);
			ALT_OLY_FIXED_HERO_MINUTE = oly.getProperty("AltOlyFixedHeroMinute", 0);
			OLY_FIGHT = oly.getProperty("AllowOlympiad", false);
			ALT_OLY_RECHARGE_SKILLS = oly.getProperty("AltOlyRechargeSkills", false);
			ALT_OLY_REMOVE_SKILL = oly.getProperty("AltOlyRemoveSkill", true);
			OLY_SKILL_PROTECT = Boolean.parseBoolean(oly.getProperty("OlySkillProtect", "True"));
			for (String id : oly.getProperty("OllySkillId", "0").split(","))
			{
				OLY_SKILL_LIST.add(Integer.parseInt(id));
			}

			OLY_PROTECT_ITEMS = new ArrayList<>();
			for (String id : oly.getProperty("OlyRestrictedItems", "0").split(","))
			{
				OLY_PROTECT_ITEMS.add(Integer.parseInt(id));
			}

			// Events config
			ExProperties events = load(EVENTS_FILE);
			ALT_GAME_REQUIRE_CLAN_CASTLE = events.getProperty("AltRequireClanCastle", false);
			ALT_GAME_CASTLE_DAWN = events.getProperty("AltCastleForDawn", true);
			ALT_GAME_CASTLE_DUSK = events.getProperty("AltCastleForDusk", true);
			ALT_FESTIVAL_MIN_PLAYER = events.getProperty("AltFestivalMinPlayer", 5);
			ALT_MAXIMUM_PLAYER_CONTRIB = events.getProperty("AltMaxPlayerContrib", 1000000);
			ALT_FESTIVAL_MANAGER_START = events.getProperty("AltFestivalManagerStart", 120000);
			ALT_FESTIVAL_LENGTH = events.getProperty("AltFestivalLength", 1080000);
			ALT_FESTIVAL_CYCLE_LENGTH = events.getProperty("AltFestivalCycleLength", 2280000);
			ALT_FESTIVAL_FIRST_SPAWN = events.getProperty("AltFestivalFirstSpawn", 120000);
			ALT_FESTIVAL_FIRST_SWARM = events.getProperty("AltFestivalFirstSwarm", 300000);
			ALT_FESTIVAL_SECOND_SPAWN = events.getProperty("AltFestivalSecondSpawn", 540000);
			ALT_FESTIVAL_SECOND_SWARM = events.getProperty("AltFestivalSecondSwarm", 720000);
			ALT_FESTIVAL_CHEST_SPAWN = events.getProperty("AltFestivalChestSpawn", 900000);
			ALT_SEVENSIGNS_LAZY_UPDATE = events.getProperty("AltSevenSignsLazyUpdate", true);

			FS_TIME_ATTACK = events.getProperty("TimeOfAttack", 50);
			FS_TIME_COOLDOWN = events.getProperty("TimeOfCoolDown", 5);
			FS_TIME_ENTRY = events.getProperty("TimeOfEntry", 3);
			FS_TIME_WARMUP = events.getProperty("TimeOfWarmUp", 2);
			FS_PARTY_MEMBER_COUNT = events.getProperty("NumberOfNecessaryPartyMembers", 4);

			RIFT_MIN_PARTY_SIZE = events.getProperty("RiftMinPartySize", 2);
			RIFT_MAX_JUMPS = events.getProperty("MaxRiftJumps", 4);
			RIFT_SPAWN_DELAY = events.getProperty("RiftSpawnDelay", 10000);
			RIFT_AUTO_JUMPS_TIME_MIN = events.getProperty("AutoJumpsDelayMin", 480);
			RIFT_AUTO_JUMPS_TIME_MAX = events.getProperty("AutoJumpsDelayMax", 600);
			RIFT_ENTER_COST_RECRUIT = events.getProperty("RecruitCost", 18);
			RIFT_ENTER_COST_SOLDIER = events.getProperty("SoldierCost", 21);
			RIFT_ENTER_COST_OFFICER = events.getProperty("OfficerCost", 24);
			RIFT_ENTER_COST_CAPTAIN = events.getProperty("CaptainCost", 27);
			RIFT_ENTER_COST_COMMANDER = events.getProperty("CommanderCost", 30);
			RIFT_ENTER_COST_HERO = events.getProperty("HeroCost", 33);
			RIFT_BOSS_ROOM_TIME_MUTIPLY = events.getProperty("BossRoomTimeMultiply", 1.);

			ALLOW_WEDDING = events.getProperty("AllowWedding", false);
			WEDDING_PRICE = events.getProperty("WeddingPrice", 1000000);
			WEDDING_SAMESEX = events.getProperty("WeddingAllowSameSex", false);
			WEDDING_FORMALWEAR = events.getProperty("WeddingFormalWear", true);

			ALT_LOTTERY_PRIZE = events.getProperty("AltLotteryPrize", 50000);
			ALT_LOTTERY_TICKET_PRICE = events.getProperty("AltLotteryTicketPrice", 2000);
			ALT_LOTTERY_5_NUMBER_RATE = events.getProperty("AltLottery5NumberRate", 0.6);
			ALT_LOTTERY_4_NUMBER_RATE = events.getProperty("AltLottery4NumberRate", 0.2);
			ALT_LOTTERY_3_NUMBER_RATE = events.getProperty("AltLottery3NumberRate", 0.2);
			ALT_LOTTERY_2_AND_1_NUMBER_PRIZE = events.getProperty("AltLottery2and1NumberPrize", 200);

			ALT_FISH_CHAMPIONSHIP_ENABLED = events.getProperty("AltFishChampionshipEnabled", true);
			ALT_FISH_CHAMPIONSHIP_REWARD_ITEM = events.getProperty("AltFishChampionshipRewardItemId", 57);
			ALT_FISH_CHAMPIONSHIP_REWARD_1 = events.getProperty("AltFishChampionshipReward1", 800000);
			ALT_FISH_CHAMPIONSHIP_REWARD_2 = events.getProperty("AltFishChampionshipReward2", 500000);
			ALT_FISH_CHAMPIONSHIP_REWARD_3 = events.getProperty("AltFishChampionshipReward3", 300000);
			ALT_FISH_CHAMPIONSHIP_REWARD_4 = events.getProperty("AltFishChampionshipReward4", 200000);
			ALT_FISH_CHAMPIONSHIP_REWARD_5 = events.getProperty("AltFishChampionshipReward5", 100000);

			// FloodProtector
			ExProperties security = load(FLOOD_PROTECTOR_FILE);
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_ROLL_DICE, "RollDice", "42");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_SHOUT_VOICE, "GlobalChat", "100");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_TRADE_CHAT, "TradeChat", "100");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_HERO_VOICE, "HeroVoice", "100");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_SUBCLASS, "Subclass", "20");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_DROP_ITEM, "DropItem", "10");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_SERVER_BYPASS, "ServerBypass", "5");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_MULTISELL, "MultiSell", "1");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_MANUFACTURE, "Manufacture", "3");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_MANOR, "Manor", "30");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_SENDMAIL, "SendMail", "100");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_CHARACTER_SELECT, "CharacterSelect", "30");
			loadFloodProtectorConfig(security, FLOOD_PROTECTOR_USE_ENCHANT, "UseEnchant", "15");

			// Geoengine
			ExProperties geoengine = load(GEOENGINE_FILE);
			GEODATA = geoengine.getProperty("GeoData", 0);
			GEODATA_PATH = geoengine.getProperty("GeoDataPath", "./data/geodata/");
			GEODATA_FORMAT = Enum.valueOf(GeoFormat.class, geoengine.getProperty("GeoDataFormat", GeoFormat.L2J.toString()));
			COORD_SYNCHRONIZE = geoengine.getProperty("CoordSynchronize", -1);
			FALLEN_POSITION = geoengine.getProperty("FallenPosition", false);

			PART_OF_CHARACTER_HEIGHT = geoengine.getProperty("PartOfCharacterHeight", 75);
			MAX_OBSTACLE_HEIGHT = geoengine.getProperty("MaxObstacleHeight", 32);

			PATHFIND_BUFFERS = geoengine.getProperty("PathFindBuffers", "100x6;128x6;192x6;256x4;320x4;384x4;500x2");
			BASE_WEIGHT = geoengine.getProperty("BaseWeight", 10);
			DIAGONAL_WEIGHT = geoengine.getProperty("DiagonalWeight", 14);
			OBSTACLE_MULTIPLIER = geoengine.getProperty("ObstacleMultiplier", 10);
			HEURISTIC_WEIGHT = geoengine.getProperty("HeuristicWeight", 20);
			MAX_ITERATIONS = geoengine.getProperty("MaxIterations", 3500);
			DEBUG_PATH = geoengine.getProperty("DebugPath", false);

			// HexID
			ExProperties hexid = load(HEXID_FILE);
			SERVER_ID = Integer.parseInt(hexid.getProperty("ServerID"));
			HEX_ID = new BigInteger(hexid.getProperty("HexID"), 16).toByteArray();

			// NPCs Auras
			ExProperties npcs = load(NPCS_FILE);

			RESPAWN_IDS = npcs.getProperty("Respawn_IDs");
			RESPAWN_IDS_LIST = new ArrayList<>();
			for(String id : RESPAWN_IDS.split(","))
				RESPAWN_IDS_LIST.add(Integer.parseInt(id));

			RESPAWN_CUSTOM = Boolean.parseBoolean(npcs.getProperty("RespawnCustom", "false"));
			MIN_RESPAWN = Integer.parseInt(npcs.getProperty("Respawn_MOB", "4"));
			MAX_RESPAWN = Integer.parseInt(npcs.getProperty("Respawn_random_MOB", "4"));

			NPC_WITH_EFFECT_RED = npcs.getProperty("NpcWithEffect_RED", "");
			LIST_NPC_WITH_EFFECT_RED = new ArrayList<>();
			for (String listid : NPC_WITH_EFFECT_RED.split(","))
			{
				LIST_NPC_WITH_EFFECT_RED.add(Integer.parseInt(listid));
			}

			NPC_WITH_EFFECT_BLUE = npcs.getProperty("NpcWithEffect_BLUE", "");
			LIST_NPC_WITH_EFFECT_BLUE = new ArrayList<>();
			for (String listid : NPC_WITH_EFFECT_BLUE.split(","))
			{
				LIST_NPC_WITH_EFFECT_BLUE.add(Integer.parseInt(listid));
			}

			ENABLE_SHIFT_CLICK_TO_NPCS = npcs.getProperty("EnableShiftClickToNpcs", false);

			CHAMPION_FREQUENCY = npcs.getProperty("ChampionFrequency", 0);
			CHAMP_MIN_LVL = npcs.getProperty("ChampionMinLevel", 20);
			CHAMP_MAX_LVL = npcs.getProperty("ChampionMaxLevel", 70);
			CHAMPION_HP = npcs.getProperty("ChampionHp", 8);
			CHAMPION_HP_REGEN = npcs.getProperty("ChampionHpRegen", 1.);
			CHAMPION_REWARDS = npcs.getProperty("ChampionRewards", 8);
			CHAMPION_ADENAS_REWARDS = npcs.getProperty("ChampionAdenasRewards", 1);
			CHAMPION_ATK = npcs.getProperty("ChampionAtk", 1.);
			CHAMPION_SPD_ATK = npcs.getProperty("ChampionSpdAtk", 1.);
			CHAMPION_REWARD = npcs.getProperty("ChampionRewardItem", 0);
			CHAMPION_REWARD_ID = npcs.getProperty("ChampionRewardItemID", 6393);
			CHAMPION_REWARD_QTY = npcs.getProperty("ChampionRewardItemQty", 1);

			BUFFER_MAX_SCHEMES = npcs.getProperty("BufferMaxSchemesPerChar", 4);
			BUFFER_STATIC_BUFF_COST = npcs.getProperty("BufferStaticCostPerBuff", -1);
			
			// METODO RANKING INTERFACE
			SHOW_PVP_RANK_HUD = npcs.getProperty("ShowPvpRankHud", false);
			SHOW_PVP_RANK_HUD_INTERVAL = Math.max(500, Math.min(10000, npcs.getProperty("ShowPvpRankHudInterval", 2000)));
			SHOW_PVP_RANK_HUD_RADIUS = Math.max(500, Math.min(6000, npcs.getProperty("ShowPvpRankHudRadius", 2000)));
			SHOW_PVP_RANK_HUD_TOP = Math.max(1, Math.min(10, npcs.getProperty("ShowPvpRankHudTop", 10)));
			SHOW_PVP_RANK_HUD_REFRESH = Math.max(30000, npcs.getProperty("ShowPvpRankHudRefresh", 300000));
			SHOW_KILL_FEED = npcs.getProperty("ShowKillFeed", true);
			SHOW_KILL_FEED_RADIUS = Math.max(500, Math.min(6000, npcs.getProperty("ShowKillFeedRadius", 2000)));
			SHOW_KILL_FEED_GLOBAL = npcs.getProperty("ShowKillFeedGlobal", false);
			SHOW_KILL_FEED_BOTS = npcs.getProperty("ShowKillFeedBots", true);
			SHOW_ITEM_TIER = npcs.getProperty("ShowItemTier", true);
			//FIM
			
			FIGHTER_BUFF = npcs.getProperty("FighterBuffList", "0");
			FIGHTER_BUFF_LIST = new ArrayList<>();
			for (String id : FIGHTER_BUFF.trim().split(","))
			{
				FIGHTER_BUFF_LIST.add(Integer.parseInt(id.trim()));
			}

			MAGE_BUFF = npcs.getProperty("MageBuffList", "0");
			MAGE_BUFF_LIST = new ArrayList<>();
			for (String id : MAGE_BUFF.trim().split(","))
			{
				MAGE_BUFF_LIST.add(Integer.parseInt(id.trim()));
			}

			EXCLUDE_SKILLS = npcs.getProperty("ExcludeSkills", "4553,4554");
			EXCLUDE_SKILLS_LIST = new ArrayList<>();
			for(String id : EXCLUDE_SKILLS.trim().split(","))
				EXCLUDE_SKILLS_LIST.add(Integer.parseInt(id.trim()));

			ALLOW_CLASS_MASTERS = npcs.getProperty("AllowClassMasters", false);
			ALLOW_ENTIRE_TREE = npcs.getProperty("AllowEntireTree", false);
			if (ALLOW_CLASS_MASTERS)
				CLASS_MASTER_SETTINGS = new ClassMasterSettings(npcs.getProperty("ConfigClassMaster"));

			ALTERNATE_CLASS_MASTER = npcs.getProperty("AlternateClassMaster", false);
			ANNOUNCE_MAMMON_SPAWN = npcs.getProperty("AnnounceMammonSpawn", true);
			ALT_MOB_AGRO_IN_PEACEZONE = npcs.getProperty("AltMobAgroInPeaceZone", true);
			ALT_GAME_FREE_TELEPORT = npcs.getProperty("AltFreeTeleporting", false);
			SHOW_NPC_LVL = npcs.getProperty("ShowNpcLevel", false);
			SHOW_NPC_CREST = npcs.getProperty("ShowNpcCrest", false);
			SHOW_NPC_EFFECT_SUBCLASS = npcs.getProperty("ShowEffectSubclasschange", false);
			SHOW_EFFECT_CLASS = npcs.getProperty("ShowEffectclass", false);
			SHOW_SUMMON_CREST = npcs.getProperty("ShowSummonCrest", false);

			WYVERN_ALLOW_UPGRADER = npcs.getProperty("AllowWyvernUpgrader", true);
			WYVERN_REQUIRED_LEVEL = npcs.getProperty("RequiredStriderLevel", 55);
			WYVERN_REQUIRED_CRYSTALS = npcs.getProperty("RequiredCrystalsNumber", 10);


			GUARD_ATTACK_AGGRO_MOB = npcs.getProperty("GuardAttackAggroMob", false);
			MAX_DRIFT_RANGE = npcs.getProperty("MaxDriftRange", 300);
			MAX_DRIFT_RANGE_EPIC = npcs.getProperty("MaxDriftRangeEpic", 300);
			KNOWNLIST_UPDATE_INTERVAL = npcs.getProperty("KnownListUpdateInterval", 1250);
			MIN_NPC_ANIMATION = npcs.getProperty("MinNPCAnimation", 20);
			MAX_NPC_ANIMATION = npcs.getProperty("MaxNPCAnimation", 40);
			MIN_MONSTER_ANIMATION = npcs.getProperty("MinMonsterAnimation", 10);
			MAX_MONSTER_ANIMATION = npcs.getProperty("MaxMonsterAnimation", 40);

			GRIDS_ALWAYS_ON = npcs.getProperty("GridsAlwaysOn", false);
			GRID_NEIGHBOR_TURNON_TIME = npcs.getProperty("GridNeighborTurnOnTime", 1);
			GRID_NEIGHBOR_TURNOFF_TIME = npcs.getProperty("GridNeighborTurnOffTime", 90);

			ENABLE_SKIPPING = npcs.getProperty("EnableSkippingItems", false);
			ITEM_ID_BUY_CLAN_HALL = npcs.getProperty("ItemIDBuyClanHall", 57);

			// Boss Configs
			ExProperties Boss = load(BOSS_FILE);

			ENABLE_UPDATE_JEWELRY = Boss.getProperty("EnableJewelryUpgrade", true);

			ENABLE_REWARD_HEART_STONE = Boss.getProperty("EnableHeartStone", true);

			String pX_br = Boss.getProperty("HeartStoneList", "57,1000");
			String[] pX_br_split = pX_br.split(";");
			for (String s : pX_br_split)
			{
				String[] ss = s.split(",");
				HEART_STONE_REWARDS.put(Integer.parseInt(ss[0]), Integer.parseInt(ss[1]));
			}

			ENABLE_REWARD_EPIC_STONE = Boss.getProperty("EnableEpicStone", true);

			String pA_br = Boss.getProperty("EpicStoneList", "57,1000");
			String[] pA_br_split = pA_br.split(";");
			for (String s : pA_br_split)
			{
				String[] ss = s.split(",");
				EPIC_STONE_REWARDS.put(Integer.parseInt(ss[0]), Integer.parseInt(ss[1]));
			}

			NOBLESS_FROM_BOSS = Boss.getProperty("NoblessFromBoss", false);
			BOSS_ID = Boss.getProperty("BossId", 25325);
			RADIUS_TO_RAID = Boss.getProperty("RadiusToRaid", 1000);

			NPCS_FLAG_RANGE = Boss.getProperty("NpcsFlagRangeDistanceOnKill", 1000);
			ALLOW_FLAG_ONKILL_BY_ID = Boss.getProperty("AllowFlagNpcOnKill", false);
			NPCS_FLAG_IDS = Boss.getProperty("NpcsFlagIDsOnKill", "29020,29019,25517,25523,25524");
			NPCS_FLAG_LIST = new ArrayList<>();
			for (final String id : NPCS_FLAG_IDS.split(","))
			{
				NPCS_FLAG_LIST.add(Integer.parseInt(id));
			}
			RAID_HP_REGEN_MULTIPLIER = Boss.getProperty("RaidHpRegenMultiplier", 1.);
			RAID_MP_REGEN_MULTIPLIER = Boss.getProperty("RaidMpRegenMultiplier", 1.);
			RAID_DEFENCE_MULTIPLIER = Boss.getProperty("RaidDefenceMultiplier", 1.);
			RAID_MINION_RESPAWN_TIMER = Boss.getProperty("RaidMinionRespawnTime", 300000);

			PLAYERS_CAN_HEAL_RB = Boss.getProperty("PlayersCanHealRaid", false);
			RAID_DISABLE_CURSE = Boss.getProperty("DisableRaidCurse", false);
			RAID_CHAOS_TIME = Boss.getProperty("RaidChaosTime", 30);
			GRAND_CHAOS_TIME = Boss.getProperty("GrandChaosTime", 30);
			MINION_CHAOS_TIME = Boss.getProperty("MinionChaosTime", 30);

			SPAWN_INTERVAL_AQ = Boss.getProperty("AntQueenSpawnInterval", 36);
			RANDOM_SPAWN_TIME_AQ = Boss.getProperty("AntQueenRandomSpawn", 17);

			SPAWN_INTERVAL_ANTHARAS = Boss.getProperty("AntharasSpawnInterval", 264);
			RANDOM_SPAWN_TIME_ANTHARAS = Boss.getProperty("AntharasRandomSpawn", 72);
			WAIT_TIME_ANTHARAS = Boss.getProperty("AntharasWaitTime", 30) * 60000;

			SPAWN_INTERVAL_BAIUM = Boss.getProperty("BaiumSpawnInterval", 168);
			RANDOM_SPAWN_TIME_BAIUM = Boss.getProperty("BaiumRandomSpawn", 48);

			SPAWN_INTERVAL_CORE = Boss.getProperty("CoreSpawnInterval", 60);
			RANDOM_SPAWN_TIME_CORE = Boss.getProperty("CoreRandomSpawn", 23);

			SPAWN_INTERVAL_ALTAR = Boss.getProperty("VanHelterSpawnInterval", 36);
			RANDOM_SPAWN_TIME_ALTAR = Boss.getProperty("VanHelterRandomSpawn", 17);

			SPAWN_INTERVAL_FRINTEZZA = Boss.getProperty("FrintezzaSpawnInterval", 48);
			RANDOM_SPAWN_TIME_FRINTEZZA = Boss.getProperty("FrintezzaRandomSpawn", 8);
			WAIT_TIME_FRINTEZZA = Boss.getProperty("FrintezzaWaitTime", 1) * 60000;
			DESPAWN_TIME_FRINTEZZA = Boss.getProperty("FrintezzaDespawnTime", 1) * 60000;
			FRINTEZZA_TIME_CHALLENGE = Boss.getProperty("FrintezzaTimeChallenge", 1) * 60000;
			BYPASS_FRINTEZZA_PARTIES_CHECK = Boolean.valueOf(Boss.getProperty("BypassPartiesCheck", "true"));
			FRINTEZZA_MIN_PARTIES = Integer.parseInt(Boss.getProperty("FrintezzaMinParties", "4"));
			FRINTEZZA_MAX_PARTIES = Integer.parseInt(Boss.getProperty("FrintezzaMaxParties", "5"));

			SPAWN_INTERVAL_ORFEN = Boss.getProperty("OrfenSpawnInterval", 48);
			RANDOM_SPAWN_TIME_ORFEN = Boss.getProperty("OrfenRandomSpawn", 20);

			SPAWN_INTERVAL_SAILREN = Boss.getProperty("SailrenSpawnInterval", 36);
			RANDOM_SPAWN_TIME_SAILREN = Boss.getProperty("SailrenRandomSpawn", 24);
			WAIT_TIME_SAILREN = Boss.getProperty("SailrenWaitTime", 5) * 60000;

			SPAWN_INTERVAL_VALAKAS = Boss.getProperty("ValakasSpawnInterval", 264);
			RANDOM_SPAWN_TIME_VALAKAS = Boss.getProperty("ValakasRandomSpawn", 72);
			WAIT_TIME_VALAKAS = Boss.getProperty("ValakasWaitTime", 30) * 60000;
			
			//ZAKEN NOVO
			SPAWN_INTERVAL_ZAKEN =Boss.getProperty("ZakenSpawnInterval", 10);

			SEGUNDS_DURATION_OPEN_ZAKEN =Boss.getProperty("ZakenRoomTime", 5);

			CUBIC_TIME_SPAWN_ZAKEN =Boss.getProperty("CubicTimeSpawn_Zaken", 1);

			ZAKEN_PRESPAWN_DOOR_TIME =Boss.getProperty("ZakenPreSpawnDoorTime", 2);

			SEGUNDS_DURATION_OPEN_ZAKEN_RANDOM =Boss.getProperty("ZakenRoomTimeRandom", 21);

			String[] zakenLoc =Boss.getProperty("ZakenLoc", "82552,-16104,-1893").split(",");

			if (zakenLoc.length != 3)
			    throw new IllegalArgumentException("ZakenLoc deve conter exatamente X,Y,Z.");

			for (int i = 0; i < 3; i++)
			    ZAKEN_LOCATION[i] = Integer.parseInt(zakenLoc[i].trim());

			String[] zakenExit =Boss.getProperty("ZakenCubicTeleportLoc","79819,152059,-3536").split(",");

			if (zakenExit.length != 3)
			    throw new IllegalArgumentException("ZakenCubicTeleportLoc deve conter exatamente X,Y,Z.");

			for (int i = 0; i < 3; i++)
			    ZAKEN_CUBIC_TELEPORT_LOC[i] =Integer.parseInt(zakenExit[i].trim());

			if (SPAWN_INTERVAL_ZAKEN <= 0)
			    throw new IllegalArgumentException("ZakenSpawnInterval deve ser maior que zero.");

			if (SEGUNDS_DURATION_OPEN_ZAKEN <= 0)
			    throw new IllegalArgumentException("ZakenRoomTime deve ser maior que zero.");

			if (CUBIC_TIME_SPAWN_ZAKEN <= 0)
			    throw new IllegalArgumentException("CubicTimeSpawn_Zaken deve ser maior que zero.");

			if (ZAKEN_PRESPAWN_DOOR_TIME < 0)
			    throw new IllegalArgumentException("ZakenPreSpawnDoorTime não pode ser negativo.");

			if (SEGUNDS_DURATION_OPEN_ZAKEN_RANDOM < -1 ||
			    SEGUNDS_DURATION_OPEN_ZAKEN_RANDOM > 23)
			{
			    throw new IllegalArgumentException("ZakenRoomTimeRandom deve ser -1 ou uma hora entre 0 e 23.");
			}

			ANTQUEEN_CUSTOM_SPAWN_ENABLED = Boss.getProperty("AntQueenCustomSpawn", false);
			ANTQUEEN_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("AntQueenRandomSpawn", "0").trim());
			ANTQUEEN_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("AntQueenDaysAndHours", "").trim(), ANTQUEEN_CUSTOM_SPAWN_RANDOM_INTERVAL);
			ANTHARAS_CUSTOM_SPAWN_ENABLED = Boss.getProperty("AntharasCustomSpawn", false);
			ANTHARAS_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("AntharasRandomSpawn", "0").trim());
			ANTHARAS_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("AntharasDaysAndHours", "").trim(), ANTHARAS_CUSTOM_SPAWN_RANDOM_INTERVAL);
			CORE_CUSTOM_SPAWN_ENABLED = Boss.getProperty("CoreCustomSpawn", false);
			CORE_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("CoreRandomSpawn", "0").trim());
			CORE_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("CoreDaysAndHours", "").trim(), CORE_CUSTOM_SPAWN_RANDOM_INTERVAL);
			ORFEN_CUSTOM_SPAWN_ENABLED = Boss.getProperty("OrfenCustomSpawn", false);
			ORFEN_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("OrfenRandomSpawn", "0").trim());
			ORFEN_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("OrfenDaysAndHours", "").trim(), ORFEN_CUSTOM_SPAWN_RANDOM_INTERVAL);
			ZAKEN_CUSTOM_SPAWN_ENABLED = Boss.getProperty("ZakenCustomSpawn", false);
			ZAKEN_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("ZakenRandomSpawn", "0").trim());
			ZAKEN_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("ZakenDaysAndHours", "").trim(), ZAKEN_CUSTOM_SPAWN_RANDOM_INTERVAL);
			FRINTEZZA_CUSTOM_SPAWN_ENABLED = Boss.getProperty("FrintezzaCustomSpawn", false);
			FRINTEZZA_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("FrintezzaRandomSpawn", "0").trim());
			FRINTEZZA_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("FrintezzaDaysAndHours", "").trim(), FRINTEZZA_CUSTOM_SPAWN_RANDOM_INTERVAL);
			BAIUM_CUSTOM_SPAWN_ENABLED = Boss.getProperty("BaiumCustomSpawn", false);
			BAIUM_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("BaiumRandomSpawn", "0").trim());
			BAIUM_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("BaiumDaysAndHours", "").trim(), BAIUM_CUSTOM_SPAWN_RANDOM_INTERVAL);
			VALAKAS_CUSTOM_SPAWN_ENABLED = Boss.getProperty("ValakasCustomSpawn", false);
			VALAKAS_CUSTOM_SPAWN_RANDOM_INTERVAL = Integer.parseInt(Boss.getProperty("ValakasRandomSpawn", "0").trim());
			VALAKAS_CUSTOM_SPAWN_TIMES = ParseDates(Boss.getProperty("ValakasDaysAndHours", "").trim(), VALAKAS_CUSTOM_SPAWN_RANDOM_INTERVAL);


			RAID_BOSS_INFO_PAGE_LIMIT = Boss.getProperty("RaidBossInfoPageLimit", 15);
			RAID_BOSS_DROP_PAGE_LIMIT = Boss.getProperty("RaidBossDropPageLimit", 15);
			RAID_BOSS_DATE_FORMAT = Boss.getProperty("RaidBossDateFormat", "MMM dd, HH:mm");
			// RAID LOW
			RAID_LOW_IDS = Boss.getProperty("RaidLowIds", "");
			LIST_RAID_LOW_IDS = new ArrayList<>();

			if (!RAID_LOW_IDS.trim().isEmpty())
			{
				for (String val : RAID_LOW_IDS.split(","))
				{
					val = val.trim();

					if (val.isEmpty())
						continue;

					int npcId = Integer.parseInt(val);
					LIST_RAID_LOW_IDS.add(npcId);
				}
			}

			// RAID MID
			RAID_MID_IDS = Boss.getProperty("RaidMidIds", "");
			LIST_RAID_MID_IDS = new ArrayList<>();

			if (!RAID_MID_IDS.trim().isEmpty())
			{
				for (String val : RAID_MID_IDS.split(","))
				{
					val = val.trim();

					if (val.isEmpty())
						continue;

					int npcId = Integer.parseInt(val);
					LIST_RAID_MID_IDS.add(npcId);
				}
			}

			// RAID HIGH
			RAID_HIGH_IDS = Boss.getProperty("RaidHighIds", "");
			LIST_RAID_HIGH_IDS = new ArrayList<>();

			if (!RAID_HIGH_IDS.trim().isEmpty())
			{
				for (String val : RAID_HIGH_IDS.split(","))
				{
					val = val.trim();

					if (val.isEmpty())
						continue;

					int npcId = Integer.parseInt(val);
					LIST_RAID_HIGH_IDS.add(npcId);
				}
			}

			RAIDINFO_USE_GRAND_BOSS_LIST = Boolean.parseBoolean(
					Boss.getProperty("RaidInfoUseGrandBossList", "false")
				);
			
			// GRAND BOSS
			GRAND_BOSS_IDS = Boss.getProperty("GrandBossIds", "");
			LIST_GRAND_BOSS_IDS = new ArrayList<>();

			if (!GRAND_BOSS_IDS.trim().isEmpty())
			{
				for (String val : GRAND_BOSS_IDS.split(","))
				{
					val = val.trim();

					if (val.isEmpty())
						continue;

					int npcId = Integer.parseInt(val);
					LIST_GRAND_BOSS_IDS.add(npcId);
				}
			}

			LIST_ITENS_NOT_SHOW = Boss.getProperty("ExceptionItemList");
			NOT_SHOW_DROP_INFO = new ArrayList<>();
			for(String id : LIST_ITENS_NOT_SHOW.split(","))
			{
				NOT_SHOW_DROP_INFO.add(Integer.parseInt(id));
			}

			// players
			ExProperties players = load(PLAYERS_FILE);
			//INICIO DOS EFFECTS PK
			PK_CONTOUR_ENABLED = players.getProperty("EnablePkContour", false);
			PK_CONTOUR_OPACITY = Math.max(0, Math.min(255,players.getProperty("PkContourOpacity", 220)));
			PVP_CONTOUR_ENABLED = players.getProperty("EnablePvpContour", true);

			try
			{
			    final String color =
			        players.getProperty("PvpContourColor", "FF00FF").trim();

			    if (!color.matches("[0-9a-fA-F]{6}"))
			        throw new IllegalArgumentException("Expected six hexadecimal digits.");

			    PVP_CONTOUR_COLOR = Integer.parseInt(color, 16);
			}
			catch (IllegalArgumentException ex)
			{
			    PVP_CONTOUR_COLOR = 0xFF00FF;
			    _log.warning("Invalid PvpContourColor. Using FF00FF.");
			}
			
			try
			{
				final String color = players.getProperty("PkContourColor", "FF2323").trim();

				if (!color.matches("[0-9a-fA-F]{6}"))
					throw new IllegalArgumentException("Expected six hexadecimal digits.");

				PK_CONTOUR_COLOR = Integer.parseInt(color, 16);
			}
			catch (IllegalArgumentException ex)
			{
				PK_CONTOUR_COLOR = 0xFF2323;
				_log.warning("Invalid PkContourColor. Using FF2323.");
			}
			//FIM
			
			NEW_TITLE_AUTO_FARM = players.getProperty("NewTitleAutoFarm", "[AUTO FARMING]");

			try
			{
			    final String color = players.getProperty("AutoFarmTitleColor", "00FFFF").trim();

			    if (!color.matches("[0-9a-fA-F]{6}"))
			        throw new NumberFormatException("Expected six hexadecimal digits");

			    AUTO_FARM_TITLE_COLOR = Integer.parseInt(color, 16);
			}
			catch (NumberFormatException e)
			{
			    AUTO_FARM_TITLE_COLOR = 0x00FFFF;
			    _log.warning("AutoFarmTitleColor invalido. Usando 00FFFF.");
			}
			
			STARTER_EQUIP_ENABLED = players.getProperty("StarterEquipEnabled", false);
			if (STARTER_EQUIP_ENABLED)
			{
				STARTER_EQUIP_FIGHTER.clear();
				for (String s : players.getProperty("StarterEquipFighter", "").split(","))
				{
					s = s.trim();
					if (!s.isEmpty())
					{
						try { STARTER_EQUIP_FIGHTER.add(Integer.parseInt(s)); }
						catch (NumberFormatException e) { _log.warning("StarterEquipFighter invalid id: " + s); }
					}
				}
				STARTER_EQUIP_MAGE.clear();
				for (String s : players.getProperty("StarterEquipMage", "").split(","))
				{
					s = s.trim();
					if (!s.isEmpty())
					{
						try { STARTER_EQUIP_MAGE.add(Integer.parseInt(s)); }
						catch (NumberFormatException e) { _log.warning("StarterEquipMage invalid id: " + s); }
					}
				}
			}
			
			STARTER_EQUIP_ENCHANT = players.getProperty("StarterEquipEnchant", 1);

			STARTER_BUFFS_ENABLED = players.getProperty("StarterBuffsEnabled", false);
			if (STARTER_BUFFS_ENABLED)
			{
				STARTER_BUFFS_FIGHTER.clear();
				for (String s : players.getProperty("StarterBuffsFighter", "").split(";"))
				{
					s = s.trim();
					if (s.isEmpty()) continue;
					final String[] parts = s.split(",");
					if (parts.length != 2)
						_log.warning("StarterBuffsFighter invalid entry (use skillId,level): " + s);
					else
					{
						try { STARTER_BUFFS_FIGHTER.add(new int[]{Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())}); }
						catch (NumberFormatException e) { _log.warning("StarterBuffsFighter invalid entry: " + s); }
					}
				}
				STARTER_BUFFS_MAGE.clear();
				for (String s : players.getProperty("StarterBuffsMage", "").split(";"))
				{
					s = s.trim();
					if (s.isEmpty()) continue;
					final String[] parts = s.split(",");
					if (parts.length != 2)
						_log.warning("StarterBuffsMage invalid entry (use skillId,level): " + s);
					else
					{
						try { STARTER_BUFFS_MAGE.add(new int[]{Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())}); }
						catch (NumberFormatException e) { _log.warning("StarterBuffsMage invalid entry: " + s); }
					}
				}
			}

			ENABLE_EFFECT_ON_DIE = Boolean.parseBoolean(players.getProperty("EnableEffectOnDie", "false"));

			CUSTOM_START_LVL = players.getProperty("CustomStartLvl", 1);
			CUSTOM_SUBCLASS_LVL = players.getProperty("CustomSubclassLvl", 40);

			SPAWN_CHAR_START = Boolean.parseBoolean(players.getProperty("CustomSpawn", "false"));
			SPAWN_X_1 = Integer.parseInt(players.getProperty("SpawnX_1", ""));
			SPAWN_Y_1 = Integer.parseInt(players.getProperty("SpawnY_1", ""));
			SPAWN_Z_1 = Integer.parseInt(players.getProperty("SpawnZ_1", ""));

			CHAR_TITLE = players.getProperty("CharTitle", false);
			ADD_CHAR_TITLE = players.getProperty("CharAddTitle", "Welcome");

			STARTING_ADENA = players.getProperty("StartingAdena", 100);

			CUSTOM_STARTER_ITEMS_ENABLED = players.getProperty("CustomStarterItemsEnabled", false);
			if (Config.CUSTOM_STARTER_ITEMS_ENABLED)
			{
				String[] propertySplit = players.getProperty("StartingCustomItemsMage", "57,0").split(";");
				STARTING_CUSTOM_ITEMS_M.clear();
				for (final String reward : propertySplit)
				{
					final String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2)
						_log.warning("StartingCustomItemsMage[Config.load()]: invalid config property -> StartingCustomItemsMage \"" + reward + "\"");
					else
					{
						try
						{
							STARTING_CUSTOM_ITEMS_M.add(new int[] {Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1])});
						}
						catch (final NumberFormatException nfe)
						{
							if (!reward.isEmpty())
								_log.warning("StartingCustomItemsMage[Config.load()]: invalid config property -> StartingCustomItemsMage \"" + reward + "\"");
						}
					}
				}

				propertySplit = players.getProperty("StartingCustomItemsFighter", "57,0").split(";");
				STARTING_CUSTOM_ITEMS_F.clear();
				for (final String reward : propertySplit)
				{
					final String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2)
						_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
					else
					{
						try
						{
							STARTING_CUSTOM_ITEMS_F.add(new int[] {Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1])});
						}
						catch (final NumberFormatException nfe)
						{
							if (!reward.isEmpty())
								_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
						}
					}
				}
			}


			EFFECT_CANCELING = players.getProperty("CancelLesserEffect", true);
			HP_REGEN_MULTIPLIER = players.getProperty("HpRegenMultiplier", 1.);
			MP_REGEN_MULTIPLIER = players.getProperty("MpRegenMultiplier", 1.);
			CP_REGEN_MULTIPLIER = players.getProperty("CpRegenMultiplier", 1.);
			PLAYER_SPAWN_PROTECTION = players.getProperty("PlayerSpawnProtection", 0);
			PLAYER_FAKEDEATH_UP_PROTECTION = players.getProperty("PlayerFakeDeathUpProtection", 0);
			RESPAWN_RESTORE_HP = players.getProperty("RespawnRestoreHP", 0.7);
			RESPAWN_RESTORE_MP = players.getProperty("RespawnRestoreMP", 0.7);
			RESPAWN_RESTORE_CP = players.getProperty("RespawnRestoreCP", 0.7);
			MAX_PVTSTORE_SLOTS_DWARF = players.getProperty("MaxPvtStoreSlotsDwarf", 5);
			MAX_PVTSTORE_SLOTS_OTHER = players.getProperty("MaxPvtStoreSlotsOther", 4);
			DEEPBLUE_DROP_RULES = players.getProperty("UseDeepBlueDropRules", true);
			ALT_GAME_DELEVEL = players.getProperty("Delevel", true);
			DEATH_PENALTY_CHANCE = players.getProperty("DeathPenaltyChance", 20);

			INVENTORY_MAXIMUM_NO_DWARF = players.getProperty("MaximumSlotsForNoDwarf", 80);
			INVENTORY_MAXIMUM_DWARF = players.getProperty("MaximumSlotsForDwarf", 100);
			INVENTORY_MAXIMUM_QUEST_ITEMS = players.getProperty("MaximumSlotsForQuestItems", 100);
			INVENTORY_MAXIMUM_PET = players.getProperty("MaximumSlotsForPet", 12);
			MAX_ITEM_IN_PACKET = Math.max(INVENTORY_MAXIMUM_NO_DWARF, INVENTORY_MAXIMUM_DWARF);
			ALT_WEIGHT_LIMIT = players.getProperty("AltWeightLimit", 1);
			WAREHOUSE_SLOTS_NO_DWARF = players.getProperty("MaximumWarehouseSlotsForNoDwarf", 100);
			WAREHOUSE_SLOTS_DWARF = players.getProperty("MaximumWarehouseSlotsForDwarf", 120);
			WAREHOUSE_SLOTS_CLAN = players.getProperty("MaximumWarehouseSlotsForClan", 150);
			FREIGHT_SLOTS = players.getProperty("MaximumFreightSlots", 20);
			ALT_GAME_FREIGHTS = players.getProperty("AltGameFreights", false);
			ALT_GAME_FREIGHT_PRICE = players.getProperty("AltGameFreightPrice", 1000);

			KARMA_PLAYER_CAN_BE_KILLED_IN_PZ = players.getProperty("KarmaPlayerCanBeKilledInPeaceZone", false);
			KARMA_PLAYER_CAN_SHOP = players.getProperty("KarmaPlayerCanShop", true);
			KARMA_PLAYER_CAN_USE_GK = players.getProperty("KarmaPlayerCanUseGK", false);
			KARMA_PLAYER_CAN_TELEPORT = players.getProperty("KarmaPlayerCanTeleport", true);
			KARMA_PLAYER_CAN_TRADE = players.getProperty("KarmaPlayerCanTrade", true);
			KARMA_PLAYER_CAN_USE_WH = players.getProperty("KarmaPlayerCanUseWareHouse", true);

			FLAG_PLAYER_CAN_USE_GK = players.getProperty("FlagPlayerCanUseGK", false);
			FLAG_PLAYER_CAN_TRADE = players.getProperty("FlagPlayerCanTrade", true);

			KARMA_DROP_GM = players.getProperty("CanGMDropEquipment", false);
			KARMA_AWARD_PK_KILL = players.getProperty("AwardPKKillPVPPoint", true);
			KARMA_PK_LIMIT = players.getProperty("MinimumPKRequiredToDrop", 5);
			KARMA_NONDROPPABLE_PET_ITEMS = players.getProperty("ListOfPetItems", "2375,3500,3501,3502,4422,4423,4424,4425,6648,6649,6650");
			KARMA_NONDROPPABLE_ITEMS = players.getProperty("ListOfNonDroppableItemsForPK", "1147,425,1146,461,10,2368,7,6,2370,2369");

			String[] array = KARMA_NONDROPPABLE_PET_ITEMS.split(",");
			KARMA_LIST_NONDROPPABLE_PET_ITEMS = new int[array.length];

			for (int i = 0; i < array.length; i++)
				KARMA_LIST_NONDROPPABLE_PET_ITEMS[i] = Integer.parseInt(array[i]);

			array = KARMA_NONDROPPABLE_ITEMS.split(",");
			KARMA_LIST_NONDROPPABLE_ITEMS = new int[array.length];

			for (int i = 0; i < array.length; i++)
				KARMA_LIST_NONDROPPABLE_ITEMS[i] = Integer.parseInt(array[i]);

			// sorting so binarySearch can be used later
			Arrays.sort(KARMA_LIST_NONDROPPABLE_PET_ITEMS);
			Arrays.sort(KARMA_LIST_NONDROPPABLE_ITEMS);

			PVP_NORMAL_TIME = players.getProperty("PvPVsNormalTime", 15000);
			PVP_PVP_TIME = players.getProperty("PvPVsPvPTime", 30000);

			PARTY_XP_CUTOFF_METHOD = players.getProperty("PartyXpCutoffMethod", "level");
			PARTY_XP_CUTOFF_PERCENT = players.getProperty("PartyXpCutoffPercent", 3.);
			PARTY_XP_CUTOFF_LEVEL = players.getProperty("PartyXpCutoffLevel", 20);
			ALT_PARTY_RANGE = players.getProperty("AltPartyRange", 1600);
			ALT_PARTY_RANGE2 = players.getProperty("AltPartyRange2", 1400);
			ALT_LEAVE_PARTY_LEADER = players.getProperty("AltLeavePartyLeader", false);

			PETITIONING_ALLOWED = players.getProperty("PetitioningAllowed", true);
			MAX_PETITIONS_PER_PLAYER = players.getProperty("MaxPetitionsPerPlayer", 5);
			MAX_PETITIONS_PENDING = players.getProperty("MaxPetitionsPending", 25);

			IS_CRAFTING_ENABLED = players.getProperty("CraftingEnabled", true);
			DWARF_RECIPE_LIMIT = players.getProperty("DwarfRecipeLimit", 50);
			COMMON_RECIPE_LIMIT = players.getProperty("CommonRecipeLimit", 50);
			ALT_BLACKSMITH_USE_RECIPES = players.getProperty("AltBlacksmithUseRecipes", true);

			ALT_SHOW_REUSE_MSG = players.getProperty("AltShowSkillReuseMessage", true);
			AUTO_LEARN_SKILLS = players.getProperty("AutoLearnSkills", false);
			ALT_GAME_MAGICFAILURES = players.getProperty("MagicFailures", true);
			ALT_GAME_SHIELD_BLOCKS = players.getProperty("AltShieldBlocks", false);
			ALT_PERFECT_SHLD_BLOCK = players.getProperty("AltPerfectShieldBlockRate", 10);
			LIFE_CRYSTAL_NEEDED = players.getProperty("LifeCrystalNeeded", true);
			SP_BOOK_NEEDED = players.getProperty("SpBookNeeded", true);
			ES_SP_BOOK_NEEDED = players.getProperty("EnchantSkillSpBookNeeded", true);
			AUTO_LEARN_DIVINE_INSPIRATION = players.getProperty("AutoLearnDivineInspiration", false);
			DIVINE_SP_BOOK_NEEDED = players.getProperty("DivineInspirationSpBookNeeded", true);
			ALT_GAME_SUBCLASS_WITHOUT_QUESTS = players.getProperty("AltSubClassWithoutQuests", false);
			ALT_GAME_SUBCLASS_EVERYWHERE = players.getProperty("AltSubclassEverywhere", false);
			BUFFS_MAX_AMOUNT = players.getProperty("MaxBuffsAmount", 20);
			STORE_SKILL_COOLTIME = players.getProperty("StoreSkillCooltime", true);
			
			//Hunter Mode:
			PVP_DROP_MODE_ENABLED = players.getProperty("PvpDropModeEnabled", false);
			PVP_DROP_MODE_BONUS = players.getProperty("PvpDropModeBonus", 50.0);
			PVP_DROP_MODE_HWID_PROTECTION = players.getProperty("PvpDropModeHwidProtection", true);
			
			// Configurações do Daily Reward
			ENBALE_DAILY_REWARD = players.getProperty("EnableDailyReward", true);
			REWARD_PER_TIME_MODE_RESTRICTION = players.getProperty("DailyRewardModeRestriction", 1);

			String dailyRewardStr = players.getProperty("DailyRewardList", "");
			DAILY_REWARD_MAP = new HashMap<>(); // Altere a variável para Map<Integer, IntIntHolder>

			if (!dailyRewardStr.isEmpty())
			{
			    int dayCounter = 1;
			    for (String rewardData : dailyRewardStr.split(";"))
			    {
			        String[] parts = rewardData.trim().split("-");
			        if (parts.length == 3) // Formato: Dia-ItemID-Quantidade
			        {
			            try
			            {
			                int day = Integer.parseInt(parts[0].trim());
			                int id = Integer.parseInt(parts[1].trim());
			                int count = Integer.parseInt(parts[2].trim());
			                DAILY_REWARD_MAP.put(day, new IntIntHolder(id, count));
			            }
			            catch (NumberFormatException e)
			            {
			                _log.warning("DailyRewardList com formato invalido: " + rewardData);
			            }
			        }
			        else if (parts.length == 2) // Formato sequencial: ItemID-Quantidade
			        {
			            try
			            {
			                int id = Integer.parseInt(parts[0].trim());
			                int count = Integer.parseInt(parts[1].trim());
			                DAILY_REWARD_MAP.put(dayCounter++, new IntIntHolder(id, count));
			            }
			            catch (NumberFormatException e)
			            {
			                _log.warning("DailyRewardList com formato invalido: " + rewardData);
			            }
			        }
			    }
			}


			ExProperties admin = load(ADMIN_FILE);

			EVERYBODY_HAS_ADMIN_RIGHTS = admin.getProperty("EverybodyHasAdminRights", false);
			MASTERACCESS_LEVEL = admin.getProperty("MasterAccessLevel", 127);
			MASTERACCESS_NAME_COLOR = Integer.decode(StringUtil.concat("0x", admin.getProperty("MasterNameColor", "00FF00")));
			MASTERACCESS_TITLE_COLOR = Integer.decode(StringUtil.concat("0x", admin.getProperty("MasterTitleColor", "00FF00")));
			GM_HERO_AURA = admin.getProperty("GMHeroAura", false);
			GM_STARTUP_SUPER_HASTE = admin.getProperty("GMStartupSuperHaste", true);
			GM_STARTUP_INVULNERABLE = admin.getProperty("GMStartupInvulnerable", true);
			GM_STARTUP_INVISIBLE = admin.getProperty("GMStartupInvisible", true);
			GM_STARTUP_SILENCE = admin.getProperty("GMStartupSilence", true);
			GM_STARTUP_AUTO_LIST = admin.getProperty("GMStartupAutoList", true);
			GM_NAMES = admin.getProperty("GmNames", "").split(",");
			ENABLE_GM_NAMES_LIST = admin.getProperty("EnableGmNamesList", false);

			// server
			ExProperties server = load(SERVER_FILE);

			GAMESERVER_HOSTNAME = server.getProperty("GameserverHostname");
			PORT_GAME = server.getProperty("GameserverPort", 7777);

			EXTERNAL_HOSTNAME = server.getProperty("ExternalHostname", "*");
			INTERNAL_HOSTNAME = server.getProperty("InternalHostname", "*");
			LICENSE_KEY = server.getProperty("LicenseKey","");
			GAME_SERVER_LOGIN_PORT = server.getProperty("LoginPort", 9014);
			GAME_SERVER_LOGIN_HOST = server.getProperty("LoginHost", "127.0.0.1");

			REQUEST_ID = server.getProperty("RequestServerID", 0);
			ACCEPT_ALTERNATE_ID = server.getProperty("AcceptAlternateID", true);

			DATABASE_URL = server.getProperty("URL", "jdbc:mysql://localhost/acis");
			DATABASE_LOGIN = server.getProperty("Login", "root");
			DATABASE_PASSWORD = server.getProperty("Password", "");
			DATABASE_MAX_CONNECTIONS = server.getProperty("MaximumDbConnections", 10);
			DATABASE_MAX_IDLE_TIME = server.getProperty("MaximumDbIdleTime", 0);

			SERVER_LIST_BRACKET = server.getProperty("ServerListBrackets", false);
			SERVER_LIST_CLOCK = server.getProperty("ServerListClock", false);
			SERVER_GMONLY = server.getProperty("ServerGMOnly", false);
			TEST_SERVER = server.getProperty("TestServer", false);
			SERVER_LIST_TESTSERVER = server.getProperty("TestServer", false);

			DELETE_DAYS = server.getProperty("DeleteCharAfterDays", 7);
			MAXIMUM_ONLINE_USERS = server.getProperty("MaximumOnlineUsers", 100);

			JAIL_IS_PVP = server.getProperty("JailIsPvp", true);
			DEFAULT_PUNISH = server.getProperty("DefaultPunish", 2);
			DEFAULT_PUNISH_PARAM = server.getProperty("DefaultPunishParam", 0);

			ALLOW_DUALBOX = server.getProperty("AllowDualBox", true);
			ALLOWED_BOXES = server.getProperty("AllowedBoxes", 1);
			ALLOW_DUALBOX_OLY = server.getProperty("AllowDualBoxInOly", true);

			MULTIBOX_PROTECTION_ENABLED = server.getProperty("MultiboxProtectionEnabled", false); 
			MULTIBOX_PROTECTION_CLIENTS_PER_PC = server.getProperty("ClientsPerPc", 2); 
						MULTIBOX_PROTECTION_PUNISH = server.getProperty("MultiboxPunish", 2);
			MULTIBOX_PROTECTION_BYPASS_IPS = new ArrayList<>();
			for (String bypassIp : server.getProperty("MultiboxProtectionBypassIPs", "").split(","))
			{
				bypassIp = bypassIp.trim();
				if (!bypassIp.isEmpty())
					MULTIBOX_PROTECTION_BYPASS_IPS.add(bypassIp);
			}

			HWID_MULTIBOX_PROTECTION_ENABLED = server.getProperty("HwidMultiboxProtectionEnabled", false); 
			HWID_MULTIBOX_PROTECTION_CLIENTS_PER_PC = server.getProperty("HwidClientsPerPc", 2); 
			HWID_MULTIBOX_PROTECTION_PUNISH = server.getProperty("HwidMultiboxPunish", 2);

			MIN_PROTOCOL_REVISION = server.getProperty("MinProtocolRevision", 730);
			MAX_PROTOCOL_REVISION = server.getProperty("MaxProtocolRevision", 746);
			if (MIN_PROTOCOL_REVISION > MAX_PROTOCOL_REVISION)
				throw new Error("MinProtocolRevision is bigger than MaxProtocolRevision in server.properties.");

			AUTO_LOOT = server.getProperty("AutoLoot", false);
			AUTO_LOOT_CHAMPION = server.getProperty("AutoLootChampion", false);
			AUTO_LOOT_HERBS = server.getProperty("AutoLootHerbs", false);
			AUTO_LOOT_RAID = server.getProperty("AutoLootRaid", false);
			LAST_HIST_BOSS_LOOT = server.getProperty("LastHitBossLoot", true);

			ALLOW_DISCARDITEM = server.getProperty("AllowDiscardItem", true);
			MULTIPLE_ITEM_DROP = server.getProperty("MultipleItemDrop", true);
			ITEM_AUTO_DESTROY_TIME = server.getProperty("AutoDestroyItemTime", 0) * 1000;
			HERB_AUTO_DESTROY_TIME = server.getProperty("AutoDestroyHerbTime", 15) * 1000;

			PROTECTED_ITEMS = server.getProperty("ListOfProtectedItems");
			LIST_PROTECTED_ITEMS = new ArrayList<>();
			for (String id : PROTECTED_ITEMS.split(","))
				LIST_PROTECTED_ITEMS.add(Integer.parseInt(id));

			DESTROY_DROPPED_PLAYER_ITEM = server.getProperty("DestroyPlayerDroppedItem", false);
			DESTROY_EQUIPABLE_PLAYER_ITEM = server.getProperty("DestroyEquipableItem", false);
			SAVE_DROPPED_ITEM = server.getProperty("SaveDroppedItem", false);
			EMPTY_DROPPED_ITEM_TABLE_AFTER_LOAD = server.getProperty("EmptyDroppedItemTableAfterLoad", false);
			SAVE_DROPPED_ITEM_INTERVAL = server.getProperty("SaveDroppedItemInterval", 0) * 60000;
			CLEAR_DROPPED_ITEM_TABLE = server.getProperty("ClearDroppedItemTable", false);

			ALLOW_FREIGHT = server.getProperty("AllowFreight", true);
			ALLOW_WAREHOUSE = server.getProperty("AllowWarehouse", true);
			ALLOW_WEAR = server.getProperty("AllowWear", true);
			WEAR_DELAY = server.getProperty("WearDelay", 5);
			WEAR_PRICE = server.getProperty("WearPrice", 10);
			ALLOW_LOTTERY = server.getProperty("AllowLottery", true);
			ALLOW_RACE = server.getProperty("AllowRace", true);
			ALLOW_WATER = server.getProperty("AllowWater", true);
			ALLOWFISHING = server.getProperty("AllowFishing", false);
			ALLOW_MANOR = server.getProperty("AllowManor", true);
			ALLOW_BOAT = server.getProperty("AllowBoat", true);
			ALLOW_CURSED_WEAPONS = server.getProperty("AllowCursedWeapons", true);

			String str = server.getProperty("EnableFallingDamage", "auto");
			ENABLE_FALLING_DAMAGE = "auto".equalsIgnoreCase(str) ? GEODATA > 0 : Boolean.parseBoolean(str);

			ALT_DEV_NO_SCRIPTS = server.getProperty("NoScripts", false);
			ALT_DEV_NO_SPAWNS = server.getProperty("NoSpawns", false);
			DEBUG = server.getProperty("Debug", false);
			DEVELOPER = server.getProperty("Developer", false);
			PACKET_HANDLER_DEBUG = server.getProperty("PacketHandlerDebug", false);

			DEADLOCK_DETECTOR = server.getProperty("DeadLockDetector", false);
			DEADLOCK_CHECK_INTERVAL = server.getProperty("DeadLockCheckInterval", 20);
			RESTART_ON_DEADLOCK = server.getProperty("RestartOnDeadlock", false);

			LOG_CHAT = server.getProperty("LogChat", false);
			LOG_ITEMS = server.getProperty("LogItems", false);
			GMAUDIT = server.getProperty("GMAudit", false);

			ENABLE_COMMUNITY_BOARD = server.getProperty("EnableCommunityBoard", false);
			BBS_DEFAULT = server.getProperty("BBSDefault", "_bbshome");

			SCHEDULED_THREAD_POOL_COUNT = server.getProperty("ScheduledThreadPoolCount", -1);
			THREADS_PER_SCHEDULED_THREAD_POOL = server.getProperty("ThreadsPerScheduledThreadPool", 4);
			INSTANT_THREAD_POOL_COUNT = server.getProperty("InstantThreadPoolCount", -1);
			THREADS_PER_INSTANT_THREAD_POOL = server.getProperty("ThreadsPerInstantThreadPool", 2);

			L2WALKER_PROTECTION = server.getProperty("L2WalkerProtection", false);
			AUTODELETE_INVALID_QUEST_DATA = server.getProperty("AutoDeleteInvalidQuestData", false);
			GAMEGUARD_ENFORCE = server.getProperty("GameGuardEnforce", false);
			ZONE_TOWN = server.getProperty("ZoneTown", 0);
			SERVER_NEWS = server.getProperty("ShowServerNews", false);
			DISABLE_TUTORIAL = server.getProperty("DisableTutorial", false);
			LOAD_CUSTOM_MULTISELLS = server.getProperty("LoadCustomMultiSells", false);

			OPEN_DOORS_ACTIVE = Boolean.parseBoolean(server.getProperty("ActiveOpenDoors", "false"));
			String open_doors = server.getProperty("OpenDoors", "24190001,24190002,24190003,24190004");
			String[] open_doors_split = open_doors.split(",");
			for (String s : open_doors_split)
			{
				int i3 = Integer.parseInt(s);
				OPEN_DOORS.add(Integer.valueOf(i3));
			}

			// rates config
			ExProperties rates = load(RATES_FILE);

			RATE_XP = rates.getProperty("RateXp", 1.);
			RATE_SP = rates.getProperty("RateSp", 1.);
			RATE_PARTY_XP = rates.getProperty("RatePartyXp", 1.);
			RATE_PARTY_SP = rates.getProperty("RatePartySp", 1.);
			RATE_DROP_ADENA = rates.getProperty("RateDropAdena", 1.);
			RATE_CONSUMABLE_COST = rates.getProperty("RateConsumableCost", 1.);
			RATE_DROP_ITEMS = rates.getProperty("RateDropItems", 1.);
			RATE_DROP_SEAL_STONES = rates.getProperty("RateDropSealStones", 1.);
			RATE_DROP_ITEMS_BY_RAID = rates.getProperty("RateRaidDropItems", 1.);
			RATE_DROP_SPOIL = rates.getProperty("RateDropSpoil", 1.);
			RATE_DROP_MANOR = rates.getProperty("RateDropManor", 1);
			RATE_QUEST_DROP = rates.getProperty("RateQuestDrop", 1.);
			RATE_QUEST_REWARD = rates.getProperty("RateQuestReward", 1.);
			RATE_QUEST_REWARD_XP = rates.getProperty("RateQuestRewardXP", 1.);
			RATE_QUEST_REWARD_SP = rates.getProperty("RateQuestRewardSP", 1.);
			RATE_QUEST_REWARD_ADENA = rates.getProperty("RateQuestRewardAdena", 1.);
			RATE_KARMA_EXP_LOST = rates.getProperty("RateKarmaExpLost", 1.);
			RATE_SIEGE_GUARDS_PRICE = rates.getProperty("RateSiegeGuardsPrice", 1.);
			RATE_DROP_COMMON_HERBS = rates.getProperty("RateCommonHerbs", 1.);
			RATE_DROP_HP_HERBS = rates.getProperty("RateHpHerbs", 1.);
			RATE_DROP_MP_HERBS = rates.getProperty("RateMpHerbs", 1.);
			RATE_DROP_SPECIAL_HERBS = rates.getProperty("RateSpecialHerbs", 1.);
			PLAYER_DROP_LIMIT = rates.getProperty("PlayerDropLimit", 3);
			PLAYER_RATE_DROP = rates.getProperty("PlayerRateDrop", 5);
			PLAYER_RATE_DROP_ITEM = rates.getProperty("PlayerRateDropItem", 70);
			PLAYER_RATE_DROP_EQUIP = rates.getProperty("PlayerRateDropEquip", 25);
			PLAYER_RATE_DROP_EQUIP_WEAPON = rates.getProperty("PlayerRateDropEquipWeapon", 5);
			PET_XP_RATE = rates.getProperty("PetXpRate", 1.);
			PET_FOOD_RATE = rates.getProperty("PetFoodRate", 1);
			SINEATER_XP_RATE = rates.getProperty("SinEaterXpRate", 1.);
			KARMA_DROP_LIMIT = rates.getProperty("KarmaDropLimit", 10);
			KARMA_RATE_DROP = rates.getProperty("KarmaRateDrop", 70);
			KARMA_RATE_DROP_ITEM = rates.getProperty("KarmaRateDropItem", 50);
			KARMA_RATE_DROP_EQUIP = rates.getProperty("KarmaRateDropEquip", 40);
			KARMA_RATE_DROP_EQUIP_WEAPON = rates.getProperty("KarmaRateDropEquipWeapon", 10);
			KARMA_XP_DIVIDER = rates.getProperty("XPDivider", 260);
			KARMA_LOST_BASE = rates.getProperty("BaseKarmaLost", 0);

			AUGMENTATION_NG_SKILL_CHANCE = rates.getProperty("AugmentationNGSkillChance", 15);
			AUGMENTATION_NG_GLOW_CHANCE = rates.getProperty("AugmentationNGGlowChance", 0);
			AUGMENTATION_NG_BASESTAT_CHANCE = rates.getProperty("AugmentationNGBaseStatChance", 1);

			AUGMENTATION_MID_SKILL_CHANCE = rates.getProperty("AugmentationMidSkillChance", 30);
			AUGMENTATION_MID_GLOW_CHANCE = rates.getProperty("AugmentationMidGlowChance", 40);
			AUGMENTATION_MID_BASESTAT_CHANCE = rates.getProperty("AugmentationMidBaseStatChance", 1);

			AUGMENTATION_HIGH_SKILL_CHANCE = rates.getProperty("AugmentationHighSkillChance", 45);
			AUGMENTATION_HIGH_GLOW_CHANCE = rates.getProperty("AugmentationHighGlowChance", 70);
			AUGMENTATION_HIGH_BASESTAT_CHANCE = rates.getProperty("AugmentationHighBaseStatChance", 1);

			AUGMENTATION_TOP_SKILL_CHANCE = rates.getProperty("AugmentationTopSkillChance", 60);
			AUGMENTATION_TOP_GLOW_CHANCE = rates.getProperty("AugmentationTopGlowChance", 100);
			AUGMENTATION_TOP_BASESTAT_CHANCE = rates.getProperty("AugmentationTopBaseStatChance", 1);

			// Commands config
			ExProperties Commands = load(COMMAND_FILE);

			ALLOW_CMD_STATUS = Commands.getProperty("AllowStatusCommands", false);
			ALLOW_CMD_INVENTORY = Commands.getProperty("AllowinventoryCommands", false);
			ALLOW_CMD_SKILLS = Commands.getProperty("AllowSkillsCommands", false);
			ALLOW_CMD_PASSWORD = Commands.getProperty("AllowPasswordCommands", false);
			ALLOW_CMD_RANKING = Commands.getProperty("AllowRankingCommands", false);
			ALLOW_CMD_CASTLE = Commands.getProperty("AllowCastleCommands", false);
			ALLOW_CMD_PVP = Commands.getProperty("AllowPvpCommands", false);
			ALLOW_CMD_PK = Commands.getProperty("AllowPkCommands", false);
			ALLOW_CMD_CLAN = Commands.getProperty("AllowClanCommands", false);
			ALLOW_CMD_CLANPOINT = Commands.getProperty("AllowClanPointsCommands", false);
			ALLOW_CMD_1X1 = Commands.getProperty("Allow1x1Commands", false);
			ALLOW_CMD_3x3 = Commands.getProperty("Allow3x3Commands", false);
			ALLOW_CMD_5x5 = Commands.getProperty("Allow5x5Commands", false);
			ALLOW_CMD_9x9 = Commands.getProperty("Allow9x9Commands", false);
			ALLOW_CMD_ELOPOINT = Commands.getProperty("AllowEloPointCommands", false);
			ALLOW_CMD_ENCHANT = Commands.getProperty("AllowEnchantRankingCommands", false);

			ALLOW_MOD_MENU = Commands.getProperty("AllowMenu", false);
			ALLOW_COLOR_MANAGER = Commands.getProperty("AllowColor", false);
			RETAIL_EVENTS_STARTED = Commands.getProperty("AllowRetailEvents", false);
			BANKING_SYSTEM_GOLDBARS = Commands.getProperty("BankingGoldbarCount", 1);
			BANKING_SYSTEM_ADENA = Commands.getProperty("BankingAdenaCount", 500000000);
			ALLOW_DONATE_COMMANDS = Commands.getProperty("AllowDonate", false);

			ALLOW_EVENTTIME_COMMANDS = Commands.getProperty("AllowEventTimeCommands", false);
			ALLOW_INFO_COMMANDS = Commands.getProperty("AllowInfoCommands", false);

			PVP_POINT_ID = Commands.getProperty("ColorCoinID", 57);
			PVP_POINT_COUNT = Commands.getProperty("ColorCoinCount", 200);	


			// Boom Configs config
			ExProperties boomevent = load(BOOM_FILE);

			if (BOOM_REWARD_ITEM_ENABLED)
			{
				String[] propertySplitboom = boomevent.getProperty("Reward_Lvl_1", "57,0").split(";");
				LVL_1_REWARD.clear();
				for (String reward : propertySplitboom)
				{
					String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2) 
					{
						_log.warning("StartingCustomItemsMage[Config.load()]: invalid config property -> StartingCustomItemsMage \"" + reward + "\"");
					} 
					else 
					{
						try
						{
							LVL_1_REWARD.add(new int[]{Integer.parseInt(rewardSplit[0]),Integer.parseInt(rewardSplit[1])});
						}
						catch (NumberFormatException nfe)
						{
							if (!reward.isEmpty())
							{
								_log.warning("StartingCustomItemsMage[Config.load()]: invalid config property -> StartingCustomItemsMage \"" + reward + "\"");
							}
						}
					}
				}
				propertySplitboom = boomevent.getProperty("Reward_Lvl_2", "57,0").split(";");
				LVL_2_REWARD.clear();
				for (String reward : propertySplitboom)
				{
					String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2) 
					{
						_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
					} 
					else 
					{
						try
						{
							LVL_2_REWARD.add(new int[] { Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1]) });
						}
						catch (NumberFormatException nfe)
						{
							if (!reward.isEmpty()) 
							{
								_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
							}
						}
					}
				}
				propertySplitboom = boomevent.getProperty("Reward_Lvl_3", "57,0").split(";");
				LVL_3_REWARD.clear();
				for (String reward : propertySplitboom)
				{
					String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2) 
					{
						_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
					} 
					else 
					{
						try
						{
							LVL_3_REWARD.add(new int[] { Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1]) });
						}
						catch (NumberFormatException nfe)
						{
							if (!reward.isEmpty()) 
							{
								_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
							}
						}
					}
				}
				propertySplitboom = boomevent.getProperty("Reward_Lvl_4", "57,0").split(";");
				LVL_4_REWARD.clear();
				for (String reward : propertySplitboom)
				{
					String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2) 
					{
						_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
					}
					else 
					{
						try
						{
							LVL_4_REWARD.add(new int[] { Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1]) });
						}
						catch (NumberFormatException nfe)
						{
							if (!reward.isEmpty())
							{
								_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
							}
						}
					}
				}
				propertySplitboom = boomevent.getProperty("Reward_Lvl_5", "57,0").split(";");
				LVL_5_REWARD.clear();
				for (String reward : propertySplitboom)
				{
					String[] rewardSplit = reward.split(",");
					if (rewardSplit.length != 2)
					{
						_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
					}
					else 
					{
						try
						{
							LVL_5_REWARD.add(new int[] { Integer.parseInt(rewardSplit[0]), Integer.parseInt(rewardSplit[1]) });
						}
						catch (NumberFormatException nfe)
						{
							if (!reward.isEmpty())
							{
								_log.warning("StartingCustomItemsFighter[Config.load()]: invalid config property -> StartingCustomItemsFighter \"" + reward + "\"");
							}
						}
					}
				}
			}

			// L2Jmods config
			ExProperties l2jmod = load(L2JMOD_FILE);
			ENABLE_TREASURE_HUNT = l2jmod.getProperty("EnableTreasureHunt", false);
			TREASURE_HUNT_INTERVAL = Math.max(1, l2jmod.getProperty("TreasureHuntInterval", 1800));
			TREASURE_HUNT_AUTO_LOOT = l2jmod.getProperty("AllowTreasureHuntAutoLoot", true);
			TREASURE_HUNT_TEST_MODE = l2jmod.getProperty("TreasureHuntTestMode", false);
			TREASURE_HUNT_TEST_X = l2jmod.getProperty("TreasureHuntTestX", 147256);
			TREASURE_HUNT_TEST_Y = l2jmod.getProperty("TreasureHuntTestY", -90488);
			TREASURE_HUNT_TEST_Z = l2jmod.getProperty("TreasureHuntTestZ", -4367);
			
			FREE_MULTISELL = Boolean.parseBoolean(l2jmod.getProperty("FreeMultiSell", "False"));
			RESTART_BY_TIME_OF_DAY = Boolean.parseBoolean(l2jmod.getProperty("EnableRestartSystem", "false"));
			RESTART_SECONDS = Integer.parseInt(l2jmod.getProperty("RestartSeconds", "360"));
			RESTART_INTERVAL_BY_TIME_OF_DAY = l2jmod.getProperty("RestartByTimeOfDay", "20:00").split(",");

			LOG_DONATE_COIN_ID = l2jmod.getProperty("LogDonateCoinID", 57);
			PVPKILL_IN_EVENTS = Boolean.parseBoolean(l2jmod.getProperty("PvPKillInEvents", "False"));
			SECONDARYPASS = Boolean.parseBoolean(l2jmod.getProperty("SecondaryPass", "False"));
			USE_NEW_AUTO_FARM = Boolean.parseBoolean(l2jmod.getProperty("UseNewAutoFarm", "False"));

			MSU_LIST_FOR_HIDE = new ArrayList<>();
			String[] skillList = l2jmod.getProperty("MSUListForHide", "1015,1218").split(",");
			for (String skill : skillList)
			{
				if (skill != null && !skill.isEmpty())
					MSU_LIST_FOR_HIDE.add(Integer.valueOf(Integer.parseInt(skill))); 
			}

			final String[] itemSkill = l2jmod.getProperty("ListOfRuneItems", "").split(";");
			LIST_RUNE_ITEMS = new HashMap<>(itemSkill.length);
			for (String prop : itemSkill)
			{
				String[] propSplit = prop.split(",");
				if (propSplit.length != 2)
				{
					_log.warning(StringUtil.concat("[ListOfRuneItems]: invalid config property -> ListOfRuneItems \"", prop, "\""));
				}

				try
				{
					LIST_RUNE_ITEMS.put(Integer.valueOf(propSplit[0]), Integer.valueOf(propSplit[1]));
				}
				catch (NumberFormatException nfe)
				{
					if (!prop.isEmpty())
					{
						_log.warning(StringUtil.concat("[ListOfRuneItems]: invalid config property -> ListOfRuneItems \"", propSplit[0], "\"", propSplit[1]));
					}
				}
			}

			ALLOW_WORK_DAY = Boolean.parseBoolean(l2jmod.getProperty("AllowWorkDay", "false"));
			ANNOUNCE_WORK_DAY = l2jmod.getProperty("AnnounceWorkDay", "Workday:");
			WORK_TIME = l2jmod.getProperty("ServerWorkNewDayTime", "20:00").split(",");

			TELEPORT_EFFECT = Boolean.parseBoolean(l2jmod.getProperty("EnableTeleportEffect", "True"));
			ID_ESCAPE_SKILL = l2jmod.getProperty("TeleportEffectSkill", 2036);

			ALL_ITEMS_SELL_ZERO_ADENA = l2jmod.getProperty("SellItemsZeroAdena", false);
			INFINITY_SS = l2jmod.getProperty("InfinitySS", false);
			INFINITY_ARROWS = l2jmod.getProperty("InfinityArrows", false);



			WEAPONS_ENCHANT_LIST_ID = l2jmod.getProperty("WeaponsRankingEnchant");
			WEAPONS_ENCHANT_LIST = new ArrayList<>();
			for (String id : WEAPONS_ENCHANT_LIST_ID.split(","))
				WEAPONS_ENCHANT_LIST.add(Integer.parseInt(id));

			DONATE_COIN_ID = l2jmod.getProperty("DonateColorCoinID", 57);
			DONATE_COIN_COUNT = l2jmod.getProperty("DonateColorCoinCount", 200);
			ALLOW_WELCOME_TO_LINEAGE = l2jmod.getProperty("AllowWelcome", false);
			ALT_GIVE_PVP_IN_ARENA = l2jmod.getProperty("AltGivePvpInArena", false);
			SHOW_HP_PVP = l2jmod.getProperty("ShowHpPvP", false);


			TIME_TELEPORTER_ENABLE = l2jmod.getProperty("TimeTeleporter", false);
			if (TIME_TELEPORTER_ENABLE)
			{
				TIME_TELEPORTERS = new ArrayList<>();
				for (String type : l2jmod.getProperty("TimeTeleportersId", "10001").split(","))
				{
					TIME_TELEPORTERS.add(Integer.valueOf(type));
				}
			}

			VOTE_FOR_PVPZONE = l2jmod.getProperty("VoteForNextPvpZone", false);

			NO_CARRIER_SYSTEM_ENABLED = l2jmod.getProperty("NoCarrierSystemEnabled", true);
			NO_CARRIER_TITLE =  l2jmod.getProperty("NoCarrierTitle", "Disconnected");
			NO_CARRIER_SYSTEM_TIMER = l2jmod.getProperty("NoCarrierTimer", 10);

			OFFLINE_TRADE_ENABLE = l2jmod.getProperty("OfflineTradeEnable", false);
			OFFLINE_CRAFT_ENABLE = l2jmod.getProperty("OfflineCraftEnable", false);
			RESTORE_OFFLINERS = l2jmod.getProperty("RestoreOffliners", false);
			OFFLINE_MAX_DAYS = l2jmod.getProperty("OfflineMaxDays", 10);
			OFFLINE_DISCONNECT_FINISHED = l2jmod.getProperty("OfflineDisconnectFinished", true);
			OFFLINE_MODE_IN_PEACE_ZONE = l2jmod.getProperty("OfflineModeInPeaceZone", false);
			OFFLINE_MODE_NO_DAMAGE = l2jmod.getProperty("OfflineModeNoDamage", false);
			OFFLINE_LOGOUT = l2jmod.getProperty("OfflineLogout", false);
			OFFLINE_SLEEP_EFFECT = l2jmod.getProperty("OfflineSleepEffect", true);

			ENABLE_AIO_SYSTEM = l2jmod.getProperty("EnableAioSystem", true);
			ALLOW_AIO_NCOLOR = l2jmod.getProperty("AllowAioNameColor", true);
			AIO_NCOLOR = Integer.decode(StringUtil.concat("0x" + l2jmod.getProperty("AioNameColor", "88AA88")));
			ALLOW_AIO_TCOLOR = l2jmod.getProperty("AllowAioTitleColor", true);
			AIO_TCOLOR = Integer.decode(StringUtil.concat("0x" + l2jmod.getProperty("AioTitleColor", "88AA88")));
			ALLOW_AIO_ITEM = l2jmod.getProperty("AllowAIOItem", false);
			AIO_ITEMID = l2jmod.getProperty("ItemIdAio", 0);

			if(ENABLE_AIO_SYSTEM)
			{
				String[] AioSkillsSplit = l2jmod.getProperty("AioSkills", "").split(";");
				AIO_SKILLS = new HashMap<>(AioSkillsSplit.length);
				for (String skill : AioSkillsSplit)
				{
					String[] skillSplit = skill.split(",");
					if (skillSplit.length != 2)
						System.out.println("[Aio System]: invalid config property in players.properties -> AioSkills \"" + skill + "\"");
					else
					{
						try
						{
							AIO_SKILLS.put(Integer.parseInt(skillSplit[0]), Integer.parseInt(skillSplit[1]));
						}
						catch (NumberFormatException nfe)
						{
							if (!skill.equals(""))
								System.out.println("[Aio System]: invalid config property in players.props -> AioSkills \"" + skillSplit[0] + "\"" + skillSplit[1]);
						}
					}
				}
			}

			LEAVE_BUFFS_ON_DIE = l2jmod.getProperty("LoseBuffsOnDeath", false);
			CHAOTIC_LEAVE_BUFFS_ON_DIE = l2jmod.getProperty("ChaoticLoseBuffsOnDeath", false);

			FORBIDDEN_NAMES = l2jmod.getProperty("ForbiddenNames", "").split(",");


			PRIVATE_STORE_NEED_PVPS = l2jmod.getProperty("AllowPvPToUseStore", false);
			MIN_PVP_TO_USE_STORE = l2jmod.getProperty("PvPToUseStore", 0);

			PRIVATE_STORE_NEED_LEVELS = l2jmod.getProperty("AllowLevelToUseStore", false);
			MIN_LEVEL_TO_USE_STORE = l2jmod.getProperty("LevelToUseStore", 0);

			EXPERTISE_PENALTY = l2jmod.getProperty("ExpertisePenality", false);

			ALLOW_HERO_SUBSKILL = l2jmod.getProperty("CustomHeroSubSkill", false);
			HERO_COUNT = l2jmod.getProperty("HeroCount", 1);

			ALT_RESTORE_EFFECTS_ON_SUBCLASS_CHANGE = l2jmod.getProperty("AltRestoreEffectOnSub", false);

			CHECK_HERO_SKILLS = l2jmod.getProperty("CheckHeroSkills", true);

			TRADE_HISTORY_ENABLED = l2jmod.getProperty("TradeHistoryEnabled", false);
			TRADE_HISTORY_PAGE_LIMIT = l2jmod.getProperty("TradeHistoryPageLimit", 20);

			PREMIUM_SERVICES_ENABLED = l2jmod.getProperty("PremiumServicesEnabled", false);
			PREMIUM_SUB_DOMINATOR_ENABLED = l2jmod.getProperty("PremiumSubDominatorEnabled", false);
			PREMIUM_SUB_DOMINATOR_CLASS_ID = l2jmod.getProperty("PremiumSubDominatorClassId", 115);
			PREMIUM_SUB_DOMINATOR_MAX_SUBS = l2jmod.getProperty("PremiumSubDominatorMaxSubs", 6);
			PREMIUM_SUB_DOMINATOR_ITEM_ID = l2jmod.getProperty("PremiumSubDominatorItemId", 57);
			PREMIUM_SUB_DOMINATOR_ITEM_COUNT = l2jmod.getProperty("PremiumSubDominatorItemCount", 100000000);
			PREMIUM_AUGMENT_TRANSFER_ENABLED = l2jmod.getProperty("PremiumAugmentTransferEnabled", false);
			PREMIUM_AUGMENT_TRANSFER_ITEM_ID = l2jmod.getProperty("PremiumAugmentTransferItemId", 57);
			PREMIUM_AUGMENT_TRANSFER_ITEM_COUNT = l2jmod.getProperty("PremiumAugmentTransferItemCount", 100000000);
			PREMIUM_ENCHANT_TRANSFER_ENABLED = l2jmod.getProperty("PremiumEnchantTransferEnabled", false);
			PREMIUM_ENCHANT_TRANSFER_ITEM_ID = l2jmod.getProperty("PremiumEnchantTransferItemId", 57);
			PREMIUM_ENCHANT_TRANSFER_ITEM_COUNT = l2jmod.getProperty("PremiumEnchantTransferItemCount", 100000000);
			PREMIUM_ENCHANT_TRANSFER_ALLOW_WEAPONS = l2jmod.getProperty("PremiumEnchantTransferAllowWeapons", true);
			PREMIUM_ENCHANT_TRANSFER_ALLOW_ARMORS = l2jmod.getProperty("PremiumEnchantTransferAllowArmors", true);
			PREMIUM_ENCHANT_TRANSFER_ALLOW_JEWELS = l2jmod.getProperty("PremiumEnchantTransferAllowJewels", true);
			PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_TYPE = l2jmod.getProperty("PremiumEnchantTransferRequireSameType", true);
			PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_SLOT = l2jmod.getProperty("PremiumEnchantTransferRequireSameSlot", true);
			PREMIUM_ENCHANT_TRANSFER_TARGET_MUST_BE_ZERO = l2jmod.getProperty("PremiumEnchantTransferTargetMustBeZero", true);
			PREMIUM_SKILL_ENCHANT_ENABLED = l2jmod.getProperty("PremiumSkillEnchantEnabled", false);
			PREMIUM_SKILL_ENCHANT_MAX = l2jmod.getProperty("PremiumSkillEnchantMax", 12);
			PREMIUM_SKILL_ENCHANT_MIN_LEVEL = l2jmod.getProperty("PremiumSkillEnchantMinLevel", 76);
			PREMIUM_SKILL_ENCHANT_ITEM_ID = l2jmod.getProperty("PremiumSkillEnchantItemId", 57);
			PREMIUM_SKILL_ENCHANT_ITEM_COUNT = l2jmod.getProperty("PremiumSkillEnchantItemCount", 100000000);
			PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL = l2jmod.getProperty("PremiumSkillEnchantPricePerLevel", true);

			CHECK_NOBLE_SKILLS = l2jmod.getProperty("CheckNobleSkills", true);
			CHECK_SKILLS_ON_ENTER = l2jmod.getProperty("CheckSkillsOnEnter", false);
			ALLOWED_SKILLS = l2jmod.getProperty("AllowedSkills", "541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,617,618,619");
			ALLOWED_SKILLS_LIST = new ArrayList<>();
			for(String id : ALLOWED_SKILLS.trim().split(","))
				ALLOWED_SKILLS_LIST.add(Integer.parseInt(id.trim()));

			DISABLE_ATTACK_NPC_TYPE = l2jmod.getProperty("DisableAttackToNpcs", false);
			ALLOWED_NPC_TYPES = l2jmod.getProperty("AllowedNPCTypes");
			LIST_ALLOWED_NPC_TYPES = new ArrayList<>();
			for (String npc_type : ALLOWED_NPC_TYPES.split(","))
				LIST_ALLOWED_NPC_TYPES.add(npc_type);

			ALLOW_PVP_REWARD = l2jmod.getProperty("PvpRewardEnabled", false);
			ALLOW_FARM_ZONE_PVP_REWARD = l2jmod.getProperty("AllowFarmZonePvpReward", false);
			PVP_REWARDS = parseReward(l2jmod, "PvpRewardItems");

			ANTI_FARM_ENABLED = l2jmod.getProperty("AntiFarmEnabled", false);
			ANTI_FARM_CLAN_ALLY_ENABLED = l2jmod.getProperty("AntiFarmClanAlly", false);
			ANTI_FARM_LVL_DIFF_ENABLED = l2jmod.getProperty("AntiFarmLvlDiff", false);
			ANTI_FARM_MAX_LVL_DIFF = l2jmod.getProperty("AntiFarmMaxLvlDiff", 40);
			ANTI_FARM_PARTY_ENABLED = l2jmod.getProperty("AntiFarmParty", false);
			ANTI_FARM_IP_ENABLED = l2jmod.getProperty("AntiFarmIP", false);   

			FARM_PROTECT = l2jmod.getProperty("FarmProtectByHwid", false);
			FARM_PROTECT_RADIUS = l2jmod.getProperty("FarmProtectRadius", false);

			SUMMON_MOUNT_PROTECTION = l2jmod.getProperty("SummonRestriction", false);
			ID_RESTRICT = l2jmod.getProperty("SummonItemID");
			LISTID_RESTRICT = new ArrayList<>();
			for(String id : ID_RESTRICT.split(","))
				LISTID_RESTRICT.add(Integer.parseInt(id));

			DELETE_AUGM_PASSIVE_ON_CHANGE = l2jmod.getProperty("DeleteAgmentPassiveEffectOnChangeWep", true);
			DELETE_AUGM_ACTIVE_ON_CHANGE = l2jmod.getProperty("DeleteAgmentActiveEffectOnChangeWep", true);
			AUG_ITEM_DROP = l2jmod.getProperty("AugmentedWeaponDropable", false);
			AUG_ITEM_TRADE = l2jmod.getProperty("AugmentedTradeDropable", false);
			AUG_ITEM_SELL = l2jmod.getProperty("AugmentedSellDropable", false);

			ALLOW_DAILY_REWARD = l2jmod.getProperty("AllowDailyReward", true);
			DAILY_LOG_REWARDS = parseReward(l2jmod, "DailyReward");
			DAILY_REWARDS_DELETE_TIME = l2jmod.getProperty("DailyRewardDeleteTime", 5);

			DAILY_REWARD_RESET_TIME = l2jmod.getProperty("DailyRewardResetTime", "20:00").split(",");

			DONATESYSTEM = l2jmod.getProperty("DonateSystem", false);
			DONATE_HTML = l2jmod.getProperty("Donate_Html", false);

			MAX_HEALER_ON_PARTY = l2jmod.getProperty("MaxHealerByParty", 1);
			MAX_WL_ON_PARTY = l2jmod.getProperty("MaxWlByParty", 1);
			MAX_OVER_ON_PARTY = l2jmod.getProperty("MaxOverByParty", 1);

			SHOW_FAKE_ARMOR = l2jmod.getProperty("ShowFakeArmorOnSelectionScreen", false);
			FAKE_OFFLINE = l2jmod.getProperty("EnableFakeOffline", false);
			NO_LOOT_PROTECTION_BOSSID = l2jmod.getProperty("NoLootProtectionBossId", 1);

			PROTECT_WEAPONS = l2jmod.getProperty("ProtectWeaponsList", "0");
			PROTECT_WEAPONS_LIST = new ArrayList<>();
			for (String id : PROTECT_WEAPONS.trim().split(","))
			{
				PROTECT_WEAPONS_LIST.add(Integer.parseInt(id.trim()));
			}

			DAILY_ON_ENTER = l2jmod.getProperty("DailyRewardOnEnter", true);
			DAILY_COMMANDS_ENTER = l2jmod.getProperty("DailyRewardCommands", true);


			//Agathions system
			ExProperties agathions = load(AGATHION_FILE);
			AGATHIONS_ENABLED = agathions.getProperty("AgathionsEnabled", false);
			String[] agathionsList = agathions.getProperty("AgathionsList", "").split(",");
			AGATHIONS_LIST_ID = new int[agathionsList.length];
			for (int i = 0; i < agathionsList.length; i++)
			{
				AGATHIONS_LIST_ID[i] = Integer.parseInt(agathionsList[i]);
			}
			Arrays.sort(AGATHIONS_LIST_ID);
			AGATHIONS_RESHP_ENABLED = agathions.getProperty("AgathionsResHpEnabled", false);
			final String[] restoreHp = agathions.getProperty("AgathionsRestoreHp", "").split(";");
			AGATHIONS_RESTORE_HP = new HashMap<>(restoreHp.length);
			for (String prop : restoreHp)
			{
				String[] propSplit = prop.split(",");
				if (propSplit.length != 2)
				{
					_log.warning(StringUtil.concat("[AgathionsRestoreHp]: invalid config property -> AgathionsRestoreHp \"", prop, "\""));
				}

				try
				{
					AGATHIONS_RESTORE_HP.put(Integer.valueOf(propSplit[0]), Integer.valueOf(propSplit[1]));
				}
				catch (NumberFormatException nfe)
				{
					if (!prop.isEmpty())
					{
						_log.warning(StringUtil.concat("[AgathionsRestoreHp]: invalid config property -> AgathionsRestoreHp \"", propSplit[0], "\"", propSplit[1]));
					}
				}
			}
			AGATHIONS_RES_HP_INTERVAL = agathions.getProperty("AgathionsResHpInterval", 5000);
			AGATHIONS_RESMP_ENABLED = agathions.getProperty("AgathionsResMpEnabled", false);
			final String[] restoreMp = agathions.getProperty("AgathionsRestoreMp", "").split(";");
			AGATHIONS_RESTORE_MP = new HashMap<>(restoreMp.length);
			for (String prop : restoreMp)
			{
				String[] propSplit = prop.split(",");
				if (propSplit.length != 2)
				{
					_log.warning(StringUtil.concat("[AgathionsRestoreMp]: invalid config property -> AgathionsRestoreMp \"", prop, "\""));
				}

				try
				{
					AGATHIONS_RESTORE_MP.put(Integer.valueOf(propSplit[0]), Integer.valueOf(propSplit[1]));
				}
				catch (NumberFormatException nfe)
				{
					if (!prop.isEmpty())
					{
						_log.warning(StringUtil.concat("[AgathionsRestoreMp]: invalid config property -> AgathionsRestoreMp \"", propSplit[0], "\"", propSplit[1]));
					}
				}
			}
			AGATHIONS_RES_MP_INTERVAL = agathions.getProperty("AgathionsResMpInterval", 5000);
			AGATHIONS_RESCP_ENABLED = agathions.getProperty("AgathionsResCpEnabled", false);
			final String[] restoreCp = agathions.getProperty("AgathionsRestoreCp", "").split(";");
			AGATHIONS_RESTORE_CP = new HashMap<>(restoreCp.length);
			for (String prop : restoreCp)
			{
				String[] propSplit = prop.split(",");
				if (propSplit.length != 2)
				{
					_log.warning(StringUtil.concat("[AgathionsRestoreCp]: invalid config property -> AgathionsRestoreCp \"", prop, "\""));
				}

				try
				{
					AGATHIONS_RESTORE_CP.put(Integer.valueOf(propSplit[0]), Integer.valueOf(propSplit[1]));
				}
				catch (NumberFormatException nfe)
				{
					if (!prop.isEmpty())
					{
						_log.warning(StringUtil.concat("[AgathionsRestoreCp]: invalid config property -> AgathionsRestoreCp \"", propSplit[0], "\"", propSplit[1]));
					}
				}
			}
			AGATHIONS_RES_CP_INTERVAL = agathions.getProperty("AgathionsResCpInterval", 5000);
			AGATHIONS_USESKILL_ENABLED = agathions.getProperty("AgathionsUseSkillEnabled", false);
			final String[] useSkill = agathions.getProperty("AgathionsUseSkill", "").split(";");
			AGATHIONS_USE_SKILL = new HashMap<>(useSkill.length);
			for (String prop : useSkill)
			{
				String[] propSplit = prop.split(",");
				if (propSplit.length != 2)
				{
					_log.warning(StringUtil.concat("[AgathionsUseSkill]: invalid config property -> AgathionsUseSkill \"", prop, "\""));
				}

				try
				{
					AGATHIONS_USE_SKILL.put(Integer.valueOf(propSplit[0]), Integer.valueOf(propSplit[1]));
				}
				catch (NumberFormatException nfe)
				{
					if (!prop.isEmpty())
					{
						_log.warning(StringUtil.concat("[AgathionsUseSkill]: invalid config property -> AgathionsUseSkill \"", propSplit[0], "\"", propSplit[1]));
					}
				}
			}
			AGATHIONS_USE_SKILL_INTERVAL = agathions.getProperty("AgathionsUseSkillInterval", 3000);

			AGATHIONS_STOP_SKILL_ENABLED = agathions.getProperty("AgathionsStopSkillEnabled", false);
			for (String id : agathions.getProperty("AgathionsStopSkillList", "0").split(","))
				AGATHIONS_STOP_SKILL_LIST.add(Integer.parseInt(id));

			// L2Jmods config
			ExProperties Vip = load(VIP_FILE);

			DROP_ITEM_VIP = Vip.getProperty("ListDropVIPItens", "");
			DROP_LIST_VIP = new ArrayList<>();
			for (String itemId : DROP_ITEM_VIP.split(","))
				DROP_LIST_VIP.add(Integer.parseInt(itemId));

			ENABLE_VIP_SYSTEM = Vip.getProperty("EnableVipSystem", false);
			ALLOW_VIP_NCOLOR =Vip.getProperty("AllowVipNameColor", false);
			VIP_NCOLOR = Integer.decode("0x" + Vip.getProperty("VipNameColor", "88AA88"));
			ALLOW_VIP_TCOLOR = Vip.getProperty("AllowVipTitleColor", false);
			VIP_TCOLOR = Integer.decode("0x" + Vip.getProperty("VipTitleColor", "88AA88"));
			VIP_XP_SP_RATE = Vip.getProperty("VIPXpSpRate", 1.);
			VIP_ADENA_RATE = Vip.getProperty("VIPAdenaRate", 1.);
			VIP_SPOIL_RATE = Vip.getProperty("VIPSpoilRate", 1.);
			VIP_DROP_RATE = Vip.getProperty("VIPDropRate", 1);

			VIP_ITEMID = Vip.getProperty("ItemIdVip", 0);
			ALLOW_VIP_ITEM = Vip.getProperty("AllowVIPItem", false);
			VIP_EFFECT = Vip.getProperty("VipEffect", false);
			ALLOW_SKIN_SYSTEM = Vip.getProperty("AllowSkinCommands", false);

			if(ENABLE_VIP_SYSTEM) //create map if system is enabled
			{
				String[] VipSkillsSplit = Vip.getProperty("VipSkills", "").split(";");
				VIP_SKILLS = new HashMap<>(VipSkillsSplit.length);
				for (String skill : VipSkillsSplit)
				{
					String[] skillSplit = skill.split(",");
					if (skillSplit.length != 2)
					{
						System.out.println("[VIP System]: invalid config property in l2jmods.properties -> VipSkills \"" + skill + "\"");
					}
					else
					{
						try
						{
							VIP_SKILLS.put(Integer.parseInt(skillSplit[0]), Integer.parseInt(skillSplit[1]));
						}
						catch (NumberFormatException nfe)
						{
							if (!skill.equals(""))
							{
								System.out.println("[VIP System]: invalid config property in l2jmod.props -> VipSkills \"" + skillSplit[0] + "\"" + skillSplit[1]);
							}
						}
					}
				}
			}

			// PcBang config
			ExProperties PcBang = load(PCBANG_FILE);
			PCB_ENABLE = PcBang.getProperty("PcBangPointEnable", false);
			PCB_MIN_LEVEL = PcBang.getProperty("PcBangPointMinLevel", 20);
			PCB_POINT_MIN = PcBang.getProperty("PcBangPointMinCount", 20);
			PCB_POINT_MAX = PcBang.getProperty("PcBangPointMaxCount", 1000000);

			if (PCB_POINT_MAX < 1)
				PCB_POINT_MAX = Integer.MAX_VALUE;

			PCB_CHANCE_DUAL_POINT = PcBang.getProperty("PcBangPointDualChance", 20);
			PCB_INTERVAL = PcBang.getProperty("PcBangPointTimeStamp", 900);

			// PartyZone config
			ExProperties partyzone = load(PARTYZONE_FILE);

			ENTER_PARTYZONE = partyzone.getProperty("OnEnterNoEvent", false);
			ANNOUNCE_ID_EVENT = Integer.parseInt(partyzone.getProperty("AnnounceIdEvents", "3"));
			NAME_EVENT = partyzone.getProperty("NamePartyZone", "PartyZone:");
			PARTY_ZONE_REWARDS = parseReward(partyzone, "PartyZoneReward_event_time");
			RADIUS_TO_PARTYZONE = Integer.parseInt(partyzone.getProperty("RadiusToPartyZone", "1000"));
			START_PARTY = Boolean.parseBoolean(partyzone.getProperty("StartSpawnPartyZone", "false"));
			START_AUTO_PARTY = Boolean.parseBoolean(partyzone.getProperty("StartAutoPartyZone", "false"));
			PARTYZONE_TIME = Integer.parseInt(partyzone.getProperty("PartyZoneEventTime", "1"));
			PARTYZONE_INTERVAL_BY_TIME_OF_DAY = partyzone.getProperty("PartyZoneStartTime", "20:00").split(",");
			PARTY_FARM_MONSTER_DALAY = Integer.parseInt(partyzone.getProperty("MonsterDelay", "10"));
			String[] monsterLocs2 = partyzone.getProperty("MonsterLoc", "").split(";");
			String[] locSplit3 = null;
			monsterId = Integer.parseInt(partyzone.getProperty("MonsterId", "1"));
			MONSTER_LOCS_COUNT = monsterLocs2.length;
			MONSTER_LOCS = new int[MONSTER_LOCS_COUNT][3];
			for (int i = 0; i < MONSTER_LOCS_COUNT; i++)
			{
				locSplit3 = monsterLocs2[i].split(",");
				for (int j = 0; j < 3; j++)
				{
					MONSTER_LOCS[i][j] = Integer.parseInt(locSplit3[j].trim());
				}
			}
			// ----------------------------------------------------
			// Leitura do RaidBoss do PartyZone
			// ----------------------------------------------------
			PARTY_FARM_RAID_ENABLED = Boolean.parseBoolean(partyzone.getProperty("PartyFarmRaidEnabled", "true"));
			PARTY_FARM_RAID_ID = Integer.parseInt(partyzone.getProperty("PartyFarmRaidId", "0"));

			String[] raidLoc = partyzone.getProperty("PartyFarmRaidLoc", "0,0,0").split(",");
			try
			{
				PARTY_FARM_RAID_LOC[0] = Integer.parseInt(raidLoc[0].trim());
				PARTY_FARM_RAID_LOC[1] = Integer.parseInt(raidLoc[1].trim());
				PARTY_FARM_RAID_LOC[2] = Integer.parseInt(raidLoc[2].trim());
			}
			catch (Exception e)
			{
				// Fallback em caso de erro na coordenada
				PARTY_FARM_RAID_LOC[0] = 0;
				PARTY_FARM_RAID_LOC[1] = 0;
				PARTY_FARM_RAID_LOC[2] = 0;
			}
			
			// Tyrannosaurus config
			ExProperties LS = load(LS_FILE);

			ENTER_LS = LS.getProperty("OnEnterNoEvent", false);
			LS_ANNOUNCE_ID_EVENT = Integer.parseInt(LS.getProperty("AnnounceIdEvents", "3"));
			LS_NAME_EVENT = LS.getProperty("NameTyrannosaurusZone", "TyrannosaurusZone:");
			LS_ZONE_REWARDS = parseReward(LS, "TyrannosaurusReward_event_time");
			RADIUS_TO_LS = Integer.parseInt(LS.getProperty("RadiusToTyrannosaurusZone", "1000"));
			START_LS = Boolean.parseBoolean(LS.getProperty("StartSpawnTyrannosaurus", "false"));
			START_AUTO_LS = Boolean.parseBoolean(LS.getProperty("StartAutoTyrannosaurusZone", "false"));
			LS_TIME = Integer.parseInt(LS.getProperty("TyrannosaurusZoneEventTime", "1"));
			LS_INTERVAL_BY_TIME_OF_DAY = LS.getProperty("TyrannosaurusZoneStartTime", "20:00").split(",");
			LS_MONSTER_DALAY = Integer.parseInt(LS.getProperty("TyrannosaurusDelay", "10"));
			String[] LSmonsterLocs2 = LS.getProperty("LS_MonsterLoc", "").split(";");
			String[] LSlocSplit3 = null;
			LS_monsterId = Integer.parseInt(LS.getProperty("LS_MonsterId", "1"));
			LS_MONSTER_LOCS_COUNT = LSmonsterLocs2.length;
			LS_MONSTER_LOCS = new int[LS_MONSTER_LOCS_COUNT][3];
			for (int i = 0; i < LS_MONSTER_LOCS_COUNT; i++)
			{
				LSlocSplit3 = LSmonsterLocs2[i].split(",");
				for (int j = 0; j < 3; j++)
				{
					LS_MONSTER_LOCS[i][j] = Integer.parseInt(LSlocSplit3[j].trim());
				}
			}
			
		    ExProperties auctionShop = load("./config/custom/AuctionShop.properties");

		    TIME_SCREEN_SHOW = Integer.parseInt(auctionShop.getProperty("TimeScreenExshow", "10"));

		    NAME_MARKET_1 = auctionShop.getProperty("CoinNameOne", "");
		    ID_MARKET_1 = auctionShop.getProperty("CoinOneID", 57);
		    IMG_MARKET_1 = auctionShop.getProperty("ImgCoinOne", "");

		    ENABLE_AUCTION_SHOP = auctionShop.getProperty("EnableAuctionShop", false);
		    ENABLE_GRADE_ITEMS_SPAWNSHOP = auctionShop.getProperty("EnableGradeItems", false);

		    GRADE_ITEMS_PAWNSHOP.clear();

		    for (String list : auctionShop.getProperty("GradeItemsPawnShop", "A;S").split(";"))
		    {
		        try
		        {
		            GRADE_ITEMS_PAWNSHOP.add(CrystalType.valueOf(list.trim()));
		        }
		        catch (Exception e)
		        {
		            _log.warning("Invalid GradeItemsPawnShop value: " + list);
		        }
		    }

		    ITEMS_NO_RULES_PAWNSHOP_ID = auctionShop.getProperty("ItemNoBlockPawnShop", "0,0");

		    ITEMS_NO_RULES_PAWNSHOP = new ArrayList<>();

		    for (String val : ITEMS_NO_RULES_PAWNSHOP_ID.split(","))
		    {
		        try
		        {
		            ITEMS_NO_RULES_PAWNSHOP.add(Integer.valueOf(Integer.parseInt(val.trim())));
		        }
		        catch (NumberFormatException e)
		        {
		            _log.warning("Invalid ItemNoBlockPawnShop ID: " + val);
		        }
		    }

		    ALLOW_CBB_MARKETPLACE = auctionShop.getProperty("AllowCBBMarketPlace", false);

		    String[] properSplit = auctionShop.getProperty("CBBMarketPlaceFee", "0,0").split(",");

		    try
		    {
		        MARKETPLACE_FEE[0] = Integer.parseInt(properSplit[0].trim());
		        MARKETPLACE_FEE[1] = Integer.parseInt(properSplit[1].trim());
		    }
		    catch (Exception e)
		    {
		        _log.warning("Invalid config property -> CBBMarketPlaceFee");
		    }

		    MARKETPLACE_ALLOW_AUGMENTED_SALES =
		        auctionShop.getProperty("MarketplaceAllowAugmentedSales", false);

		    _log.info("AuctionShop config reloaded. CoinOneID: " + ID_MARKET_1);

			// L2jEvents config
			ExProperties l2jevent = load(L2JEVENT_FILE);

			CKM_ENABLED = l2jevent.getProperty("CKMEnabled", false);
			CKM_CYCLE_LENGTH = l2jevent.getProperty("CKMCycleLength", 86400000);
			CKM_PVP_NPC_TITLE = l2jevent.getProperty("CKMPvPNpcTitle", "%kills% PvPs in the last 24h");
			CKM_PVP_NPC_TITLE_COLOR = Integer.decode(StringUtil.concat("0x", l2jevent.getProperty("CKMPvPNpcTitleColor", "00CCFF")));
			CKM_PVP_NPC_NAME_COLOR = Integer.decode(StringUtil.concat("0x", l2jevent.getProperty("CKMPvPNpcNameColor", "FFFFFF")));
			CKM_PK_NPC_TITLE = l2jevent.getProperty("CKMPKNpcTitle", "%kills% PKs in the last 24h");
			CKM_PK_NPC_TITLE_COLOR = Integer.decode(StringUtil.concat("0x", l2jevent.getProperty("CKMPKNpcTitleColor", "00CCFF")));
			CKM_PK_NPC_NAME_COLOR = Integer.decode(StringUtil.concat("0x", l2jevent.getProperty("CKMPKNpcNameColor", "FFFFFF")));
			CKM_PLAYER_REWARDS = parseItemsList(l2jevent.getProperty("CKMReward", "6651,50"));

			MIN_PLAYERS_CLANFULL_REWARD = l2jevent.getProperty("MinPlayerToRewardClanFull", 10);
			MIN_PLAYERS_CLANITEMS_REWARD = l2jevent.getProperty("MinPlayersToRewardItemsList", 20);
			CLAN_ITEMS_REWARD = parseItemsList(l2jevent.getProperty("ClanRewardItemsList", "6651,50"));

			TOP_KILLER_PLAYER_ROUND = l2jevent.getProperty("TopRoundKillerSystem", false);
			TOP_1ST_KILLER_PLAYER_REWARDS = parseItemsList(l2jevent.getProperty("1stTopRoundKillerReward", "6651,50"));
			TOP_2ND_KILLER_PLAYER_REWARDS = parseItemsList(l2jevent.getProperty("2ndTopRoundKillerReward", "6651,50"));
			TOP_3RD_KILLER_PLAYER_REWARDS = parseItemsList(l2jevent.getProperty("3rdTopRoundKillerReward", "6651,50"));

			ALLOW_RANKED_SYSTEM = l2jevent.getProperty("RankedSystemEnable", false);
			ALLOW_RANKED_SYSTEM_SKILL = l2jevent.getProperty("RankedSystemEnableSkill", false);
			RANKED_REWARD_IRON = l2jevent.getProperty("RankedRewardIron", 1);
			RANKED_REWARD_BRONZE = l2jevent.getProperty("RankedRewardBronze", 1);
			RANKED_REWARD_SILVER = l2jevent.getProperty("RankedRewardSilver", 1);
			RANKED_REWARD_GOLD = l2jevent.getProperty("RankedRewardGold", 1);
			RANKED_REWARD_PLATINUM = l2jevent.getProperty("RankedRewardPlatinum", 1);
			RANKED_REWARD_DIAMOND = l2jevent.getProperty("RankedRewardDiamond", 1);

			HUMAN_MAGE_BASE = l2jevent.getProperty("HumanMageList");
			LIST_HUMAN_MAGE_BASE = new ArrayList<>();
			for (String listid : HUMAN_MAGE_BASE.split(","))
				LIST_HUMAN_MAGE_BASE.add(Integer.parseInt(listid));

			ORC_SHAMAN_BASE = l2jevent.getProperty("OrcShamanList");
			LIST_ORC_SHAMAN_BASE = new ArrayList<>();
			for (String listid : ORC_SHAMAN_BASE.split(","))
				LIST_ORC_SHAMAN_BASE.add(Integer.parseInt(listid));

			ALLOW_HIDE_ITEM_EVENT = l2jevent.getProperty("HideEventEnable", false);
			HIDE_ITEM_REWARDS = parseReward(l2jevent, "HideEventRewardList");
			HIDE_EVENT_ITEM_TIME = l2jevent.getProperty("HideEventTime", 100);
			HIDE_EVENT_DISSAPEAR_TIME = l2jevent.getProperty("HideEventRunTime", 100);
			String[] hideLocs = l2jevent.getProperty("HideEventLoc", "").split(";");
			String[] locSplit = null;
			HIDE_EVENT_ITEM_COUNT = hideLocs.length;
			HIDE_EVENT_ITEM_LOCS = new int[HIDE_EVENT_ITEM_COUNT][3];
			for (int i = 0; i < HIDE_EVENT_ITEM_COUNT; i++)
			{
				locSplit = hideLocs[i].split(",");
				for (int j = 0; j < 3; j++)
					HIDE_EVENT_ITEM_LOCS[i][j] = Integer.parseInt(locSplit[j].trim());
			}

			PUZZLE_ITEM_REWARDS = parseReward(l2jevent, "PuzzleEventRewardList");

			RATE_MULTIPLER = Float.parseFloat(l2jevent.getProperty("RateMultipler", "2.00"));
			CRAZY_RATE_TIME = l2jevent.getProperty("TimeCrazy", 1);


			WEAPON_ID_ENCHANT_RESTRICT = l2jevent.getProperty("WeaponAllowedToEnchant");
			WEAPON_LIST_ID_ENCHANT_RESTRICT = new ArrayList<>();
			for (String id : WEAPON_ID_ENCHANT_RESTRICT.split(","))
				WEAPON_LIST_ID_ENCHANT_RESTRICT.add(Integer.parseInt(id));

			ARMOR_ID_ENCHANT_RESTRICT = l2jevent.getProperty("ArmorAllowedToEnchant");
			ARMOR_LIST_ID_ENCHANT_RESTRICT = new ArrayList<>();
			for (String id : ARMOR_ID_ENCHANT_RESTRICT.split(","))
				ARMOR_LIST_ID_ENCHANT_RESTRICT.add(Integer.parseInt(id));

			PVP_ITEM_ENCHANT_EVENT = l2jevent.getProperty("EnchantEquipByPvp", false);
			PVP_ITEM_ENCHANT_WEAPON_CHANCE = Float.parseFloat(l2jevent.getProperty("ChanceToEnchantWeapon", "1.0"));
			PVP_ITEM_ENCHANT_ARMOR_CHANCE = Float.parseFloat(l2jevent.getProperty("ChanceToEnchantArmor", "1.0"));

			CHECK_MIN_ENCHANT_WEAPON = l2jevent.getProperty("CheckMinEnchatWeapon", 0);
			CHECK_MAX_ENCHANT_WEAPON = l2jevent.getProperty("CheckMaxEnchatWeapon", 0);
			CHECK_MIN_ENCHANT_ARMOR_JEWELS = l2jevent.getProperty("CheckMinEnchatArmorJewels", 0);
			CHECK_MAX_ENCHANT_ARMOR_JEWELS = l2jevent.getProperty("CheckMaxEnchatArmorJewels", 0);

			// NFT boss Configs
			ExProperties nftboss = load(NFTBOSS_FILE);
			NFT_BOSS_EVENT  = nftboss.getProperty("NftbossEvent", false);
			REWARD_ALL_PLAYERS  = nftboss.getProperty("NftBossRewardAllPlayers", false);
			REWARD_RANDOM_PLAYER  = nftboss.getProperty("NftBossRewardRandomPlayer", false);
			NFT_BOSS_EVENT_START = nftboss.getProperty("NftBossEventStart", 20);
			NFT_BOSS_EVENT_INTERVAL_BY_TIME_OF_DAY = nftboss.getProperty("NftBossStartTime", "20:00").split(",");
			NFT_RAID_REWARDS_RANGE = nftboss.getProperty("NftBossRangeToReward", 1000);

			REWARD_BY_HWID = nftboss.getProperty("NftbossRewardByHwid", false);

			NFT_BOSS_ID = nftboss.getProperty("NftBossId", 1);
			NFT_BOSS_ID_SPAWN_X = nftboss.getProperty("NftBoss_x", 1);
			NFT_BOSS_ID_SPAWN_Y = nftboss.getProperty("NftBoss_y", 1);
			NFT_BOSS_ID_SPAWN_Z = nftboss.getProperty("NftBoss_z", 1);
			NFT_RAID_REWARDS_LIST_FOR_ALL = parseReward(nftboss, "NftBossRewardsForAllPlayers");
			NFT_RAID_REWARDS_LIST_FOR_ONE = parseReward(nftboss, "NftBossRewardsForOneRandomPlayer");

			// solo boss Configs
			ExProperties soloboss = load(SOLOBOSS_FILE);
			SOLO_BOSS_EVENT  = soloboss.getProperty("SoloBossEvent", false);
			SOLO_BOSS_EVENT_START = soloboss.getProperty("SoloBossEventStart", 20);
			SOLO_BOSS_EVENT_INTERVAL_BY_TIME_OF_DAY = soloboss.getProperty("SoloBossStartTime", "20:00").split(",");
			SOLO_RAID_REWARDS_RANGE = soloboss.getProperty("SoloBossRangeToReward", 1000);

			SOLO_BOSS_ID_ONE = soloboss.getProperty("SoloBossIdA", 1);
			BOSS_ID_ONE_X = soloboss.getProperty("SoloBossIdAx", 1);
			BOSS_ID_ONE_Y = soloboss.getProperty("SoloBossIdAy", 1);
			BOSS_ID_ONE_Z = soloboss.getProperty("SoloBossIdAz", 1);
			SOLO_RAID_REWARDS_LIST_ONE = parseReward(soloboss, "SoloBossRangeRewardsA");

			SOLO_BOSS_ID_TWO = soloboss.getProperty("SoloBossIdB", 1);
			BOSS_ID_TWO_X = soloboss.getProperty("SoloBossIdBx", 1);
			BOSS_ID_TWO_Y = soloboss.getProperty("SoloBossIdBy", 1);
			BOSS_ID_TWO_Z = soloboss.getProperty("SoloBossIdBz", 1);
			SOLO_RAID_REWARDS_LIST_TWO = parseReward(soloboss, "SoloBossRangeRewardsB");

			SOLO_BOSS_ID_TREE = soloboss.getProperty("SoloBossIdC", 1);
			BOSS_ID_TREE_X = soloboss.getProperty("SoloBossIdCx", 1);
			BOSS_ID_TREE_Y = soloboss.getProperty("SoloBossIdCy", 1);
			BOSS_ID_TREE_Z = soloboss.getProperty("SoloBossIdCz", 1);
			SOLO_RAID_REWARDS_LIST_TREE = parseReward(soloboss, "SoloBossRangeRewardsC");

			SOLO_BOSS_ID_FOUR = soloboss.getProperty("SoloBossIdD", 1);
			BOSS_ID_FOUR_X = soloboss.getProperty("SoloBossIdDx", 1);
			BOSS_ID_FOUR_Y = soloboss.getProperty("SoloBossIdDy", 1);
			BOSS_ID_FOUR_Z = soloboss.getProperty("SoloBossIdDz", 1);
			SOLO_RAID_REWARDS_LIST_FOUR = parseReward(soloboss, "SoloBossRangeRewardsD");

			SOLO_BOSS_ID_FIVE = soloboss.getProperty("SoloBossIdE", 1);
			BOSS_ID_FIVE_X = soloboss.getProperty("SoloBossIdEx", 1);
			BOSS_ID_FIVE_Y = soloboss.getProperty("SoloBossIdEy", 1);
			BOSS_ID_FIVE_Z = soloboss.getProperty("SoloBossIdEz", 1);
			SOLO_RAID_REWARDS_LIST_FIVE = parseReward(soloboss, "SoloBossRangeRewardsE");

			// Mission Configs
			ExProperties mission = load(MISSION_FILE);
			RESET_MISSION_EVENT_ENABLED = mission.getProperty("ResetMissionEnabled", false);
			RESET_MISSION_INTERVAL_BY_TIME_OF_DAY = mission.getProperty("ResetMissionStartTime", "20:00").split(",");
			ALLOW_MISSION_COMMANDS = mission.getProperty("MissionCommandEnabled", false);

			ACTIVE_MISSION_TVT = mission.getProperty("ActiveTvTMission", false);
			MISSION_TVT_COUNT = mission.getProperty("TvTCount", 1);
			MISSION_TVT_REWARD_ID = mission.getProperty("TvTReward", 57);
			MISSION_TVT_REWARD_AMOUNT = mission.getProperty("TvTRewardAmmount", 100);

			ACTIVE_MISSION_CTF = mission.getProperty("ActiveCTFMission", false);
			MISSION_CTF_COUNT = mission.getProperty("CTFCount", 1);
			MISSION_CTF_REWARD_ID = mission.getProperty("CTFReward", 57);
			MISSION_CTF_REWARD_AMOUNT = mission.getProperty("CTFRewardAmmount", 100);

			ACTIVE_MISSION_DM = mission.getProperty("ActiveDMMission", false);
			MISSION_DM_COUNT = mission.getProperty("DMCount", 1);
			MISSION_DM_REWARD_ID = mission.getProperty("DMReward", 57);
			MISSION_DM_REWARD_AMOUNT = mission.getProperty("DMRewardAmmount", 100);

			ACTIVE_MISSION_KTB = mission.getProperty("ActiveKTBMission", false);
			MISSION_KTB_COUNT = mission.getProperty("KTBCount", 1);
			MISSION_KTB_REWARD_ID = mission.getProperty("KTBReward", 57);
			MISSION_KTB_REWARD_AMOUNT = mission.getProperty("KTBRewardAmmount", 100);

			ACTIVE_MISSION_TOURNAMENT = mission.getProperty("ActiveTournamentMission", false);
			MISSION_TOURNAMENT_COUNT = mission.getProperty("TournamentCount", 1);
			MISSION_TOURNAMENT_REWARD_ID = mission.getProperty("TournamentReward", 57);
			MISSION_TOURNAMENT_REWARD_AMOUNT = mission.getProperty("TournamentRewardAmmount", 100);

			ACTIVE_MISSION_1X1 = mission.getProperty("Active1x1Mission", false);
			MISSION_1X1_COUNT = mission.getProperty("1x1Count", 1);
			MISSION_1X1_REWARD_ID = mission.getProperty("1x1Reward", 57);
			MISSION_1X1_REWARD_AMOUNT = mission.getProperty("1x1RewardAmmount", 100);

			ACTIVE_MISSION_3X3 = mission.getProperty("Active3x3Mission", false);
			MISSION_3X3_COUNT = mission.getProperty("3x3Count", 1);
			MISSION_3X3_REWARD_ID = mission.getProperty("3x3Reward", 57);
			MISSION_3X3_REWARD_AMOUNT = mission.getProperty("3x3RewardAmmount", 100);

			ACTIVE_MISSION_5X5 = mission.getProperty("Active5x5Mission", false);
			MISSION_5X5_COUNT = mission.getProperty("5x5Count", 1);
			MISSION_5X5_REWARD_ID = mission.getProperty("5x5Reward", 57);
			MISSION_5X5_REWARD_AMOUNT = mission.getProperty("5x5RewardAmmount", 100);

			ACTIVE_MISSION_9X9 = mission.getProperty("Active9x9Mission", false);
			MISSION_9X9_COUNT = mission.getProperty("9x9Count", 1);
			MISSION_9X9_REWARD_ID = mission.getProperty("9x9Reward", 57);
			MISSION_9X9_REWARD_AMOUNT = mission.getProperty("9x9RewardAmmount", 100);

			ACTIVE_MISSION_FARM = mission.getProperty("ActiveFarmMission", false);
			MISSION_FARM_COUNT = mission.getProperty("FarmCount", 1);
			MISSION_LIST_MOBS = mission.getProperty("ListFarmMobs", "0");			
			MISSION_LIST_MONSTER = new ArrayList<>();
			for (final String id : MISSION_LIST_MOBS.split(","))
			{
				MISSION_LIST_MONSTER.add(Integer.parseInt(id));
			}
			MISSION_FARM_REWARD_ID = mission.getProperty("FarmReward", 57);
			MISSION_FARM_REWARD_AMOUNT = mission.getProperty("FarmRewardAmmount", 100);

			ACTIVE_MISSION_CHAMPION = mission.getProperty("ActiveChampionMission", false);
			MISSION_CHAMPION_COUNT = mission.getProperty("ChampionCount", 1);
			MISSION_LIST_CHAMPION = mission.getProperty("ListChampionMobs", "0");			
			MISSION_LIST_CHAMPION_MONSTER = new ArrayList<>();
			for (final String id : MISSION_LIST_CHAMPION.split(","))
			{
				MISSION_LIST_CHAMPION_MONSTER.add(Integer.parseInt(id));
			}
			MISSION_CHAMPION_REWARD_ID = mission.getProperty("ChampionReward", 57);
			MISSION_CHAMPION_REWARD_AMOUNT = mission.getProperty("ChampionRewardAmmount", 100);

			ACTIVE_MISSION_PVP = mission.getProperty("ActivePvPMission", false);
			MISSION_PVP_COUNT = mission.getProperty("PvPCount", 1);
			MISSION_PVP_REWARD_ID = mission.getProperty("PvPReward", 57);
			MISSION_PVP_REWARD_AMOUNT = mission.getProperty("PvPRewardAmmount", 100);

			ACTIVE_MISSION_RAIDKILL = mission.getProperty("ActiveRaidKillMission", false);
			MISSION_RAIDKILL_CONT = mission.getProperty("RaidKillCont", 1);
			RAIDKILL_ID_1 = mission.getProperty("RaidID_1", 0);
			RAIDKILL_ID_2 = mission.getProperty("RaidID_2", 0);
			RAIDKILL_ID_3 = mission.getProperty("RaidID_3", 0);
			RAIDKILL_ID_4 = mission.getProperty("RaidID_4", 0);
			RAIDKILL_ID_5 = mission.getProperty("RaidID_5", 0);
			RAIDKILL_ID_6 = mission.getProperty("RaidID_6", 0);
			MISSION_RAIDKILL_REWARD_ID = mission.getProperty("RaidKillReward", 6392);
			MISSION_RAIDKILL_REWARD_AMOUNT = mission.getProperty("RaidKillRewardAmmount", 1);

			// Balance config
			ExProperties balance = load(BALANCE_FILE);

			RUN_SPD_BOOST = balance.getProperty("RunSpeedBoost", 0);
			MAX_RUN_SPEED = balance.getProperty("MaxRunSpeed", 250);
			MAX_PCRIT_RATE = balance.getProperty("MaxPCritRate", 500);
			ENABLE_MAX_MCRIT_RATE = balance.getProperty("EnableMaxMCritRate", false);
			BASE_MCRITICAL_RATE = balance.getProperty("BaseMCritRate", 8.0);
			MAX_MCRIT_RATE = balance.getProperty("MaxMCritRate", 200);
			MAX_PATK_SPEED = balance.getProperty("MaxPAtkSpeed", 1500);
			MAX_MATK_SPEED = balance.getProperty("MaxMAtkSpeed", 1999);
			MAX_EVASION = balance.getProperty("MaxEvasion", 250);
			MAX_ACCURACY = balance.getProperty("MaxAccuracy", 300);

			ENABLE_CUSTOM_MAGE_CRITICAL_POWER = balance.getProperty("EnableCustomMagicCriticalPower", false);
			MAGIC_CRITICAL_POWER = Float.parseFloat(balance.getProperty("MagicCriticalPower", "1.0"));

			MCRIT_RATE_MUL = Float.parseFloat(balance.getProperty("McritMulDif", "1.0"));
			AOE_DAMAGE = Float.parseFloat(balance.getProperty("AoeDamage", "1.0"));

			ALT_SURRENDER_NO_FAIL = balance.getProperty("SurrenderNoFail", false);

			ENABLE_CUSTOM_PHYSICAL_CRITICAL_POWER = balance.getProperty("EnableCustomPhysicalCriticalPower", false);
			PHYSICAL_CRITICAL_POWER = Float.parseFloat(balance.getProperty("PhysicalCriticalPower", "1.0"));

			HERO_WEAPON_SKILLS_DEBUFF_CHANCE = balance.getProperty("EnableCustomWeaponHeroDebuffModifier", false);
			HERO_SKILL_WEAPON_DEBUFF_CHANCE_MODIFIER = Float.parseFloat(balance.getProperty("DebuffWeaponHeroModifier", "1.0"));

			HERO_SKILL_MODIFIER = l2jmod.getProperty("WeaponHeroSkillListModifier", "3590,3586");
			HERO_SKILL_MODIFIER_LIST = new ArrayList<>();
			for(String id : HERO_SKILL_MODIFIER.trim().split(","))
				HERO_SKILL_MODIFIER_LIST.add(Integer.parseInt(id.trim()));

			ITEM_IDBUFF = balance.getProperty("ItemId_buff", 0);

			ENABLE_MODIFY_SKILL_DURATION = balance.getProperty("EnableModifySkillDuration", false);
			if (ENABLE_MODIFY_SKILL_DURATION)
			{
				SKILL_DURATION_LIST = new HashMap<>();
				array = balance.getProperty("SkillDurationList", "").split(";");
				for (String skill : array)
				{
					String[] skillSplit = skill.split(",");
					if (skillSplit.length != 2)
					{
						System.out.println("SkillDurationList: invalid config property -> SkillDurationList \"" + skill + "\"");
					}
					else
					{
						try
						{
							SKILL_DURATION_LIST.put(Integer.valueOf(skillSplit[0]), Integer.valueOf(skillSplit[1]));
						}
						catch (NumberFormatException nfe)
						{
							if (!skill.equals(""))
							{
								System.out.println("SkillDurationList: invalid config property -> SkillList \"" + skillSplit[0] + "\"" + skillSplit[1]);
							}
						}
					}
				}
			}

			MASTERY_PENALTY = balance.getProperty("MasteryPenality", false);
			LEVEL_TO_GET_PENALITY = balance.getProperty("LevelToGetPenalty", 20);
			ARMOR_PENALTY_SKILL = balance.getProperty("ArmorPenaltySkill", 8000);

			MASTERY_WEAPON_PENALTY = balance.getProperty("MasteryWeaponPenality", false);
			LEVEL_TO_GET_WEAPON_PENALITY = balance.getProperty("LevelToGetWeaponPenalty", 20);
			WEAPON_PENALTY_SKILL = balance.getProperty("WeaponPenaltySkill", 8001);

			ANTI_SS_BUG_1 = balance.getProperty("Delay", 2700);
			ANTI_SS_BUG_2 = balance.getProperty("DelayNextAttack", 470000);		

			ALT_DAGGER_DMG_VS_HEAVY = Float.parseFloat(balance.getProperty("DaggerVSHeavy", "2.50"));
			ALT_DAGGER_DMG_VS_ROBE = Float.parseFloat(balance.getProperty("DaggerVSRobe", "1.80"));
			ALT_DAGGER_DMG_VS_LIGHT = Float.parseFloat(balance.getProperty("DaggerVSLight", "2.00"));

			ALT_DUAL_DMG_VS_HEAVY = Float.parseFloat(balance.getProperty("DualVSHeavy", "2.50"));
			ALT_DUAL_DMG_VS_ROBE = Float.parseFloat(balance.getProperty("DualVSRobe", "1.80"));
			ALT_DUAL_DMG_VS_LIGHT = Float.parseFloat(balance.getProperty("DualVSLight", "2.00"));
			ALT_DUAL_DMG_VS_HEAVY_OLY = Float.parseFloat(balance.getProperty("DualVSHeavyOly", "1.00"));
			ALT_DUAL_DMG_VS_ROBE_OLY = Float.parseFloat(balance.getProperty("DualVSRobeOly", "1.00"));
			ALT_DUAL_DMG_VS_LIGHT_OLY = Float.parseFloat(balance.getProperty("DualVSLightOly", "1.00"));


			ALT_DUALFISTS_DMG_VS_HEAVY = Float.parseFloat(balance.getProperty("DualFistsVSHeavy", "2.50"));
			ALT_DUALFISTS_DMG_VS_ROBE = Float.parseFloat(balance.getProperty("DualFistsVSRobe", "1.80"));
			ALT_DUALFISTS_DMG_VS_LIGHT = Float.parseFloat(balance.getProperty("DualFistsVSLight", "2.00"));
			ALT_DUALFISTS_DMG_VS_HEAVY_OLY = Float.parseFloat(balance.getProperty("DualFistsVSHeavyOly", "1.00"));
			ALT_DUALFISTS_DMG_VS_ROBE_OLY = Float.parseFloat(balance.getProperty("DualFistsVSRobeOly", "1.00"));
			ALT_DUALFISTS_DMG_VS_LIGHT_OLY = Float.parseFloat(balance.getProperty("DualFistsVSLightOly", "1.00"));

			ENABLE_CLASS_DAMAGES = balance.getProperty("EnableClassDamagesSettings", true);
			ENABLE_CLASS_DAMAGES_LOGGER = balance.getProperty("EnableClassDamagesLogger", true);

			ENABLE_OLY_CLASS_DAMAGES = balance.getProperty("EnableClassDamagesSettingsInOly", true);
			ENABLE_OLY_CLASS_DAMAGES_LOGGER = balance.getProperty("EnableClassDamagesLoggerInOly", true);

			PROTECTED_SKILLS = balance.getProperty("NotCanceledSkills");

			NOT_CANCELED_SKILLS = new ArrayList<>();
			for (String id : PROTECTED_SKILLS.split(","))
				NOT_CANCELED_SKILLS.add(Integer.parseInt(id));

			BLOCK_BUFFS = balance.getProperty("NotBlockBuffSkills");

			NO_BLOCK_BUFFS = new ArrayList<>();
			for (String id : BLOCK_BUFFS.split(","))
				NO_BLOCK_BUFFS.add(Integer.valueOf(Integer.parseInt(id)));

			CANCEL_BACK_TIME = balance.getProperty("CancelTimer", 5);

			// Skills Physics settings.
			ExProperties balanceSkills = load(BALANCE_SKILLS_FILE);

			ENABLE_CUSTOM_CHANCE_SKILL = Boolean.parseBoolean(balanceSkills.getProperty("Enable_chance_skills", "true"));
			VORTEX_TO_FIRE = Float.parseFloat(balanceSkills.getProperty("Vortex_to_fire", "1.0"));
			WIND_VORTEX = Float.parseFloat(balanceSkills.getProperty("Vortex_to_wind", "1.0"));
			DARK_VORTEX = Float.parseFloat(balanceSkills.getProperty("Dark_vortex", "1.0"));
			ICE_VORTEX = Float.parseFloat(balanceSkills.getProperty("Ice_vortex", "1.0"));
			LIGHT_VORTEX = Float.parseFloat(balanceSkills.getProperty("Light_vortex", "1.0"));
			SILENCE = Float.parseFloat(balanceSkills.getProperty("Silence", "1.0"));
			TRICK = Float.parseFloat(balanceSkills.getProperty("Trick", "1.0"));
			SLEEP = Float.parseFloat(balanceSkills.getProperty("Sleep", "1.0"));
			CURSE_FEAR = Float.parseFloat(balanceSkills.getProperty("Curse_fear", "1.0"));
			ANCHOR = Float.parseFloat(balanceSkills.getProperty("Anchor", "1.0"));
			CURSE_OF_DOOM = Float.parseFloat(balanceSkills.getProperty("Curse_of_Doom", "1.0"));
			CURSE_OF_ABYSS = Float.parseFloat(balanceSkills.getProperty("Curse_of_Abyss", "1.0"));
			CANCELLATION = Float.parseFloat(balanceSkills.getProperty("Cancellation", "1.0"));
			MASS_SLOW = Float.parseFloat(balanceSkills.getProperty("Mass_slow", "1.0"));
			MASS_FEAR = Float.parseFloat(balanceSkills.getProperty("Mass_fear", "1.0"));
			MASS_GLOOM = Float.parseFloat(balanceSkills.getProperty("Mass_gloom", "1.0"));
			SLEEPING_CLOUD = Float.parseFloat(balanceSkills.getProperty("Sleeping_cloud", "1.0"));
			HEROIC_GRANDEUR = Float.parseFloat(balanceSkills.getProperty("Heroic_grandeur", "1.0"));
			HEROIC_DREAD = Float.parseFloat(balanceSkills.getProperty("Heroic_dread", "1.0"));
			STUNNING_SHOT = Float.parseFloat(balanceSkills.getProperty("Stunning_shot", "1.0"));
			HEX = Float.parseFloat(balanceSkills.getProperty("Hex", "1.0"));
			SHOCK_STOMP = Float.parseFloat(balanceSkills.getProperty("Shock_stomp", "1.0"));
			THUNDER_STORM = Float.parseFloat(balanceSkills.getProperty("Thunder_storm", "1.0"));
			SHIELD_STUN = Float.parseFloat(balanceSkills.getProperty("Shield_stun", "1.0"));
			SHIELD_SLAM = Float.parseFloat(balanceSkills.getProperty("Shield_slam", "1.0"));
			SHACKLE = Float.parseFloat(balanceSkills.getProperty("Shackle", "1.0"));
			MASS_SHACKLING = Float.parseFloat(balanceSkills.getProperty("Mass_shackling", "1.0"));
			ARREST = Float.parseFloat(balanceSkills.getProperty("Arrest", "1.0"));
			BLUFF = Float.parseFloat(balanceSkills.getProperty("Bluff", "1.0"));
			SWITCH = Float.parseFloat(balanceSkills.getProperty("Switch", "1.0"));
			STUNNING_FIST = Float.parseFloat(balanceSkills.getProperty("Stunning_fist", "1.0"));
			FEAR_OVER = Float.parseFloat(balanceSkills.getProperty("Fear_over", "1.0"));
			SEAL_OF_SILENCE = Float.parseFloat(balanceSkills.getProperty("Seal_of_Silence", "1.0"));
			SEAL_OF_SUSPENSION = Float.parseFloat(balanceSkills.getProperty("Seal_of_Suspension", "1.0"));
			STUN_ATTACK = Float.parseFloat(balanceSkills.getProperty("Stun_attack", "1.0"));
			ARMOR_CRUSH = Float.parseFloat(balanceSkills.getProperty("Armor_crush", "1.0"));
			SLOW = Float.parseFloat(balanceSkills.getProperty("Slow", "1.0"));
			SEAL_OF_DESPAIR = Float.parseFloat(balanceSkills.getProperty("Seal_of_Despair", "1.0"));
			DREAMING_SPIRIT = Float.parseFloat(balanceSkills.getProperty("Dreaming_spirit", "1.0"));
			SEAL_OF_BINDING = Float.parseFloat(balanceSkills.getProperty("Seal_of_Binding", "1.0"));
			MASS_WARRIOR_BANE = Float.parseFloat(balanceSkills.getProperty("Mass_Warrior_Bane", "1.0"));
			MASS_MAGE_BANE = Float.parseFloat(balanceSkills.getProperty("Mass_Mage_Bane", "1.0"));
			SHIELD_BASH = Float.parseFloat(balanceSkills.getProperty("Shield_Bash", "1.0"));
			SHOCK_BLAST = Float.parseFloat(balanceSkills.getProperty("Shock_Blast", "1.0"));
			LIGHTNING_STRIKE = Float.parseFloat(balanceSkills.getProperty("Lightning_strike", "1.0"));
			TRANCE = Float.parseFloat(balanceSkills.getProperty("Trance", "1.0"));
			SOUL_BREAK = Float.parseFloat(balanceSkills.getProperty("Soul_break", "1.0"));
			
			ExProperties pvpboss = load(PVP_BOSS_EVENT_FILE);
			PVP_BOSS_EVENT  = pvpboss.getProperty("PvPBossEvent", false);
			PVPBOSS_EVENT_PVPS = pvpboss.getProperty("PvPBossCount", 1);
			PVPBOSS_EVENT_ANNOUNCE_PROGRESS = pvpboss.getProperty("PvPBossAnnounceProgress", 1);
			PVPBOSS_EVENT = pvpboss.getProperty("PvPBossIds");
			PVPBOSS_EVENT_ID = new ArrayList<>();
			for (String id : PVPBOSS_EVENT.split(","))
				PVPBOSS_EVENT_ID.add(Integer.parseInt(id));
			
			String[] ppbossLocs1 = pvpboss.getProperty("PvPBossSpawnLoc", "").split(";");
			String[] locPBplit1 = null;
			
			PVPBOSS_EVENT_LOCS_COUNT = ppbossLocs1.length;
			PVPBOSS_EVENT_LOCS = new int[PVPBOSS_EVENT_LOCS_COUNT][3];
			for (int i = 0; i < PVPBOSS_EVENT_LOCS_COUNT; i++)
			{
				locPBplit1 = ppbossLocs1[i].split(",");
				for (int j = 0; j < 3; j++)
				{
					PVPBOSS_EVENT_LOCS[i][j] = Integer.parseInt(locPBplit1[j].trim());
				}
			}

			// Annoucements config
			ExProperties annouce = load(ANNOUCEMENTS_FILE);

			ID_DROP = annouce.getProperty("AnnounceDropItemList", "10");
			LISTID_DROP = new ArrayList<>();
			for (String classId : ID_DROP.split(","))
			{
				LISTID_DROP.add(Integer.parseInt(classId));
			}

			ANNOUNCE_ZONE_PVP = Boolean.parseBoolean(annouce.getProperty("AnnounceZonePvp", "False"));
			ANNOUNCE_DROP_ITEM = Boolean.parseBoolean(annouce.getProperty("AnnounceDropItem", "false"));

			GET_SELF_ANNOUNCE = annouce.getProperty("AllowSelfAnnounce", false);
			GET_SELF_MSG = annouce.getProperty("SelfAnnounce", "Death");
			ANNOUNCE_SELF_ID = annouce.getProperty("Announce_Self_Color_Id", 16);
			ANNOUNCE_SELF_NAME = annouce.getProperty("Announce_Self_Name", "");

			ANNOUNCE_TYPE_MSG_PVP = annouce.getProperty("AnnounceTypesPvP", "Derrotou");
			LIST_OF_TYPES_PVP = new ArrayList<>();
			for (String type : ANNOUNCE_TYPE_MSG_PVP.split(","))
			{
				LIST_OF_TYPES_PVP.add(type);
			}
			ANNOUNCE_TYPE_MSG_PVP = null;

			ANNOUNCE_TYPE_MSG_PK = annouce.getProperty("AnnounceTypesPk", "Assassinou");
			LIST_OF_TYPES_PK = new ArrayList<>();
			for (String type2 : ANNOUNCE_TYPE_MSG_PK.split(","))
			{
				LIST_OF_TYPES_PK.add(type2);
			}
			ANNOUNCE_TYPE_MSG_PK = null;

			ANNOUNCE_CASTLE_LORDS = annouce.getProperty("AnnounceLordOnEnter", false);
			ANNOUNCE_AIO_LOGIN = annouce.getProperty("AnnounceAioOnEnter", false);
			ANNOUNCE_HERO_LOGIN = annouce.getProperty("AnnounceHeroOnEnter", false);
			ANNOUNCE_HERO_ON_CUSTOM = annouce.getProperty("AnnounceHeroOnCustom", false);
			ANNOUNCE_HALL_OWNERS = annouce.getProperty("AnnounceEnterLeadersHall", false);


			ALLOW_QUAKE_SYSTEM = annouce.getProperty("AllowQuakeSystem", false);

			String killing_spree_values = annouce.getProperty("QuakeSystemValues", "");
			String killing_spree_values_splitted_1[] = killing_spree_values.split(";");
			for (String s : killing_spree_values_splitted_1)
			{
				String killing_spree_values_splitted_2[] = s.split(",");
				QUAKE_VALUES.put(Integer.parseInt(killing_spree_values_splitted_2[0]), killing_spree_values_splitted_2[1]);
			}

			ALLOW_QUAKE_REWARD = annouce.getProperty("AllowQuakeReward", false);
			QUAKE_REWARD_ITEM = annouce.getProperty("QuakeRewardItemId", 57);


			ANNOUNCE_ID_QUAKE = annouce.getProperty("AnnounceColorQuakePvpId", 16);
			ANNOUNCE_QUAKE_PVP = annouce.getProperty("AnnounceQuakePvp", "");

			WAR_LEGEND_AURA = annouce.getProperty("QuakeWarLegend", false);
			KILLS_TO_GET_WAR_LEGEND_AURA = annouce.getProperty("KillsToGetWarLegend", 30);

			CHAT_SHOUT_NEED_PVPS = annouce.getProperty("ShoutChatWithPvP", false);
			PVPS_TO_USE_CHAT_SHOUT = annouce.getProperty("ShoutPvPAmount", 0);
			CHAT_TRADE_NEED_PVPS = annouce.getProperty("TradeChatWithPvP", false);
			PVPS_TO_USE_CHAT_TRADE = annouce.getProperty("TradePvPAmount", 0);
			CHAT_HERO_NEED_PVPS = annouce.getProperty("HeroChatWithPvP", false);
			PVPS_TO_USE_CHAT_HERO = annouce.getProperty("HeroPvPAmount", 0);

			ALT_OLY_END_ANNOUNCE = annouce.getProperty("AltOlyEndAnnounce", false);

			NPC_ITEM_ANNOUNCE = annouce.getProperty("AnnounceItemSell", false);
			NPC_ITEM_ANNOUNCE_SELL = annouce.getProperty("AnnouceItensSellList");
			NPC_ITEM_ANNOUNCE_SELL_LIST = new ArrayList<>();
			for (String id : NPC_ITEM_ANNOUNCE_SELL.split(","))
				NPC_ITEM_ANNOUNCE_SELL_LIST.add(Integer.parseInt(id));

			USE_SAY_FILTER = annouce.getProperty("AllowSayFilter", false);
			CHAT_FILTER_CHARS = annouce.getProperty("SayFilterWrite", "********");
			CHAT_FILTER_PUNISHMENT = annouce.getProperty("SayFilterPunishment", "off");
			CHAT_FILTER_PUNISHMENT_PARAM1 = annouce.getProperty("SayFilterPunishmentParam1", 1);
			CHAT_FILTER_PUNISHMENT_PARAM2 = annouce.getProperty("SayFilterPunishmentParam2", 1000);

			if (USE_SAY_FILTER)
			{
				try
				{
					@SuppressWarnings("resource")
					LineNumberReader lnr = new LineNumberReader(new BufferedReader(new FileReader(new File(SAY_FILTER_FILE))));
					String line = null;
					while ((line = lnr.readLine()) != null)
					{
						if (line.trim().length() == 0 || line.startsWith("#"))
						{
							continue;
						}
						FILTER_LIST.add(line.trim());
					}
					_log.info("Chat Filter: Loaded " + FILTER_LIST.size() + " words");
				}
				catch (Exception e)
				{
					e.printStackTrace();
					throw new Error("Failed to Load "+SAY_FILTER_FILE+" File.");
				}
			}

			ExProperties pvpevent = load(PVP_EVENT_FILE);

			CUSTOM_TELEGIRAN_ON_DIE = pvpevent.getProperty("CustomTeleFixed", false);
			PVPEVENT_NAME = pvpevent.getProperty("PvPEventName", "");
			PVPEVENT_TITLE = pvpevent.getProperty("PvPEventTitle", "");
			AUTO_PVP_ZONE_NAME = pvpevent.getProperty("PvPEventCharInfoEnable", false);
			PVP_EVENT_ENABLED = pvpevent.getProperty("PvPEventEnabled", false);
			PVP_EVENT_INTERVAL = pvpevent.getProperty("PvPEventInterval", "20:00").split(",");
			PVP_EVENT_RUNNING_TIME = pvpevent.getProperty("PvPEventRunningTime", 120);

			PVP_EVENT_REGISTER_TIME = Integer.parseInt(pvpevent.getProperty("PvPEventRegisterTime", "5")); // valor padrao: 5 minutos
			PVP_SPECIAL_ITEMS_REWARD = parseReward(pvpevent, "SpecialPvpItemsReward");
			ALLOW_SPECIAL_PVP_REWARD = pvpevent.getProperty("SpecialPvpRewardEnabled", false);
			PVP_EVENT_RANKING_REWARD = pvpevent.getProperty("PvPEventFirstPlayers", 1);

			PVP_EVENT_WINNER_REWARDS.clear();

			String[] pvpEventRewards = pvpevent.getProperty("PvPEventRewards", "57,100000").split(";");
			for (String reward : pvpEventRewards) {
			    String[] rewardSplit = reward.split(",");
			    if (rewardSplit.length != 2) {
			        System.out.println("PVP Event Rewards: Configuracao invalida -> " + reward);
			    } else {
			        try {
			            int itemId = Integer.parseInt(rewardSplit[0].trim());
			            int itemAmount = Integer.parseInt(rewardSplit[1].trim());

			            PVP_EVENT_WINNER_REWARDS.add(new IntIntHolder(itemId, itemAmount));
			        } catch (NumberFormatException e) {
			            System.out.println("PVP Event Rewards: Erro ao analisar a recompensa -> " + reward);
			        }
			    }
			}

			// ===============================
			// MOD CERTIFICAÇÃO
			// ===============================
			try
			{
			    final ExProperties certification = load(CERTIFICATION_FILE);

			    CERTIFICATION_ENABLED = certification.getProperty("Certification.Enabled", true);
			    CERTIFICATION_DEFAULT_CHANCE = certification.getProperty("Certification.DefaultChance", 15.0);
			    CERTIFICATION_ITEM_IDS = parseIntegerArray(certification.getProperty("Certification.ItemIds", "60001,60002,60003,60004,60005,60006"));
			    CERTIFICATION_PASSIVE_SKILL_IDS = parseIntegerArray(certification.getProperty("Certification.PassiveSkillIds", "92001,92002,92003,92004,92005,92006"));
			    CERTIFICATION_ACTIVE_SKILL_IDS = parseIntegerArray(certification.getProperty("Certification.ActiveSkillIds", "92101,92102,92103,92104,92105,92106"));
			    CERTIFICATION_NOTIFY_ON_ACTIVATE = certification.getProperty("Certification.NotifyOnActivate", true);
			}
			catch (Exception e)
			{
			    _log.warning("Erro ao carregar o arquivo Certification.properties: " + e.getMessage());
			}

			ExProperties timezone = load(TIME_ZONE_FILE);

			TIME_INSTANCE_ENABLED = timezone.getProperty("TimeInstanceEnabled", false);
			TIME_INSTANCE_PLAYER_TIME = timezone.getProperty("TimeInstancePlayerTime", 1);
			TIME_INSTANCE_SCREEN_MESSAGE = timezone.getProperty("TimeInstanceScreenMessage", false);
			TIME_INSTANCE_FLAG_ZONE = timezone.getProperty("TimeInstanceFlagZone", false);
			TIME_INSTANCE_ALLOW_PARTY = timezone.getProperty("TimeInstanceAllowParty", true);

			for (String class_id : timezone.getProperty("TimeInstanceBlockClassesIds").split(","))
			{
				TIME_INSTANCE_BLOCK_CLASS_LIST.add(Integer.parseInt(class_id));
			}

			TIME_INSTANCE_ITEM_ID_TO_ACESS = timezone.getProperty("TimeInstanceItemIdToAcess", 31004);
			TIME_INSTANCE_ITEM_ID_TO_ACESS_COUNT = timezone.getProperty("TimeInstanceItemIdToAcessCount", 31004);
			TIME_INSTANCE_ENTER_LIMIT_COUNT = timezone.getProperty("TimeInstanceDailyEnterCount", 31004);
			RESET_TIME_INSTANCE_INTERVAL_BY_TIME_OF_DAY = timezone.getProperty("TimeInstanceResetStartTime", "20:00").split(",");

			String[] timeLocSpot1 = timezone.getProperty("TimeInstanceAreaLocSpot1", "-16390,-51203,-11021").split(",");
			String[] timeLocSpot2 = timezone.getProperty("TimeInstanceAreaLocSpot2", "-16361,-49308,-10500").split(",");
			String[] timeLocSpot3 = timezone.getProperty("TimeInstanceAreaLocSpot3", "-16376,-47664,-10829").split(",");
			String[] timeLocSpot4 = timezone.getProperty("TimeInstanceAreaLocSpot4", "-16357,-44993,-10733").split(",");
			TIME_INSTANCE_AREA_LOC_1 = new Location(Integer.parseInt(timeLocSpot1[0]), Integer.parseInt(timeLocSpot1[1]), Integer.parseInt(timeLocSpot1[2]));
			TIME_INSTANCE_AREA_LOC_2 = new Location(Integer.parseInt(timeLocSpot2[0]), Integer.parseInt(timeLocSpot2[1]), Integer.parseInt(timeLocSpot2[2]));
			TIME_INSTANCE_AREA_LOC_3 = new Location(Integer.parseInt(timeLocSpot3[0]), Integer.parseInt(timeLocSpot3[1]), Integer.parseInt(timeLocSpot3[2]));
			TIME_INSTANCE_AREA_LOC_4 = new Location(Integer.parseInt(timeLocSpot4[0]), Integer.parseInt(timeLocSpot4[1]), Integer.parseInt(timeLocSpot4[2]));

			ExProperties enchant = load(ENCHANT_FILE);
			String[] propertySplitEnchant = enchant.getProperty("NormalWeaponEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant) 
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) 
				{
					_log.info("invalid config property");
				} 
				else 
				{
					try 
					{
						NORMAL_WEAPON_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("BlessWeaponEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) 
				{
					_log.info("invalid config property");
				}
				else
				{
					try 
					{
						BLESS_WEAPON_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe) 
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("CrystalWeaponEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					_log.info("invalid config property");
				} 
				else
				{
					try
					{
						CRYSTAL_WEAPON_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("EpicWeaponEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant) 
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) 
				{
					System.out.println("invalid config property");
				}
				else
				{
					try 
					{
						EPIC_WEAPON_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe) 
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("DiamoundWeaponEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant) 
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) 
				{
					System.out.println("invalid config property");
				}
				else
				{
					try 
					{
						DIAMOUND_WEAPON_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe) 
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("NormalArmorEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant) {
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					_log.info("invalid config property");
				}
				else
				{
					try
					{
						NORMAL_ARMOR_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 
			propertySplitEnchant = enchant.getProperty("BlessArmorEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					_log.info("invalid config property");
				}
				else
				{
					try
					{
						BLESS_ARMOR_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("CrystalArmorEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) {
					_log.info("invalid config property");
				} 
				else
				{
					try
					{
						CRYSTAL_ARMOR_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("EpicArmorEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					System.out.println("invalid config property");
				}
				else 
				{
					try 
					{
						EPIC_ARMOR_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe) {
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			}

			propertySplitEnchant = enchant.getProperty("DiamoundArmorEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					System.out.println("invalid config property");
				}
				else 
				{
					try 
					{
						DIAMOUND_ARMOR_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} catch (NumberFormatException nfe) {
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			}

			propertySplitEnchant = enchant.getProperty("NormalJewelryEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) 
				{
					_log.info("invalid config property");
				} 
				else 
				{
					try 
					{
						NORMAL_JEWELRY_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					}
					catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("BlessJewelryEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2) {
					_log.info("invalid config property");
				} 
				else 
				{
					try
					{
						BLESS_JEWELRY_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					}
					catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("CrystalJewelryEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					_log.info("invalid config property");
				} 
				else
				{
					try 
					{
						CRYSTAL_JEWELRY_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					} 
					catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							_log.info("invalid config property"); 
					} 
				} 
			} 

			propertySplitEnchant = enchant.getProperty("EpicJewelryEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					System.out.println("invalid config property");
				}
				else 
				{
					try
					{
						EPIC_JEWELRY_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					}
					catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			}

			propertySplitEnchant = enchant.getProperty("DiamoundJewelryEnchantLevel", "").split(";");
			for (String readData : propertySplitEnchant)
			{
				String[] writeData = readData.split(",");
				if (writeData.length != 2)
				{
					System.out.println("invalid config property");
				}
				else 
				{
					try
					{
						DIAMOUND_JEWELRY_ENCHANT_LEVEL.put(Integer.valueOf(Integer.parseInt(writeData[0])), Integer.valueOf(Integer.parseInt(writeData[1])));
					}
					catch (NumberFormatException nfe)
					{
						if (DEBUG)
							nfe.printStackTrace(); 
						if (!readData.equals(""))
							System.out.println("invalid config property"); 
					} 
				} 
			}

			ENABLE_ENCHANT_ANNOUNCE = enchant.getProperty("EnableEnchantAnnounceSucessfully", false);
			ENABLE_ENCHANT_ANNOUNCE_FAIL = enchant.getProperty("EnableEnchantAnnounceFail", false);
			ENCHANT_ANNOUNCE_LEVEL = enchant.getProperty("EnchantAnnounceLevels", "6,10,16,20");
			LIST_ENCHANT_ANNOUNCE_LEVEL = new ArrayList<>();
			for (String id : ENCHANT_ANNOUNCE_LEVEL.split(","))
			{
				LIST_ENCHANT_ANNOUNCE_LEVEL.add(Integer.parseInt(id));
			}

			ENABLE_VIP_ENCHANT_BONUS = Boolean.parseBoolean(enchant.getProperty("EnableVipEnchantBonus", "False"));
			VIP_ENCHANT_BONUS = Integer.parseInt(enchant.getProperty("VipEnchantBonus", "15"));

			ENCHANT_HERO_WEAPON = Boolean.parseBoolean(enchant.getProperty("EnableEnchantHeroWeapons", "False"));

			ENCHANT_SAFE_MAX = Integer.parseInt(enchant.getProperty("EnchantSafeMax", "3"));
			ENCHANT_SAFE_MAX_FULL = Integer.parseInt(enchant.getProperty("EnchantSafeMaxFull", "4"));

			SCROLL_STACKABLE = Boolean.parseBoolean(enchant.getProperty("ScrollStackable", "False"));

			ENCHANT_WEAPON_MAX = Integer.parseInt(enchant.getProperty("EnchantWeaponMax", "25"));
			ENCHANT_ARMOR_MAX = Integer.parseInt(enchant.getProperty("EnchantArmorMax", "25"));
			ENCHANT_JEWELRY_MAX = Integer.parseInt(enchant.getProperty("EnchantJewelryMax", "25"));

			BLESSED_ENCHANT_WEAPON_MAX = Integer.parseInt(enchant.getProperty("BlessedEnchantWeaponMax", "25"));
			BLESSED_ENCHANT_ARMOR_MAX = Integer.parseInt(enchant.getProperty("BlessedEnchantArmorMax", "25"));
			BLESSED_ENCHANT_JEWELRY_MAX = Integer.parseInt(enchant.getProperty("BlessedEnchantJewelryMax", "25"));
			BREAK_ENCHANT = Integer.valueOf(enchant.getProperty("BlessedBreakEnchant", "0")).intValue();

			CRYSTAL_ENCHANT_MIN = Integer.parseInt(enchant.getProperty("CrystalEnchantMin", "20"));
			CRYSTAL_ENCHANT_WEAPON_MAX = Integer.parseInt(enchant.getProperty("CrystalEnchantWeaponMax", "25"));
			CRYSTAL_ENCHANT_ARMOR_MAX = Integer.parseInt(enchant.getProperty("CrystalEnchantArmorMax", "25"));
			CRYSTAL_ENCHANT_JEWELRY_MAX = Integer.parseInt(enchant.getProperty("CrystalEnchantJewelryMax", "25"));
			CRYSTAL_BREAK_ENCHANT = Integer.valueOf(enchant.getProperty("CrystalBreakEnchant", "0")).intValue();
			CRYSTAL_LOST_ENCHANT = Boolean.valueOf(enchant.getProperty("CrystalLostEnchant", "false")).booleanValue();
			CRYSTAL_DECREASE_ENCHANT = Boolean.valueOf(enchant.getProperty("CrystalDecreaseEnchant", "false")).booleanValue();

			EPIC_WEAPON = Integer.parseInt(enchant.getProperty("EpicWeapon", "10010"));
			EPIC_ARMOR = Integer.parseInt(enchant.getProperty("EpicArmor", "10011"));
			EPIC_ENCHANT_MIN = Integer.parseInt(enchant.getProperty("EpicEnchantMin", "20"));
			EPIC_ENCHANT_WEAPON_MAX = Integer.parseInt(enchant.getProperty("EpicEnchantWeaponMax", "25"));
			EPIC_ENCHANT_ARMOR_MAX = Integer.parseInt(enchant.getProperty("EpicEnchantArmorMax", "25"));
			EPIC_ENCHANT_JEWELRY_MAX = Integer.parseInt(enchant.getProperty("EpicEnchantJewelryMax", "25"));
			EPIC_BREAK_ENCHANT = Integer.valueOf(enchant.getProperty("EpicBreakEnchant", "0")).intValue();
			EPIC_LOST_ENCHANT = Boolean.valueOf(enchant.getProperty("EpicLostEnchant", "false")).booleanValue();
			EPIC_DECREASE_ENCHANT = Boolean.valueOf(enchant.getProperty("EpicDecreaseEnchant", "false")).booleanValue();

			DIAMOUND_WEAPON = Integer.parseInt(enchant.getProperty("DiamoundWeapon", "10010"));
			DIAMOUND_ARMOR = Integer.parseInt(enchant.getProperty("DiamoundArmor", "10011"));
			DIAMOUND_ENCHANT_MIN = Integer.parseInt(enchant.getProperty("DiamoundEnchantMin", "20"));
			DIAMOUND_ENCHANT_WEAPON_MAX = Integer.parseInt(enchant.getProperty("DiamoundEnchantWeaponMax", "25"));
			DIAMOUND_ENCHANT_ARMOR_MAX = Integer.parseInt(enchant.getProperty("DiamoundEnchantArmorMax", "25"));
			DIAMOUND_ENCHANT_JEWELRY_MAX = Integer.parseInt(enchant.getProperty("DiamoundEnchantJewelryMax", "25"));
			DIAMOUND_BREAK_ENCHANT = Integer.valueOf(enchant.getProperty("DiamoundBreakEnchant", "0")).intValue();
			DIAMOUND_LOST_ENCHANT = Boolean.valueOf(enchant.getProperty("DiamoundLostEnchant", "false")).booleanValue();
			DIAMOUND_DECREASE_ENCHANT = Boolean.valueOf(enchant.getProperty("DiamoundDecreaseEnchant", "false")).booleanValue();
		}
		else if (Server.serverMode == Server.MODE_LOGINSERVER)
		{
			_log.info("Loading loginserver configuration files.");

			ExProperties server = load(LOGIN_CONFIGURATION_FILE);
			GAME_SERVER_LOGIN_HOST = server.getProperty("LoginHostname", "*");
			GAME_SERVER_LOGIN_PORT = server.getProperty("LoginPort", 9013);

			LOGIN_BIND_ADDRESS = server.getProperty("LoginserverHostname", "*");
			PORT_LOGIN = server.getProperty("LoginserverPort", 2106);

			DEBUG = server.getProperty("Debug", false);
			DEVELOPER = server.getProperty("Developer", false);
			PACKET_HANDLER_DEBUG = server.getProperty("PacketHandlerDebug", false);
			ACCEPT_NEW_GAMESERVER = server.getProperty("AcceptNewGameServer", true);
			REQUEST_ID = server.getProperty("RequestServerID", 0);
			ACCEPT_ALTERNATE_ID = server.getProperty("AcceptAlternateID", true);

			LOGIN_TRY_BEFORE_BAN = server.getProperty("LoginTryBeforeBan", 10);
			LOGIN_BLOCK_AFTER_BAN = server.getProperty("LoginBlockAfterBan", 600);

			LOG_LOGIN_CONTROLLER = server.getProperty("LogLoginController", false);

			LOGIN_SERVER_SCHEDULE_RESTART = Boolean.parseBoolean(server.getProperty("LoginRestartSchedule", "False"));
			LOGIN_SERVER_SCHEDULE_RESTART_TIME = Long.parseLong(server.getProperty("LoginRestartTime", "24"));

			INTERNAL_HOSTNAME = server.getProperty("InternalHostname", "localhost");
			EXTERNAL_HOSTNAME = server.getProperty("ExternalHostname", "localhost");

			DATABASE_URL = server.getProperty("URL", "jdbc:mysql://localhost/acis");
			DATABASE_LOGIN = server.getProperty("Login", "root");
			DATABASE_PASSWORD = server.getProperty("Password", "");
			DATABASE_MAX_CONNECTIONS = server.getProperty("MaximumDbConnections", 10);
			DATABASE_MAX_IDLE_TIME = server.getProperty("MaximumDbIdleTime", 0);

			SHOW_LICENCE = server.getProperty("ShowLicence", true);
			IP_UPDATE_TIME = server.getProperty("IpUpdateTime", 15);
			FORCE_GGAUTH = server.getProperty("ForceGGAuth", false);
			L2ARTS_PROTECTION_ENABLED = server.getProperty("L2ArtsProtectionEnabled", true);

			AUTO_CREATE_ACCOUNTS = server.getProperty("AutoCreateAccounts", true);

			FLOOD_PROTECTION = server.getProperty("EnableFloodProtection", true);
			FAST_CONNECTION_LIMIT = server.getProperty("FastConnectionLimit", 15);
			NORMAL_CONNECTION_TIME = server.getProperty("NormalConnectionTime", 700);
			FAST_CONNECTION_TIME = server.getProperty("FastConnectionTime", 350);
			MAX_CONNECTION_PER_IP = server.getProperty("MaxConnectionPerIP", 50);
		}
		else
			_log.severe("Couldn't load configs: server mode wasn't set.");
	}
	/**
	 * Loads PlayerKillsManager settings.
	 */
	public static final String PK_MANAGER_FILE = "./config/custom/events/Pkmanager.properties";

	public static void loadPKManager() {
		final ExProperties pk = load(PK_MANAGER_FILE);

		BOUNTY_ENABLED = Boolean.parseBoolean(pk.getProperty("BountyEnabled", "true"));
		PRICE_ITEMID = Integer.parseInt(pk.getProperty("PriceItemId", "4037"));
		PRICE_ITEMCOUNT = Integer.parseInt(pk.getProperty("PriceItemCount", "1"));
		TASKS_MAX_COUNT = Integer.parseInt(pk.getProperty("MaxTasksCount", "60"));
		MAX_KILLS_COUNT = Integer.parseInt(pk.getProperty("MaxKillsCount", "5"));
		TASKS_DELETE_INTERVAL = Integer.parseInt(pk.getProperty("DeleteIntervalMinutes", "45"));
		ANNOUNCE_ON_ADD = Boolean.parseBoolean(pk.getProperty("AnnounceOnAdd", "true"));
		ANNOUNCE_ON_KILL = Boolean.parseBoolean(pk.getProperty("AnnounceOnKill", "true"));
		BLOCK_SELF_HWID = Boolean.parseBoolean(pk.getProperty("BlockSelfHWID", "true"));
		ADD_MESSAGE = pk.getProperty("AddMessage", "Player %playername% has appointed the award for the player's head %aimname% %itemcount% %itemname%");
		KILL_MESSAGE = pk.getProperty("KillMessage", "Player %killer% has executed the order and has killed the player %aim%");
		PRICE_ITEMNAME = pk.getProperty("PriceItemName", "Coin of Luck");

		// Inicializa a lista
		LIST_ALLOWED_ITEMS = new ArrayList<>();

		// Pega a string do properties
		String allowedItemsStr = pk.getProperty("AllowedItems", "57");

		// Só processa se a string não estiver vazia
		if (allowedItemsStr != null && !allowedItemsStr.isEmpty()) {
			for (String id : allowedItemsStr.split(",")) {
				try {
					LIST_ALLOWED_ITEMS.add(Integer.parseInt(id.trim()));
				} catch (NumberFormatException e) {
					_log.warning("PlayerKillsManager: ID de item invalido encontrado na lista: " + id);
				}
			}
		}
	}
	
	/**
	 * Loads Spoil Instance
	 */
	public static final void loadSpoilInstance() {
		final ExProperties SpoilInstance = load(Config.SPOIL_INSTANCE_FILE);
		ENABLE_CLASS_ONLY_SPOIL = Boolean.parseBoolean(SpoilInstance.getProperty("EnableClassOnlySpoil", "false"));
		SPOIL_ENTRANCE_TIME = Integer.parseInt(SpoilInstance.getProperty("TimeInstanceSpoil", "100"));
		ITEM_SPOIL_ENTRANCE = Integer.parseInt(SpoilInstance.getProperty("ItemNecessaryEntrance", "100"));
		ITEM_SPOIL_ENTRANCE_AMOUNT = Integer.parseInt(SpoilInstance.getProperty("ItemQuantiy", "100"));
		SPOIL_FARM_TITLE_ENABLED = Boolean.parseBoolean(SpoilInstance.getProperty("SpoilFarmTitleEnabled", "true"));
		SPOIL_FARM_TITLE = SpoilInstance.getProperty("SpoilFarmTitle","Spoil Farming").trim();
			try
			{
			    final String color = SpoilInstance.getProperty(
			        "SpoilFarmTitleColor",
			        "00A5FF"
			    ).trim();

			    if (!color.matches("[0-9a-fA-F]{6}"))
			        throw new NumberFormatException("Expected six hexadecimal digits");

			    SPOIL_FARM_TITLE_COLOR = Integer.parseInt(color, 16);
			}
			catch (NumberFormatException e)
			{
			    SPOIL_FARM_TITLE_COLOR = 0x00A5FF;
			    _log.warning("SpoilFarmTitleColor invalido. Usando 00A5FF.");
			}
		// Retonar para instancia caso player morra ou de escape
		String[] TelepropertySplit = SpoilInstance.getProperty("ReturnInstanceZone", "0,0,0").split(",");
		if (TelepropertySplit.length < 3) {
			System.out.println("ReturnInstanceZone[Config.load()]: invalid config property -> ReturnInstanceZone");
		} else {
			RETURN_SPOIL_LOCATION[0] = Integer.parseInt(TelepropertySplit[0]);
			RETURN_SPOIL_LOCATION[1] = Integer.parseInt(TelepropertySplit[1]);
			RETURN_SPOIL_LOCATION[2] = Integer.parseInt(TelepropertySplit[2]);
		}

		// Retornar a cidade quando acabar a instancia.
		String[] TeleportTown = SpoilInstance.getProperty("ReturnTownZone", "0,0,0").split(",");
		if (TeleportTown.length < 3) {
			System.out.println("ReturnTownZone[Config.load()]: invalid config property -> ReturnTownZone");
		} else {
			RETURN_SPOIL_TOWN[0] = Integer.parseInt(TeleportTown[0]);
			RETURN_SPOIL_TOWN[1] = Integer.parseInt(TeleportTown[1]);
			RETURN_SPOIL_TOWN[2] = Integer.parseInt(TeleportTown[2]);
		}

		// Onde jogador vai se jogado no spawn 1 da gk.
		String[] Spawn1 = SpoilInstance.getProperty("LocationSpawn", "0,0,0").split(",");
		if (Spawn1.length < 3) {
			System.out.println("LocationSpawn[Config.load()]: invalid config property -> LocationSpawn");
		} else {
			LOC_SPOIL_SPAWN_1[0] = Integer.parseInt(Spawn1[0]);
			LOC_SPOIL_SPAWN_1[1] = Integer.parseInt(Spawn1[1]);
			LOC_SPOIL_SPAWN_1[2] = Integer.parseInt(Spawn1[2]);
		}

		// Onde jogador vai se jogado no spawn 2 da gk.
		String[] Spawn2 = SpoilInstance.getProperty("LocationSpawnII", "0,0,0").split(",");
		if (Spawn2.length < 3) {
			System.out.println("LocationSpawnII[Config.load()]: invalid config property -> LocationSpawnII");
		} else {
			LOC_SPOIL_SPAWN_2[0] = Integer.parseInt(Spawn2[0]);
			LOC_SPOIL_SPAWN_2[1] = Integer.parseInt(Spawn2[1]);
			LOC_SPOIL_SPAWN_2[2] = Integer.parseInt(Spawn2[2]);
		}

		// Onde jogador vai se jogado no spawn 3 da gk.
		String[] Spawn3 = SpoilInstance.getProperty("LocationSpawnIII", "0,0,0").split(",");
		if (Spawn3.length < 3) {
			System.out.println("LocationSpawnIII[Config.load()]: invalid config property -> LocationSpawnIII");
		} else {
			LOC_SPOIL_SPAWN_3[0] = Integer.parseInt(Spawn3[0]);
			LOC_SPOIL_SPAWN_3[1] = Integer.parseInt(Spawn3[1]);
			LOC_SPOIL_SPAWN_3[2] = Integer.parseInt(Spawn3[2]);
		}
	}
	
	// It has no instances
	private Config()
	{
	}

	public static void saveHexid(int serverId, String string)
	{
		Config.saveHexid(serverId, string, HEXID_FILE);
	}

	public static void saveHexid(int serverId, String hexId, String fileName)
	{
		try
		{
			Properties hexSetting = new Properties();
			File file = new File(fileName);
			file.createNewFile();

			OutputStream out = new FileOutputStream(file);
			hexSetting.setProperty("ServerID", String.valueOf(serverId));
			hexSetting.setProperty("HexID", hexId);
			hexSetting.store(out, "the hexID to auth into login");
			out.close();
		}
		catch (Exception e)
		{
			_log.warning("Failed to save hex id to " + fileName + " file.");
			e.printStackTrace();
		}
	}


	protected static final ArrayList<Calendar> ParseDates(
		    String datesString,
		    int randMax)
		{
		    if (randMax < 0)
		    {
		        throw new IllegalArgumentException(
		            "Intervalo aleatorio de spawn nao pode ser negativo: "
		            + randMax
		        );
		    }

		    ArrayList<Calendar> tempList = new ArrayList<>();
		    String[] dates = datesString.split(";");
		    Calendar today = Calendar.getInstance();

		    for (String dateItem : dates)
		    {
		        String[] tokens = dateItem.split(",");
		        Calendar cal = Calendar.getInstance();

		        cal.set(7, GetDayFromString(tokens[0]));

		        String[] timeTokens = tokens[1].split(":");

		        cal.set(11, Integer.parseInt(timeTokens[0]));
		        cal.set(12, Integer.parseInt(timeTokens[1]));
		        cal.set(13, 0);

		        // Zero: horario exato, sem atraso aleatorio.
		        if (randMax > 0)
		        {
		            cal.add(12, (new Random()).nextInt(randMax));
		        }

		        if (cal.getTimeInMillis() - today.getTimeInMillis() < 0L)
		            cal.add(5, 7);

		        tempList.add(cal);
		    }

		    return tempList;
		}

	public static int GetDayFromString(String day)
	{
		day = day.toLowerCase();
		int dayVal = 2;
		switch (day)
		{
		case "monday":
			dayVal = 2;
			break;
		case "tuesday":
			dayVal = 3;
			break;
		case "wednesday":
			dayVal = 4;
			break;
		case "thursday":
			dayVal = 5;
			break;
		case "friday":
			dayVal = 6;
			break;
		case "saturday":
			dayVal = 7;
			break;
		case "sunday":
			dayVal = 1;
			break;
		} 
		return dayVal;
	}

	public static Calendar FindNext(ArrayList<Calendar> times)
	{
		Calendar today = Calendar.getInstance();
		ArrayList<Calendar> tempTimes = new ArrayList<>();
		for (Calendar time : times)
		{
			if (time.getTimeInMillis() - today.getTimeInMillis() < 0L)
				time.add(5, 7); 
			tempTimes.add(time);
		} 
		if (tempTimes.size() == 0)
			return null; 
		Calendar nextTime = tempTimes.get(0);
		for (Calendar t : tempTimes)
		{
			if (t.getTimeInMillis() - today.getTimeInMillis() < nextTime.getTimeInMillis() - today.getTimeInMillis())
				nextTime = t; 
		} 
		return nextTime;
	}

	/**
	 * Loads single flood protector configuration.
	 * @param properties L2Properties file reader
	 * @param config flood protector configuration instance
	 * @param configString flood protector configuration string that determines for which flood protector configuration should be read
	 * @param defaultInterval default flood protector interval
	 */
	private static void loadFloodProtectorConfig(final Properties properties, final FloodProtectorConfig config, final String configString, final String defaultInterval)
	{
		config.FLOOD_PROTECTION_INTERVAL = Integer.parseInt(properties.getProperty(StringUtil.concat("FloodProtector", configString, "Interval"), defaultInterval));
		config.LOG_FLOODING = Boolean.parseBoolean(properties.getProperty(StringUtil.concat("FloodProtector", configString, "LogFlooding"), "False"));
		config.PUNISHMENT_LIMIT = Integer.parseInt(properties.getProperty(StringUtil.concat("FloodProtector", configString, "PunishmentLimit"), "0"));
		config.PUNISHMENT_TYPE = properties.getProperty(StringUtil.concat("FloodProtector", configString, "PunishmentType"), "none");
		config.PUNISHMENT_TIME = Integer.parseInt(properties.getProperty(StringUtil.concat("FloodProtector", configString, "PunishmentTime"), "0"));
	}

	public static class ClassMasterSettings
	{
		private final Map<Integer, Boolean> _allowedClassChange;
		private final Map<Integer, List<ItemHolder>> _claimItems;
		private final Map<Integer, List<ItemHolder>> _rewardItems;

		public ClassMasterSettings(String configLine)
		{
			_allowedClassChange = new HashMap<>(3);
			_claimItems = new HashMap<>(3);
			_rewardItems = new HashMap<>(3);

			if (configLine != null)
				parseConfigLine(configLine.trim());
		}

		private void parseConfigLine(String configLine)
		{
			StringTokenizer st = new StringTokenizer(configLine, ";");

			while (st.hasMoreTokens())
			{
				// get allowed class change
				int job = Integer.parseInt(st.nextToken());

				_allowedClassChange.put(job, true);

				List<ItemHolder> items = new ArrayList<>();

				// Parse items needed for class change.
				if (st.hasMoreTokens())
				{
					StringTokenizer st2 = new StringTokenizer(st.nextToken(), "[],");

					while (st2.hasMoreTokens())
					{
						StringTokenizer st3 = new StringTokenizer(st2.nextToken(), "()");
						items.add(new ItemHolder(Integer.parseInt(st3.nextToken()), Integer.parseInt(st3.nextToken())));
					}
				}

				// Feed the map, and clean the list.
				_claimItems.put(job, items);
				items = new ArrayList<>();

				// Parse gifts after class change.
				if (st.hasMoreTokens())
				{
					StringTokenizer st2 = new StringTokenizer(st.nextToken(), "[],");

					while (st2.hasMoreTokens())
					{
						StringTokenizer st3 = new StringTokenizer(st2.nextToken(), "()");
						items.add(new ItemHolder(Integer.parseInt(st3.nextToken()), Integer.parseInt(st3.nextToken())));
					}
				}

				_rewardItems.put(job, items);
			}
		}

		public boolean isAllowed(int job)
		{
			if (_allowedClassChange == null)
				return false;

			if (_allowedClassChange.containsKey(job))
				return _allowedClassChange.get(job);

			return false;
		}

		public List<ItemHolder> getRewardItems(int job)
		{
			return _rewardItems.get(job);
		}

		public List<ItemHolder> getRequiredItems(int job)
		{
			return _claimItems.get(job);
		}
	}

	/**
	 * itemId1,itemNumber1;itemId2,itemNumber2... to the int[n][2] = [itemId1][itemNumber1],[itemId2][itemNumber2]...
	 * @param line
	 * @return an array consisting of parsed items.
	 */
	private static int[][] parseItemsList(String line)
	{
		final String[] propertySplit = line.split(";");
		if (propertySplit.length == 0)
			return null;

		int i = 0;
		String[] valueSplit;
		final int[][] result = new int[propertySplit.length][];
		for (String value : propertySplit)
		{
			valueSplit = value.split(",");
			if (valueSplit.length != 2)
			{
				_log.warning(StringUtil.concat("parseItemsList[Config.load()]: invalid entry -> \"", valueSplit[0], "\", should be itemId,itemNumber"));
				return null;
			}

			result[i] = new int[2];
			try
			{
				result[i][0] = Integer.parseInt(valueSplit[0]);
			}
			catch (NumberFormatException e)
			{
				_log.warning(StringUtil.concat("parseItemsList[Config.load()]: invalid itemId -> \"", valueSplit[0], "\""));
				return null;
			}

			try
			{
				result[i][1] = Integer.parseInt(valueSplit[1]);
			}
			catch (NumberFormatException e)
			{
				_log.warning(StringUtil.concat("parseItemsList[Config.load()]: invalid item number -> \"", valueSplit[1], "\""));
				return null;
			}
			i++;
		}
		return result;
	}

	public static List<RewardHolder> parseReward(ExProperties propertie, String configName)
	{
		List<RewardHolder> auxReturn = new ArrayList<>();

		String aux = propertie.getProperty(configName).trim();
		for (String randomReward : aux.split(";"))
		{
			final String[] infos = randomReward.split(",");

			if (infos.length > 3)
				auxReturn.add(new RewardHolder(Integer.valueOf(infos[0]), Integer.valueOf(infos[1]), Integer.valueOf(infos[2]), Integer.valueOf(infos[3])));
			else
				auxReturn.add(new RewardHolder(Integer.valueOf(infos[0]), Integer.valueOf(infos[1]), Integer.valueOf(infos[2])));
		}
		return auxReturn;
	}


/**
 * Converte uma lista de IDs separados por vírgula em um array de int.
 * Exemplo: "60001,60002,60003" -> [60001, 60002, 60003]
 */
private static int[] parseIntegerArray(String value)
{
    if (value == null || value.trim().isEmpty())
        return new int[0];

    String[] parts = value.split(",");
    int[] ids = new int[parts.length];
    int count = 0;

    for (String part : parts)
    {
        String id = part.trim();

        if (id.isEmpty())
            continue;

        try
        {
            ids[count++] = Integer.parseInt(id);
        }
        catch (NumberFormatException e)
        {
            _log.warning("ID inválido na configuração: " + id);
        }
    }

    if (count == ids.length)
        return ids;

    int[] result = new int[count];
    System.arraycopy(ids, 0, result, 0, count);

    return result;
}


	public static ExProperties load(String filename)
	{
		return load(new File(filename));
	}

	public static ExProperties load(File file)
	{
		ExProperties result = new ExProperties();

		try
		{
			result.load(file);
		}
		catch (IOException e)
		{
			_log.warning("Error loading config : " + file.getName() + "!");
		}

		return result;
	}
}
