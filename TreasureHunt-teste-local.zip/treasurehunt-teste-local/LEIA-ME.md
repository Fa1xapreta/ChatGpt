# Treasure Hunt: teste em local fixo

Atualização para quem já instalou o primeiro ZIP `TreasureHunt-adaptado.zip`.
Altera somente Config.java, CustomTreasureHunt.java e TreasureHuntManager.java.
Não substitui o mod completo. Os XMLs, recompensas e a lógica da ferramenta
permanecem os da versão anterior.

## Instalar

1. Faça backup das três classes atuais.
2. Mescle/copie `arquivos-atualizados/net/` na raiz das fontes do core. Se as
   classes foram editadas após o primeiro pacote, faça merge para preservar suas
   alterações. Como alternativa, aplique `atualizar-v1.patch` na raiz das fontes:

   ```sh
   git apply --check --ignore-space-change /caminho/atualizar-v1.patch
   git apply --ignore-space-change /caminho/atualizar-v1.patch
   ```

   Use uma das opções, não ambas.
3. Atualize/acrescente as chaves de `l2jmod.properties-teste.txt` no arquivo
   existente `config/custom/l2jmod.properties`. Não substitua o arquivo inteiro
   nem deixe duas ocorrências da mesma chave. O bloco liga o evento e o modo de
   teste, usa intervalo de 60 segundos e a coordenada informada pelo usuário.
4. Recompile pelo build normal da pack e reinicie o gameserver. Só recarregar
   config não instala as classes Java novas.

## Local e efeitos

A primeira rodada ocorre no próximo ciclo do gerenciador, cerca de um segundo
após a inicialização. As próximas ocorrem a cada 60 segundos, removendo a rodada
anterior. Em modo de teste não há sorteio de chance: nasce uma pedra por tipo de
NPC encontrado no treasurehunt.xml. Nas quatro definições enviadas:

| NPC | X | Y | Z solicitado |
|---|---:|---:|---:|
| 52000 | 147256 | -90488 | -4367 |
| 52001 | 147376 | -90488 | -4367 |
| 52002 | 147256 | -90368 | -4367 |
| 52003 | 147376 | -90368 | -4367 |

O L2Spawn do seu core ainda pode ajustar o Z ao chão próximo. O console registra
as coordenadas finais como `TreasureHunt TEST: NPC ... spawned at ...`; o anúncio
também exibe essas coordenadas. Não é necessário procurar as regiões do XML.

Todos os spawns passam pela mesma rotina de efeitos do modo normal:
SocialAction ID 1, Earthquake intensidade 5/duração 3, som
`SkillSound5.target_magic_circle_01` e lançamento dos jogadores próximos usando
FlyToLocation/THROW_UP. Para observar, fique próximo antes da próxima rodada.
O lançamento pode afastar seu personagem, como na versão original.

As chances de recompensa não foram alteradas: os drops da pedra verde continuam
em 0,01%. O item continua sendo equipado automaticamente ao clicar na pedra.

## Voltar ao modo normal

Defina `TreasureHuntTestMode = False`, restaure o intervalo desejado (por exemplo,
1800 segundos) e execute `//reload config` e `//reload treasurehunt`, ou reinicie.
Isso limpa as pedras do modo anterior. O modo normal volta às regiões e chances
configuradas no XML.

## Validação

55 verificações isoladas passaram, com substitutos explícitos do core. Foram
verificados os quatro tipos, posições separadas, spawn imediato no modo de teste,
SocialAction 1 e Earthquake (5, 3) para cada pedra, quatro sons, limpeza ao
desabilitar e retorno às chances normais. O patch incremental foi aplicado e
comparado às três classes esperadas. A sintaxe Java foi analisada.

Não foi executado o build completo da pack, nem teste gráfico com cliente. O
envio dos pacotes está implementado e verificado nos testes isolados; a animação,
som e tremor visíveis precisam ser conferidos dentro do jogo. Se não aparecerem,
envie os logs e o comportamento observado.
