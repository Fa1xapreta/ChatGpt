package net.sf.l2j.gameserver.util;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedHashMap;
import java.util.Map;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
public final class TargetPlayerStatusRegression
{
 private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 private static Map<Integer,Integer> parse(byte[] data,int targetId)
 {
  check(data.length==41,"Native four-attribute packet length");ByteBuffer b=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
  check((b.get()&255)==14,"Native StatusUpdate opcode");check(b.getInt()==targetId,"Correct target server ID");check(b.getInt()==4,"Exactly four fields");
  Map<Integer,Integer> values=new LinkedHashMap<>();while(b.hasRemaining())values.put(b.getInt(),b.getInt());
  check(values.size()==4 && values.containsKey(0x0a) && values.containsKey(9) && values.containsKey(0x22) && values.containsKey(0x21),"Only max/current HP and CP; no MP/XP/private stats");return values;
 }
 private static Map<Integer,Integer> last(L2PcInstance observer){return parse(observer.sent.get(observer.sent.size()-1),700);}
 public static void main(String[] args)
 {
  L2PcInstance target=new L2PcInstance(700),a=new L2PcInstance(1),b=new L2PcInstance(2),stale=new L2PcInstance(3),offline=new L2PcInstance(4);
  a.target=target;b.target=target;offline.target=target;offline.online=false;
  TargetPlayerStatus.selected(a,target);Map<Integer,Integer> v=last(a);check(v.get(9)==10000&&v.get(0x21)==4000,"Initial selection sends real full HP/CP");
  target.status.listeners.add(a);target.status.listeners.add(b);target.status.listeners.add(stale);target.status.listeners.add(offline);target.status.listeners.add(target);target.status.listeners.add(new L2Character());
  target.cp=2500;TargetPlayerStatus.changed(target);v=last(a);check(v.get(9)==10000&&v.get(0x21)==2500,"CP-only PvP damage reaches observer immediately");check(last(b).equals(v),"All actual target observers updated");
  target.cp=0;target.hp=8000;TargetPlayerStatus.changed(target);v=last(a);check(v.get(0x21)==0&&v.get(9)==8000,"CP exhaustion and HP damage transmitted, including zero");
  check(v.get(9)*70/v.get(0x0a)==56 && v.get(0x21)*70/v.get(0x22)==0,"Existing client's 70px bar formula shrinks HP and empties CP");
  target.hp=9000;target.cp=1000;TargetPlayerStatus.changed(target);v=last(a);check(v.get(9)==9000&&v.get(0x21)==1000,"Healing/regeneration updates both bars");
  target.maxHp=15000;target.maxCp=6000;TargetPlayerStatus.changed(target);v=last(a);check(v.get(0x0a)==15000&&v.get(0x22)==6000,"Changed buff/subclass maxima included");
  check(stale.sent.isEmpty()&&offline.sent.isEmpty()&&target.sent.isEmpty(),"Stale/offline/non-player/self listeners excluded");
  int count=a.sent.size();a.target=b;TargetPlayerStatus.changed(target);check(a.sent.size()==count,"Switching target prevents old-target updates");
  TargetPlayerStatus.selected(a,target);check(a.sent.size()==count,"Initial snapshot also validates current target");
  target.online=false;count=b.sent.size();TargetPlayerStatus.changed(target);check(b.sent.size()==count,"Offline target not broadcast");
  TargetPlayerStatus.changed(null);TargetPlayerStatus.selected(null,target);TargetPlayerStatus.selected(a,null);
  System.out.println("PASS: actual observer helper + actual packet serializer; native 41-byte payload, CP damage, HP damage, zero CP, healing, max changes, 70px bar ratios and listener filters (player/status/transport fixtures)");
 }
}
