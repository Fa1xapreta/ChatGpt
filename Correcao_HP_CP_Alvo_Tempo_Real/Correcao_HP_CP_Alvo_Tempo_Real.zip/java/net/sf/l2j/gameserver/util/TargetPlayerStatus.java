package net.sf.l2j.gameserver.util;

import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.TargetPlayerStatusUpdate;

/** Native target-bar updates; no polling, extra screen messages or MP disclosure. */
public final class TargetPlayerStatus
{
    private TargetPlayerStatus() { }

    private static boolean observes(L2PcInstance observer,L2PcInstance target)
    {
        return observer!=target && observer.isOnline() && observer.getTarget()==target;
    }

    public static void selected(L2PcInstance observer,L2PcInstance target)
    {
        if (observer!=null && target!=null && observes(observer,target))
            observer.sendPacket(new TargetPlayerStatusUpdate(target));
    }

    public static void changed(L2PcInstance target)
    {
        if (target==null || !target.isOnline() || target.getStatus().getStatusListener().isEmpty())
            return;
        TargetPlayerStatusUpdate update=null;
        for (L2Character listener:target.getStatus().getStatusListener())
        {
            if (!(listener instanceof L2PcInstance)) continue;
            L2PcInstance observer=(L2PcInstance)listener;
            if (!observes(observer,target)) continue;
            if (update==null) update=new TargetPlayerStatusUpdate(target);
            observer.sendPacket(update);
        }
    }
}
