package net.sf.l2j.gameserver.network.serverpackets;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

/** Standard 0x0e StatusUpdate, restricted to the four public target-bar values. */
public final class TargetPlayerStatusUpdate extends L2GameServerPacket
{
    private final int objectId,maxHp,hp,maxCp,cp;

    public TargetPlayerStatusUpdate(L2PcInstance player)
    {
        objectId=player.getObjectId();
        maxHp=player.getMaxHp();hp=(int)player.getCurrentHp();
        maxCp=player.getMaxCp();cp=(int)player.getCurrentCp();
    }

    @Override
    protected void writeImpl()
    {
        writeC(0x0e);
        writeD(objectId);
        writeD(4);
        writeD(StatusUpdate.MAX_HP);writeD(maxHp);
        writeD(StatusUpdate.CUR_HP);writeD(hp);
        writeD(StatusUpdate.MAX_CP);writeD(maxCp);
        writeD(StatusUpdate.CUR_CP);writeD(cp);
    }
}
