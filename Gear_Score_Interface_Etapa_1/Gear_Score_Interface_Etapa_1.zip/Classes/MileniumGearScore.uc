class MileniumGearScore extends UICommonAPI;

struct PlayerRankingInfo
{
    var int RankingDiff;
    var string Name;
    var int ClassId;
    var string ClanName;
    var int Score;
};
struct PlayerGearItem
{
    var int ServerID;
    var int ItemID;
    var int Enchant;
    var int RefineryOp1;
    var int RefineryOp2;
    var int SlotBitType;
    var int GearScore;
};
var Color BrightWhite;
var Color BrightYellow;
var Color Blue;
var Color Red;
var Color Gold;
var Color Yellow03;
var Color ColorGold;
var Color ColorYellow;
var Color White;
var Color Gray;
var array<string> Fields;
var array<PlayerGearItem> ItemScores;
var string GearToken;
var string PvpToken;
var string InspectToken;
var int LastTargetID;

function OnLoad()
{
    RegisterEvent(140);
    RegisterEvent(160);
    RegisterEvent(980);
    RegisterEvent(990);
    RegisterEvent(88857);
    RegisterEvent(94600);
    ResetGearData();
}
function OnEvent(int Event_ID, string param)
{
    local string Message;
    local int Score;
    if (Event_ID == 160) { ResetGearData(); return; }
    if (Event_ID == 980 || Event_ID == 990) { CheckTarget(); return; }
    if (Event_ID == 94600)
    {
        if (!ParseString(param, "Payload", Message)) return;
        HandleGearMessage(Message);
        return;
    }
    if (Event_ID == 88857)
    {
        if (!ParseInt(param, "Gear", Score)) return;
        OnUpdateUserScore(Score);
        return;
    }
    if (Event_ID != 140) return;
    if (!ParseString(param, "Msg", Message)) return;
    HandleGearMessage(Message);
}
function ResetGearData()
{
    Fields.Length = 0;
    ItemScores.Length = 0;
    GearToken = "";
    PvpToken = "";
    InspectToken = "";
    LastTargetID = 0;
    TextBoxHandle(GetHandle("MileniumGearUserScoreWnd.txtScore")).SetText("--");
    GetHandle("MileniumGearTargetScoreWnd").HideWindow();
    if (RankingWnd(GetScript("RankingWnd")) != None)
    {
        RankingWnd(GetScript("RankingWnd")).GearScoreList.Length = 0;
        RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRank = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRankingDiff = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRank = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRankingDiff = 0;
        GetHandle("RankingWnd").HideWindow();
    }
    if (InspectWnd(GetScript("InspectWnd")) != None)
    {
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length = 0;
        GetHandle("InspectWnd").HideWindow();
    }
    if (DetailStatusWnd(GetScript("DetailStatusWnd")) != None)
    {
        DetailStatusWnd(GetScript("DetailStatusWnd")).zzgearequip = 0;
        TextBoxHandle(GetHandle("DetailStatusWnd.txtScore")).SetText("--");
    }
}
function OnClickButton(string strID)
{
    if (strID != "btnScoreRank") return;
    if (RankingWnd(GetScript("RankingWnd")) == None) return;
    RankingWnd(GetScript("RankingWnd")).xxSetRankingData();
    ShowWindowWithFocus("RankingWnd");
    RequestBypassToServer("RankingOpen");
}
function OnUpdateUserScore(int Score)
{
    if (Score < 0) return;
    TextBoxHandle(GetHandle("MileniumGearUserScoreWnd.txtScore")).SetInt(Score);
    TextBoxHandle(GetHandle("DetailStatusWnd.txtScore")).SetInt(Score);
    if (DetailStatusWnd(GetScript("DetailStatusWnd")) == None) return;
    DetailStatusWnd(GetScript("DetailStatusWnd")).zzgearequip = Score;
}
function OnUpdateTargetScore(int Score)
{
    if (Score < 0) return;
    TextBoxHandle(GetHandle("MileniumGearTargetScoreWnd.txtScore")).SetInt(Score);
    GetHandle("MileniumGearTargetScoreWnd").ShowWindow();
}
function CheckTarget()
{
    local UserInfo Info;
    if (GetTargetInfo(Info) && Info.nID == LastTargetID) return;
    GetHandle("MileniumGearTargetScoreWnd").HideWindow();
}
function CacheItemScore(int ObjectID, int ItemID, int Enchant, int Score)
{
    local int i, Slot;
    if (ObjectID < 0 || ItemID <= 0 || Enchant < 0 || Score < 0) return;
    i = 0;
    Slot = -1;
    while (i < ItemScores.Length)
    {
        if (ItemScores[i].ServerID == ObjectID)
        {
            if (ObjectID > 0) { Slot = i; break; }
            if (ItemScores[i].ItemID == ItemID && ItemScores[i].Enchant == Enchant)
            { Slot = i; break; }
        }
        i++;
    }
    if (Slot < 0)
    {
        if (ItemScores.Length >= 2048) return;
        Slot = ItemScores.Length;
        ItemScores.Length++;
    }
    ItemScores[Slot].ServerID = ObjectID;
    ItemScores[Slot].ItemID = ItemID;
    ItemScores[Slot].Enchant = Enchant;
    ItemScores[Slot].GearScore = Score;
}
function int GetItemScore(int ObjectID, int ItemID, int Enchant)
{
    local int i;
    i = 0;
    while (i < ItemScores.Length)
    {
        if (ObjectID > 0)
        {
            if (ItemScores[i].ServerID == ObjectID) return ItemScores[i].GearScore;
        }
        else if (ItemScores[i].ServerID == 0 && ItemScores[i].ItemID == ItemID && ItemScores[i].Enchant == Enchant)
            return ItemScores[i].GearScore;
        i++;
    }
    return -1;
}
function AppendItemScoreTooltip(out CustomTooltip Tip, ItemInfo Item, bool Preview)
{
    local int Score, Row;
    Score = GetItemScore(Item.ServerID, Item.ClassID, Item.Enchanted);
    if (Score < 0 && Preview) Score = GetItemScore(0, Item.ClassID, Item.Enchanted);
    if (Score <= 0) return;
    Row = Tip.DrawList.Length;
    Tip.DrawList.Length++;
    Tip.DrawList[Row].eType = DIT_TEXT;
    Tip.DrawList[Row].t_strText = "Gear Score: +" $ string(Score);
    Tip.DrawList[Row].nOffSetX = 3;
    Tip.DrawList[Row].nOffSetY = 4;
    Tip.DrawList[Row].t_color = Gold;
    Tip.DrawList[Row].bLineBreak = true;
    Tip.DrawList[Row].t_bDrawOneLine = true;
}
function HandleGearMessage(string Message)
{
    local string Kind, Type, Token;
    local int Row, Score;
    local UserInfo Info;
    if (Len(Message) > 8192) return;
    Fields.Length = 0;
    Split(Message, "|", Fields);
    if (Fields.Length < 2 || Fields[0] != "CustomEvent=GearScoreV1") return;
    Kind = Fields[1];
    if (Kind == "Self")
    {
        if (Fields.Length != 4) return;
        if (!GetPlayerInfo(Info) || Info.nID != int(Fields[2])) return;
        OnUpdateUserScore(int(Fields[3]));
        return;
    }
    if (Kind == "Target")
    {
        if (Fields.Length != 4) return;
        if (!GetTargetInfo(Info) || Info.bNpc || Info.nID != int(Fields[2])) return;
        LastTargetID = int(Fields[2]);
        OnUpdateTargetScore(int(Fields[3]));
        return;
    }
    if (Kind == "RankBegin")
    {
        if (Fields.Length != 6 || RankingWnd(GetScript("RankingWnd")) == None || Len(Fields[3]) == 0) return;
        Type = Fields[2];
        if (Type == "Gear")
        {
            GearToken = Fields[3];
            RankingWnd(GetScript("RankingWnd")).GearScoreList.Length = 0;
            RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRank = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRankingDiff = int(Fields[5]);
        }
        else if (Type == "PvP")
        {
            PvpToken = Fields[3];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length = 0;
            RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRank = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRankingDiff = int(Fields[5]);
        }
        return;
    }
    if (Kind == "RankRow")
    {
        if (Fields.Length != 9 || RankingWnd(GetScript("RankingWnd")) == None) return;
        if (int(Fields[8]) < 0 || int(Fields[6]) < 0 || int(Fields[6]) > 255 || Len(Fields[5]) == 0) return;
        Type = Fields[2];
        Token = Fields[3];
        if (Type == "Gear")
        {
            if (Len(GearToken) == 0 || Token != GearToken) return;
            Row = RankingWnd(GetScript("RankingWnd")).GearScoreList.Length;
            if (Row >= 200) return;
            RankingWnd(GetScript("RankingWnd")).GearScoreList.Length++;
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].RankingDiff = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].Name = Fields[5];
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].ClassId = int(Fields[6]);
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].ClanName = Fields[7];
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].Score = int(Fields[8]);
        }
        else if (Type == "PvP")
        {
            if (Len(PvpToken) == 0 || Token != PvpToken) return;
            Row = RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length;
            if (Row >= 200) return;
            RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length++;
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].RankingDiff = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].Name = Fields[5];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].ClassId = int(Fields[6]);
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].ClanName = Fields[7];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].Score = int(Fields[8]);
        }
        return;
    }
    if (Kind == "RankEnd")
    {
        if (Fields.Length != 4 || RankingWnd(GetScript("RankingWnd")) == None) return;
        Type = Fields[2];
        Token = Fields[3];
        if (Type == "Gear")
        {
            if (Len(GearToken) == 0 || Token != GearToken) return;
            GearToken = "";
        }
        else if (Type == "PvP")
        {
            if (Len(PvpToken) == 0 || Token != PvpToken) return;
            PvpToken = "";
        }
        else return;
        RankingWnd(GetScript("RankingWnd")).xxSetRankingData();
        ShowWindowWithFocus("RankingWnd");
        return;
    }
    if (Kind == "InspectBegin")
    {
        if (Fields.Length != 6 || InspectWnd(GetScript("InspectWnd")) == None || Len(Fields[2]) == 0) return;
        InspectToken = Fields[2];
        InspectWnd(GetScript("InspectWnd")).zz_PlayerNickname = Fields[3];
        InspectWnd(GetScript("InspectWnd")).zz_PlayerClassID = int(Fields[4]);
        InspectWnd(GetScript("InspectWnd")).zz_PlayerGearScore = int(Fields[5]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length = 0;
        return;
    }
    if (Kind == "InspectItem")
    {
        if (Fields.Length != 10 || InspectWnd(GetScript("InspectWnd")) == None) return;
        if (Len(InspectToken) == 0 || Fields[2] != InspectToken) return;
        Row = InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length;
        if (Row >= 64 || int(Fields[4]) <= 0 || int(Fields[9]) < 0) return;
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length++;
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].ServerID = int(Fields[3]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].ItemID = int(Fields[4]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].Enchant = int(Fields[5]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].RefineryOp1 = int(Fields[6]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].RefineryOp2 = int(Fields[7]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].SlotBitType = int(Fields[8]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].GearScore = int(Fields[9]);
        CacheItemScore(int(Fields[3]), int(Fields[4]), int(Fields[5]), int(Fields[9]));
        return;
    }
    if (Kind == "InspectEnd")
    {
        if (Fields.Length != 3 || InspectWnd(GetScript("InspectWnd")) == None) return;
        if (Len(InspectToken) == 0 || Fields[2] != InspectToken) return;
        InspectToken = "";
        InspectWnd(GetScript("InspectWnd")).xxSetInspectItens();
        return;
    }
    if (Kind == "Item")
    {
        if (Fields.Length != 6) return;
        CacheItemScore(int(Fields[2]), int(Fields[3]), int(Fields[4]), int(Fields[5]));
        return;
    }
    if (Kind == "ClearItems")
    {
        if (Fields.Length != 2) return;
        ItemScores.Length = 0;
    }
}

function MileniumGearScore getInstanceL2Util()
{
    local MileniumGearScore zz_script;
    return self;
}

function string xxGetDetailedClassIconName(int zz_ClassID, int zz_iconType)
{
	local string zz_iconSize, zz_iconPrefix;
	
	zz_iconPrefix = "MUI_GEAR.ClassMark.PlayerStatusWnd_ClassMark_";

	if (zz_iconType == 1) zz_iconSize = "_Big";
	if (zz_iconType == 2) zz_iconSize = "_Small";

	switch (zz_ClassID)
	{
		case 0:
		case 10:	//Human
			return zz_iconPrefix $ "human" $ zz_iconSize;
		break;
		case 18:
		case 25:	//Elf
			return zz_iconPrefix $ "elf" $ zz_iconSize;
		break;
		case 31:
		case 38:	//DarkElf
			return zz_iconPrefix $ "darkelf" $ zz_iconSize;
		break;
		case 44:
		case 49:	//Orc
			return zz_iconPrefix $ "orc" $ zz_iconSize;
		break;
		case 53:	//Dwarf
			return zz_iconPrefix $ "dwarf" $ zz_iconSize;
		break;
		
		default:	//Class Icon
			return zz_iconPrefix $ zz_classID $ zz_iconSize;
		break;
	}
}

function bool xxGetItemInfo( int zz_ClassID, out ItemInfo zz_info )
{
	local ItemInfo zz_clsInfo;

	zz_info = zz_clsInfo;

	if( !class'UIDATA_ITEM'.static.GetItemInfo( zz_ClassID, zz_info ) )
		return false;

	if( zz_info.PhysicalDamage > 0 || zz_info.MagicalDamage > 0 )
	{
		zz_info.ItemType = 0;
	}else if( zz_info.PhysicalDefense > 0 )
	{
		zz_info.ItemType = 1;
	}else if( zz_info.MagicalDefense > 0 )
	{
		zz_info.ItemType = 2;
	}else
	{
		zz_info.ItemType = 5;
	}

	return true;
}

function xxtoServer(string zzstr)
{
	RequestBypassToServer(zzstr);
}

defaultproperties
{
    BrightWhite=(R=255,G=255,B=255,A=255)
    BrightYellow=(R=230,G=217,B=190,A=255)
    Blue=(R=102,G=150,B=253,A=255)
    Red=(R=250,G=50,B=0,A=255)
    Gold=(R=176,G=153,B=121,A=255)
    Yellow03=(R=255,G=204,B=0,A=255)
    ColorGold=(R=176,G=153,B=121,A=255)
    ColorYellow=(R=255,G=221,B=102,A=255)
    White=(R=170,G=170,B=170,A=255)
    Gray=(R=120,G=120,B=120,A=255)
}
