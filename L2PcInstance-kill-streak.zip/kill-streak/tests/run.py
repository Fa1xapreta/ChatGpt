#!/usr/bin/env python3
"""Compile real edited methods with explicit core doubles, not the whole L2PcInstance."""
from pathlib import Path
import subprocess,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'src/net/sf/l2j/gameserver/model/actor/instance/L2PcInstance.java').read_text()
def method(signature):
 start=source.index(signature);brace=source.index('{',start);level=1;p=brace+1
 while level:
  if source[p]=='{':level+=1
  elif source[p]=='}':level-=1
  p+=1
 return source[start:p]
quake=method('public static void quake(');system=method('public void QuakeSystem(')
death=method('public boolean doDie(')
prefix=death[death.index('{')+1:death.index('if (isMounted())')]
assert prefix.index('if (!super.doDie(killer))')<prefix.index('quakeSystem = 0;')
assert source.count('quake(quakeSystem, this);')==1
sources={
'net/sf/l2j/Config.java':'''package net.sf.l2j;
public class Config { public static boolean ALLOW_QUAKE_REWARD;public static int QUAKE_REWARD_ITEM=57;public static final java.util.Map<Integer,String> QUAKE_VALUES=new java.util.LinkedHashMap<>(); }''',
'net/sf/l2j/gameserver/model/L2World.java':'''package net.sf.l2j.gameserver.model;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
public class L2World { private static final L2World I=new L2World();public static L2World getInstance(){return I;}public final java.util.List<L2PcInstance> players=new java.util.ArrayList<>();public java.util.Collection<L2PcInstance> getL2Players(){return players;} }''',
'net/sf/l2j/gameserver/util/Broadcast.java':'''package net.sf.l2j.gameserver.util;
public class Broadcast { public static final java.util.List<String> legacy=new java.util.ArrayList<>();public static void QuakeAnnounce(String text){legacy.add(text);} }''',
'net/sf/l2j/gameserver/model/actor/L2Character.java':'''package net.sf.l2j.gameserver.model.actor;
public class L2Character { public boolean acceptDeath=true;public boolean doDie(L2Character killer){return acceptDeath;} }''',
'net/sf/l2j/gameserver/model/actor/instance/FakePlayer.java':'''package net.sf.l2j.gameserver.model.actor.instance;
public class FakePlayer extends L2PcInstance { public FakePlayer(){super("Fake",true);} }''',
'net/sf/l2j/gameserver/model/actor/instance/L2PcInstance.java':'''package net.sf.l2j.gameserver.model.actor.instance;
import net.sf.l2j.Config;import net.sf.l2j.gameserver.model.L2World;import net.sf.l2j.gameserver.util.Broadcast;import net.sf.l2j.gameserver.model.actor.L2Character;
public class L2PcInstance extends L2Character {
 private static final int KILL_STREAK_ANNOUNCE_CHANNEL=18;
 private int quakeSystem=0;private boolean streak;private final String name;private final boolean online;public int rewards;
 public final java.util.List<String> messages=new java.util.ArrayList<>();public final java.util.List<Integer> channels=new java.util.ArrayList<>();
 public L2PcInstance(String name,boolean online){this.name=name;this.online=online;}
 public String getName(){return name;}public boolean isOnline(){return online;}
 public void sendChatMessage(int id,int type,String author,String text){if(id!=0||!author.isEmpty())throw new AssertionError("packet fields");channels.add(type);messages.add(text);}
 public void setKillStreak(boolean b){streak=b;}public boolean isKillStreak(){return streak;}
 public int getSequence(){return quakeSystem;}
 public void addItem(String source,int id,int count,Object owner,boolean notify){rewards+=count;}
 private final Session _treasureHuntSession=new Session();private static class Session {void finish(){}}
'''+quake+'\n'+system+'\npublic boolean doDie(L2Character killer){'+prefix+'\nif(isKillStreak())setKillStreak(false);return true;}\n}',
'KillStreakTest.java':r'''
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.*;
import net.sf.l2j.gameserver.util.Broadcast;
public class KillStreakTest {
 static void check(boolean b,String text){if(!b)throw new AssertionError(text);System.out.println("PASS: "+text);}
 public static void main(String[]args){
  L2PcInstance killer=new L2PcInstance("Killer",true),viewer=new L2PcInstance("Viewer",true),offline=new L2PcInstance("Offline",false);
  L2World.getInstance().players.add(killer);L2World.getInstance().players.add(viewer);L2World.getInstance().players.add(offline);L2World.getInstance().players.add(null);
  Config.ALLOW_QUAKE_REWARD=true;for(int n:new int[]{3,10,15,20})Config.QUAKE_VALUES.put(n,"old message "+n);
  for(int i=0;i<9;i++)killer.QuakeSystem();check(viewer.messages.isEmpty(),"no critical announcement before ten");
  killer.QuakeSystem();check(viewer.messages.size()==1&&viewer.messages.get(0).equals("Monster! Killer Killed 10 consecutive players"),"exact Monster announcement at ten");
  for(int i=10;i<20;i++)killer.QuakeSystem();
  check(viewer.messages.size()==3&&viewer.messages.get(1).equals("Legendary! Killer Killed 15 consecutive players")&&viewer.messages.get(2).equals("WTF ! Killer Killed 20 consecutive players"),"Legendary and WTF at fifteen and twenty");
  check(killer.messages.equals(viewer.messages)&&offline.messages.isEmpty(),"all online recipients receive messages; offline receives none");
  for(Integer channel:viewer.channels)check(channel==18,"critical announcement channel eighteen");
  check(Broadcast.legacy.size()==1&&Broadcast.legacy.get(0).contains("old message 3"),"other configured announcements remain, no duplicate legacy at 10/15/20");
  check(killer.rewards==4,"existing configured rewards preserved at all four thresholds");
  killer.QuakeSystem();check(viewer.messages.size()==3,"twenty-one does not repeat twentieth announcement");
  check(killer.doDie(null)&&killer.getSequence()==0&&!killer.isKillStreak(),"confirmed death ends active sequence");
  Config.QUAKE_VALUES.clear();int before=viewer.messages.size();for(int i=0;i<9;i++)killer.QuakeSystem();
  check(!killer.isKillStreak(),"no legacy flag before configured threshold");
  check(killer.doDie(null)&&killer.getSequence()==0,"death before first milestone resets even without legacy streak flag");
  for(int i=0;i<9;i++)killer.QuakeSystem();check(viewer.messages.size()==before,"new life requires ten new kills");
  killer.acceptDeath=false;check(!killer.doDie(null)&&killer.getSequence()==9,"rejected or duplicate death does not reset sequence");
  killer.QuakeSystem();check(viewer.messages.size()==before+1,"tenth kill after reset announces correctly");
  int last=viewer.messages.size();L2PcInstance.quake(99,killer);L2PcInstance.quake(10,null);check(viewer.messages.size()==last,"other thresholds and null killer send nothing");
 }
}'''
}
with tempfile.TemporaryDirectory(prefix='kill-streak-tests-') as tmp:
 root=Path(tmp);classes=root/'classes';classes.mkdir();paths=[]
 for name,text in sources.items():
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);paths.append(p)
 java=shutil.which('java')
 subprocess.run([java,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*map(str,paths)],check=True)
 subprocess.run([java,'-cp',str(classes),'KillStreakTest'],check=True)
print('PASS: real edited methods compiled at Java 8 level; isolated behavior checks passed. Full core build not performed.')
