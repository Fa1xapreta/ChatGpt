#!/usr/bin/env python3
"""Compile the complete edited L2Playable against explicit core doubles."""
from pathlib import Path
import re,subprocess,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
actual=ROOT/'src/net/sf/l2j/gameserver/model/actor/L2Playable.java'
source=actual.read_text();S={}
def put(pkg,name,body):S[pkg.replace('.','/')+'/'+name+'.java']='package '+pkg+';\n'+body
put('net.sf.l2j','Config','public class Config { public static boolean GET_SELF_ANNOUNCE=true,LEAVE_BUFFS_ON_DIE;public static String GET_SELF_MSG="was SELF"; }')
put('net.sf.l2j.gameserver.ai','CtrlEvent','public enum CtrlEvent { EVT_DEAD }')
put('net.sf.l2j.gameserver.model','L2Effect','public class L2Effect {}')
put('net.sf.l2j.gameserver.model','L2Skill','public class L2Skill {}')
put('net.sf.l2j.gameserver.model','L2WorldRegion','public class L2WorldRegion { public void onDeath(net.sf.l2j.gameserver.model.actor.L2Playable p){} }')
put('net.sf.l2j.gameserver.model','L2Clan','''public class L2Clan {
 private final String name;public final java.util.List<L2ClanMember> members=new java.util.ArrayList<>();public L2Clan(String n){name=n;}
 public String getName(){return name;}public java.util.Collection<L2ClanMember> getMembers(){return members;}
 public void add(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p){members.add(new L2ClanMember(p));if(p!=null)p.clan=this;}
}''')
put('net.sf.l2j.gameserver.model','L2ClanMember','public class L2ClanMember { private final net.sf.l2j.gameserver.model.actor.instance.L2PcInstance player;public L2ClanMember(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p){player=p;}public net.sf.l2j.gameserver.model.actor.instance.L2PcInstance getPlayerInstance(){return player;} }')
put('net.sf.l2j.gameserver.model.actor.knownlist','PlayableKnownList','public class PlayableKnownList { public PlayableKnownList(net.sf.l2j.gameserver.model.actor.L2Playable p){} }')
put('net.sf.l2j.gameserver.model.actor.stat','PlayableStat','public class PlayableStat { public PlayableStat(net.sf.l2j.gameserver.model.actor.L2Playable p){} }')
put('net.sf.l2j.gameserver.model.actor.status','PlayableStatus','public class PlayableStatus { public PlayableStatus(net.sf.l2j.gameserver.model.actor.L2Playable p){}public void stopHpMpRegeneration(){} }')
put('net.sf.l2j.gameserver.model.actor.template','CharTemplate','public class CharTemplate {}')
for sub,name in [('capturetheflag','CTFEvent'),('deathmatch','DMEvent'),('fortress','FOSEvent'),('lastman','LMEvent'),('teamvsteam','TvTEvent')]:
 put('net.sf.l2j.gameserver.model.entity.events.'+sub,name,'public class '+name+' { public static boolean onAction(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p,int id){return true;} }')
put('net.sf.l2j.gameserver.model.entity.events.tournaments.properties','ArenaConfig','public class ArenaConfig { public static boolean LOST_BUFFS_ONDIE_5X5=true,LOST_BUFFS_ONDIE_9X9=true; }')
put('net.sf.l2j.gameserver.model.quest','QuestState','public class QuestState { public Quest getQuest(){return new Quest();}public static class Quest {public void notifyDeath(net.sf.l2j.gameserver.model.actor.L2Character killer,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance target){}} }')
put('net.sf.l2j.gameserver.model.zone','ZoneId','public enum ZoneId { FLAG_AREA_SELF, LSZONE, PARTY_FARM, PVP, SIEGE }')
put('net.sf.l2j.gameserver.network','SystemMessageId','public class SystemMessageId {}')
put('net.sf.l2j.gameserver.network.serverpackets','ActionFailed','public class ActionFailed { public static final Object STATIC_PACKET=new Object(); }')
put('net.sf.l2j.gameserver.network.serverpackets','ExShowScreenMessage','public class ExShowScreenMessage { public final String text;public final int duration;public ExShowScreenMessage(String text,int duration){this.text=text;this.duration=duration;} }')
for typ in ['L2EffectFlag','L2EffectType']:
 values=sorted(set(re.findall(typ+r'\.([A-Z_]+)',source)))
 put('net.sf.l2j.gameserver.templates.skills',typ,'public enum '+typ+' { '+','.join(values)+' }')
put('net.sf.l2j.gameserver.util','Broadcast','public class Broadcast { public static final java.util.List<String> chat=new java.util.ArrayList<>();public static void SelfAnnounce(String text){chat.add(text);} }')
put('net.sf.l2j.gameserver.model.actor','L2Character','''
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.CharTemplate;
import net.sf.l2j.gameserver.model.zone.ZoneId;
public class L2Character {
 protected final int id;protected String name="NPC";private boolean dead;public int buffsRemoved;public boolean arena5,arena9;
 private Object known,stat,status;public final java.util.Set<ZoneId> zones=new java.util.HashSet<>();
 public L2Character(int id,CharTemplate t){this.id=id;initKnownList();initCharStat();initCharStatus();}
 public void initKnownList(){}public void initCharStat(){}public void initCharStatus(){}
 public void setKnownList(Object o){known=o;}public Object getKnownList(){return known;}
 public void setStat(Object o){stat=o;}public Object getStat(){return stat;}
 public void setStatus(Object o){status=o;}public Object getStatus(){return status;}
 public void onActionShift(L2PcInstance p){}public boolean doDie(L2Character killer){return true;}
 public int getObjectId(){return id;}public String getName(){return name;}public boolean isDead(){return dead;}
 public void setCurrentHp(double hp){}public void setIsDead(boolean b){dead=b;}public void setTarget(Object o){}public void stopMove(Object o){}
 public void stopAllEffectsExceptThoseThatLastThroughDeath(){buffsRemoved++;}
 public boolean isArena5x5(){return arena5;}public boolean isArena9x9(){return arena9;}
 public boolean isInsideZone(ZoneId z){return zones.contains(z);}public boolean isInArena(){return false;}
 public void broadcastStatusUpdate(){}public void sendPacket(Object p){}public boolean isAttackable(){return true;}
 public net.sf.l2j.gameserver.model.L2WorldRegion getWorldRegion(){return null;}
 public L2PcInstance getActingPlayer(){return null;}
 public AI getAI(){return new AI();}public static class AI {public void notifyEvent(net.sf.l2j.gameserver.ai.CtrlEvent e){}}
 protected final Effects _effects=new Effects();
 public void effect(net.sf.l2j.gameserver.templates.skills.L2EffectFlag f){_effects.flags.add(f);}
 public static class Effects {final java.util.Set<net.sf.l2j.gameserver.templates.skills.L2EffectFlag> flags=new java.util.HashSet<>();public boolean isAffected(net.sf.l2j.gameserver.templates.skills.L2EffectFlag f){return flags.contains(f);}public void updateEffectIcons(boolean b){}}
 public void stopEffects(net.sf.l2j.gameserver.templates.skills.L2EffectType t){}public void removeEffect(net.sf.l2j.gameserver.model.L2Effect e){}public void updateAbnormalEffect(){}
 public void updateEffectIcons(boolean b){}
}''')
put('net.sf.l2j.gameserver.model.actor.instance','L2PcInstance','''
import net.sf.l2j.gameserver.model.actor.*;import net.sf.l2j.gameserver.model.actor.template.CharTemplate;
public class L2PcInstance extends L2Playable {
 public net.sf.l2j.gameserver.model.L2Clan clan;public boolean online=true;public final java.util.List<Object> packets=new java.util.ArrayList<>();
 public L2PcInstance(int id,String n){super(id,new CharTemplate());name=n;}
 @Override public L2PcInstance getActingPlayer(){return this;}public net.sf.l2j.gameserver.model.L2Clan getClan(){return clan;}public boolean isOnline(){return online;}
 @Override public void sendPacket(Object packet){packets.add(packet);}
 public Object target;public Object getTarget(){return target;}@Override public void setTarget(Object o){target=o;}
 public java.util.Collection<net.sf.l2j.gameserver.model.quest.QuestState> getNotifyQuestOfDeath(){return java.util.Collections.emptyList();}
 public static boolean simulateHp;
 public void onKillUpdatePvPKarma(L2Playable target){if(simulateHp && target instanceof L2PcInstance)((L2PcInstance)target).sendPacket(new net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage("HP notification",4000));}
 @Override public int getKarma(){return 0;}@Override public byte getPvpFlag(){return 0;}@Override public boolean useMagic(net.sf.l2j.gameserver.model.L2Skill s,boolean f,boolean d){return false;}
}''')
put('phantom','FakePlayer','public class FakePlayer extends net.sf.l2j.gameserver.model.actor.instance.L2PcInstance {public FakePlayer(int id,String name){super(id,name);} }')
S['SelfMessageTest.java']=r'''
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.*;
import net.sf.l2j.gameserver.model.actor.*;
import net.sf.l2j.gameserver.model.actor.instance.*;
import net.sf.l2j.gameserver.model.actor.template.CharTemplate;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.util.Broadcast;
public class SelfMessageTest {
 static int next=1;
 static L2PcInstance player(String name){return new L2PcInstance(next++,name);}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);System.out.println("PASS: "+m);}
 static void self(L2PcInstance p){p.zones.add(ZoneId.FLAG_AREA_SELF);}
 static String text(L2PcInstance p){check(p.packets.size()==1,"one screen packet for "+p.getName());ExShowScreenMessage msg=(ExShowScreenMessage)p.packets.get(0);check(msg.duration==6000,"six-second duration for "+p.getName());return msg.text;}
 static class Pet extends L2Playable {
  final L2PcInstance owner;Pet(L2PcInstance p){super(next++,new CharTemplate());owner=p;name="Pet";}
  @Override public L2PcInstance getActingPlayer(){return owner;}
  @Override public int getKarma(){return 0;}@Override public byte getPvpFlag(){return 0;}@Override public boolean useMagic(L2Skill s,boolean f,boolean d){return false;}
 }
 public static void main(String[] args){
  L2PcInstance killer=player("Killer"),victim=player("Victim"),ally=player("Ally"),mate=player("Mate"),offline=player("Offline");offline.online=false;
  L2Clan kc=new L2Clan("Attackers"),vc=new L2Clan("Victims");kc.add(killer);kc.add(ally);vc.add(victim);vc.add(mate);vc.add(offline);vc.members.add(null);vc.members.add(new L2ClanMember(null));
  self(victim);check(victim.doDie(killer),"death succeeds with new messages");
  check(text(victim).equals("You was SELF !"),"victim gets personal SELF notice");
  check(text(killer).equals("Victim was SELF !"),"killer gets victim notice");
  check(text(ally).equals("A Clan member Killer left Victim was SELF !"),"killer clan uses actual killer name");
  check(text(mate).equals("A Clan member Victim was SELF !"),"victim clan gets member notice");
  check(offline.packets.isEmpty(),"offline clan member receives nothing");
  check(Broadcast.chat.isEmpty(),"no global SYS SELF chat message");
  check(!victim.doDie(killer)&&victim.packets.size()==1&&Broadcast.chat.isEmpty(),"duplicate death cannot repeat notifications");
  killer=player("NoClanKiller");victim=player("NoClanVictim");self(victim);victim.doDie(killer);check(text(killer).equals("NoClanVictim was SELF !")&&text(victim).equals("You was SELF !"),"players without clans still get personal messages");
  killer=player("SameKiller");victim=player("SameVictim");mate=player("Shared");L2Clan shared=new L2Clan("SharedClan");shared.add(killer);shared.add(victim);shared.add(mate);self(victim);victim.doDie(killer);
  check(text(killer).equals("SameVictim was SELF !")&&text(victim).equals("You was SELF !"),"same-clan participants keep their personal messages");check(text(mate).equals("A Clan member SameVictim was SELF !"),"shared-clan observer gets one victim-priority notice");
  victim=player("Environment");mate=player("EnvironmentMate");vc=new L2Clan("Env");vc.add(victim);vc.add(mate);self(victim);victim.doDie(null);check(text(victim).equals("You was SELF !")&&text(mate).contains("Environment"),"null killer still safely notifies victim and victim clan");
  victim=player("NpcDeath");self(victim);victim.doDie(new L2Character(next++,new CharTemplate()));check(text(victim).equals("You was SELF !"),"NPC killer does not require player cast");
  victim=player("OwnDeath");self(victim);victim.doDie(victim);check(text(victim).equals("You was SELF !"),"self-inflicted death produces one personal notice");
  killer=player("Summoner");victim=player("PetVictim");self(victim);victim.doDie(new Pet(killer));check(text(killer).equals("PetVictim was SELF !"),"summon killer is attributed to its owner");
  L2PcInstance owner=player("Owner");Pet pet=new Pet(owner);pet.zones.add(ZoneId.FLAG_AREA_SELF);pet.doDie(null);check(owner.packets.isEmpty(),"pet death does not send owner a personal SELF notice");
  victim=player("Disabled");self(victim);Config.GET_SELF_ANNOUNCE=false;int before=Broadcast.chat.size();victim.doDie(null);check(victim.packets.isEmpty()&&Broadcast.chat.size()==before&&victim.buffsRemoved==1,"disabled announcement keeps buff-removal behavior but sends no notices");Config.GET_SELF_ANNOUNCE=true;
  victim=player("Ordinary");victim.doDie(null);check(victim.packets.isEmpty(),"ordinary death outside existing SELF paths is unchanged");
  Config.LEAVE_BUFFS_ON_DIE=true;victim=player("GlobalRule");victim.doDie(null);check(text(victim).equals("You was SELF !"),"existing global-config SELF path is supported");Config.LEAVE_BUFFS_ON_DIE=false;
  victim=player("Blessed");self(victim);victim.effect(net.sf.l2j.gameserver.templates.skills.L2EffectFlag.NOBLESS_BLESSING);victim.doDie(null);check(victim.packets.isEmpty()&&victim.buffsRemoved==0,"noblesse branch retains original precedence over SELF paths");
  phantom.FakePlayer fake=new phantom.FakePlayer(next++,"Fake");fake.zones.add(ZoneId.FLAG_AREA_SELF);fake.doDie(killer);check(fake.packets.isEmpty(),"fake victim does not receive new screen notices");
  killer=player("HpKiller");victim=player("HpVictim");self(victim);L2PcInstance.simulateHp=true;victim.doDie(killer);L2PcInstance.simulateHp=false;
  check(victim.packets.size()==2&&((ExShowScreenMessage)victim.packets.get(1)).text.equals("You was SELF !"),"SELF is sent after the kill callback HP popup");
  for(int mode=0;mode<5;mode++){
   victim=player("Path"+mode);if(mode==0)victim.arena5=true;else if(mode==1)victim.arena9=true;else if(mode==2)victim.zones.add(ZoneId.LSZONE);else if(mode==3)victim.zones.add(ZoneId.PARTY_FARM);else victim.zones.add(ZoneId.FLAG_AREA_SELF);
   victim.doDie(null);check(text(victim).equals("You was SELF !"),"existing SELF path "+mode+" delivers notice");
  }
 }
}'''
assert source.count('announceSelf(killer);')==1 and source.count('selfNotification = true;')==6
assert source.index('player.onKillUpdatePvPKarma(this);') < source.index('announceSelf(killer);')
with tempfile.TemporaryDirectory(prefix='self-messages-') as tmp:
 t=Path(tmp);classes=t/'classes';classes.mkdir();paths=[]
 for name,body in S.items():
  p=t/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body);paths.append(p)
 java=shutil.which('java')
 subprocess.run([java,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),str(actual),*map(str,paths)],check=True)
 subprocess.run([java,'-cp',str(classes),'SelfMessageTest'],check=True)
print('PASS: complete edited L2Playable compiled at Java 8 level against explicit core doubles; behavior tests passed. Full production-core build not performed.')
