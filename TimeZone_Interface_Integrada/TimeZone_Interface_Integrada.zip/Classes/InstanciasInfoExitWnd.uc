//================================================================================
// InstanciasInfoExitWnd - Janela para informações e saída de instância.
// Bypass: timezone_toggle
//   - Dentro da Time Instance → Exit → Giran
//   - Fora → Enter (somente cidade/vila; ticket/tempo no servidor)
//================================================================================

class InstanciasInfoExitWnd extends MileniumTimeZoneAPI;

var private WindowHandle MainWnd;
var private ButtonHandle BtnEspadas;
var private ButtonHandle BtnExit;
var private string LastBypass;
var private bool bInTimeInstance; // true = botão Exit; false = Enter

// Ao carregar a janela, registra os eventos e pega os handles dos botões
function OnLoad()
{
    RegisterEvent(55562); // timer
    RegisterEvent(55563); // Enter/Exit mode

    MainWnd = GetHandle("InstanciasInfoExitWnd");
    BtnEspadas = ButtonHandle(GetHandle("InstanciasInfoExitWnd.BtnEspadas"));
    BtnExit = ButtonHandle(GetHandle("InstanciasInfoExitWnd.BtnExit"));
    // Click visual: normal / pushed / over (Blessing TimeZoneButton Down+Over)
    BtnEspadas.SetTexture(
        "MUI_TBT.SideBarWnd.SideBar_TimeZoneIcon",
        "MUI_TZONE.TimeZoneWnd.TimeZoneWnd_TimeZoneButton_Down",
        "MUI_TZONE.TimeZoneWnd.TimeZoneWnd_TimeZoneButton_Over");
    bInTimeInstance = False;
    SetEnterExitButton(False);
    return;
}

// Evento recebido do servidor/cliente
function OnEvent(private int EventID, private string Param)
{
    switch (EventID)
    {
        case 55562: // Atualiza temporizador
            xxTimeLeft(Param);
            break;
        case 55563: // 1 = Exit (dentro), 0 = Enter (fora)
            xxButtonMode(Param);
            break;
        default:
            break;
    }
    return;
}

function xxButtonMode(string zzparam)
{
    local int zzMode;
    ParseInt(zzparam, "TimeHunting", zzMode);
    SetEnterExitButton(zzMode == 1);
}

function SetEnterExitButton(bool inInstance)
{
    bInTimeInstance = inInstance;
    if (inInstance)
    {
        BtnExit.SetButtonName(1459); // Exit
        BtnExit.SetTooltipCustomType(CreateTooltip("Exit"));
    }
    else
    {
        BtnExit.SetButtonName(423); // Enter
        BtnExit.SetTooltipCustomType(CreateTooltip("Enter"));
    }
}

// Atualiza o tooltip do botão com o nome da instância
function UpdateTooltip(private string Param)
{
    local private string Name;
    ParseString(Param, "Name", Name);
    Name = ReplaceText(Name, "-", " ");
    BtnEspadas.SetTooltipCustomType(CreateTooltip(Name));
    return;
}

// Atualiza o comando de bypass para sair da instância
function UpdateBypass(private string Param)
{
    local private int Bypass;
    ParseInt(Param, "Bypass", Bypass);
    LastBypass = "lotusdk LotusEx " $ string(Bypass);
    return;
}

// Atualiza informações da janela (tempo, nome, bypass)
function UpdateInfo(private string Param)
{
    local private string TimeLeft, Name, Bypass;

    ParseString(Param, "timeleft", TimeLeft);
    ParseString(Param, "name", Name);
    ParseString(Param, "bypass", Bypass);

    TimeLeft = ReplaceText(TimeLeft, "_", " ");
    Name = ReplaceText(Name, "_", " ");
    Bypass = ReplaceText(Bypass, "_", " ");

    BtnEspadas.SetTooltipCustomType(CreateTooltip(Name));
    BtnEspadas.SetButtonName(423); // Nome alternativo para botão
    BtnEspadas.SetTooltipCustomType(CreateTooltip("Enter"));

    LastBypass = Bypass;
    Class'UIAPI_TEXTBOX'.static.SetText("InstanciasInfoExitWnd.TimeExit", TimeLeft);

    if (!IsShowWindow("InstanciasInfoExitWnd"))
        ShowWindow("InstanciasInfoExitWnd");
}

// Atualiza o texto do tempo restante
function UpdateTimeLeft(private string Param)
{
    local private string TimeLeft, InstanceName;
    ParseString(Param, "IN", TimeLeft);
    ParseString(Param, "INAM", InstanceName);

    TimeLeft = ReplaceText(TimeLeft, "-", " ");
    Class'UIAPI_TEXTBOX'.static.SetText("InstanciasInfoExitWnd.TimeExit", TimeLeft);

    BtnEspadas.SetButtonName(1459);
    BtnEspadas.SetTooltipCustomType(CreateTooltip("Exit Instance"));
    BtnEspadas.SetTooltipCustomType(CreateTooltip(InstanceName));

    if (!IsShowWindow("InstanciasInfoExitWnd"))
        ShowWindow("InstanciasInfoExitWnd");
}

// Formata o tempo da instância e mostra na janela
function ShowTimeLeft(private string Param)
{
    local private int TimeInstance, InstanceId;
    local private int Hours, Minutes, Seconds;
    local private string TimeText;

    ParseInt(Param, "TimeInstance", TimeInstance);
    ParseInt(Param, "InstanceId", InstanceId);
    TimeInstance = TimeInstance / 1000; // Converte ms pra segundos

    if (TimeInstance < 60)
        TimeText = string(TimeInstance) $ "s";
    else if (TimeInstance < 3600)
    {
        Minutes = TimeInstance / 60;
        Seconds = TimeInstance % 60;
        TimeText = string(Minutes) $ "m " $ string(Seconds) $ "s";
    }
    else
    {
        Hours = TimeInstance / 3600;
        Minutes = (TimeInstance % 3600) / 60;
        Seconds = TimeInstance % 60;
        TimeText = string(Hours) $ "h " $ string(Minutes) $ "m " $ string(Seconds) $ "s";
    }

    Class'UIAPI_TEXTBOX'.static.SetText("InstanciasInfoExitWnd.TimeExit", TimeText);

    // Atualiza outros contadores em outras janelas, se necessário
    switch (InstanceId)
    {
        case 1013:
            Class'UIAPI_TEXTBOX'.static.SetText("SuperiorInstancesWnd.Instance2PVP.TimePvPCount", TimeText);
            break;
        case 1014:
            Class'UIAPI_TEXTBOX'.static.SetText("SuperiorInstancesWnd.Instance3Solo.TimeSoloCount", TimeText);
            break;
        case 1015:
            Class'UIAPI_TEXTBOX'.static.SetText("SuperiorInstancesWnd.Instance1PVE.TimePvECount", TimeText);
            break;
        case 1016:
            Class'UIAPI_TEXTBOX'.static.SetText("SuperiorInstancesWnd.Instance4PVP.TimeLairPvPCount", TimeText);
            break;
        default:
            break;
    }
    ShowWindow("InstanciasInfoExitWnd");
}
function xxTimeLeft(string zzparam)
{
    local int zzTimePvE;
    local int zzhours;
    local int zzminutes;
    local int zzseconds;
    local string zzdurationString;
    local int zzremainingTimeSeconds;
    local Color zzTextColor;
    local string strHours, strMinutes, strSeconds;

    // Converte o parâmetro para inteiro (milissegundos)
    ParseInt(zzparam, "TimeHunting", zzTimePvE);
    zzremainingTimeSeconds = zzTimePvE / 1000;

    // Calcula horas, minutos e segundos
    zzhours   = zzremainingTimeSeconds / 3600;
    zzminutes = (zzremainingTimeSeconds % 3600) / 60;
    zzseconds = zzremainingTimeSeconds % 60;

    // Formata com zero à esquerda
    if (zzhours < 10)
        strHours = "0" $ string(zzhours);
    else
        strHours = string(zzhours);

    if (zzminutes < 10)
        strMinutes = "0" $ string(zzminutes);
    else
        strMinutes = string(zzminutes);

    if (zzseconds < 10)
        strSeconds = "0" $ string(zzseconds);
    else
        strSeconds = string(zzseconds);

    // Mostra como "Time Left: HH:MM:SS" ou "Time Left: MM:SS" (igual label do XDAT Blessing)
    if (zzhours > 0)
        zzdurationString = "Time Left: " $ strHours $ ":" $ strMinutes $ ":" $ strSeconds;
    else
        zzdurationString = "Time Left: " $ strMinutes $ ":" $ strSeconds;

    // Define cor conforme o tempo restante
    if (zzremainingTimeSeconds > 300) // mais de 5 min
    {
        zzTextColor.R = 0;
        zzTextColor.G = 255;
        zzTextColor.B = 0; // verde
    }
    else if (zzremainingTimeSeconds > 180) // entre 3 e 5 min
    {
        zzTextColor.R = 255;
        zzTextColor.G = 255;
        zzTextColor.B = 0; // amarelo
    }
    else
    {
        zzTextColor.R = 255;
        zzTextColor.G = 0;
        zzTextColor.B = 0; // vermelho
    }
    zzTextColor.A = 255;

    // Atualiza texto e cor na interface
    Class'UIAPI_TEXTBOX'.static.SetText("InstanciasInfoExitWnd.TimeExit", zzdurationString);
    Class'UIAPI_TEXTBOX'.static.SetTextColor("InstanciasInfoExitWnd.TimeExit", zzTextColor);

    if (!IsShowWindow("InstanciasInfoExitWnd"))
        ShowWindow("InstanciasInfoExitWnd");
}


// Envia o comando para o servidor (sair / entrar na Time Instance)
function SendExitCommand()
{
    RequestBypassToServer("timezone_toggle");
}

// Quando clica no botão
function OnClickButton(private string BtnName)
{
    switch (BtnName)
    {
    case "BtnExit":
        PlaySound("InterfaceSound.system_open_01");
        SendExitCommand();
        break;
    case "BtnEspadas":
        // Open/close Time Instance panel (TimeZoneWnd); HUD BtnExit still toggles enter/exit.
        if (IsShowWindow("TimeZoneWnd"))
        {
            PlaySound("InterfaceSound.system_close_01");
            HideWindow("TimeZoneWnd");
        }
        else
        {
            PlaySound("InterfaceSound.system_open_01");
            ShowWindowWithFocus("TimeZoneWnd");
            RequestBypassToServer("lotusdk RefreshPassInfo");
        }
        break;
    default:
        break;
    }

    return;
}

// Cria um tooltip simples para o botão
function CustomTooltip CreateTooltip(string Text)
{
    local CustomTooltip TT;
    local DrawItemInfo Info;

    TT.DrawList.Length = 1;
    Info.eType = DIT_TEXT;
    Info.t_strText = Text;
    TT.DrawList[0] = Info;
    return TT;
}
