/*******************************************************************************
 * TimeZoneWnd — Blessing MVP panel for Time Instance (4 spots).
 * Layout from Revolution XDAT; logic wired to lotusdk bypasses.
 *******************************************************************************/
class TimeZoneWnd extends MileniumTimeZoneAPI;

const EVT_REFRESH = 77750;

var bool TZClickGuard;
var WindowHandle Me;
var TextBoxHandle TitleTxt;
var TextBoxHandle PageCurrTxt;
var TextBoxHandle PageNextTxt;
var int LastSeconds;
var int LastItemId;
var int LastNeedCount;
var string LastItemName;
var bool bInside;

function OnLoad()
{
    RegisterEvent(77750); RegisterEvent(140); RegisterEvent(94600); RegisterEvent(160);
    Me = GetHandle("TimeZoneWnd");
    TitleTxt = TextBoxHandle(GetHandle("TimeZoneWnd.TitleInterface"));
    PageCurrTxt = TextBoxHandle(GetHandle("TimeZoneWnd.PageNaviControl.ControlNavi_CurrPageText"));
    PageNextTxt = TextBoxHandle(GetHandle("TimeZoneWnd.PageNaviControl.ControlNavi_NextPageText"));
    InitStaticCards();
    TitleTxt.SetText("Time Instance");
}

function OnShow()
{
	RequestBypassToServer("lotusdk RefreshPassInfo");
	return;
}

function OnEvent(int EventID, string Param)
{
	local string payload;
	local array<string> parts;

	if (TZNativeEvent(EventID, Param)) return;
	if( EventID != EVT_REFRESH )
		return;

	ParseString(Param, "CustomEvent", payload);
	Split(payload, "|", parts);
	if( parts.Length < 1 )
		return;

	if( parts[0] == "77750Refresh" )
		ApplyRefresh(parts);
	else if( parts[0] == "77750Open" )
		ShowWindowWithFocus("TimeZoneWnd");
	return;
}

function ApplyRefresh(array<string> parts)
{
	local string timeStr;
	local int i;

	// 77750Refresh|seconds|itemId|needCount|inside|itemName|name1|name2|name3|name4
	if( parts.Length < 5 )
		return;

	LastSeconds = int(parts[1]);
	LastItemId = int(parts[2]);
	LastNeedCount = int(parts[3]);
	bInside = (parts[4] == "1");
	LastItemName = "";
	if( parts.Length > 5 )
		LastItemName = parts[5];

	timeStr = FormatSeconds(LastSeconds);
	if( TitleTxt != None )
		TitleTxt.SetText("Time Instance");
	if( PageCurrTxt != None )
		PageCurrTxt.SetText("4");
	if( PageNextTxt != None )
		PageNextTxt.SetText("4");

	for( i = 0; i < 4; i++ )
	{
		SetCardTexts(i, timeStr);
		if( parts.Length > (6 + i) && parts[6 + i] != "" )
			SetCardName(i, parts[6 + i]);
		SetCardMeta(i, "Spot " $ string(i + 1), SpotTypeLabel(i), "OPEN");
		UpdateEnterExitButtons(i);
		SetCardCost(i);
	}
	return;
}

function string SpotTypeLabel(int idx)
{
	switch( idx )
	{
		case 0:
			return "GATE";
		case 1:
			return "NORTH";
		case 2:
			return "EAST";
		case 3:
			return "WEST";
	}
	return "PVE";
}

function SetCardCost(int idx)
{
	local ItemWindowHandle iw;
	local TextBoxHandle nameTb, countTb;
	local ItemInfo item;
	local string shownName;

	if( LastItemId <= 0 )
		return;

	iw = ItemWindowHandle(GetHandle(RendererPath(idx) $ ".ItemNeedW"));
	nameTb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ItemNameText"));
	countTb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ItemCountText"));

	Class'UIDATA_ITEM'.static.GetItemInfo(LastItemId, item);
	item.ItemNum = 1;
	item.bShowCount = False;
	item.Enchanted = 0;
	if( iw != None )
	{
		iw.Clear();
		iw.AddItem(item);
	}

	shownName = LastItemName;
	if( shownName == "" )
		shownName = Class'UIDATA_ITEM'.static.GetItemName(LastItemId);
	if( shownName == "" )
		shownName = "Item #" $ string(LastItemId);

	if( nameTb != None )
		nameTb.SetText(shownName);
	if( countTb != None )
		countTb.SetText("x" $ string(LastNeedCount));
	return;
}

function InitStaticCards()
{
	local int i;
	SetCardName(0, "Spot 1 - Gate");
	SetCardName(1, "Spot 2 - North");
	SetCardName(2, "Spot 3 - East");
	SetCardName(3, "Spot 4 - West");
	for( i = 0; i < 4; i++ )
	{
		SetCardMeta(i, "Spot " $ string(i + 1), SpotTypeLabel(i), "OPEN");
		UpdateEnterExitButtons(i);
	}
	if( PageCurrTxt != None )
		PageCurrTxt.SetText("4");
	if( PageNextTxt != None )
		PageNextTxt.SetText("4");
	ApplyCardImages();
	return;
}

/** Preview art: keep XDAT Lotus path (World_Special_field_29). Custom SetTexture fought ZoneImg UV. */
function ApplyCardImages()
{
    // Preview textures come from the original XDAT, without a runtime override.
    return;
}

function string RendererPath(int idx)
{
	return "TimeZoneWnd.ScrollAreaWnd.itemRenderer0" $ string(idx);
}

function SetCardName(int idx, string zoneName)
{
	local TextBoxHandle tb;
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ZoneNameTitle_Text"));
	if( tb != None )
		tb.SetText(zoneName);
	return;
}

function SetCardMeta(int idx, string lv, string playType, string openTitle)
{
	local TextBoxHandle tb;
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ZoneLV_Text"));
	if( tb != None )
		tb.SetText(lv);
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ZonePlayType_Text"));
	if( tb != None )
		tb.SetText(playType);
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".ZoneOpenTitle_Text"));
	if( tb != None )
		tb.SetText(openTitle);
	return;
}

function SetCardTexts(int idx, string timeStr)
{
	local TextBoxHandle tb;
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".TimeZoneTimeNow_Txt"));
	if( tb != None )
		tb.SetText(timeStr);
	tb = TextBoxHandle(GetHandle(RendererPath(idx) $ ".TimeZoneTimeNowTitle_Txt"));
	if( tb != None )
		tb.SetText("Time Left");
	return;
}

function UpdateEnterExitButtons(int idx)
{
    if (idx == 0)
    {
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1")).SetButtonName(423);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").SetTooltipText("Enter Spot 1");
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1")).SetButtonName(1459);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").SetTooltipText("Exit Time Instance");
        if (bInside) { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").DisableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").EnableWindow(); }
        else { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZEnter1").EnableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer00.TZExit1").DisableWindow(); }
        return;
    }
    if (idx == 1)
    {
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2")).SetButtonName(423);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").SetTooltipText("Enter Spot 2");
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2")).SetButtonName(1459);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").SetTooltipText("Exit Time Instance");
        if (bInside) { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").DisableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").EnableWindow(); }
        else { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZEnter2").EnableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer01.TZExit2").DisableWindow(); }
        return;
    }
    if (idx == 2)
    {
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3")).SetButtonName(423);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").SetTooltipText("Enter Spot 3");
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3")).SetButtonName(1459);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").SetTooltipText("Exit Time Instance");
        if (bInside) { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").DisableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").EnableWindow(); }
        else { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZEnter3").EnableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer02.TZExit3").DisableWindow(); }
        return;
    }
    if (idx == 3)
    {
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4")).SetButtonName(423);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").SetTooltipText("Enter Spot 4");
        ButtonHandle(GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4")).SetButtonName(1459);
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").SetTooltipType("Text");
        GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").SetTooltipText("Exit Time Instance");
        if (bInside) { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").DisableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").EnableWindow(); }
        else { GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").ShowWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZEnter4").EnableWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").HideWindow(); GetHandle("TimeZoneWnd.ScrollAreaWnd.itemRenderer03.TZExit4").DisableWindow(); }
        return;
    }

}

function CustomTooltip MakeSimpleTooltip(string Text)
{
	local CustomTooltip TT;
	local DrawItemInfo Info;

	TT.DrawList.Length = 1;
	Info.eType = DIT_TEXT;
	Info.t_strText = Text;
	Info.t_bDrawOneLine = True;
	TT.DrawList[0] = Info;
	return TT;
}

function string FormatSeconds(int totalSec)
{
	local int m, s;
	if( totalSec <= 0 )
		return "00:00";
	m = totalSec / 60;
	s = totalSec % 60;
	if( m < 10 )
	{
		if( s < 10 )
			return "0" $ string(m) $ ":0" $ string(s);
		return "0" $ string(m) $ ":" $ string(s);
	}
	if( s < 10 )
		return string(m) $ ":0" $ string(s);
	return string(m) $ ":" $ string(s);
}

function OnClickButton(string BtnName)
{
    if (TZClickGuard) return;
    if (BtnName == "TZEnter1") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusIN 1"); PlaySound("InterfaceSound.system_open_01"); return; }
    if (BtnName == "TZExit1") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusEx"); PlaySound("InterfaceSound.system_close_01"); return; }
    if (BtnName == "TZEnter2") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusIN 2"); PlaySound("InterfaceSound.system_open_01"); return; }
    if (BtnName == "TZExit2") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusEx"); PlaySound("InterfaceSound.system_close_01"); return; }
    if (BtnName == "TZEnter3") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusIN 3"); PlaySound("InterfaceSound.system_open_01"); return; }
    if (BtnName == "TZExit3") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusEx"); PlaySound("InterfaceSound.system_close_01"); return; }
    if (BtnName == "TZEnter4") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusIN 4"); PlaySound("InterfaceSound.system_open_01"); return; }
    if (BtnName == "TZExit4") { TZClickGuard=True; Me.SetTimer(8177750,250); RequestBypassToServer("lotusdk LotusEx"); PlaySound("InterfaceSound.system_close_01"); return; }

}

function OnClickButtonWithHandle(ButtonHandle aButtonHandle)
{
    if (aButtonHandle != None) OnClickButton(aButtonHandle.GetWindowName());
}

function int SpotFromRenderer(string parentName)
{
	local int idx;
	if( InStr(parentName, "itemRenderer0") >= 0 )
	{
		idx = int(Right(parentName, 1));
		return idx + 1;
	}
	return 1;
}

function OnTimer(int TimerID)
{
    if (TimerID != 8177750) return;
    TZClickGuard=False; Me.KillTimer(8177750);
}
function OnHide() { TZClickGuard=False; Me.KillTimer(8177750); }
function OnReceivedCloseUI() { TZClickGuard=False; Me.KillTimer(8177750); Me.HideWindow(); }
function OnEnterState(name PrevState) { Me.HideWindow(); GetHandle("InstanciasInfoExitWnd").HideWindow(); }
function bool TZNativeEvent(int EventID, string Param)
{
    local string Message;
    local array<string> Parts;
    if (EventID == 160) { Me.HideWindow(); GetHandle("InstanciasInfoExitWnd").HideWindow(); return True; }
    if (EventID == 140) { if (!ParseString(Param,"Msg",Message)) return False; }
    else { if (EventID != 94600) return False; if (!ParseString(Param,"Payload",Message)) return False; }
    if (Len(Message) >= 8193) return False;
    MileniumGearScore(GetScript("MileniumGearScore")).GearSplit(Message,"|",Parts);
    if (Parts.Length == 0) return False;
    if (Parts[0] == "CustomEvent=77750Refresh") { if (Parts.Length < 5) return False; ApplyRefresh(Parts); return True; }
    if (Parts[0] == "CustomEvent=77750Open") { ShowWindowWithFocus("TimeZoneWnd"); return True; }
    if (Parts[0] == "CustomEvent=TimeZoneTimer")
    {
        if (Parts.Length < 3) return False;
        bInside = int(Parts[2]) == 1;
        LastSeconds = int(Parts[1]) / 1000;
        SetCardTexts(0,FormatSeconds(LastSeconds)); UpdateEnterExitButtons(0);
        SetCardTexts(1,FormatSeconds(LastSeconds)); UpdateEnterExitButtons(1);
        SetCardTexts(2,FormatSeconds(LastSeconds)); UpdateEnterExitButtons(2);
        SetCardTexts(3,FormatSeconds(LastSeconds)); UpdateEnterExitButtons(3);
        ExecuteEvent(55562,"TimeHunting=" $ Parts[1]);
        ExecuteEvent(55563,"TimeHunting=" $ Parts[2]);
        return True;
    }
    return False;
}
