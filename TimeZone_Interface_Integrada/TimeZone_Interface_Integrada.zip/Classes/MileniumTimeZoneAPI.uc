class MileniumTimeZoneAPI extends UICommonAPI;
