package net.sf.l2j.gameserver.taskmanager.tasks;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.custom.TimeZoneUI;
import net.sf.l2j.gameserver.instancemanager.custom.TimeInstanceManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;

/** At most one HUD timer per player, stopped after logout or zone exit. */
public class TimeInstanceRemainTaskManager implements Runnable
{
    private static final ConcurrentMap<Integer,TimeInstanceRemainTaskManager> ACTIVE=new ConcurrentHashMap<>();
    private final int objectId;
    public TimeInstanceRemainTaskManager(L2PcInstance player)
    {
        objectId=player.getObjectId();
        if (ACTIVE.putIfAbsent(objectId,this)==null)
            ThreadPoolManager.getInstance().scheduleGeneral(this,1000);
    }
    @Override public void run()
    {
        L2PcInstance player=L2World.getInstance().getPlayer(objectId);
        boolean again=false;
        try
        {
            if (player==null || !player.isOnline()) return;
            boolean inside=player.isInsideZone(ZoneId.TIME_INSTANCE_ZONE);
            TimeZoneUI.timer(player,TimeInstanceManager.getRemainingMillis(player),inside);
            again=inside;
        }
        finally
        {
            if (again) ThreadPoolManager.getInstance().scheduleGeneral(this,1000);
            else ACTIVE.remove(objectId,this);
        }
    }
}
