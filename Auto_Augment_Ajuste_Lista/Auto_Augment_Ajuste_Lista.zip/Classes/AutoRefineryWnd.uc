class AutoRefineryWnd extends MileniumAugmentAPI;

const REF_CAT_COUNT = 4;

var WindowHandle zz_Me;

var ButtonHandle zz_AutoRefToggleButton;

var TreeHandle zz_SkillList;

var ToolTipHandle zz_RefToolTipHandle;

var string strRefCategory[REF_CAT_COUNT];

var bool zz_AutoRefStatus;

enum RefCategory {
    REF_PASSIVE,
    REF_ACTIVE,
    REF_CHANCE,
    REF_STATS,
};

struct RefSkills {
    var RefCategory RefCat;
    var array<int> RefID;
    var string RefName;
    var string RefIcon;
    var bool Selected;
};

var array<RefSkills> RefinerySkills;
var array<int> SelectedRefinerySkills;


function OnLoad() {
    zz_Me = xxGetWindowHandle("AutoRefineryWnd");
    zz_AutoRefToggleButton = xxGetButtonHandle("AutoRefineryWnd.AutoRefinery_Toggle");

    zz_SkillList = class'TreeHandle'.static.Inst();

    zz_SkillList.Init("AutoRefineryWnd.SkillsTree", "tree_skills", 256, 38, class'TreeHandle'.default.TablesPosition);
    zz_RefToolTipHandle = class'ToolTipHandle'.static.Inst();

    strRefCategory[RefCategory.REF_PASSIVE] = "passive";
    strRefCategory[RefCategory.REF_ACTIVE] = "active";
    strRefCategory[RefCategory.REF_CHANCE] = "chance";
    strRefCategory[RefCategory.REF_STATS] = "stats";
}

function OnShow() {
    xxAddRefineryNodes(true);
}

function xxAddRefineryNodes(bool zz_ExpandNodes) {
    local int i;
    local array<string> CatNodeNames;

    zz_SkillList.Reset();
    
    CatNodeNames = xxInsertRefNodeCat();

    for( i = 0; i < RefinerySkills.Length; i++) {
        xxInsertRefNode(RefinerySkills[i], CatNodeNames[RefinerySkills[i].RefCat], i);
    }

    if(zz_ExpandNodes) {
        xxExpandRefNodeCat(CatNodeNames);
    }
}

function array<string> xxInsertRefNodeCat() {
    local int i;
    local array<string> CatNodeNames;

    CatNodeNames.Length = REF_CAT_COUNT;

    for( i = 0; i < CatNodeNames.Length; i++ ) {
        CatNodeNames[i] = zz_SkillList.InsertExpandButtonNode(strRefCategory[i], 256, 28, "MUI_AUGM.RefineryWnd.List_Header_Down", "MUI_AUGM.RefineryWnd.List_Header_Down_Over", "MUI_AUGM.RefineryWnd.List_Header_Up", "MUI_AUGM.RefineryWnd.List_Header_Up_Over");

        zz_SkillList.InsertSimpleText( CatNodeNames[i], xxGetCatName(i), -246, 6, getInstanceL2Util().BrightYellow, true, false );
    }

    return CatNodeNames;
}

function xxInsertRefNode(RefSkills RefinerySkill, string zz_ParentNode, int Index) {
    local string NodeName;

    NodeName = zz_SkillList.InsertParentNode( zz_ParentNode, RefinerySkill.RefID[0], , xxMakeRefToolip( RefinerySkill.RefID[0] ) );

    zz_SkillList.InsertColoredByIndexButton( NodeName, Index );

    zz_SkillList.InsertTexture( NodeName, "MUI_AUGM.AutoPotions.AutoPotionBG", "", 28, 28, 0, "CenterLeft", "CenterLeft", 10, 0, true, true);
    zz_SkillList.InsertTexture( NodeName, RefinerySkill.RefIcon, "", 24, 24, 0, "CenterLeft", "CenterLeft", -26, 0, true, false, 32, 32);

    zz_SkillList.InsertText( NodeName, RefinerySkill.RefName , 0, "CenterLeft", "CenterLeft", 10, 0, getInstanceL2Util().BrightWhite, true, false);

    zz_SkillList.InsertTexture( NodeName, "MUI_AUGM.EntrepostoWnd.Entreposto_CheckBox_" $ RefinerySkill.Selected ? "On" ~ "Off", "", 24, 24, 0, "CenterLeft", "CenterLeft", 225, 0, true, true);
}

function xxExpandRefNodeCat(array<string> CatNodeNames) {
    local int i;

    for( i = 0; i < CatNodeNames.Length; i++ ) {
        class'UIAPI_TREECTRL'.static.SetExpandedNode("AutoRefineryWnd.SkillsTree", CatNodeNames[i], true);
    }
}

function string xxGetCatName(int zz_Cat)
{
    switch (zz_Cat)
    {
        case 0: return "Passiva";
        case 1: return "Ativa";
        case 2: return "Chance de sucesso:";
        case 3: return "Básico";
    }
    return "";
}

function OnClickButton(string str) {
    local int i;
    local array<string> arr;

    switch( str ) {
        case "btnClose":
            zz_Me.HideWindow();
            break;
        case "AutoRefinery_Toggle":
            zz_AutoRefStatus = !zz_AutoRefStatus;
            xxSetRefToggleTex();
            break;
    }

    arr = xxSplitString(str, ".");

    if( arr.Length <= 2) return;

    for( i = 0; i < RefinerySkills.Length; i++) {
        if(RefinerySkills[i].RefID[0] == int(arr[2])) {
            RefinerySkills[i].Selected = !RefinerySkills[i].Selected;
            break;
        }
    }

    // Preserve the open categories when updating a checkbox.
    Split(class'UIAPI_TREECTRL'.static.GetExpandedNode("AutoRefineryWnd.SkillsTree", "tree_skills"), "|", arr);
    xxAddRefineryNodes(false);
    for (i = 0; i < arr.Length; i++)
        class'UIAPI_TREECTRL'.static.SetExpandedNode("AutoRefineryWnd.SkillsTree", arr[i], true);
    ListActiveSkills();
}

function xxSetRefToggleTex() {
    local string zz_Tex;

    if(zz_AutoRefStatus) {
        zz_Tex = "MUI_AUGM.RefineryWnd.Auto_Refinery_On";
    	ShowWindow("RefineryWnd.tex_autoRefinery");

    }else {
        zz_Tex = "MUI_AUGM.RefineryWnd.Auto_Refinery_Off";
	    HideWindow("RefineryWnd.tex_autoRefinery");
    }

    zz_AutoRefToggleButton.SetTexture(zz_Tex, zz_Tex, zz_Tex);
}

function ListActiveSkills() {
    local int i, ii;

    SelectedRefinerySkills.Length = 0;

    for( i = 0; i < RefinerySkills.Length; i++) {
        if(RefinerySkills[i].Selected) {
            for( ii = 0; ii < RefinerySkills[i].RefID.Length; ii++ ) {
                SelectedRefinerySkills.Length = SelectedRefinerySkills.Length + 1;
                SelectedRefinerySkills[SelectedRefinerySkills.Length - 1] = RefinerySkills[i].RefID[ii];
            }
        }
    }
}

function bool xxIsCheckedRefID(int Ref1, int Ref2) {
    local int i;

    for( i = 0; i < SelectedRefinerySkills.Length; i++) {
        if(SelectedRefinerySkills[i] == Ref1 || SelectedRefinerySkills[i] == Ref2) {
            return true;
        }
    }

    return false;
}

function bool xxGetAutoRefineryStatus() {
    return zz_AutoRefStatus;
}

function CustomTooltip xxMakeRefToolip( int RefID ) {
    local int zz_RefQuality;
    local string zz_RefDesc1, zz_RefDesc2, zz_RefDesc3;

    zz_RefQuality = class'UIDATA_REFINERYOPTION'.static.GetQuality( RefID );
    class'UIDATA_REFINERYOPTION'.static.GetOptionDescription( RefID, zz_RefDesc1, zz_RefDesc2, zz_RefDesc3 );

    zz_RefToolTipHandle.Init( 256 );

    if( zz_RefDesc1 != "" )
        zz_RefToolTipHandle.DrawText( zz_RefDesc1, 4, 0, getInstanceL2Util().RefineryColor[zz_RefQuality], true, true );

    if( zz_RefDesc2 != "" )
        zz_RefToolTipHandle.DrawText( zz_RefDesc2, 4, 0, getInstanceL2Util().RefineryColor[zz_RefQuality], true, true );

    if( zz_RefDesc3 != "" )
        zz_RefToolTipHandle.DrawText( zz_RefDesc3, 4, 0, getInstanceL2Util().RefineryColor[zz_RefQuality], true, true );

    zz_RefToolTipHandle.DrawBlank( 2 );

    return zz_RefToolTipHandle.ToolTip;
}

defaultproperties
{
    RefinerySkills(0)=(RefCat=REF_PASSIVE,RefID=(14729,14730,14907,14908,15085,15086,15264,15442,15620,15798,15976,16154,16332),RefName="Agility",RefIcon="icon.skill1087",Selected=False)
    RefinerySkills(1)=(RefCat=REF_PASSIVE,RefID=(14680,14858,15036,15214,15392,15570,15748,15926,16104,16282),RefName="Magic Barrier",RefIcon="icon.skill1036",Selected=False)
    RefinerySkills(2)=(RefCat=REF_PASSIVE,RefID=(15263,15441,15619,15797,15975,16153,16331),RefName="Clarity",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(3)=(RefCat=REF_PASSIVE,RefID=(15272,15450,15628,15806,15984,16162,16340),RefName="Clarity - Magic Skills",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(4)=(RefCat=REF_PASSIVE,RefID=(15270,15448,15626,15804,15982,16160,16338),RefName="Clarity - Physical Skills",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(5)=(RefCat=REF_PASSIVE,RefID=(15271,15449,15627,15805,15983,16161,16339),RefName="Clarity - Song / Dance Skills",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(6)=(RefCat=REF_PASSIVE,RefID=(14683,14861,15039,15217,15395,15573,15751,15929,16107,16285),RefName="Duel Might",RefIcon="icon.skill0376",Selected=False)
    RefinerySkills(7)=(RefCat=REF_PASSIVE,RefID=(14679,14857,15035,15213,15391,15569,15747,15925,16103,16281),RefName="Empower",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(8)=(RefCat=REF_PASSIVE,RefID=(14731,14732,14909,14910,15087,15088,15265,15443,15621,15799,15977,16155,16333),RefName="Focus",RefIcon="icon.skill1077",Selected=False)
    RefinerySkills(9)=(RefCat=REF_PASSIVE,RefID=(14733,14911,15089,15267,15445,15623,15801,15979,16157,16335),RefName="Guidance",RefIcon="icon.skill1240",Selected=False)
    RefinerySkills(10)=(RefCat=REF_PASSIVE,RefID=(14677,14855,15033,15211,15389,15567,15745,15923,16101,16279),RefName="Heal Empower",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(11)=(RefCat=REF_PASSIVE,RefID=(14735,14736,14737,14738,14913,14914,14915,14916,15091,15092,15093,15094,15269,15447,15625,15803,15981,16159,16337),RefName="Mana Gain",RefIcon="icon.skill0285",Selected=False)
    RefinerySkills(12)=(RefCat=REF_PASSIVE,RefID=(14681,14859,15037,15215,15393,15571,15749,15927,16105,16283),RefName="Might",RefIcon="icon.skill1068",Selected=False)
    RefinerySkills(13)=(RefCat=REF_PASSIVE,RefID=(14678,14856,15034,15212,15390,15568,15746,15924,16102,16280),RefName="Prayer",RefIcon="icon.skill1307",Selected=False)
    RefinerySkills(14)=(RefCat=REF_PASSIVE,RefID=(15266,15444,15622,15800,15978,16156,16334),RefName="Reflect Damage",RefIcon="icon.skill0086",Selected=False)
    RefinerySkills(15)=(RefCat=REF_PASSIVE,RefID=(14682,14860,15038,15216,15394,15572,15750,15928,16106,16284),RefName="Shield",RefIcon="icon.skill1040",Selected=False)
    RefinerySkills(16)=(RefCat=REF_PASSIVE,RefID=(14734,14912,15090,15268,15446,15624,15802,15980,16158,16336),RefName="Wild Magic",RefIcon="icon.skill1303",Selected=False)
    RefinerySkills(17)=(RefCat=REF_ACTIVE,RefID=(14587,14765,14943,15121,15299,15477,15655,15833,16011,16189),RefName="Aggression",RefIcon="icon.skill0028",Selected=False)
    RefinerySkills(18)=(RefCat=REF_ACTIVE,RefID=(14579,14757,14935,15113,15291,15469,15647,15825,16003,16181),RefName="Agility",RefIcon="icon.skill1087",Selected=False)
    RefinerySkills(19)=(RefCat=REF_ACTIVE,RefID=(14625,14803,14981,15159,15337,15515,15693,15871,16049,16227),RefName="Aura Flare",RefIcon="icon.skill1231",Selected=False)
    RefinerySkills(20)=(RefCat=REF_ACTIVE,RefID=(14615,14793,14971,15149,15327,15505,15683,15861,16039,16217),RefName="Aura Flare - Area",RefIcon="icon.skill1231",Selected=False)
    RefinerySkills(21)=(RefCat=REF_ACTIVE,RefID=(14599,14777,14955,15133,15311,15489,15667,15845,16023,16201),RefName="Magic Barrier",RefIcon="icon.skill1036",Selected=False)
    RefinerySkills(22)=(RefCat=REF_ACTIVE,RefID=(14596,14774,14952,15130,15308,15486,15664,15842,16020,16198),RefName="Battle Roar",RefIcon="icon.skill0121",Selected=False)
    RefinerySkills(23)=(RefCat=REF_ACTIVE,RefID=(14580,14758,14936,15114,15292,15470,15648,15826,16004,16182),RefName="Bleed",RefIcon="icon.skill0096",Selected=False)
    RefinerySkills(24)=(RefCat=REF_ACTIVE,RefID=(14597,14775,14953,15131,15309,15487,15665,15843,16021,16199),RefName="Blessed Body",RefIcon="icon.skill1045",Selected=False)
    RefinerySkills(25)=(RefCat=REF_ACTIVE,RefID=(14598,14776,14954,15132,15310,15488,15666,15844,16022,16200),RefName="Blessed Soul",RefIcon="icon.skill1048",Selected=False)
    RefinerySkills(26)=(RefCat=REF_ACTIVE,RefID=(14691,14869,15047,15225,15403,15581,15759,15937,16115,16293),RefName="Celestial Shield",RefIcon="icon.skill1418",Selected=False)
    RefinerySkills(27)=(RefCat=REF_ACTIVE,RefID=(14585,14763,14764,14941,14942,15119,15120,15297,15298,15475,15476,15653,15654,15831,15832,16009,16010,16187,16188),RefName="Charm",RefIcon="icon.skill0015",Selected=False)
    RefinerySkills(28)=(RefCat=REF_ACTIVE,RefID=(14595,14773,14951,15129,15307,15485,15663,15841,16019,16197),RefName="Cheer",RefIcon="icon.skill3080",Selected=False)
    RefinerySkills(29)=(RefCat=REF_ACTIVE,RefID=(15220,15398,15576,15754,15932,16110,16288),RefName="Clarity",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(30)=(RefCat=REF_ACTIVE,RefID=(15234,15235,15412,15590,15768,15946,16124,16302),RefName="Clarity - Magic Skills",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(31)=(RefCat=REF_ACTIVE,RefID=(15230,15408,15586,15764,15942,16120,16298),RefName="Clarity - Physical Skills",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(32)=(RefCat=REF_ACTIVE,RefID=(15232,15410,15588,15766,15944,16122,16300),RefName="Clarity - Song / Dance",RefIcon="icon.skill1397",Selected=False)
    RefinerySkills(33)=(RefCat=REF_ACTIVE,RefID=(14689,14867,15045,15223,15401,15579,15757,15935,16113,16291),RefName="Curse of Doom",RefIcon="icon.skill1336",Selected=False)
    RefinerySkills(34)=(RefCat=REF_ACTIVE,RefID=(14609,14787,14965,15143,15321,15499,15677,15855,16033,16211),RefName="Duel Might",RefIcon="icon.skill0376",Selected=False)
    RefinerySkills(35)=(RefCat=REF_ACTIVE,RefID=(14608,14786,14964,15142,15320,15498,15676,15854,16032,16210),RefName="Duel Weakness",RefIcon="icon.skill1164",Selected=False)
    RefinerySkills(36)=(RefCat=REF_ACTIVE,RefID=(14594,14772,14950,15128,15306,15484,15662,15840,16018,16196),RefName="Empower",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(37)=(RefCat=REF_ACTIVE,RefID=(14583,14761,14939,15117,15295,15473,15651,15829,16007,16185),RefName="Curse Fear",RefIcon="icon.skill1169",Selected=False)
    RefinerySkills(38)=(RefCat=REF_ACTIVE,RefID=(14685,14686,14687,14688,14863,14864,14865,14866,15041,15042,15043,15044,15221,15399,15577,15755,15933,16111,16289),RefName="Focus",RefIcon="icon.skill1077",Selected=False)
    RefinerySkills(39)=(RefCat=REF_ACTIVE,RefID=(14588,14766,14944,15122,15300,15478,15656,15834,16012,16190),RefName="Guidance",RefIcon="icon.skill1240",Selected=False)
    RefinerySkills(40)=(RefCat=REF_ACTIVE,RefID=(14593,14771,14949,15127,15305,15483,15661,15839,16017,16195),RefName="Battle Heal",RefIcon="icon.skill1015",Selected=False)
    RefinerySkills(41)=(RefCat=REF_ACTIVE,RefID=(14591,14769,14947,15125,15303,15481,15659,15837,16015,16193),RefName="Heal Empower",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(42)=(RefCat=REF_ACTIVE,RefID=(14589,14767,14945,15123,15301,15479,15657,15835,16013,16191),RefName="Hold",RefIcon="icon.skill4047",Selected=False)
    RefinerySkills(43)=(RefCat=REF_ACTIVE,RefID=(14628,14806,14984,15162,15340,15518,15696,15874,16052,16230),RefName="Hurricane",RefIcon="icon.skill1239",Selected=False)
    RefinerySkills(44)=(RefCat=REF_ACTIVE,RefID=(14618,14796,14974,15152,15330,15508,15686,15864,16042,16220),RefName="Hurricane - Area",RefIcon="icon.skill1239",Selected=False)
    RefinerySkills(45)=(RefCat=REF_ACTIVE,RefID=(14627,14634,14805,14812,14983,14990,15161,15168,15339,15346,15517,15524,15695,15702,15873,15880,16051,16058,16229,16236),RefName="Hydro Blast",RefIcon="icon.skill1235",Selected=False)
    RefinerySkills(46)=(RefCat=REF_ACTIVE,RefID=(14617,14795,14973,15151,15329,15507,15685,15863,16041,16219),RefName="Hydro Blast - Area",RefIcon="icon.skill1235",Selected=False)
    RefinerySkills(47)=(RefCat=REF_ACTIVE,RefID=(14600,14778,14956,15134,15312,15490,15668,15846,16024,16202),RefName="Mana Burn",RefIcon="icon.skill1398",Selected=False)
    RefinerySkills(48)=(RefCat=REF_ACTIVE,RefID=(14601,14779,14957,15135,15313,15491,15669,15847,16025,16203),RefName="Mana Gain",RefIcon="icon.skill0285",Selected=False)
    RefinerySkills(49)=(RefCat=REF_ACTIVE,RefID=(14630,14808,14986,15164,15342,15520,15698,15876,16054,16232),RefName="Medusa",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(50)=(RefCat=REF_ACTIVE,RefID=(14604,14782,14960,15138,15316,15494,15672,15850,16028,16206),RefName="Might",RefIcon="icon.skill1068",Selected=False)
    RefinerySkills(51)=(RefCat=REF_ACTIVE,RefID=(14605,14783,14961,15139,15317,15495,15673,15851,16029,16207),RefName="Paralyze",RefIcon="icon.skill1307",Selected=False)
    RefinerySkills(52)=(RefCat=REF_ACTIVE,RefID=(14607,14785,14963,15141,15319,15497,15675,15853,16031,16209),RefName="Poison",RefIcon="icon.skill4036",Selected=False)
    RefinerySkills(53)=(RefCat=REF_ACTIVE,RefID=(14592,14770,14948,15126,15304,15482,15660,15838,16016,16194),RefName="Prayer",RefIcon="icon.skill1307",Selected=False)
    RefinerySkills(54)=(RefCat=REF_ACTIVE,RefID=(14623,14635,14801,14813,14979,14991,15157,15169,15335,15347,15513,15525,15691,15703,15869,15881,16047,16059,16225,16237),RefName="Prominence",RefIcon="icon.skill1230",Selected=False)
    RefinerySkills(55)=(RefCat=REF_ACTIVE,RefID=(14613,14791,14969,15147,15325,15503,15681,15859,16037,16215),RefName="Prominence - Area",RefIcon="icon.skill1230",Selected=False)
    RefinerySkills(56)=(RefCat=REF_ACTIVE,RefID=(14602,14780,14958,15136,15314,15492,15670,15848,16026,16204),RefName="Recharge",RefIcon="icon.skill1013",Selected=False)
    RefinerySkills(57)=(RefCat=REF_ACTIVE,RefID=(15222,15400,15578,15756,15934,16112,16290),RefName="Reflect Damage",RefIcon="icon.skill0086",Selected=False)
    RefinerySkills(58)=(RefCat=REF_ACTIVE,RefID=(15219,15397,15575,15753,15931,16109,16287),RefName="Refresh",RefIcon="icon.skill1332",Selected=False)
    RefinerySkills(59)=(RefCat=REF_ACTIVE,RefID=(15233,15411,15589,15767,15945,16123,16301),RefName="Refresh - Magic Skills",RefIcon="icon.skill1332",Selected=False)
    RefinerySkills(60)=(RefCat=REF_ACTIVE,RefID=(15229,15407,15585,15763,15941,16119,16297),RefName="Refresh - Physical Skills",RefIcon="icon.skill1332",Selected=False)
    RefinerySkills(61)=(RefCat=REF_ACTIVE,RefID=(15231,15409,15587,15765,15943,16121,16299),RefName="Refresh - Song / Dance",RefIcon="icon.skill1332",Selected=False)
    RefinerySkills(62)=(RefCat=REF_ACTIVE,RefID=(14611,14789,14967,15145,15323,15501,15679,15857,16035,16213),RefName="Resurrection",RefIcon="icon.skill1016",Selected=False)
    RefinerySkills(63)=(RefCat=REF_ACTIVE,RefID=(14581,14759,14937,15115,15293,15471,15649,15827,16005,16183),RefName="Ritual",RefIcon="icon.skill0400",Selected=False)
    RefinerySkills(64)=(RefCat=REF_ACTIVE,RefID=(14626,14804,14982,15160,15338,15516,15694,15872,16050,16228),RefName="Shadow Flare",RefIcon="icon.skill1267",Selected=False)
    RefinerySkills(65)=(RefCat=REF_ACTIVE,RefID=(14616,14794,14972,15150,15328,15506,15684,15862,16040,16218),RefName="Shadow Flare - Area",RefIcon="icon.skill1267",Selected=False)
    RefinerySkills(66)=(RefCat=REF_ACTIVE,RefID=(14606,14784,14962,15140,15318,15496,15674,15852,16030,16208),RefName="Shield",RefIcon="icon.skill1040",Selected=False)
    RefinerySkills(67)=(RefCat=REF_ACTIVE,RefID=(14694,14697,14698,14699,14700,14701,14872,14875,14876,14877,14878,14879,15050,15054,15055,15056,15057,15228,15406,15584,15762,15940,16118,16296),RefName="Silence",RefIcon="icon.skill1064",Selected=False)
    RefinerySkills(68)=(RefCat=REF_ACTIVE,RefID=(14619,14797,14975,15153,15331,15509,15687,15865,16043,16221),RefName="Sleep",RefIcon="icon.skill4046",Selected=False)
    RefinerySkills(69)=(RefCat=REF_ACTIVE,RefID=(14620,14798,14976,15154,15332,15510,15688,15866,16044,16222),RefName="Slow",RefIcon="icon.skill1160",Selected=False)
    RefinerySkills(70)=(RefCat=REF_ACTIVE,RefID=(14624,14802,14980,15158,15336,15514,15692,15870,16048,16226),RefName="Solar Flare",RefIcon="icon.skill1265",Selected=False)
    RefinerySkills(71)=(RefCat=REF_ACTIVE,RefID=(14614,14792,14970,15148,15326,15504,15682,15860,16038,16216),RefName="Solar Flare - Area",RefIcon="icon.skill1265",Selected=False)
    RefinerySkills(72)=(RefCat=REF_ACTIVE,RefID=(14621,14799,14977,15155,15333,15511,15689,15867,16045,16223),RefName="Stun",RefIcon="icon.skill0100",Selected=False)
    RefinerySkills(73)=(RefCat=REF_ACTIVE,RefID=(14629,14807,14985,15163,15341,15519,15697,15875,16053,16231),RefName="Trick",RefIcon="icon.skill0011",Selected=False)
    RefinerySkills(74)=(RefCat=REF_ACTIVE,RefID=(14702,14880,15058,15236,15414,15592,15770,15948,16126,16304),RefName="Vampiric Rage",RefIcon="icon.skill1268",Selected=False)
    RefinerySkills(75)=(RefCat=REF_ACTIVE,RefID=(14633,14811,14989,15167,15345,15523,15701,15879,16057,16235),RefName="Vampiric Touch",RefIcon="icon.skill1147",Selected=False)
    RefinerySkills(76)=(RefCat=REF_ACTIVE,RefID=(14692,14693,14695,14696,14870,15048,15226,15404,15582,15760,15938,16116,16294),RefName="Wild Magic",RefIcon="icon.skill1303",Selected=False)
    RefinerySkills(77)=(RefCat=REF_ACTIVE,RefID=(14578,14756,14934,15112,15290,15468,15646,15824,16002,16180),RefName="Winter",RefIcon="icon.skill1178",Selected=False)
    RefinerySkills(78)=(RefCat=REF_CHANCE,RefID=(14572,14586,14750,14928,15106,15284,15462,15640,15818,15996,16174),RefName="Aggression - Critical Attack",RefIcon="icon.skill0028",Selected=False)
    RefinerySkills(79)=(RefCat=REF_CHANCE,RefID=(14569,14747,14925,15103,15281,15459,15637,15815,15993,16171),RefName="Aggression - Physical Attack",RefIcon="icon.skill0028",Selected=False)
    RefinerySkills(80)=(RefCat=REF_CHANCE,RefID=(14649,14827,15005,15183,15361,15539,15717,15895,16073,16251),RefName="Agility - Take Damage",RefIcon="icon.skill1087",Selected=False)
    RefinerySkills(81)=(RefCat=REF_CHANCE,RefID=(14663,14841,15019,15197,15375,15553,15731,15909,16087,16265),RefName="Magic Barrier - Take Damage",RefIcon="icon.skill1036",Selected=False)
    RefinerySkills(82)=(RefCat=REF_CHANCE,RefID=(14643,14821,14999,15177,15355,15533,15711,15889,16067,16245),RefName="Bleed - Critical Attack",RefIcon="icon.skill0096",Selected=False)
    RefinerySkills(83)=(RefCat=REF_CHANCE,RefID=(14672,14850,15028,15206,15384,15562,15740,15918,16096,16274),RefName="Bleed - Magic Attack",RefIcon="icon.skill0096",Selected=False)
    RefinerySkills(84)=(RefCat=REF_CHANCE,RefID=(14637,14815,14993,15171,15349,15527,15705,15883,16061,16239),RefName="Bleed - Physical Attack",RefIcon="icon.skill0096",Selected=False)
    RefinerySkills(85)=(RefCat=REF_CHANCE,RefID=(14650,14828,15006,15184,15362,15540,15718,15896,16074,16252),RefName="Bleed - Take Damage",RefIcon="icon.skill0096",Selected=False)
    RefinerySkills(86)=(RefCat=REF_CHANCE,RefID=(14661,14839,15017,15195,15373,15551,15729,15907,16085,16263),RefName="Blessed Body - Take Damage",RefIcon="icon.skill1045",Selected=False)
    RefinerySkills(87)=(RefCat=REF_CHANCE,RefID=(14662,14840,15018,15196,15374,15552,15730,15908,16086,16264),RefName="Blessed Soul - Take Damage",RefIcon="icon.skill1048",Selected=False)
    RefinerySkills(88)=(RefCat=REF_CHANCE,RefID=(14571,14749,14927,15105,15283,15461,15639,15817,15995,16173),RefName="Charm - Critical Attack",RefIcon="icon.skill0015",Selected=False)
    RefinerySkills(89)=(RefCat=REF_CHANCE,RefID=(14568,14570,14746,14924,15102,15280,15458,15636,15814,15992,16170),RefName="Charm - Physical Attack",RefIcon="icon.skill0015",Selected=False)
    RefinerySkills(90)=(RefCat=REF_CHANCE,RefID=(14653,14831,15009,15187,15365,15543,15721,15899,16077,16255),RefName="Charm - Take Damage",RefIcon="icon.skill0015",Selected=False)
    RefinerySkills(91)=(RefCat=REF_CHANCE,RefID=(14651,14829,15007,15185,15363,15541,15719,15897,16075,16253),RefName="Cheer - Take Damage",RefIcon="icon.skill3080",Selected=False)
    RefinerySkills(92)=(RefCat=REF_CHANCE,RefID=(14660,14838,15016,15194,15372,15550,15728,15906,16084,16262),RefName="The Victor of War - Take Damage",RefIcon="icon.skill5074",Selected=False)
    RefinerySkills(93)=(RefCat=REF_CHANCE,RefID=(14709,14887,15065,15243,15421,15599,15777,15955,16133,16311),RefName="Curse of Doom - Critical Attack",RefIcon="icon.skill1336",Selected=False)
    RefinerySkills(94)=(RefCat=REF_CHANCE,RefID=(14723,14901,15079,15257,15435,15613,15791,15969,16147,16325),RefName="Curse of Doom - Magic Attack",RefIcon="icon.skill1336",Selected=False)
    RefinerySkills(95)=(RefCat=REF_CHANCE,RefID=(14703,14881,15059,15237,15415,15593,15771,15949,16127,16305),RefName="Curse of Doom - Physical Attack",RefIcon="icon.skill1336",Selected=False)
    RefinerySkills(96)=(RefCat=REF_CHANCE,RefID=(14715,14893,15071,15249,15427,15605,15783,15961,16139,16317),RefName="Curse of Doom - Take Damage",RefIcon="icon.skill1336",Selected=False)
    RefinerySkills(97)=(RefCat=REF_CHANCE,RefID=(14668,14846,15024,15202,15380,15558,15736,15914,16092,16270),RefName="Duel Might - Take Damage",RefIcon="icon.skill0376",Selected=False)
    RefinerySkills(98)=(RefCat=REF_CHANCE,RefID=(14667,14845,15023,15201,15379,15557,15735,15913,16091,16269),RefName="Duel Weakness - Take Damage",RefIcon="icon.skill1164",Selected=False)
    RefinerySkills(99)=(RefCat=REF_CHANCE,RefID=(14658,14836,15014,15192,15370,15548,15726,15904,16082,16260),RefName="Empower - Take Damage",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(100)=(RefCat=REF_CHANCE,RefID=(14644,14822,15000,15178,15356,15534,15712,15890,16068,16246),RefName="Curse Fear - Critical Attack",RefIcon="icon.skill1169",Selected=False)
    RefinerySkills(101)=(RefCat=REF_CHANCE,RefID=(14673,14851,15029,15207,15385,15563,15741,15919,16097,16275),RefName="Curse Fear - Magic Attack",RefIcon="icon.skill1169",Selected=False)
    RefinerySkills(102)=(RefCat=REF_CHANCE,RefID=(14638,14816,14994,15172,15350,15528,15706,15884,16062,16240),RefName="Curse Fear - Physical Attack",RefIcon="icon.skill1169",Selected=False)
    RefinerySkills(103)=(RefCat=REF_CHANCE,RefID=(14716,14894,15072,15250,15428,15606,15784,15962,16140,16318),RefName="Curse Fear - Take Damage",RefIcon="icon.skill1169",Selected=False)
    RefinerySkills(104)=(RefCat=REF_CHANCE,RefID=(14652,14830,15008,15186,15364,15542,15720,15898,16076,16254),RefName="Focus - Take Damage",RefIcon="icon.skill1077",Selected=False)
    RefinerySkills(105)=(RefCat=REF_CHANCE,RefID=(14654,14832,15010,15188,15366,15544,15722,15900,16078,16256),RefName="Guidance - Take Damage",RefIcon="icon.skill1240",Selected=False)
    RefinerySkills(106)=(RefCat=REF_CHANCE,RefID=(14657,14835,15013,15191,15369,15547,15725,15903,16081,16259),RefName="Battle Heal - Take Damage",RefIcon="icon.skill1015",Selected=False)
    RefinerySkills(107)=(RefCat=REF_CHANCE,RefID=(14656,14834,15012,15190,15368,15546,15724,15902,16080,16258),RefName="Heal Empower - Take Damage",RefIcon="icon.skill1059",Selected=False)
    RefinerySkills(108)=(RefCat=REF_CHANCE,RefID=(14645,14823,15001,15179,15357,15535,15713,15891,16069,16247),RefName="Hold - Critical Attack",RefIcon="icon.skill4047",Selected=False)
    RefinerySkills(109)=(RefCat=REF_CHANCE,RefID=(14674,14852,15030,15208,15386,15564,15742,15920,16098,16276),RefName="Hold - Magic Attack",RefIcon="icon.skill4047",Selected=False)
    RefinerySkills(110)=(RefCat=REF_CHANCE,RefID=(14639,14817,14995,15173,15351,15529,15707,15885,16063,16241),RefName="Hold - Physical Attack",RefIcon="icon.skill4047",Selected=False)
    RefinerySkills(111)=(RefCat=REF_CHANCE,RefID=(14655,14833,15011,15189,15367,15545,15723,15901,16079,16257),RefName="Hold - Take Damage",RefIcon="icon.skill4047",Selected=False)
    RefinerySkills(112)=(RefCat=REF_CHANCE,RefID=(14710,14888,15066,15244,15422,15600,15778,15956,16134,16312),RefName="Mana Burn - Critical Attack",RefIcon="icon.skill1398",Selected=False)
    RefinerySkills(113)=(RefCat=REF_CHANCE,RefID=(14724,14902,15080,15258,15436,15614,15792,15970,16148,16326),RefName="Mana Burn - Magic Attack",RefIcon="icon.skill1398",Selected=False)
    RefinerySkills(114)=(RefCat=REF_CHANCE,RefID=(14704,14882,15060,15238,15416,15594,15772,15950,16128,16306),RefName="Mana Burn - Physical Attack",RefIcon="icon.skill1398",Selected=False)
    RefinerySkills(115)=(RefCat=REF_CHANCE,RefID=(14717,14895,15073,15251,15429,15607,15785,15963,16141,16319),RefName="Mana Gain - Take Damage",RefIcon="icon.skill0285",Selected=False)
    RefinerySkills(116)=(RefCat=REF_CHANCE,RefID=(14647,14825,15003,15181,15359,15537,15715,15893,16071,16249),RefName="Medusa - Critical Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(117)=(RefCat=REF_CHANCE,RefID=(14676,14854,15032,15210,15388,15566,15744,15922,16100,16278),RefName="Medusa - Magic Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(118)=(RefCat=REF_CHANCE,RefID=(14641,14819,14997,15175,15353,15531,15709,15887,16065,16243),RefName="Medusa - Physical Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(119)=(RefCat=REF_CHANCE,RefID=(14722,14900,15078,15256,15434,15612,15790,15968,16146,16324),RefName="Medusa - Take Damage",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(120)=(RefCat=REF_CHANCE,RefID=(14664,14842,15020,15198,15376,15554,15732,15910,16088,16266),RefName="Might - Take Damage",RefIcon="icon.skill1068",Selected=False)
    RefinerySkills(121)=(RefCat=REF_CHANCE,RefID=(14711,14889,15067,15245,15423,15601,15779,15957,16135,16313),RefName="Paralyze - Critical Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(122)=(RefCat=REF_CHANCE,RefID=(14725,14903,15081,15259,15437,15615,15793,15971,16149,16327),RefName="Paralyze - Magic Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(123)=(RefCat=REF_CHANCE,RefID=(14705,14883,15061,15239,15417,15595,15773,15951,16129,16307),RefName="Paralyze - Physical Attack",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(124)=(RefCat=REF_CHANCE,RefID=(14719,14897,15075,15253,15431,15609,15787,15965,16143,16321),RefName="Paralyze - Take Damage",RefIcon="icon.skill1170",Selected=False)
    RefinerySkills(125)=(RefCat=REF_CHANCE,RefID=(14646,14824,15002,15180,15358,15536,15714,15892,16070,16248),RefName="Poison - Critical Attack",RefIcon="icon.skill4036",Selected=False)
    RefinerySkills(126)=(RefCat=REF_CHANCE,RefID=(14675,14853,15031,15209,15387,15565,15743,15921,16099,16277),RefName="Poison - Magic Attack",RefIcon="icon.skill4036",Selected=False)
    RefinerySkills(127)=(RefCat=REF_CHANCE,RefID=(14640,14818,14996,15174,15352,15530,15708,15886,16064,16242),RefName="Poison - Physical Attack",RefIcon="icon.skill4036",Selected=False)
    RefinerySkills(128)=(RefCat=REF_CHANCE,RefID=(14666,14844,15022,15200,15378,15556,15734,15912,16090,16268),RefName="Poison - Take Damage",RefIcon="icon.skill4036",Selected=False)
    RefinerySkills(129)=(RefCat=REF_CHANCE,RefID=(14718,14896,15074,15252,15430,15608,15786,15964,16142,16320),RefName="Recharge - Take Damage",RefIcon="icon.skill1013",Selected=False)
    RefinerySkills(130)=(RefCat=REF_CHANCE,RefID=(14665,14843,15021,15199,15377,15555,15733,15911,16089,16267),RefName="Shield - Take Damage",RefIcon="icon.skill1040",Selected=False)
    RefinerySkills(131)=(RefCat=REF_CHANCE,RefID=(14712,14890,15068,15246,15424,15602,15780,15958,16136,16314),RefName="Silence - Critical Attack",RefIcon="icon.skill1064",Selected=False)
    RefinerySkills(132)=(RefCat=REF_CHANCE,RefID=(14726,14904,15082,15260,15438,15616,15794,15972,16150,16328),RefName="Silence - Magic Attack",RefIcon="icon.skill1064",Selected=False)
    RefinerySkills(133)=(RefCat=REF_CHANCE,RefID=(14706,14884,15062,15240,15418,15596,15774,15952,16130,16308),RefName="Silence - Physical Attack",RefIcon="icon.skill1064",Selected=False)
    RefinerySkills(134)=(RefCat=REF_CHANCE,RefID=(14720,14898,15076,15254,15432,15610,15788,15966,16144,16322),RefName="Silence - Take Damage",RefIcon="icon.skill1064",Selected=False)
    RefinerySkills(135)=(RefCat=REF_CHANCE,RefID=(14713,14891,15069,15247,15425,15603,15781,15959,16137,16315),RefName="Sleep - Critical Attack",RefIcon="icon.skill4046",Selected=False)
    RefinerySkills(136)=(RefCat=REF_CHANCE,RefID=(14727,14905,15083,15261,15439,15617,15795,15973,16151,16329),RefName="Sleep - Magic Attack",RefIcon="icon.skill4046",Selected=False)
    RefinerySkills(137)=(RefCat=REF_CHANCE,RefID=(14707,14885,15063,15241,15419,15597,15775,15953,16131,16309),RefName="Sleep - Physical Attack",RefIcon="icon.skill4046",Selected=False)
    RefinerySkills(138)=(RefCat=REF_CHANCE,RefID=(14669,14847,15025,15203,15381,15559,15737,15915,16093,16271),RefName="Sleep - Take Damage",RefIcon="icon.skill4046",Selected=False)
    RefinerySkills(139)=(RefCat=REF_CHANCE,RefID=(14573,14751,14929,15107,15285,15463,15641,15819,15997,16175),RefName="Slow - Critical Attack",RefIcon="icon.skill1160",Selected=False)
    RefinerySkills(140)=(RefCat=REF_CHANCE,RefID=(14574,14752,14930,15108,15286,15464,15642,15820,15998,16176),RefName="Slow - Magic Attack",RefIcon="icon.skill1160",Selected=False)
    RefinerySkills(141)=(RefCat=REF_CHANCE,RefID=(14748,14926,15104,15282,15460,15638,15816,15994,16172),RefName="Slow - Physical Attack",RefIcon="icon.skill1160",Selected=False)
    RefinerySkills(142)=(RefCat=REF_CHANCE,RefID=(14670,14848,15026,15204,15382,15560,15738,15916,16094,16272),RefName="Slow - Take Damage",RefIcon="icon.skill1160",Selected=False)
    RefinerySkills(143)=(RefCat=REF_CHANCE,RefID=(14714,14892,15070,15248,15426,15604,15782,15960,16138,16316),RefName="Stun - Critical Attack",RefIcon="icon.skill0100",Selected=False)
    RefinerySkills(144)=(RefCat=REF_CHANCE,RefID=(14728,14906,15084,15262,15440,15618,15796,15974,16152,16330),RefName="Stun - Magic Attack",RefIcon="icon.skill0100",Selected=False)
    RefinerySkills(145)=(RefCat=REF_CHANCE,RefID=(14708,14886,15064,15242,15420,15598,15776,15954,16132,16310),RefName="Stun - Physical Attack",RefIcon="icon.skill0100",Selected=False)
    RefinerySkills(146)=(RefCat=REF_CHANCE,RefID=(14721,14899,15077,15255,15433,15611,15789,15967,16145,16323),RefName="Stun - Take Damage",RefIcon="icon.skill0100",Selected=False)
    RefinerySkills(147)=(RefCat=REF_CHANCE,RefID=(14659,14837,15015,15193,15371,15549,15727,15905,16083,16261),RefName="Wild Magic - Take Damage",RefIcon="icon.skill1303",Selected=False)
    RefinerySkills(148)=(RefCat=REF_CHANCE,RefID=(14642,14820,14998,15176,15354,15532,15710,15888,16066,16244),RefName="Winter - Critical Attack",RefIcon="icon.skill1178",Selected=False)
    RefinerySkills(149)=(RefCat=REF_CHANCE,RefID=(14671,14849,15027,15205,15383,15561,15739,15917,16095,16273),RefName="Winter - Magic Attack",RefIcon="icon.skill1178",Selected=False)
    RefinerySkills(150)=(RefCat=REF_CHANCE,RefID=(14636,14814,14992,15170,15348,15526,15704,15882,16060,16238),RefName="Winter - Physical Attack",RefIcon="icon.skill1178",Selected=False)
    RefinerySkills(151)=(RefCat=REF_CHANCE,RefID=(14648,14826,15004,15182,15360,15538,15716,15894,16072,16250),RefName="Winter - Take Damage",RefIcon="icon.skill1178",Selected=False)
    RefinerySkills(152)=(RefCat=REF_STATS,RefID=(16342,16346,16350,16354,16358,16362,16366,16370,16374,16378),RefName="CON +1",RefIcon="icon.etc_con_symbol_i01",Selected=False)
    RefinerySkills(153)=(RefCat=REF_STATS,RefID=(16343,16347,16351,16355,16359,16363,16367,16371,16375,16379),RefName="INT +1",RefIcon="icon.etc_int_symbol_i01",Selected=False)
    RefinerySkills(154)=(RefCat=REF_STATS,RefID=(16344,16348,16352,16356,16360,16364,16368,16372,16376,16380),RefName="MEN +1",RefIcon="icon.etc_men_symbol_i01",Selected=False)
    RefinerySkills(155)=(RefCat=REF_STATS,RefID=(16341,16345,16349,16353,16357,16361,16365,16369,16373,16377),RefName="STR +1",RefIcon="icon.etc_str_symbol_i01",Selected=False)
}
