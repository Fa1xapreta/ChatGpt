# Treasure Hunt — pedras acumuladas até serem quebradas

As rodadas acrescentam novas pedras aleatórias e não substituem as pedras vivas.
Uma pedra permanece no mesmo lugar até ser quebrada. Se alguém apenas atacar e
for embora, ela permanece. Se o servidor reiniciar, as pedras ainda vivas são
restauradas nas posições registradas. Pedras quebradas não retornam.

## Atualizar a instalação existente

1. Pare o servidor e faça backup das fontes e da pasta `data`, incluindo os dados
   do evento. Não substitua nem esvazie `data/treasurehunt-used-locations.log`.
2. Copie/mescle as **nove classes de `src/net/`** na raiz de fontes da pack.
   Elas devem ser atualizadas juntas para não misturar versões.
3. Compile com limpeza dos arquivos compilados anteriores, substitua o JAR usado
   pelo gameserver e reinicie. Recarga de XML não atualiza Java.
4. Mantenha seu XML por regiões e suas propriedades atuais. O intervalo de
   `300` segundos continua válido. Quem já usa as 12 entradas por geodata não
   precisa substituir o XML ou os XMLs de NPCs/item novamente.
5. O novo `data/treasurehunt-active-stones.log` é criado automaticamente apenas
   na primeira inicialização deste recurso. A criação também registra o marcador
   `# ACTIVE_STONES_V1` no histórico de lugares, sem remover seus registros.
6. Faça backup consistente dos dois arquivos e da pasta de sessões:

   ```text
   data/treasurehunt-used-locations.log
   data/treasurehunt-active-stones.log
   data/treasurehunt-sessions/
   ```

Não é necessário copiar um arquivo vazio de pedras ativas. Se ele desaparecer
após a inicialização, o evento bloqueia a geração/restauração e pede o backup;
não cria outro vazio para esconder a perda. Não remova o marcador do histórico.
Os arquivos são bloqueados durante a execução para impedir gravações simultâneas.
Faça backups com servidor parado ou por snapshot consistente.

**A persistência começa nas pedras registradas por esta versão.** Pedras de uma
versão anterior que nunca teve o registro de pedras vivas não podem ser
reconstruídas automaticamente no primeiro reinício de atualização.

O patch `patches/atualizar-aleatorio-para-persistente.patch` compara com o ZIP
aleatório originalmente publicado. Se aplicou correções manuais posteriores,
prefira mesclar as classes completas; esse patch pode não aplicar diretamente.

Se suas fontes foram editadas depois dos envios anteriores, faça merge para
preservar essas alterações. A atualização mantém a integração anterior com o
core. As seis classes de `core-editados/` e `patches/core.patch` estão incluídas
para instalação completa sobre as classes originais; não precisa substituir
Config/L2PcInstance/etc. novamente para atualizar somente este recurso.

## Configuração

Mantenha estas chaves no arquivo existente `config/custom/l2jmod.properties`:

```properties
EnableTreasureHunt = true
TreasureHuntInterval = 300
AllowTreasureHuntAutoLoot = true
```

O intervalo controla novas rodadas, não o tempo de vida das pedras. Cada entrada
faz seu sorteio de chance e pode acrescentar uma nova pedra na rodada. Não existe
expiração ou substituição automática das pedras anteriores.

`EnableTreasureHunt = false` pausa **novas quedas**. As pedras já existentes
permanecem e continuam podendo ser mineradas, inclusive após reinício.
`//reload treasurehunt` atualiza a configuração para as próximas rodadas sem
remover pedras vivas. Entradas removidas/alteradas do XML não apagam as pedras
já registradas; elas conservam sua definição até serem quebradas.

Se `DisableAttackToNpcs = True`, acrescente `StoneMiner` à linha já existente de
`AllowedNPCTypes`, preservando os demais tipos e sem espaço após a vírgula.
Essa permissão é necessária no core fornecido. Não duplique a propriedade.

Como não há expiração, as pedras acumulam se ninguém minerar. Para reduzir novas
quedas, aumente o intervalo ou pause a geração; isso não apaga as pedras antigas.

## Reinício e quebra

Cada pedra tem um identificador persistente independente do objectId do NPC.
O registro contém região, definição, coordenadas e a existência da pedra.
Restaurar esse identificador na mesma posição é continuar a vida da mesma pedra,
não sortear novamente um lugar já usado.

O registro da quebra é gravado e forçado ao disco **antes** de entregar prêmios.
Se essa gravação falhar, a morte/recompensa é bloqueada, a pedra fica viva com
1 HP e o erro aparece no console. Isso evita entregar um prêmio e restaurar a
mesma pedra como se nunca tivesse sido quebrada.

As pedras restauradas reaparecem com HP cheio. O dano parcial não é salvo.
A restauração não repete SocialAction, tremor ou lançamento: a pedra já caiu
antes do reinício. As novas quedas continuam executando todos os efeitos.

A restauração valida novamente a posição. Se a geodata/recursos mudaram e não
permitirem restaurar uma pedra com segurança, seu registro é preservado e o
console informa a falha; ela não é movida para outro local. Após corrigir, use
`//reload treasurehunt` ou aguarde nova rodada para tentar novamente.
Uma remoção temporária por GM sem quebra não retira o registro de pedra viva;
a rotina pode restaurá-la. Somente a quebra registra a retirada permanente.

## Sorteio e segurança

Mantidas as 12 entradas do XML original, com IDs únicos de 0 a 11, nas regiões
`16_25`, `23_24` e `24_15`. Os nomes de território são textos do anúncio; as áreas
físicas são determinadas pelos números de região.

X/Y são sorteados em toda a região, sem pontos fixos e sem modo de teste.
Caminhos e montanhas podem receber pedras quando forem caminháveis.

Antes da criação, o código exige geodata habilitada, chão, espaço para a colisão
com margem, ausência de paredes na área ocupada, caminhos completos de ida e
volta nas células dessa área e uma aproximação caminhável a 128 unidades.
Ladeiras são permitidas: não se exige piso plano ou Z fixo do jogador.

As novas pedras respeitam a distância das outras pedras vivas, incluindo as de
rodadas anteriores. O sorteio faz no máximo 1000 tentativas por entrada e até
16 criações para validação posterior. Sem candidato válido e novo, não há spawn
forçado nem remoção de uma pedra anterior.

O histórico dos lugares é compartilhado por todas as cores/regiões. Uma célula
XY de 64 x 64 não é reutilizada, e novos centros ficam a pelo menos 64 unidades
dos centros anteriores, mesmo atravessando bordas de células. O registro é
forçado ao disco antes de criar a pedra e não expira após morte ou reinício.
Uma reserva pode ser consumida mesmo que a criação falhe depois.

**Preserve o histórico para manter a regra de não repetição.** Ele não consegue
reconstruir posições antigas que nunca foram registradas; o arquivo inicial
inclui apenas os quatro locais conhecidos das versões de teste anteriores.
As regiões são finitas: se não houver lugar novo adequado, aquela entrada fica
sem nova queda na rodada, preservando todas as pedras já existentes.

Os arquivos ausentes/corrompidos/bloqueados não são apagados ou reiniciados
silenciosamente. Restaure backups consistentes se ocorrer uma perda de dados.

## Efeitos, mineração e logs

As novas quedas mantêm SocialAction 1, Earthquake (5, 3), som e lançamento dos
jogadores próximos, com validação do destino do lançamento.

O primeiro clique equipa a ferramenta temporária 30139; o seguinte segue o ataque
normal. A ferramenta é controlada pelo objeto criado, sem destruir ferramentas
legítimas pelo mesmo template. Troca/cancelamento do alvo, morte, teleporte,
saída e despawn limpam a sessão e restauram as mãos quando os itens anteriores
ainda estão no inventário. Isso não remove uma pedra viva do registro.

Prêmios e XMLs de NPCs/ferramenta permanecem iguais. A pedra verde conserva a
chance de drop 100/1000000 = 0,01%, conforme os dados enviados.

O console mantém o cabeçalho próprio e uma linha de carregamento, sem mensagem
para cada spawn. Avisos e falhas continuam registrados. A leitura do histórico e
do novo registro usa o mesmo canal que possui o bloqueio, preservando a correção
para Windows já aplicada pelo usuário.

## Validação e limites

Passaram 160 verificações isoladas com substitutos do core: geração aleatória,
paredes, encosta caminhável, não repetição, disco, concorrência, mineração,
recompensa única, acúmulo de rodadas, preservação em recarga/pausa, restauração,
registro perdido/corrompido e falha de gravação na quebra.

Também foram executados dois processos Java separados: o primeiro criou 12
pedras e quebrou uma; o segundo restaurou as 11 sobreviventes nas mesmas
coordenadas, sem ressuscitar a quebrada ou repetir os efeitos de queda.
Os patches, a sintaxe Java e a integridade do ZIP são conferidos.

Esses testes não são o build completo da sua pack. A nova versão ainda precisa
ser compilada e verificada no servidor com cliente/geodata reais.
A validação é local e depende da qualidade da geodata; não analisa a conectividade
do mundo inteiro nem classifica todo terreno por água/telhado.

## Instalação completa, se necessária

Além das nove classes do mod, a instalação original integra Config, GameServer,
L2PcInstance, EnterWorld, UseItem e AdminAdmin. Use `core-editados/` ou o patch
original na raiz de fontes que contém `net/`, preservando alterações posteriores.
Mescle o datapack sem duplicar NPCs 52000–52003 ou item 30139.

Somente na primeira instalação do histórico de lugares, copie
`historico-inicial/treasurehunt-used-locations.log` para `data/`. Se já existir,
nunca substitua pelo arquivo inicial. A geodata deve estar habilitada em
`config/main/geoengine.properties`, com os arquivos das regiões carregados.
