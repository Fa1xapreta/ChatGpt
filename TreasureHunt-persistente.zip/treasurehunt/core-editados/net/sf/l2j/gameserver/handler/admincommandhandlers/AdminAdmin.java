/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntManager;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.script.ScriptException;

import TeleporterInterface.TeleportLocationData2;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.cache.CrestCache;
import net.sf.l2j.gameserver.cache.HtmCache;
import net.sf.l2j.gameserver.datatables.AdminCommandAccessRights;
import net.sf.l2j.gameserver.datatables.AnnouncementTable;
import net.sf.l2j.gameserver.datatables.DoorTable;
import net.sf.l2j.gameserver.datatables.GmListTable;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.MultisellData;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.NpcWalkerRoutesTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.datatables.TeleportLocationTable;
import net.sf.l2j.gameserver.datatables.custom.AnnouceMultiSell;
import net.sf.l2j.gameserver.datatables.custom.FakePcsTable;
import net.sf.l2j.gameserver.datatables.custom.IconTable;
import net.sf.l2j.gameserver.datatables.custom.RaidSpawnTable;
import net.sf.l2j.gameserver.datatables.custom.SkipTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.handler.community.dailyreward.data.DailyRewardCBData;
import net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox.LuckBoxData;
import net.sf.l2j.gameserver.instancemanager.ClassDamageManager;
import net.sf.l2j.gameserver.instancemanager.CursedWeaponsManager;
import net.sf.l2j.gameserver.instancemanager.OlyClassDamageManager;
import net.sf.l2j.gameserver.instancemanager.QuestManager;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.instancemanager.dropcustom.DropDataCustom;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Party;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.cloak.CloakSystemManager;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.PvpBossManager;
import net.sf.l2j.gameserver.model.entity.events.SoloBossEvent;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyFarmEvent;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFConfig;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFManager;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMConfig;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMManager;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSConfig;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSManager;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBConfig;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBManager;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMConfig;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMManager;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTManager;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTManager;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEventManager;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaConfig;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaEvent;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.scripting.L2ScriptEngineManager;
import net.sf.l2j.gameserver.taskmanager.FarmRandomZoneTaskManager;
import net.sf.l2j.gameserver.util.Util;
import phantom.FakePlayerConfig;


/**
 * This class handles following admin commands:<br>
 * <br>
 * - admin|admin1/admin2/admin3/admin4 = slots for the starting admin menus<br>
 * - gmliston/gmlistoff = includes/excludes active character from /gmlist results<br>
 * - silence = toggles private messages acceptance mode<br>
 * - tradeoff = toggles trade acceptance mode<br>
 * - reload = reloads specified component from multisell|skill|npc|htm|item|instancemanager<br>
 * - saveolymp = saves olympiad state manually<br>
 * - script_load = loads following script. MUSTN'T be used instead of //reload quest !<br>
 * - manualhero = cycles olympiad and calculate new heroes.
 */
public class AdminAdmin implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
		{
		"admin_admin",
		"admin_admin1",
		"admin_admin2",
		"admin_admin3",
		"admin_admin4",
		"admin_gmliston",
		"admin_gmlistoff",
		"admin_kill",
		"admin_silence",
		"admin_tradeoff",
		"admin_reload",
		"admin_script_load",
		"admin_mods",
		"admin_tag",
		"admin_balance"
		};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{

		if (!activeChar.isGM())
		{	
			activeChar.sendMessage("WARN: You do not have access to these commands");
			return false;
		}

		if (command.startsWith("admin_admin"))
			showMainPage(activeChar, command);
		else if (command.equals("admin_mods"))
			AdminHelpPage.showHelpPage(activeChar, "mods.htm");
		else if (command.startsWith("admin_gmliston"))
		{
			GmListTable.getInstance().showGm(activeChar);
			activeChar.sendMessage("Registered into GMList.");
		}
		else if (command.startsWith("admin_gmlistoff"))
		{
			GmListTable.getInstance().hideGm(activeChar);
			activeChar.sendMessage("Removed from GMList.");
		}
		else if (command.startsWith("admin_kill"))
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken(); // skip command

			if (!st.hasMoreTokens())
			{
				final L2Object obj = activeChar.getTarget();
				if (!(obj instanceof L2Character))
					activeChar.sendPacket(SystemMessageId.INCORRECT_TARGET);
				else
					kill(activeChar, (L2Character) obj);

				return true;
			}

			String firstParam = st.nextToken();
			L2PcInstance player = L2World.getInstance().getPlayer(firstParam);
			if (player != null)
			{
				if (st.hasMoreTokens())
				{
					String secondParam = st.nextToken();
					if (Util.isDigit(secondParam))
					{
						int radius = Integer.parseInt(secondParam);
						for (L2Character knownChar : player.getKnownList().getKnownTypeInRadius(L2Character.class, radius))
						{
							if (knownChar.equals(activeChar))
								continue;

							kill(activeChar, knownChar);
						}
						activeChar.sendMessage("Killed all characters within a " + radius + " unit radius around " + player.getName() + ".");
					}
					else
						activeChar.sendMessage("Invalid radius.");
				}
				else
					kill(activeChar, player);
			}
			else if (Util.isDigit(firstParam))
			{
				int radius = Integer.parseInt(firstParam);
				for (L2Character knownChar : activeChar.getKnownList().getKnownTypeInRadius(L2Character.class, radius))
				{
					if (knownChar.equals(activeChar))
						continue;

					kill(activeChar, knownChar);
				}
				activeChar.sendMessage("Killed all characters within a " + radius + " unit radius.");
			}
		}

		else if (command.startsWith("admin_tag"))
		{
			String[] cmdr = command.split(" ");
			NpcHtmlMessage html = new NpcHtmlMessage(0);
			html.setFile("data/html/admin/tag.htm");
			html.replace("%time%", Util.formatDate(new Date(), "dd/MM/yyyy - H:mm:ss"));
			html.replace("%list%", "");
			html.replace("%search%", "Info");
			html.replace("%radius%", "0");
			activeChar.sendPacket(html);
			if (cmdr.length != 3)
				return true; 
			String link = cmdr[1];
			StringBuilder htm = new StringBuilder();
			if (link.equals("LeaderPt"))
			{
				L2Party party = L2World.getInstance().getPlayer(cmdr[2]).getParty();
				List<L2PcInstance> partyMembers = party.getPartyMembers();
				partyMembers.forEach(x -> {
					String clan = "";
					if (x.getClan() != null)
						clan = " (" + x.getClan().getName() + ")"; 
					htm.append("<table><tr><td width=30></td><td width=200>" + x.getName() + clan + " </td><td width=50></td></tr></table>");
				});
				html.setFile("data/html/admin/tag.htm");
				html.replace("%list%", htm.toString());
				html.replace("%time%", Util.formatDate(new Date(), "dd/MM/yyyy - H:mm:ss"));
				html.replace("%search%", link.substring(0, 1).toUpperCase().concat(link.substring(1)));
				html.replace("%radius%", "");
				activeChar.sendPacket(html);
				return true;
			} 
			int raius = Integer.valueOf(cmdr[2]).intValue();
			int raiusx = (raius > 46300) ? 46300 : raius;
			HashMap<String, Integer> Clan = new HashMap<>();
			HashMap<String, Integer> Ally = new HashMap<>();
			HashMap<String, Integer> Party = new HashMap<>();
			L2World.getInstance().getPlayers().stream().filter(x -> x.isInsideRadius(activeChar.getX(), activeChar.getY(), activeChar.getZ(), raiusx, true, true)).forEach(x -> {
				if (x.getClan() != null) 
				{
					Clan.put(x.getClan().getName(), Integer.valueOf((Clan.get(x.getClan().getName()) == null) ? 1 : (Clan.get(x.getClan().getName()).intValue() + 1)));
					if (x.getClan().getAllyName() != null)
						Ally.put(x.getClan().getAllyName(), Integer.valueOf((Ally.get(x.getClan().getAllyName()) == null) ? 1 : (Ally.get(x.getClan().getAllyName()).intValue() + 1))); 
				} 
				if (x.getParty() != null)
					Party.put(x.getParty().getLeader().getName(), Integer.valueOf((Party.get(x.getParty().getLeader().getName()) == null) ? 1 : (Party.get(x.getParty().getLeader().getName()).intValue() + 1))); 
			}
					);
			int pos = 1;
			if (link.equals("clan")) 
			{
				for (Map.Entry<String, Integer> map : Clan.entrySet())
					htm.append("<table><tr><td width=30>" + String.valueOf(pos++) + "</td><td width=200>" + map.getKey() + "</td><td width=50> " + map.getValue() + "</td></tr></table>"); 
			}
			else if (link.equals("ally"))
			{
				for (Map.Entry<String, Integer> map : Ally.entrySet())
					htm.append("<table><tr><td width=30>" + String.valueOf(pos++) + "</td><td width=200>" + map.getKey() + "</td><td width=50> " + map.getValue() + "</td></tr></table>"); 
			}
			else if (link.equals("party"))
			{
				for (Map.Entry<String, Integer> map : Party.entrySet())
				{
					if (L2World.getInstance().getPlayer(map.getKey()).getClan() == null)
					{
						htm.append("<table><tr><td width=30>" + String.valueOf(pos++) + "</td><td width=200><a action=\"bypass -h admin_tag LeaderPt " + map.getKey() + "\">" + map.getKey() + "</a> </td><td width=50> " + map.getValue() + "</td></tr></table>");
						continue;
					} 
					htm.append("<table><tr><td width=30>" + String.valueOf(pos++) + "</td><td width=200><a action=\"bypass -h admin_tag LeaderPt " + map.getKey() + "\">" + map.getKey() + "</a> (" + L2World.getInstance().getPlayer(map.getKey()).getClan().getName() + ")</td><td width=50> " + map.getValue() + "</td></tr></table>");
				} 
			} 
			html.setFile("data/html/admin/tag.htm");
			html.replace("%time%", Util.formatDate(new Date(), "dd/MM/yyyy - H:mm:ss"));
			html.replace("%list%", htm.toString());
			html.replace("%search%", link.substring(0, 1).toUpperCase().concat(link.substring(1)));
			html.replace("%radius%", String.valueOf(raiusx));
			activeChar.sendPacket(html);
			return true;
		}

		else if (command.startsWith("admin_silence"))
		{
			if (activeChar.isInRefusalMode()) // already in message refusal mode
			{
				activeChar.setInRefusalMode(false);
				activeChar.sendPacket(SystemMessageId.MESSAGE_ACCEPTANCE_MODE);
			}
			else
			{
				activeChar.setInRefusalMode(true);
				activeChar.sendPacket(SystemMessageId.MESSAGE_REFUSAL_MODE);
			}
		}
		else if (command.startsWith("admin_tradeoff"))
		{
			try
			{
				String mode = command.substring(15);
				if (mode.equalsIgnoreCase("on"))
				{
					activeChar.setTradeRefusal(true);
					activeChar.sendMessage("Trade refusal enabled");
				}
				else if (mode.equalsIgnoreCase("off"))
				{
					activeChar.setTradeRefusal(false);
					activeChar.sendMessage("Trade refusal disabled");
				}
			}
			catch (Exception ex)
			{
				if (activeChar.getTradeRefusal())
				{
					activeChar.setTradeRefusal(false);
					activeChar.sendMessage("Trade refusal disabled");
				}
				else
				{
					activeChar.setTradeRefusal(true);
					activeChar.sendMessage("Trade refusal enabled");
				}
			}
		}
		else if (command.startsWith("admin_reload"))
		{
			StringTokenizer st = new StringTokenizer(command);
			st.nextToken();
			try
			{
				String type = st.nextToken();
				if (type.startsWith("acar"))
				{
					AdminCommandAccessRights.getInstance().reload();
					activeChar.sendMessage("Admin commands rights have been reloaded.");
				}
				else if (type.startsWith("announcement"))
				{
					AnnouncementTable.getInstance().reload();
					activeChar.sendMessage("The content of announcements.xml has been reloaded.");
				}
				else if (type.startsWith("drop"))
				{
					DropDataCustom.getInstance().reload();
					activeChar.sendMessage("Drop Custom has been reloaded.");
				}
				else if (type.startsWith("icon"))
				{
					IconTable.getInstance().reload();
					activeChar.sendMessage("Icon Table has been reloaded.");
				}
				else if (type.startsWith("randomfarm"))
				{
					FarmRandomZoneTaskManager.getInstance().reload();
					activeChar.sendMessage("Random Farm has been reloaded.");
				}
				else if (type.equalsIgnoreCase("treasurehunt"))
				{
					activeChar.sendMessage(TreasureHuntManager.getInstance().reload() ? "Treasure Hunt recarregado." : "Falha ao recarregar Treasure Hunt. Confira o log.");
				}
				else if (type.startsWith("retaildrop"))
				{
					NpcTable.getInstance().reloadDrops();
					activeChar.sendMessage("Drop Retail has been reloaded.");
				}
				else if (type.startsWith("raidspawn"))
				{
					RaidSpawnTable.getInstance().reload();
					activeChar.sendMessage("RaidSpawnTable has been reloaded.");
				}
				else if (type.startsWith("am"))
				{
					AnnouceMultiSell.getInstance().reload();
					activeChar.sendMessage("AnnouceMultiSell has been reloaded.");
				}
				else if (type.startsWith("luckbox"))
				{
					LuckBoxData.getInstance().load();
					activeChar.sendMessage("Luck Box have been reloaded.");
				}
				else if (type.startsWith("cloak"))
				{
					CloakSystemManager.getInstance().reload();
					int refreshed = 0;
					for (L2PcInstance player : L2World.getInstance().getPlayers())
					{
						if (player != null)
						{
							CloakSystemManager.getInstance().sendConfig(player);
							refreshed++;
						}
					}
					activeChar.sendMessage("Cloak system reloaded. Players refreshed: " + refreshed + ", visual values: " + CloakSystemManager.getInstance().getRecordCount() + ".");
				}
				else if (type.startsWith("config"))
				{
					Config.load();
					activeChar.sendMessage("Configs files have been reloaded.");
				}
				else if (type.startsWith("oly"))
				{
					OlyClassDamageManager.loadConfig();
					activeChar.sendMessage("Oly Damage have been reloaded.");
				}
				else if (type.startsWith("crest"))
				{
					CrestCache.load();
					activeChar.sendMessage("Crests have been reloaded.");
				}
				else if (type.startsWith("gkinterface"))
				{
				TeleportLocationData2.getInstance().reload();			
				activeChar.sendMessage("Teleport Interface locations have been reloaded.");
				}
						
				else if (type.startsWith("cw"))
				{
					CursedWeaponsManager.getInstance().reload();
					activeChar.sendMessage("Cursed weapons have been reloaded.");
				}
				else if (type.startsWith("door"))
				{
					DoorTable.getInstance().reload();
					activeChar.sendMessage("Doors instance has been reloaded.");
				}
				else if (type.startsWith("htm"))
				{
					HtmCache.getInstance().reload();
					activeChar.sendMessage("The HTM cache has been reloaded.");
				}
				else if (type.startsWith("item"))
				{
					ItemTable.getInstance().reload();
					activeChar.sendMessage("Items' templates have been reloaded.");
				}
				else if (type.equals("multisell"))
				{
					MultisellData.getInstance().reload();
					activeChar.sendMessage("The multisell instance has been reloaded.");
				}
				else if (type.equals("npc"))
				{
					NpcTable.getInstance().reloadAllNpc();
					activeChar.sendMessage("NPCs templates have been reloaded.");
				}
				else if (type.startsWith("npcwalker"))
				{
					NpcWalkerRoutesTable.getInstance().reload();
					activeChar.sendMessage("NPCwalkers' routes have been reloaded.");
				}
				else if (type.startsWith("quest"))
				{
					if (st.hasMoreTokens())
					{
						int qId = Integer.parseInt(st.nextToken());
						if (QuestManager.getInstance().reload(qId))
							activeChar.sendMessage("Quest " + qId + " has been reloaded.");
						else
							activeChar.sendMessage("Quest " + qId + " failed reloading.");
					}
					else
						activeChar.sendMessage("Usage : //reload quest questNumber.");
				}
				else if (type.startsWith("scripts"))
				{
					QuestManager.getInstance().reloadAllQuests();
					activeChar.sendMessage("All scripts have been reloaded.");
				}
				else if (type.startsWith("skill"))
				{
					SkillTable.getInstance().reload();
					activeChar.sendMessage("Skills' XMLs have been reloaded.");
				}
				else if (type.startsWith("teleport"))
				{
					TeleportLocationTable.getInstance().reload();
					activeChar.sendMessage("The teleport location table has been reloaded.");
				}
				else if (type.startsWith("zone"))
				{
					ZoneManager.getInstance().reload();
					activeChar.sendMessage("Zones have been reloaded.");
				}
				else if (type.startsWith("fakenpc"))
				{
					FakePcsTable.getInstance().reload();
					activeChar.sendMessage("Fake PC templates have been reloaded.");
				}
				else if (type.startsWith("skip"))
				{
					SkipTable.getInstance();
					activeChar.sendMessage("Skip list have been reloaded.");
				}
				else if (type.startsWith("pvp"))
				{
					ClassDamageManager.loadConfig();
					activeChar.sendMessage("PvP Damage have been reloaded.");
				}
				/*
				else if (type.startsWith("balance"))
				{
					ClassDamageManager.loadConfig();
					OlyClassDamageManager.loadConfig();
					activeChar.sendMessage("Balance have been reloaded.");
				}*/
				else if (type.startsWith("fakeplayer"))
				{
					FakePlayerConfig.init();
					activeChar.sendMessage("FakePlayer config have been reloaded.");
				}
				else if (type.startsWith("dailyreward"))
				{
					DailyRewardCBData.getInstance().reload();
					activeChar.sendMessage("Daily rewards have been reloaded.");
				}
				else if (type.startsWith("events"))
				{
					TvTConfig.init();
					MultiTvTConfig.init();
					CTFConfig.init();
					DMConfig.init();
					LMConfig.init();
					KTBConfig.init();
					FOSConfig.init();
					ArenaConfig.init();

					TvTManager.getInstance().reload();
					MultiTvTManager.getInstance().reload();
					CTFManager.getInstance().reload();
					DMManager.getInstance().reload();
					LMManager.getInstance().reload();
					KTBManager.getInstance().reload();
					FOSManager.getInstance().reload();
					ArenaEvent.getInstance().reload();
					PartyFarmEvent.getInstance().reload();
					SoloBossEvent.getInstance().reload();
					PvpBossManager.reload();
					PvPEventManager.getInstance().reload();

					activeChar.sendMessage("All Events properties and schedules have been reloaded.");
				}
			}
			catch (Exception e)
			{
				activeChar.sendMessage("Usage : //reload <acar|announcement|config|crest|door|hwidbans>");
				activeChar.sendMessage("Usage : //reload <htm|item|multisell|npc|npcwalker|quest>");
				activeChar.sendMessage("Usage : //reload <scripts|skill|teleport|zone|fakenpc|skip|raidspawn>");
				activeChar.sendMessage("Usage : //reload <balance>|<fakeplayer>");
			}
		}
		// This provides a way to load new scripts without having to reboot the server.
		// If a script is already loaded, quest_reload should be used.
		else if (command.startsWith("admin_script_load"))
		{
			String[] parts = command.split(" ");
			if (parts.length < 2)
				activeChar.sendMessage("Example: //script_load quests/questFolder/filename.ext");
			else
			{
				File file = new File(L2ScriptEngineManager.SCRIPT_FOLDER, parts[1]);
				if (file.isFile())
				{
					try
					{
						L2ScriptEngineManager.getInstance().executeScript(file);
					}
					catch (ScriptException e)
					{
						activeChar.sendMessage("Failed loading: " + parts[1]);
						L2ScriptEngineManager.reportScriptFileError(file, e);
					}
					catch (Exception e)
					{
						activeChar.sendMessage("Failed loading: " + parts[1]);
					}
				}
				else
					activeChar.sendMessage("Current file hasn't been found: " + parts[1]);
			}
		}
		else if (command.equals("admin_balance"))
		{
			NpcHtmlMessage htm = new NpcHtmlMessage(0);
			htm.setFile("data/html/admin/balance/main.htm");
			activeChar.sendPacket(htm);
		}
		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}

	private static void kill(L2PcInstance activeChar, L2Character target)
	{
		if (target instanceof L2PcInstance)
		{
			if (!((L2PcInstance) target).isGM())
				target.stopAllEffects(); // e.g. invincibility effect
			target.reduceCurrentHp(target.getMaxHp() + target.getMaxCp() + 1, activeChar, null);
		}
		else if (target.isChampion())
			target.reduceCurrentHp(target.getMaxHp() * Config.CHAMPION_HP + 1, activeChar, null);
		else
			target.reduceCurrentHp(target.getMaxHp() + 1, activeChar, null);
	}

	private static void showMainPage(L2PcInstance activeChar, String command)
	{
		int mode = 0;
		String filename = null;
		try
		{
			mode = Integer.parseInt(command.substring(11));
		}
		catch (Exception e)
		{
		}

		switch (mode)
		{
		case 1:
			filename = "main";
			break;
		case 2:
			filename = "game";
			break;
		case 3:
			filename = "effects";
			break;
		case 4:
			filename = "server";
			break;
		default:
			filename = "main";
			break;
		}
		AdminHelpPage.showHelpPage(activeChar, filename + "_menu.htm");
	}
}
