// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.item.kind.Weapon;
import net.sf.l2j.gameserver.model.itemcontainer.Inventory;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;

/** One session per player. Never remove an inventory item by template ID. */
public final class TreasureHuntSession
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntSession.class.getName());
    private final L2PcInstance player;
    private StoneMinerInstance target;
    private int toolObjectId, toolItemId, rightHandId, leftHandId;

    public TreasureHuntSession(L2PcInstance player) { this.player = player; }

    public synchronized boolean begin(StoneMinerInstance stone)
    {
        CustomTreasureHunt hunt = stone.getTreasureHunt();
        if (hunt == null || stone.isDead() || !stone.isVisible() || stone.getTreasureHunt() == null ||
            player.getTarget() != stone || player.isAlikeDead() || player.isMounted() || player.isInStoreMode() ||
            player.isProcessingTransaction() || player.isInOlympiadMode() || player.isCursedWeaponEquipped() || player.isFishing())
            return false;
        if (target == stone && isEquippedFor(stone))
            return true;
        if (!finish())
            return false;
        // Do not overwrite an unresolved recovery record.
        if (Files.exists(journal()) || !player.getInventory().validateCapacity(1, false))
        {
            player.sendMessage("Nao foi possivel iniciar a mineracao. Verifique o inventario ou avise um administrador.");
            return false;
        }
        ItemInstance originalRight = player.getInventory().getPaperdollItem(Inventory.PAPERDOLL_RHAND);
        ItemInstance originalLeft = player.getInventory().getPaperdollItem(Inventory.PAPERDOLL_LHAND);
        rightHandId = originalRight == null ? 0 : originalRight.getObjectId();
        leftHandId = originalLeft == null ? 0 : originalLeft.getObjectId();
        toolItemId = hunt.getDefinition().getWeaponId();
        ItemInstance tool = null;
        try
        {
            tool = ItemTable.getInstance().createItem("TreasureHuntTool", toolItemId, 1, player, stone);
            toolObjectId = tool.getObjectId();
            // Persist exact IDs BEFORE adding the tool to the persistent inventory.
            saveJournal();
            player.getInventory().addItem("TreasureHuntTool", tool, player, stone);
            target = stone;
            stone.addMiner(player);
            player.useEquippableItem(tool, true);
            player.sendPacket(new ItemList(player, false));
            player.broadcastUserInfo();
            if (stone.getTreasureHunt() != hunt || stone.isDead() || !isEquippedFor(stone))
            {
                finish();
                player.sendMessage("Nao foi possivel equipar a ferramenta de mineracao.");
                return false;
            }
            return true;
        }
        catch (Exception e)
        {
            LOG.log(Level.SEVERE, "TreasureHunt tool creation failed for player " + player.getObjectId(), e);
            if (tool != null && player.getInventory().getItemByObjectId(tool.getObjectId()) == null)
                ItemTable.getInstance().destroyItem("TreasureHuntTool", tool, player, stone);
            finish();
            return false;
        }
    }

    public synchronized boolean isEquippedFor(StoneMinerInstance stone)
    {
        ItemInstance active = player.getActiveWeaponInstance();
        return target == stone && toolObjectId != 0 &&
            active != null && active.getObjectId() == toolObjectId && active.getItemId() == toolItemId;
    }

    public synchronized boolean ownsTemporary(int objectId)
    {
        return objectId != 0 && objectId == toolObjectId;
    }

    public synchronized boolean blocksUse(ItemInstance item)
    {
        return toolObjectId != 0 && (ownsTemporary(item.getObjectId()) || item.getItem() instanceof Weapon ||
            item.getItem().getBodyPart() == Item.SLOT_L_HAND);
    }

    public synchronized void onTargetChanged(L2Object newTarget)
    {
        if (target != null && target != newTarget)
            finish();
    }

    public synchronized void finishIfTarget(StoneMinerInstance stone)
    {
        if (target == stone)
            finish();
    }

    /** Returns false on cleanup failure, preserving IDs and the journal for recovery. */
    public synchronized boolean finish()
    {
        if (toolObjectId == 0)
            return true;
        player.abortAttack();
        ItemInstance tool = player.getInventory().getItemByObjectId(toolObjectId);
        if (tool != null)
        {
            if (tool.getItemId() != toolItemId || tool.getOwnerId() != player.getObjectId())
            {
                LOG.severe("TreasureHunt: tool identity mismatch for " + player.getObjectId() + "; manual recovery required.");
                return false;
            }
            if (tool.isEquipped())
                player.useEquippableItem(tool, true);
            if (!player.destroyItem("TreasureHuntTool", tool, player, false))
                return false;
        }
        restore(rightHandId);
        if (leftHandId != rightHandId)
            restore(leftHandId);
        try { Files.deleteIfExists(journal()); }
        catch (Exception e)
        {
            LOG.log(Level.WARNING, "TreasureHunt: cannot clear recovery journal", e);
            return false;
        }
        toolObjectId = toolItemId = rightHandId = leftHandId = 0;
        if (target != null)
            target.removeMiner(player);
        target = null;
        player.sendPacket(new ItemList(player, false));
        player.broadcastUserInfo();
        return true;
    }

    private void restore(int objectId)
    {
        if (objectId == 0)
            return;
        ItemInstance item = player.getInventory().getItemByObjectId(objectId);
        if (item != null && item.getOwnerId() == player.getObjectId() && !item.isEquipped())
            player.useEquippableItem(item, false);
    }

    /** Called on EnterWorld, before normal client interaction, including after a crash. */
    public synchronized void recover()
    {
        if (!Files.exists(journal()))
            return;
        try (InputStream input = Files.newInputStream(journal()))
        {
            Properties record = new Properties();
            record.load(input);
            int objectId = Integer.parseInt(record.getProperty("toolObjectId"));
            int itemId = Integer.parseInt(record.getProperty("toolItemId"));
            int right = Integer.parseInt(record.getProperty("rightHandId"));
            int left = Integer.parseInt(record.getProperty("leftHandId"));
            if (objectId <= 0 || itemId <= 0 || right < 0 || left < 0)
                throw new IllegalArgumentException("Invalid session journal");
            toolObjectId = objectId;
            toolItemId = itemId;
            rightHandId = right;
            leftHandId = left;
        }
        catch (Exception e)
        {
            LOG.log(Level.SEVERE, "TreasureHunt: invalid recovery journal for " + player.getObjectId() + "; manual recovery required.", e);
            return;
        }
        finish();
    }

    private Path journal()
    {
        return Paths.get("./data/treasurehunt-sessions", player.getObjectId() + ".properties");
    }

    private void saveJournal() throws Exception
    {
        Path destination = journal();
        Files.createDirectories(destination.getParent());
        Properties record = new Properties();
        record.setProperty("toolObjectId", Integer.toString(toolObjectId));
        record.setProperty("toolItemId", Integer.toString(toolItemId));
        record.setProperty("rightHandId", Integer.toString(rightHandId));
        record.setProperty("leftHandId", Integer.toString(leftHandId));
        Path temporary = Files.createTempFile(destination.getParent(), "session-", ".tmp");
        try
        {
            try (OutputStream output = Files.newOutputStream(temporary)) { record.store(output, "TreasureHunt recovery; preserve with database backups"); }
            Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        }
        finally { Files.deleteIfExists(temporary); }
    }
}
