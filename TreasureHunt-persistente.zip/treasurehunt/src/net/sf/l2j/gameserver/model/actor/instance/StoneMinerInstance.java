// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.actor.instance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.CustomTreasureHunt;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSpawnPoint;
import net.sf.l2j.gameserver.model.item.DropCategory;
import net.sf.l2j.gameserver.model.item.DropData;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.FlyToLocation;
import net.sf.l2j.gameserver.network.serverpackets.FlyToLocation.FlyType;
import net.sf.l2j.gameserver.network.serverpackets.PlaySound;
import net.sf.l2j.gameserver.network.serverpackets.ValidateLocation;
import net.sf.l2j.util.Rnd;

/** Non-monster NPC: rewards are handled here once, without the normal monster drop path. */
public final class StoneMinerInstance extends L2Npc
{
    private static final Logger LOG = Logger.getLogger(StoneMinerInstance.class.getName());
    private final AtomicBoolean deathHandled = new AtomicBoolean();
    private final AtomicBoolean saveFailureReported = new AtomicBoolean();
    private volatile CustomTreasureHunt treasureHunt;
    private final Set<L2PcInstance> miners = Collections.newSetFromMap(new ConcurrentHashMap<L2PcInstance, Boolean>());

    public StoneMinerInstance(int objectId, NpcTemplate template)
    {
        super(objectId, template);
        setIsImmobilized(true);
    }

    public CustomTreasureHunt getTreasureHunt() { return treasureHunt; }
    public void setTreasureHunt(CustomTreasureHunt hunt) { treasureHunt = hunt; }
    public void addMiner(L2PcInstance player) { miners.add(player); }
    public void removeMiner(L2PcInstance player) { miners.remove(player); }

    public void releaseMiners()
    {
        for (L2PcInstance player : new ArrayList<>(miners))
            player.getTreasureHuntSession().finishIfTarget(this);
    }

    @Override public boolean isAutoAttackable(L2Character attacker) { return true; }
    @Override public boolean isAggressive() { return false; }

    @Override
    public void onAction(L2PcInstance player)
    {
        boolean alreadyTargeted = player.getTarget() == this;
        if (!alreadyTargeted)
            player.setTarget(this);
        if (player.getTarget() != this || !player.getTreasureHuntSession().begin(this))
        {
            player.sendPacket(ActionFailed.STATIC_PACKET);
            return;
        }
        if (alreadyTargeted)
            super.onAction(player);
        else
            player.sendPacket(ActionFailed.STATIC_PACKET);
    }

    @Override
    public void reduceCurrentHp(double damage, L2Character attacker, boolean awake, boolean isDOT, L2Skill skill)
    {
        // Pets, summons, DOTs and skills cannot bypass the event tool.
        if (treasureHunt == null || !(attacker instanceof L2PcInstance) || skill != null || isDOT)
            return;
        L2PcInstance player = (L2PcInstance) attacker;
        if (player.getTarget() == this && !player.isAlikeDead() && player.getTreasureHuntSession().isEquippedFor(this))
            super.reduceCurrentHp(damage, attacker, awake, false, null);
    }

    @Override
    public synchronized boolean doDie(L2Character killer)
    {
        if (isDead() || !deathHandled.compareAndSet(false, true)) return false;
        CustomTreasureHunt owner = treasureHunt;
        boolean rewardEligible = owner != null && killer instanceof L2PcInstance &&
            ((L2PcInstance) killer).getTreasureHuntSession().isEquippedFor(this);
        if (owner != null && !owner.recordDestroyed())
        {
            setCurrentHp(1);
            deathHandled.set(false);
            if (saveFailureReported.compareAndSet(false, true))
                LOG.severe("TreasureHunt: cannot save broken stone; death and reward blocked until storage is repaired.");
            return false;
        }
        if (!super.doDie(killer)) return false;
        try
        {
            if (rewardEligible)
            {
                L2PcInstance player = (L2PcInstance) killer;
                for (DropCategory category : getTemplate().getDropData())
                {
                    if (category.isSweep())
                        continue;
                    for (DropData drop : category.getAllDrops())
                    {
                        if (drop.isQuestDrop() || drop.getMinDrop() <= 0 || drop.getMaxDrop() < drop.getMinDrop() || Rnd.get(DropData.MAX_CHANCE) >= drop.getChance())
                            continue;
                        int count = Rnd.get(drop.getMinDrop(), drop.getMaxDrop());
                        if (Config.TREASURE_HUNT_AUTO_LOOT)
                            player.addItem("StoneMinerReward", drop.getItemId(), count, this, true);
                        else
                        {
                            ItemInstance item = ItemTable.getInstance().createItem("TreasureHuntReward", drop.getItemId(), count, player, this);
                            item.dropMe(this, getX(), getY(), getZ());
                        }
                    }
                }
                player.sendPacket(new PlaySound("ItemSound.quest_finish"));
            }
        }
        catch (Exception e) { LOG.log(Level.SEVERE, "StoneMiner reward failed for NPC " + getObjectId(), e); }
        finally
        {
            releaseMiners();
            if (killer instanceof L2PcInstance)
                ((L2PcInstance) killer).getTreasureHuntSession().finishIfTarget(this);
        }
        return true;
    }

    @Override
    public void deleteMe()
    {
        treasureHunt = null;
        releaseMiners();
        super.deleteMe();
    }

    /** Preserve the original entrance effect, clipping displacement with the core's path API. */
    public void throwUpNearbyPlayers()
    {
        for (L2PcInstance player : getKnownList().getKnownType(L2PcInstance.class))
        {
            if (player.isAlikeDead() || player.isTeleporting() || player.isMounted() || player.isInBoat())
                continue;
            double dx = player.getX() - getX(), dy = player.getY() - getY();
            if (dx == 0 && dy == 0) { dx = 1; dy = 1; }
            double distance = Math.sqrt(dx * dx + dy * dy);
            if (distance >= 500 || Math.abs(player.getZ() - getZ()) > 200)
                continue;
            int x = getX() + (int) (dx * 500 / distance);
            int y = getY() + (int) (dy * 500 / distance);
            Location destination = PathFinding.getInstance().canMoveToTargetLoc(player.getX(), player.getY(), player.getZ(), x, y, player.getZ());
            if (destination == null || !TreasureHuntSpawnPoint.isClearArea(GeoData.getInstance(),
                destination.getX(), destination.getY(), destination.getZ(), Math.max(32, (int) Math.ceil(player.getTemplate().getCollisionRadius()) + 16)))
                continue;
            player.abortAttack();
            player.broadcastPacket(new FlyToLocation(player, destination.getX(), destination.getY(), destination.getZ(), FlyType.THROW_UP));
            player.setXYZ(destination.getX(), destination.getY(), destination.getZ());
            player.broadcastPacket(new ValidateLocation(player));
            player.standUp();
        }
    }
}
