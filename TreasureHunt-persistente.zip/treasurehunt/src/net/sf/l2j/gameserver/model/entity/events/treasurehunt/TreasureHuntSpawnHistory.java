// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.io.BufferedReader;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Durable shared history; no expiry or automatic reset. A 64x64 XY cell is never reused. */
public final class TreasureHuntSpawnHistory implements AutoCloseable
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntSpawnHistory.class.getName());
    private final Map<Long, List<UsedPoint>> used = new HashMap<>();
    private FileChannel channel;
    private FileLock lock;
    private boolean ready;
    private boolean activeStoreInitialized;

    public TreasureHuntSpawnHistory(Path file)
    {
        try
        {
            Path path = file.toAbsolutePath();
            Files.createDirectories(path.getParent());
            channel = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE);
            lock = channel.tryLock();
            if (lock == null) throw new IllegalStateException("History is locked by another server");
            if (channel.size() > 0)
            {
                ByteBuffer tail = ByteBuffer.allocate(1);
                channel.read(tail, channel.size() - 1);
                if (tail.get(0) != '\n') throw new IllegalArgumentException("Incomplete history record; restore a consistent backup");
            }
            channel.position(0);
            // Borrow the already locked channel. Its lifetime is owned by this class.
            // Do not close this reader here: that would close the channel used by reserve().
            BufferedReader reader = new BufferedReader(Channels.newReader(channel, StandardCharsets.UTF_8.newDecoder(), -1));
            String line;
            while ((line = reader.readLine()) != null)
            {
                line = line.trim();
                if (line.equals("# ACTIVE_STONES_V1")) activeStoreInitialized = true;
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] fields = line.split("\\s+");
                if (fields.length != 2) throw new IllegalArgumentException("Invalid history record");
                remember(Integer.parseInt(fields[0]), Integer.parseInt(fields[1]));
            }
            ready = true;
        }
        catch (Exception e)
        {
            close();
            LOG.log(Level.SEVERE, "TreasureHunt: location history unavailable; spawning is blocked to prevent repeats.", e);
        }
    }

    public static TreasureHuntSpawnHistory getInstance() { return Holder.INSTANCE; }
    public synchronized boolean isReady() { return ready; }
    public synchronized boolean wasUsed(int x, int y)
    {
        if (!ready || used.containsKey(key(x, y))) return true;
        int cx = Math.floorDiv(x, 64), cy = Math.floorDiv(y, 64);
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
            {
                List<UsedPoint> points = used.get(cellKey(cx + dx, cy + dy));
                if (points == null) continue;
                for (UsedPoint point : points)
                {
                    long px = (long) x - point.x, py = (long) y - point.y;
                    if (px * px + py * py < 64L * 64) return true;
                }
            }
        return false;
    }

    private void remember(int x, int y)
    {
        long cell = key(x, y);
        List<UsedPoint> points = used.get(cell);
        if (points == null) { points = new ArrayList<>(); used.put(cell, points); }
        points.add(new UsedPoint(x, y));
    }

    /** Force the record to disk BEFORE creating an NPC, including across restarts. */
    public synchronized boolean reserve(int x, int y)
    {
        if (wasUsed(x, y)) return false;
        remember(x, y);
        try
        {
            append(x + " " + y + "\n");
            return true;
        }
        catch (Exception e)
        {
            ready = false;
            LOG.log(Level.SEVERE, "TreasureHunt: cannot persist location; no NPC will be created.", e);
            return false;
        }
    }

    public synchronized boolean isActiveStoreInitialized() { return activeStoreInitialized; }

    /** Marker distinguishes first installation from a lost active-stones file. */
    public synchronized boolean initializeActiveStore()
    {
        if (!ready) return false;
        if (activeStoreInitialized) return true;
        try
        {
            append("# ACTIVE_STONES_V1\n");
            activeStoreInitialized = true;
            return true;
        }
        catch (Exception e)
        {
            ready = false;
            LOG.log(Level.SEVERE, "TreasureHunt: active-stones marker cannot be saved.", e);
            return false;
        }
    }

    private void append(String line) throws java.io.IOException
    {
        ByteBuffer record = ByteBuffer.wrap(line.getBytes(StandardCharsets.UTF_8));
        channel.position(channel.size());
        while (record.hasRemaining()) channel.write(record);
        channel.force(true);
    }

    private static long key(int x, int y)
    {
        if (x < -327680 || x > 229375 || y < -262144 || y > 262143)
            throw new IllegalArgumentException("History coordinates outside world");
        return cellKey(Math.floorDiv(x, 64), Math.floorDiv(y, 64));
    }

    private static long cellKey(int x, int y) { return ((long) x << 32) | (y & 0xffffffffL); }

    private static final class UsedPoint
    {
        private final int x, y;
        private UsedPoint(int x, int y) { this.x = x; this.y = y; }
    }

    @Override public synchronized void close()
    {
        ready = false;
        try { if (lock != null) lock.release(); }
        catch (Exception e) { LOG.log(Level.WARNING, "TreasureHunt: history lock release failed", e); }
        try { if (channel != null) channel.close(); }
        catch (Exception e) { LOG.log(Level.WARNING, "TreasureHunt: history close failed", e); }
    }

    private static final class Holder
    {
        private static final TreasureHuntSpawnHistory INSTANCE = new TreasureHuntSpawnHistory(Paths.get("./data/treasurehunt-used-locations.log"));
    }
}
