// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.model.Location;

/** Terrain validation for random surface coordinates; no list of fixed positions. */
public final class TreasureHuntSpawnPoint
{
    private TreasureHuntSpawnPoint() { }

    public static final class Validation
    {
        private final Integer groundZ;
        private final String code, detail;
        private Validation(Integer groundZ, String code, String detail)
        { this.groundZ = groundZ; this.code = code; this.detail = detail; }
        public Integer getGroundZ() { return groundZ; }
        public String getCode() { return code; }
        public String getReason() { return code + (detail == null ? "" : " " + detail); }
    }

    public static Validation validateSurface(int x, int y, int clearance)
    {
        GeoData geo = GeoData.getInstance();
        if (Config.GEODATA <= 0) return rejected("GEODATA_DISABLED", "GeoData=" + Config.GEODATA);
        if (geo == null || !geo.hasGeo(x, y)) return rejected("GEODATA_MISSING", x + " " + y);
        PathFinding paths = PathFinding.getInstance();
        if (paths == null) return rejected("PATHFINDING_UNAVAILABLE", null);
        // Select the highest loaded layer, not a player's Z or a fixed expected altitude.
        int groundZ = geo.getHeight(x, y, Short.MAX_VALUE);
        String failure = areaFailure(geo, paths, x, y, groundZ, clearance);
        if (failure != null) return rejected(failure, x + " " + y + " " + groundZ);
        // A walkable approach is sufficient; do not demand a perfectly flat mountain.
        for (int dx = -128; dx <= 128; dx += 128)
            for (int dy = -128; dy <= 128; dy += 128)
            {
                if ((dx == 0 && dy == 0) || !geo.hasGeo(x + dx, y + dy)) continue;
                int ax = x + dx, ay = y + dy, az = geo.getHeight(ax, ay, groundZ);
                if ((geo.getNsweNearest(geo.getGeoX(ax), geo.getGeoY(ay), az) & 15) == 0) continue;
                if (reaches(paths.canMoveToTargetLoc(ax, ay, az, x, y, groundZ), x, y, groundZ) &&
                    reaches(paths.canMoveToTargetLoc(x, y, groundZ, ax, ay, az), ax, ay, az))
                    return new Validation(groundZ, "OK", null);
            }
        return rejected("NO_WALKABLE_APPROACH", x + " " + y + " " + groundZ);
    }

    public static boolean isClearArea(GeoData geo, int x, int y, int z, int clearance)
    {
        return Config.GEODATA > 0 && geo != null && PathFinding.getInstance() != null &&
            areaFailure(geo, PathFinding.getInstance(), x, y, z, clearance) == null;
    }

    private static String areaFailure(GeoData geo, PathFinding paths, int x, int y, int z, int clearance)
    {
        if (clearance < 16 || clearance > 256) return "INVALID_CLEARANCE";
        int radius = ((clearance + 15) / 16) * 16;
        for (int dx = -radius; dx <= radius; dx += 16)
            for (int dy = -radius; dy <= radius; dy += 16)
            {
                int px = x + dx, py = y + dy;
                if (!geo.hasGeo(px, py)) return "FOOTPRINT_NO_GEO";
                int pz = geo.getHeight(px, py, z);
                // Permit slopes; still reject ledges or another floor under the footprint.
                if (Math.abs(pz - z) > 64) return "FOOTPRINT_HEIGHT_EDGE";
                if ((geo.getNsweNearest(geo.getGeoX(px), geo.getGeoY(py), pz) & 15) != 15)
                    return "FOOTPRINT_WALL";
                if ((dx != 0 || dy != 0) &&
                    (!reaches(paths.canMoveToTargetLoc(x, y, z, px, py, pz), px, py, pz) ||
                     !reaches(paths.canMoveToTargetLoc(px, py, pz, x, y, z), x, y, z)))
                    return "FOOTPRINT_PATH_BLOCKED";
            }
        return null;
    }

    private static boolean reaches(Location result, int x, int y, int z)
    {
        return result != null && Math.abs(result.getX() - x) <= 8 && Math.abs(result.getY() - y) <= 8 && Math.abs(result.getZ() - z) <= 24;
    }

    private static Validation rejected(String code, String detail) { return new Validation(null, code, detail); }
}
