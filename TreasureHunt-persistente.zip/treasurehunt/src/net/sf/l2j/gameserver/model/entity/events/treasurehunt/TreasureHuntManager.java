// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.util.Rnd;

public final class TreasureHuntManager implements Runnable
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntManager.class.getName());
    private List<TreasureHunt> hunts = Collections.emptyList();
    private final Map<String, CustomTreasureHunt> active = new LinkedHashMap<>();
    private boolean started, enabled, restorePending = true;
    private int interval;
    private long nextRun;

    private TreasureHuntManager() { }
    public static TreasureHuntManager getInstance() { return Holder.INSTANCE; }

    public synchronized void start()
    {
        if (started) return;
        reload();
        started = true;
        ThreadPoolManager.getInstance().scheduleGeneral(this, 1000);
    }

    /** Reload affects future draws; it never deletes a living stone. */
    public synchronized boolean reload()
    {
        try
        {
            List<TreasureHunt> replacement = TreasureHuntData.load();
            if (!TreasureHuntSpawnHistory.getInstance().isReady() || !TreasureHuntActiveStore.getInstance().isReady())
            {
                LOG.warning("TreasureHunt: history/journal unavailable; keeping current stones.");
                return false;
            }
            hunts = replacement;
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
            nextRun = System.nanoTime();
            restorePending = true;
            LOG.info("TreasureHunt: Loaded " + hunts.size() + " entries." + (enabled ? "" : " (new spawns paused)"));
            return true;
        }
        catch (Exception e)
        {
            LOG.log(Level.SEVERE, "TreasureHunt: configuration rejected; previous events preserved.", e);
            return false;
        }
    }

    @Override public void run()
    {
        try { tick(); }
        catch (Exception e) { LOG.log(Level.SEVERE, "TreasureHunt tick failed", e); }
        finally { ThreadPoolManager.getInstance().scheduleGeneral(this, 1000); }
    }

    private synchronized void tick()
    {
        for (Iterator<CustomTreasureHunt> iterator = active.values().iterator(); iterator.hasNext();)
        {
            L2Npc npc = iterator.next().getNpc();
            if (npc == null || npc.isDead() || !npc.isVisible())
            {
                iterator.remove();
                restorePending = true;
            }
        }
        long now = System.nanoTime();
        int configuredInterval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
        if (enabled != Config.ENABLE_TREASURE_HUNT || interval != configuredInterval)
        {
            boolean enabling = !enabled && Config.ENABLE_TREASURE_HUNT;
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = configuredInterval;
            nextRun = now + (enabling ? 0 : TimeUnit.SECONDS.toNanos(interval));
        }
        TreasureHuntActiveStore store = TreasureHuntActiveStore.getInstance();
        if (!store.isReady()) return;
        if (restorePending || (enabled && now - nextRun >= 0))
        {
            restorePending = false;
            for (TreasureHuntActiveStore.Record record : store.snapshot())
                if (!active.containsKey(record.getId()))
                {
                    CustomTreasureHunt restored = new CustomTreasureHunt(record.getDefinition());
                    if (restored.restoreNpc(record, occupied())) active.put(record.getId(), restored);
                }
        }
        if (!enabled || now - nextRun < 0) return;
        nextRun = now + TimeUnit.SECONDS.toNanos(interval);
        for (TreasureHunt definition : hunts)
            if (Rnd.get(100) < definition.getChance())
            {
                CustomTreasureHunt added = new CustomTreasureHunt(definition);
                added.spawnNpc(occupied());
                if (added.getNpc() != null && added.getNpc().isVisible() && !added.getNpc().isDead() && added.getActiveId() != null)
                    active.put(added.getActiveId(), added);
            }
    }

    private List<L2Npc> occupied()
    {
        List<L2Npc> result = new ArrayList<>();
        for (CustomTreasureHunt hunt : active.values())
            if (hunt.getNpc() != null && !hunt.getNpc().isDead() && hunt.getNpc().isVisible()) result.add(hunt.getNpc());
        return result;
    }

    private static final class Holder
    {
        private static final TreasureHuntManager INSTANCE = new TreasureHuntManager();
    }
}
