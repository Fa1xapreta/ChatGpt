// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.item.kind.Weapon;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.network.serverpackets.Earthquake;
import net.sf.l2j.gameserver.network.serverpackets.PlaySound;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Rnd;

public final class CustomTreasureHunt
{
    private static final Logger LOG = Logger.getLogger(CustomTreasureHunt.class.getName());
    private static final int MAX_ATTEMPTS = 1000;
    private final TreasureHunt definition;
    private final TreasureHuntSpawnHistory history;
    private final TreasureHuntActiveStore store;
    private String activeId;
    private volatile StoneMinerInstance npc;

    public CustomTreasureHunt(TreasureHunt definition)
    { this(definition, TreasureHuntSpawnHistory.getInstance(), TreasureHuntActiveStore.getInstance()); }
    public CustomTreasureHunt(TreasureHunt definition, TreasureHuntSpawnHistory history)
    { this(definition, history, TreasureHuntActiveStore.getInstance()); }
    public CustomTreasureHunt(TreasureHunt definition, TreasureHuntSpawnHistory history, TreasureHuntActiveStore store)
    { this.definition = definition; this.history = history; this.store = store; }
    public String getActiveId() { return activeId; }
    public boolean recordDestroyed() { return store.remove(activeId); }
    public TreasureHunt getDefinition() { return definition; }
    public StoneMinerInstance getNpc() { return npc; }

    /** Manager serializes rounds. Every candidate is sampled across the configured region. */
    public boolean spawnNpc(List<L2Npc> occupied)
    {
        L2Npc pending = null;
        try
        {
            NpcTemplate template = NpcTable.getInstance().getTemplate(definition.getNpcId());
            if (template == null)
                throw new IllegalStateException("Missing NPC template " + definition.getNpcId());
            int clearance = Math.max(32, (int) Math.ceil(template.getCollisionRadius()) + 16);
            if (npc != null && !npc.isDead() && npc.isVisible())
                return false; // A living stone is never replaced by another round.
            if (!store.isReady())
            {
                LOG.severe("TreasureHunt " + definition.getId() + ": ACTIVE_JOURNAL_UNAVAILABLE; spawn blocked.");
                return false;
            }
            if (!history.isReady())
            {
                LOG.severe("TreasureHunt " + definition.getId() + ": HISTORY_UNAVAILABLE; spawn blocked.");
                return false;
            }
            if (Config.GEODATA <= 0)
            {
                LOG.warning("TreasureHunt " + definition.getId() + ": GEODATA_DISABLED; spawn blocked.");
                return false;
            }
            Map<String, Integer> rejections = new LinkedHashMap<>();
            String lastFailure = "none";
            int materializations = 0;
            for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++)
            {
                int x = definition.getMinX() + Rnd.get(32768);
                int y = definition.getMinY() + Rnd.get(32768);
                if (history.wasUsed(x, y))
                {
                    count(rejections, "USED_LOCATION");
                    continue;
                }
                TreasureHuntSpawnPoint.Validation validation = TreasureHuntSpawnPoint.validateSurface(x, y, clearance);
                Integer groundZ = validation.getGroundZ();
                if (groundZ == null)
                {
                    count(rejections, validation.getCode());
                    lastFailure = validation.getReason();
                    continue;
                }
                if (!hasRoom(x, y, groundZ, clearance, occupied))
                {
                    count(rejections, "STONE_OCCUPIED");
                    continue;
                }
                if (materializations >= 16)
                {
                    count(rejections, "SPAWN_VALIDATION_LIMIT");
                    break;
                }
                // Keep the current stone until the replacement passes post-spawn validation.
                L2Spawn spawn = new L2Spawn(template);
                spawn.setLocx(x);
                spawn.setLocy(y);
                spawn.setLocz(groundZ);
                spawn.setHeading(0);
                spawn.stopRespawn();
                // A crash or spawn failure may consume a point, but it can never be reused.
                if (!history.reserve(x, y))
                {
                    LOG.severe("TreasureHunt " + definition.getId() + ": cannot durably reserve a new location; spawn aborted.");
                    return false;
                }
                activeId = store.add(definition, x, y, groundZ);
                if (activeId == null) return false;
                materializations++;
                pending = spawn.doSpawn(false);
                L2Npc created = pending;
                if (!(created instanceof StoneMinerInstance) || !created.isVisible())
                {
                    if (created != null) created.deleteMe();
                    pending = null;
                    if (!store.remove(activeId)) return false;
                    activeId = null;
                    throw new IllegalStateException("StoneMiner spawn failed for " + definition.getId());
                }
                // L2Spawn performs its own height adjustment. Reject a changed floor/location.
                if (created.getX() != x || created.getY() != y || Math.abs(created.getZ() - groundZ) > 16 ||
                    !TreasureHuntSpawnPoint.isClearArea(GeoData.getInstance(), created.getX(), created.getY(), created.getZ(), clearance))
                {
                    created.deleteMe();
                    pending = null;
                    if (!store.remove(activeId)) return false;
                    activeId = null;
                    count(rejections, "SPAWN_POSITION_CHANGED");
                    LOG.warning("TreasureHunt " + definition.getId() + ": L2Spawn changed the validated position; rejected.");
                    continue;
                }
                npc = (StoneMinerInstance) created;
                pending = null;
                npc.setTreasureHunt(this);
                npc.broadcastPacket(new SocialAction(npc, 1));
                npc.broadcastPacket(new Earthquake(npc.getX(), npc.getY(), npc.getZ(), 5, 3));
                npc.broadcastPacket(new PlaySound("SkillSound5.target_magic_circle_01"));
                npc.throwUpNearbyPlayers();
                Broadcast.gameAnnounceToOnlinePlayers(npc.getName() + " apareceu em " + definition.getTerritoryName() + ".");
                return true;
            }
            LOG.warning("TreasureHunt " + definition.getId() + " region=" + definition.getRegion() + ": no new safe position after " +
                MAX_ATTEMPTS + " attempts; rejected=" + rejections + "; last=" + lastFailure + ". No forced spawn.");
        }
        catch (Exception e)
        {
            if (pending != null)
                try { pending.deleteMe(); }
                catch (Exception cleanup) { LOG.log(Level.SEVERE, "TreasureHunt pending NPC cleanup failed", cleanup); }
            LOG.log(Level.WARNING, "TreasureHunt spawn failed: " + definition.getId(), e);
        }
        return false;
    }

    /** Restore the same living stone; this is not a new draw and does not reuse history. */
    public boolean restoreNpc(TreasureHuntActiveStore.Record record, List<L2Npc> occupied)
    {
        if (!store.isReady() || !history.isReady()) return false;
        if (npc != null && npc.isVisible() && !npc.isDead()) return true;
        L2Npc pending = null;
        try
        {
            NpcTemplate template = NpcTable.getInstance().getTemplate(definition.getNpcId());
            if (template == null || !"StoneMiner".equals(template.getType()) ||
                !(ItemTable.getInstance().getTemplate(definition.getWeaponId()) instanceof Weapon))
            {
                LOG.warning("TreasureHunt: saved stone resources are unavailable; record preserved: " + record.getId());
                return false;
            }
            int clearance = Math.max(32, (int) Math.ceil(template.getCollisionRadius()) + 16);
            int x = record.getX(), y = record.getY(), z = record.getZ();
            TreasureHuntSpawnPoint.Validation validation = TreasureHuntSpawnPoint.validateSurface(x, y, clearance);
            if (validation.getGroundZ() == null || Math.abs(validation.getGroundZ() - z) > 16 ||
                !hasRoom(x, y, z, clearance, occupied))
            {
                LOG.warning("TreasureHunt: saved stone " + record.getId() + " cannot be restored safely at " + x + " " + y + " " + z + "; record preserved.");
                return false;
            }
            if (!history.wasUsed(x, y) && !history.reserve(x, y)) return false;
            L2Spawn spawn = new L2Spawn(template);
            spawn.setLocx(x); spawn.setLocy(y); spawn.setLocz(z); spawn.setHeading(0); spawn.stopRespawn();
            pending = spawn.doSpawn(false);
            if (!(pending instanceof StoneMinerInstance) || !pending.isVisible() || pending.getX() != x || pending.getY() != y ||
                Math.abs(pending.getZ() - z) > 16 || !TreasureHuntSpawnPoint.isClearArea(GeoData.getInstance(), x, y, pending.getZ(), clearance))
            {
                if (pending != null) pending.deleteMe();
                return false;
            }
            activeId = record.getId();
            npc = (StoneMinerInstance) pending;
            npc.setTreasureHunt(this);
            return true; // Existing stones do not replay the falling effects on restart.
        }
        catch (Exception e)
        {
            if (pending != null)
                try { pending.deleteMe(); }
                catch (Exception cleanup) { LOG.log(Level.SEVERE, "TreasureHunt restore cleanup failed", cleanup); }
            LOG.log(Level.WARNING, "TreasureHunt saved stone restoration failed; record preserved.", e);
            return false;
        }
    }

    private static void count(Map<String, Integer> rejections, String reason)
    {
        Integer previous = rejections.get(reason);
        rejections.put(reason, previous == null ? 1 : previous + 1);
    }

    private static boolean hasRoom(int x, int y, int z, int clearance, List<L2Npc> occupied)
    {
        for (L2Npc other : occupied)
        {
            if (other == null || other.isDead() || !other.isVisible())
                continue;
            long dx = (long) x - other.getX(), dy = (long) y - other.getY();
            int gap = Math.max(96, clearance + (int) Math.ceil(other.getCollisionRadius()) + 16);
            if (Math.abs(z - other.getZ()) < 128 && dx * dx + dy * dy < (long) gap * gap)
                return false;
        }
        return true;
    }

    public void despawnNpc()
    {
        StoneMinerInstance old = npc;
        npc = null;
        if (old == null) return;
        old.setTreasureHunt(null);
        old.releaseMiners();
        if (old.getSpawn() != null) old.getSpawn().stopRespawn();
        old.deleteMe();
    }
}
