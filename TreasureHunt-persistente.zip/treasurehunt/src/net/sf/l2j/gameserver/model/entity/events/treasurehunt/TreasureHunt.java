// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

/** Immutable region definition, using the same region names as geodata files. */
public final class TreasureHunt
{
    private final int id, npcId, weaponId, chance, tileX, tileY;
    private final String territoryName;

    public TreasureHunt(int id, String geodata, int npcId, int weaponId, int chance, String territoryName)
    {
        if (id < 0 || npcId <= 0 || weaponId <= 0 || chance < 0 || chance > 100 || territoryName.trim().isEmpty())
            throw new IllegalArgumentException("Invalid treasure configuration: " + id);
        if (!geodata.matches("[0-9]{2}_[0-9]{2}"))
            throw new IllegalArgumentException("Invalid geodata region: " + geodata);
        String[] tile = geodata.split("_");
        tileX = Integer.parseInt(tile[0]); tileY = Integer.parseInt(tile[1]);
        if (tileX < 10 || tileX > 26 || tileY < 10 || tileY > 25)
            throw new IllegalArgumentException("Region outside Interlude world: " + geodata);
        this.id = id; this.npcId = npcId; this.weaponId = weaponId; this.chance = chance;
        this.territoryName = territoryName;
    }

    public int getId() { return id; }
    public int getNpcId() { return npcId; }
    public int getWeaponId() { return weaponId; }
    public int getChance() { return chance; }
    public String getTerritoryName() { return territoryName; }
    public int getMinX() { return (tileX - 20) * 32768; }
    public int getMinY() { return (tileY - 18) * 32768; }
    public String getRegion() { return tileX + "_" + tileY; }
}
