CREATE TABLE IF NOT EXISTS milenium_gear_players (
  char_id INT NOT NULL,
  name VARCHAR(35) NOT NULL,
  class_id INT NOT NULL DEFAULT 0,
  clan VARCHAR(64) NOT NULL DEFAULT '',
  score INT NOT NULL DEFAULT 0,
  pvp INT NOT NULL DEFAULT 0,
  gm TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (char_id), KEY gear_rank (score), KEY pvp_rank (pvp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS milenium_gear_items (
  char_id INT NOT NULL,
  object_id INT NOT NULL,
  item_id INT NOT NULL,
  enchant_level INT NOT NULL DEFAULT 0,
  ref1 INT NOT NULL DEFAULT 0,
  ref2 INT NOT NULL DEFAULT 0,
  slot_mask INT NOT NULL DEFAULT 0,
  score INT NOT NULL DEFAULT 0,
  PRIMARY KEY (char_id,object_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
