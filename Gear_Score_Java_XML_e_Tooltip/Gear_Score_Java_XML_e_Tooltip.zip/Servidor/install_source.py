#!/usr/bin/env python3
"""Apply only the four GearScore integration edits to the user's CURRENT Java sources."""
from pathlib import Path
import sys,shutil,difflib,datetime
G='net/sf/l2j/gameserver/'
def edit(rel,s):
 if 'Milenium GearScore integration' in s:return s
 if rel.endswith('/Item.java'):
  assert 'int getScore(' not in s,'Item already has getScore(); compare its existing implementation manually.'
  assert s.count('private final String _name;')==1 and s.count('_name = set.getString("name");')==1
  s=s.replace('private final String _name;','// Milenium GearScore integration\n\tprivate final int _score;\n\tprivate final String _name;',1)
  s=s.replace('_name = set.getString("name");','_name = set.getString("name");\n\t\t_score = Math.max(0, set.getInteger("score", 0));',1)
  needle='public final String getName()';assert s.count(needle)==1
  return s.replace(needle,'public int getScore() { return _score; }\n\n\t'+needle,1)
 if rel.endswith('/GameServer.java'):
  needle='ThreadPoolManager.getInstance();';assert s.count(needle)==1
  # Initialization here schedules first run after startup; source tables are loaded later.
  # Start after the standard LuckBox loading marker, when ItemTable/world are ready.
  needle='LuckBoxData.getInstance().load();';assert s.count(needle)==1
  return s.replace(needle,needle+'\n\t\t// Milenium GearScore integration\n\t\tnet.sf.l2j.gameserver.gearscore.GearScoreService.getInstance().start();',1)
 if rel.endswith('/RequestBypassToServer.java'):
  needle='if (activeChar == null)';a=s.index(needle);brace=s.index('{',a);depth=1;i=brace+1
  while depth:
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  return s[:i]+'''\n        // Milenium GearScore integration: exact commands, independent one-second limit.
        if (net.sf.l2j.gameserver.gearscore.GearScoreService.getInstance().handle(activeChar, _command))
            return;
'''+s[i:]
 if rel.endswith('/MultisellData.java'):
  needle='final ListContainer list = generateMultiSell(listName, inventoryOnly, player, taxRate);';assert s.count(needle)==1
  return s.replace(needle,needle+'\n\t\t// Milenium GearScore integration\n\t\tnet.sf.l2j.gameserver.gearscore.GearScoreService.getInstance().sendPreviews(player, list);',1)
 raise AssertionError(rel)
FILES=[G+'model/item/kind/Item.java',G+'GameServer.java',G+'network/clientpackets/RequestBypassToServer.java',G+'datatables/MultisellData.java']
def main():
 root=Path(sys.argv[1]).resolve();plan=[]
 for rel in FILES:
  p=root/rel;b=p.read_bytes()
  try:s=b.decode('utf-8');encoding='utf-8'
  except UnicodeDecodeError:s=b.decode('cp1252');encoding='cp1252'
  s=s.replace('\r\n','\n');changed=edit(rel,s)
  if changed!=s:plan.append((p,b,changed.replace('\n','\r\n').encode(encoding) if b'\r\n' in b else changed.encode(encoding)))
 bundled=Path(__file__).parent/'java'/G/'gearscore';assert bundled.is_dir()
 backup=root.parent/('gearscore-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir()
 for p,old,new in plan:
  dest=backup/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(old);p.write_bytes(new)
 target=root/G/'gearscore';target.mkdir(parents=True,exist_ok=True)
 for p in bundled.glob('*.java'):
  dst=target/p.name
  if dst.exists():shutil.copyfile(dst,backup/p.name)
  shutil.copyfile(p,dst)
 print('Integrated',len(plan),'existing files; new module copied. Backup:',backup)
 print('Import sql/gearscore.sql, install config/GearScore.properties, then rebuild your server normally.')
if __name__=='__main__':main()
