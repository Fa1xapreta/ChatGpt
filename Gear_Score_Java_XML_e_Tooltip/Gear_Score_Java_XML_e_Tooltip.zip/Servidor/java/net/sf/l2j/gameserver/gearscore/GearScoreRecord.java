package net.sf.l2j.gameserver.gearscore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable snapshot; never holds a live player/item reference. */
final class GearScoreRecord
{
    final int id, classId, score, pvp;
    final String name, clan;
    final boolean gm;
    final List<GearItem> items;
    GearScoreRecord(int id, String name, int classId, String clan, int score, int pvp,
        boolean gm, List<GearItem> items)
    {
        this.id = id; this.name = GearScoreMath.field(name); this.classId = classId;
        this.clan = GearScoreMath.field(clan); this.score = score; this.pvp = pvp; this.gm = gm;
        this.items = Collections.unmodifiableList(new ArrayList<>(items));
    }
    String signature()
    {
        StringBuilder b = new StringBuilder(id + "|" + name + "|" + classId + "|" + clan + "|" + score + "|" + pvp + "|" + gm);
        for (GearItem i : items) b.append(';').append(i.wire());
        return b.toString();
    }
    static final class GearItem
    {
        final int objectId, itemId, enchant, ref1, ref2, slot, score;
        GearItem(int objectId, int itemId, int enchant, int ref1, int ref2, int slot, int score)
        {
            this.objectId=objectId; this.itemId=itemId; this.enchant=enchant;
            this.ref1=ref1; this.ref2=ref2; this.slot=slot; this.score=score;
        }
        String wire() { return objectId+"|"+itemId+"|"+enchant+"|"+ref1+"|"+ref2+"|"+slot+"|"+score; }
        String cache() { return objectId+"|"+itemId+"|"+enchant+"|"+score; }
    }
}
