import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.lang.reflect.Field;
import java.util.*;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.*;

public class RestartCleanupTest {
 private static void check(boolean condition, String message) {
  if (!condition) throw new AssertionError(message);
  System.out.println("PASS: " + message);
 }
 private static TreasureHunt definition() { return new TreasureHunt(0,"24_15",52000,30139,100,"Ketra"); }
 private static void write(Path path, String text) throws Exception {
  Files.createDirectories(path.toAbsolutePath().getParent());
  Files.write(path,text.getBytes(StandardCharsets.UTF_8));
 }
 private static void due(TreasureHuntManager manager) throws Exception {
  Field field=TreasureHuntManager.class.getDeclaredField("nextRun");field.setAccessible(true);
  field.setLong(manager,System.nanoTime()-1);
 }
 private static void unit() throws Exception {
  Path h=Paths.get("unit/used.log"),a=Paths.get("unit/active.log");
  write(h,"# history\n");
  try(TreasureHuntSpawnHistory history=new TreasureHuntSpawnHistory(h)) {
   check(history.isReady()&&history.reserve(131500,-98000),"history reserves location");
   try(TreasureHuntActiveStore store=new TreasureHuntActiveStore(a,history)) {
    String first=store.add(definition(),131500,-98000,-4408);
    String second=store.add(definition(),131700,-98000,-4408);
    check(first!=null&&second!=null&&store.snapshot().size()==2,"new run can record stones");
    check(store.remove(first)&&store.snapshot().size()==1,"mining still retires current-run stones");
    byte[] before=Files.readAllBytes(a);
    try(TreasureHuntActiveStore competing=new TreasureHuntActiveStore(a,history)) {
     check(!competing.isReady(),"competing open cannot obtain journal lock");
    }
    check(Arrays.equals(before,Files.readAllBytes(a))&&store.snapshot().size()==1,
          "failed lock never truncates or clears the live journal");
   }
   byte[] before=Files.readAllBytes(h);
   try(TreasureHuntActiveStore next=new TreasureHuntActiveStore(a,history)) {
    check(next.isReady()&&next.snapshot().isEmpty()&&Files.size(a)==0,"new run clears old survivors durably");
    check(history.wasUsed(131500,-98000)&&Arrays.equals(before,Files.readAllBytes(h)),"used-location history is preserved");
    check(next.add(definition(),132000,-98000,-4408)!=null,"journal accepts new additions after clearing");
   }
   Files.delete(a);
   try(TreasureHuntActiveStore missing=new TreasureHuntActiveStore(a,history)) {
    check(missing.isReady()&&missing.snapshot().isEmpty(),"missing old active journal can be recreated");
   }
   write(a,"A incomplete old record");
   try(TreasureHuntActiveStore partial=new TreasureHuntActiveStore(a,history)) {
    check(partial.isReady()&&Files.size(a)==0,"partial old journal is discarded on a new run");
   }
  }
  Path bad=Paths.get("unit/bad-history.log"),untouched=Paths.get("unit/untouched-active.log");
  write(bad,"bad history line\n");write(untouched,"preserve when history is unavailable\n");
  byte[] before=Files.readAllBytes(untouched);
  try(TreasureHuntSpawnHistory history=new TreasureHuntSpawnHistory(bad);
      TreasureHuntActiveStore store=new TreasureHuntActiveStore(untouched,history)) {
   check(!store.isReady()&&Arrays.equals(before,Files.readAllBytes(untouched)),"unavailable history blocks opening without altering active journal");
  }
 }
 private static void create() throws Exception {
  Config.ENABLE_TREASURE_HUNT=true;
  TreasureHuntManager manager=TreasureHuntManager.getInstance();manager.start();manager.run();
  check(L2Spawn.spawned.isEmpty(),"initial start waits for configured interval");
  due(manager);manager.run();
  check(L2Spawn.spawned.size()==12&&TreasureHuntActiveStore.getInstance().snapshot().size()==12,"elapsed interval creates twelve stones normally");
  List<L2Npc> stones=new ArrayList<>(L2Spawn.spawned);
  byte[] live=Files.readAllBytes(Paths.get("data/treasurehunt-active-stones.log"));
  Config.ENABLE_TREASURE_HUNT=false;
  check(manager.reload(),"configuration reload succeeds");manager.run();manager.start();
  check(L2Spawn.spawned.size()==12&&Arrays.equals(live,Files.readAllBytes(Paths.get("data/treasurehunt-active-stones.log"))),"reload and repeated start do not clear or duplicate current stones");
  for(L2Npc stone:stones)check(stone.isVisible()&&!stone.isDead(),"living stone survives reload");
  StoneMinerInstance broken=(StoneMinerInstance)stones.get(0);
  check(broken.doDie(null),"a current-run stone can still be mined/broken");manager.run();
  List<TreasureHuntActiveStore.Record> records=TreasureHuntActiveStore.getInstance().snapshot();
  check(records.size()==11,"broken stone is not restored during same run");
  List<String> old=new ArrayList<>();for(TreasureHuntActiveStore.Record r:records)old.add(r.getId()+" "+r.getX()+" "+r.getY());
  Files.write(Paths.get("old-stones.txt"),old,StandardCharsets.UTF_8);
  Files.write(Paths.get("history-before.bin"),Files.readAllBytes(Paths.get("data/treasurehunt-used-locations.log")));
  write(Paths.get("data/treasurehunt-sessions/7.properties"),"recovery-must-be-preserved\n");
  System.out.println("PASS: leaving eleven durable survivors for next JVM (abrupt exit)");System.out.flush();
  Runtime.getRuntime().halt(0);
 }
 private static void restart(boolean enabled) throws Exception {
  Config.ENABLE_TREASURE_HUNT=enabled;
  List<String> old=Files.readAllLines(Paths.get("old-stones.txt"),StandardCharsets.UTF_8);
  check(old.size()==11,"previous JVM left eleven old stones");
  TreasureHuntManager manager=TreasureHuntManager.getInstance();manager.start();manager.run();
  check(TreasureHuntActiveStore.getInstance().snapshot().isEmpty()&&Files.size(Paths.get("data/treasurehunt-active-stones.log"))==0,"restart clears previous-run journal");
  check(L2Spawn.spawned.isEmpty(),"restart never restores old stones or spawns before the interval (enabled="+enabled+")");
  check(Arrays.equals(Files.readAllBytes(Paths.get("history-before.bin")),Files.readAllBytes(Paths.get("data/treasurehunt-used-locations.log"))),"restart keeps location history byte-for-byte");
  for(String line:old) {
   String[] parts=line.split(" ");check(TreasureHuntSpawnHistory.getInstance().wasUsed(Integer.parseInt(parts[1]),Integer.parseInt(parts[2])),"old coordinates remain reserved");
  }
  check(new String(Files.readAllBytes(Paths.get("data/treasurehunt-sessions/7.properties")),StandardCharsets.UTF_8).equals("recovery-must-be-preserved\n"),"player recovery journals survive cleanup");
  if(enabled) {
   due(manager);manager.run();
   check(L2Spawn.spawned.size()==12,"new run spawns normally after configured interval");
   Set<String> oldIds=new HashSet<>();for(String line:old)oldIds.add(line.split(" ")[0]);
   for(TreasureHuntActiveStore.Record r:TreasureHuntActiveStore.getInstance().snapshot())check(!oldIds.contains(r.getId()),"new stones are not restored records");
  } else {
   manager.run();check(manager.reload(),"reload while paused succeeds");manager.run();
   check(L2Spawn.spawned.isEmpty(),"paused feature stays clean after reload");
  }
 }
 public static void main(String[] args)throws Exception {
  if(args[0].equals("unit"))unit();else if(args[0].equals("create"))create();else restart(args[0].equals("restart-enabled"));
 }
}
