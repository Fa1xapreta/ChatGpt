#!/usr/bin/env python3
"""Real mod classes + explicit isolated GameServer doubles; not a full server build."""
from pathlib import Path
import shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
JAVA=shutil.which('java')
if not JAVA:raise SystemExit('Java with jdk.compiler module required')
# Definitions are kept separately for review; none are installed into the server.
ns={};exec(compile((ROOT/'tests/core_doubles.py').read_text(),'core_doubles.py','exec'),ns)
S=ns['S']
with tempfile.TemporaryDirectory(prefix='treasure-cleanup-') as temp:
 t=Path(temp);src=t/'src';classes=t/'classes';classes.mkdir()
 for name,body in S.items():
  p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 paths=list(src.rglob('*.java'))+list((ROOT/'src').rglob('*.java'))+list((ROOT/'tests/fixtures').rglob('*.java'))+[ROOT/'tests/RestartCleanupTest.java']
 subprocess.run([JAVA,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*map(str,paths)],check=True)
 subprocess.run([JAVA,'-cp',str(classes),'RestartCleanupTest','unit'],cwd=t,check=True)
 boot=t/'boot';(boot/'data/xml').mkdir(parents=True)
 shutil.copy(ROOT/'tests/fixtures/treasurehunt.xml',boot/'data/xml/treasurehunt.xml')
 shutil.copy(ROOT/'tests/fixtures/treasurehunt-used-locations.log',boot/'data/treasurehunt-used-locations.log')
 subprocess.run([JAVA,'-cp',str(classes),'RestartCleanupTest','create'],cwd=boot,check=True)
 enabled=t/'enabled';shutil.copytree(boot,enabled)
 for mode,folder in [('restart-paused',boot),('restart-enabled',enabled)]:
  subprocess.run([JAVA,'-cp',str(classes),'RestartCleanupTest',mode],cwd=folder,check=True)
print('PASS: compilation (Java 8 source/target), journal lifecycle, lock protection, reload, abrupt restart, enabled/paused startup and retained history/recovery journals')
