package net.sf.l2j.gameserver.model.actor.instance;

import java.util.ArrayList;
import java.util.Map;

/** The scheme pages are separate from this pack's normal buff category pages. */
final class BufferSchemeHtml
{
    static final int MENU_PAGE = 99;
    static final int EDIT_PAGE = 100;

    private BufferSchemeHtml() { }

    static String pagePath(int npcId, int page)
    {
        return "data/html/mods/buffer/" + npcId + "-" + page + ".htm";
    }

    static boolean isMenu(String html)
    {
        return html != null && html.contains("%schemes%");
    }

    static String render(Map<String, ArrayList<Integer>> schemes, int maxBuffs)
    {
        if (schemes == null || schemes.isEmpty())
            return "<font color=\"LEVEL\">Voce ainda nao criou esquemas de buffs.</font><br>";

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, ArrayList<Integer>> scheme : schemes.entrySet())
        {
            // Names are used in both text and HTML attributes.
            String name = escape(scheme.getKey());
            sb.append("<font color=\"LEVEL\">").append(name).append(" [")
                .append(scheme.getValue().size()).append(" / ").append(maxBuffs).append("]</font><br1>");
            sb.append("<a action=\"bypass npc_%objectId%_givebuffs ").append(name).append("\">Use on Me</a>&nbsp;|&nbsp;");
            sb.append("<a action=\"bypass npc_%objectId%_givebuffs ").append(name).append(" pet\">Use on Pet</a>&nbsp;|&nbsp;");
            sb.append("<a action=\"bypass npc_%objectId%_editschemes Buffs ").append(name).append(" 1\">Edit</a>&nbsp;|&nbsp;");
            sb.append("<a action=\"bypass npc_%objectId%_deletescheme ").append(name).append("\">Delete</a><br>");
        }
        return sb.toString();
    }

    private static String escape(String name)
    {
        return name.replace("&", "&amp;").replace("\"", "&quot;")
            .replace("<", "&lt;").replace(">", "&gt;");
    }
}
