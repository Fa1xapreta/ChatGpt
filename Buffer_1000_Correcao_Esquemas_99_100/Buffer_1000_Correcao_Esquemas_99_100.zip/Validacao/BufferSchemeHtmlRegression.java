package net.sf.l2j.gameserver.model.actor.instance;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
public final class BufferSchemeHtmlRegression
{
    private static void check(boolean b,String message) { if (!b) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception
    {
        check(BufferSchemeHtml.MENU_PAGE==99 && BufferSchemeHtml.EDIT_PAGE==100,"Dedicated macro pages; normal buff category pages preserved");
        String path=BufferSchemeHtml.pagePath(1000,BufferSchemeHtml.MENU_PAGE);
        String template=new String(Files.readAllBytes(Paths.get(args[0],path)),StandardCharsets.UTF_8);
        check(BufferSchemeHtml.isMenu(template),"Chat and direct link can identify the actual user scheme template");
        check(!BufferSchemeHtml.isMenu("<html>Normal buff category</html>"),"Normal buff pages remain normal");
        check(!BufferSchemeHtml.isMenu(null),"Missing HTML is handled");
        Map<String,ArrayList<Integer>> saved=new LinkedHashMap<>();
        check(BufferSchemeHtml.render(saved,24).contains("ainda nao criou"),"Empty list has visible explanation");
        saved.put("Mago",new ArrayList<>());
        String html=BufferSchemeHtml.render(saved,24);
        check(html.contains("Mago [0 / 24]"),"A newly created EMPTY scheme is visible");
        check(html.contains("_editschemes Buffs Mago 1"),"Edit action available immediately after creation");
        saved.put("Fighter",new ArrayList<>(Arrays.asList(1204,1035)));
        html=template.replace("%schemes%",BufferSchemeHtml.render(saved,24)).replace("%max_schemes%","4").replace("%objectId%","123456");
        check(!html.contains("%schemes%") && !html.contains("%max_schemes%") && !html.contains("%objectId%"),"Sent HTML has no unfilled scheme placeholders");
        check(html.contains("Fighter [2 / 24]"),"Existing skills counted correctly");
        for (String command:Arrays.asList("givebuffs Mago","givebuffs Mago pet","editschemes Buffs Mago 1","deletescheme Mago"))
            check(html.contains("bypass npc_123456_"+command),"Real NPC OBJECT ID and saved name routed: "+command);
        check(html.contains("_createscheme $name"),"Existing Create input substitution preserved");
        String edit=new String(Files.readAllBytes(Paths.get(args[0],BufferSchemeHtml.pagePath(1000,100))),StandardCharsets.UTF_8);
        check(edit.contains("%schemename%") && edit.contains("%typesframe%") && edit.contains("%skilllistframe%"),"Editor file uses existing Java's placeholders");
        System.out.println("PASS: actual renderer and packaged 1000-99/1000-100 templates; new empty scheme visible, existing lists/actions/counts correct, dynamic placeholders replaced, category pages untouched");
    }
}
