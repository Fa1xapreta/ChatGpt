#!/usr/bin/env python3
"""Isolated behavior tests with explicit core doubles; not a gameserver build."""
from pathlib import Path
import os, shutil, subprocess, tempfile
ROOT=Path(__file__).resolve().parents[1]
JAVA=shutil.which('java') or '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
S={}
def stub(pkg,name,body):
 S[pkg.replace('.','/')+'/'+name+'.java']='package '+pkg+';\n'+body
stub('net.sf.l2j','Config','public class Config { public static boolean ENABLE_TREASURE_HUNT=true,TREASURE_HUNT_AUTO_LOOT=true; public static int TREASURE_HUNT_INTERVAL=1800; }')
stub('net.sf.l2j.util','Rnd','public class Rnd { public static int value=0; public static int get(int n){ return Math.min(value,n-1); } public static int get(int a,int b){return a;} }')
stub('net.sf.l2j.gameserver','ThreadPoolManager','public class ThreadPoolManager { private static final ThreadPoolManager I=new ThreadPoolManager(); public static ThreadPoolManager getInstance(){return I;} public void scheduleGeneral(Runnable r,long delay){} }')
stub('net.sf.l2j.gameserver.model','L2Object','public class L2Object { public int id,x,y,z; public int getObjectId(){return id;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;} public boolean isVisible(){return true;} }')
stub('net.sf.l2j.gameserver.model','L2Skill','public class L2Skill {}')
stub('net.sf.l2j.gameserver.model','Location','public class Location { public int getX(){return 1;} public int getY(){return 1;} public int getZ(){return 0;} }')
stub('net.sf.l2j.gameserver.geoengine','GeoData','public class GeoData { public int calls; public static final GeoData I=new GeoData(); public static GeoData getInstance(){return I;} public boolean hasGeo(int x,int y){calls++;return false;} public int getHeight(int x,int y,int z){return 0;} public int getGeoX(int x){return x;} public int getGeoY(int y){return y;} public int getNsweNearest(int x,int y,int z){return 15;} }')
stub('net.sf.l2j.gameserver.geoengine','PathFinding','public class PathFinding { public static PathFinding getInstance(){return new PathFinding();} public net.sf.l2j.gameserver.model.Location canMoveToTargetLoc(int a,int b,int c,int d,int e,int f){return new net.sf.l2j.gameserver.model.Location();} }')
stub('net.sf.l2j.gameserver.model.item.kind','Item','public class Item { public static final int SLOT_L_HAND=1; public int getBodyPart(){return 0;} }')
stub('net.sf.l2j.gameserver.model.item.kind','Weapon','public class Weapon extends Item {}')
stub('net.sf.l2j.gameserver.model.item.instance','ItemInstance','''public class ItemInstance extends net.sf.l2j.gameserver.model.L2Object {
 public int itemId,owner=7; public boolean equipped,leftHand; public ItemInstance(int id,int itemId){this.id=id;this.itemId=itemId;}
 public int getItemId(){return itemId;} public int getOwnerId(){return owner;} public boolean isEquipped(){return equipped;}
 public net.sf.l2j.gameserver.model.item.kind.Item getItem(){return new net.sf.l2j.gameserver.model.item.kind.Weapon();}
 public void dropMe(net.sf.l2j.gameserver.model.L2Object o,int x,int y,int z){}
}''')
stub('net.sf.l2j.gameserver.model.item','DropData','''public class DropData {
 public static final int MAX_CHANCE=1000000; public int chance=1000000;
 public boolean isQuestDrop(){return false;} public int getItemId(){return 9501;}
 public int getMinDrop(){return 1;} public int getMaxDrop(){return 1;} public int getChance(){return chance;}
}''')
stub('net.sf.l2j.gameserver.model.item','DropCategory','''public class DropCategory {
 public final java.util.List<DropData> drops=new java.util.ArrayList<>(); public boolean isSweep(){return false;}
 public java.util.List<DropData> getAllDrops(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor.template','NpcTemplate','''public class NpcTemplate {
 public final java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> drops=new java.util.ArrayList<>();
 public String getType(){return "StoneMiner";}
 public java.util.List<net.sf.l2j.gameserver.model.item.DropCategory> getDropData(){return drops;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Character','''public class L2Character extends net.sf.l2j.gameserver.model.L2Object {
 public int damageCalls; public boolean dead; public boolean isDead(){return dead;} public boolean isAlikeDead(){return dead;}
 public void reduceCurrentHp(double d,L2Character a,boolean b,boolean c,net.sf.l2j.gameserver.model.L2Skill s){damageCalls++;}
 public boolean doDie(L2Character killer){if(dead)return false;dead=true;return true;}
 public boolean isAutoAttackable(L2Character a){return false;} public void setIsImmobilized(boolean b){}
 public void broadcastPacket(Object o){} public void sendPacket(Object o){} public void abortAttack(){}
 public void setXYZ(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public boolean isTeleporting(){return false;}
}''')
stub('net.sf.l2j.gameserver.model.actor','L2Npc','''public class L2Npc extends L2Character {
 private final net.sf.l2j.gameserver.model.actor.template.NpcTemplate template;
 public L2Npc(int id,net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){this.id=id;template=t;}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(){return template;}
 public boolean isAggressive(){return false;} public void onAction(net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p){}
 public String getName(){return "Stone";} public net.sf.l2j.gameserver.model.L2Spawn getSpawn(){return null;}
 public void deleteMe(){} public Known getKnownList(){return new Known();}
 public static class Known { public <T> java.util.List<T> getKnownType(Class<T> c){return new java.util.ArrayList<>();} }
}''')
stub('net.sf.l2j.gameserver.model','L2Spawn','''public class L2Spawn {
 public L2Spawn(net.sf.l2j.gameserver.model.actor.template.NpcTemplate t){}
 public void setLocx(int x){} public void setLocy(int y){} public void setLocz(int z){} public void setHeading(int h){} public void stopRespawn(){}
 public net.sf.l2j.gameserver.model.actor.L2Npc doSpawn(boolean b){return null;}
}''')
stub('net.sf.l2j.gameserver.model.itemcontainer','Inventory','''public class Inventory {
 public static final int PAPERDOLL_RHAND=0,PAPERDOLL_LHAND=1;
 public final java.util.Map<Integer,net.sf.l2j.gameserver.model.item.instance.ItemInstance> items=new java.util.HashMap<>();
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance right,left;
 public boolean validateCapacity(int n,boolean q){return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getItemByObjectId(int id){return items.get(id);}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getPaperdollItem(int slot){return slot==0?right:left;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){items.put(i.id,i);return i;}
}''')
stub('net.sf.l2j.gameserver.model.actor.instance','L2PcInstance','''public class L2PcInstance extends net.sf.l2j.gameserver.model.actor.L2Character {
 public final net.sf.l2j.gameserver.model.itemcontainer.Inventory inventory=new net.sf.l2j.gameserver.model.itemcontainer.Inventory();
 private final net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession session=new net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession(this);
 public net.sf.l2j.gameserver.model.L2Object target; public int rewards; public boolean failDestroy;
 public L2PcInstance(){id=7;} public net.sf.l2j.gameserver.model.itemcontainer.Inventory getInventory(){return inventory;}
 public net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntSession getTreasureHuntSession(){return session;}
 public net.sf.l2j.gameserver.model.L2Object getTarget(){return target;} public void setTarget(net.sf.l2j.gameserver.model.L2Object t){session.onTargetChanged(t);target=t;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance getActiveWeaponInstance(){return inventory.right;}
 public void useEquippableItem(net.sf.l2j.gameserver.model.item.instance.ItemInstance i,boolean b){
 if(i.equipped){i.equipped=false;if(inventory.right==i)inventory.right=null;if(inventory.left==i)inventory.left=null;}
 else{ i.equipped=true; if(i.leftHand){if(inventory.left!=null)inventory.left.equipped=false;inventory.left=i;}else{if(inventory.right!=null)inventory.right.equipped=false;if(i.itemId==30139 && inventory.left!=null){inventory.left.equipped=false;inventory.left=null;}inventory.right=i;}}}
 public boolean destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.L2Object r,boolean b){if(failDestroy)return false;inventory.items.remove(i.id);return true;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance addItem(String p,int id,int count,net.sf.l2j.gameserver.model.L2Object r,boolean b){rewards+=count;return null;}
 public void broadcastUserInfo(){} public void sendMessage(String s){} public void standUp(){}
 public boolean isMounted(){return false;} public boolean isInStoreMode(){return false;} public boolean isProcessingTransaction(){return false;}
 public boolean isInOlympiadMode(){return false;} public boolean isCursedWeaponEquipped(){return false;} public boolean isFishing(){return false;} public boolean isInBoat(){return false;}
}''')
stub('net.sf.l2j.gameserver.datatables','NpcTable','''public class NpcTable {
 public static NpcTable getInstance(){return new NpcTable();}
 public net.sf.l2j.gameserver.model.actor.template.NpcTemplate getTemplate(int id){return id>=52000&&id<=52003?new net.sf.l2j.gameserver.model.actor.template.NpcTemplate():null;}
}''')
stub('net.sf.l2j.gameserver.datatables','ItemTable','''public class ItemTable {
 private static int next=1000; public static ItemTable getInstance(){return new ItemTable();}
 public net.sf.l2j.gameserver.model.item.kind.Item getTemplate(int id){return id==30139?new net.sf.l2j.gameserver.model.item.kind.Weapon():null;}
 public net.sf.l2j.gameserver.model.item.instance.ItemInstance createItem(String p,int id,int count,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){return new net.sf.l2j.gameserver.model.item.instance.ItemInstance(next++,id);}
 public void destroyItem(String p,net.sf.l2j.gameserver.model.item.instance.ItemInstance i,net.sf.l2j.gameserver.model.actor.instance.L2PcInstance a,net.sf.l2j.gameserver.model.L2Object r){}
}''')
for name,ctor in [('Earthquake','int a,int b,int c,int d,int e'),('PlaySound','String s'),('SocialAction','net.sf.l2j.gameserver.model.L2Object o,int a'),('ItemList','net.sf.l2j.gameserver.model.actor.instance.L2PcInstance p,boolean b'),('ValidateLocation','net.sf.l2j.gameserver.model.actor.L2Character c')]:
 stub('net.sf.l2j.gameserver.network.serverpackets',name,'public class '+name+' { public '+name+'('+ctor+'){} }')
stub('net.sf.l2j.gameserver.network.serverpackets','ActionFailed','public class ActionFailed { public static final ActionFailed STATIC_PACKET=new ActionFailed(); }')
stub('net.sf.l2j.gameserver.network.serverpackets','FlyToLocation','public class FlyToLocation { public enum FlyType {THROW_UP} public FlyToLocation(net.sf.l2j.gameserver.model.actor.L2Character c,int x,int y,int z,FlyType t){} }')
stub('net.sf.l2j.gameserver.util','Broadcast','public class Broadcast { public static void gameAnnounceToOnlinePlayers(String s){} }')
S['TreasureHuntTests.java']=r'''
import java.nio.file.*;
import java.util.*;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.entity.events.treasurehunt.*;
import net.sf.l2j.gameserver.model.actor.instance.*;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.*;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
public class TreasureHuntTests {
 static int count;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);count++;}
 interface Checked {void run() throws Exception;}
 static void rejects(Checked c,String s)throws Exception{boolean bad=false;try{c.run();}catch(Exception e){bad=true;}check(bad,s);}
 static StoneMinerInstance stone(){StoneMinerInstance n=new StoneMinerInstance(55,new NpcTemplate());n.setTreasureHunt(new CustomTreasureHunt(new TreasureHunt(0,"16_25",52000,30139,80,"Island")));return n;}
 public static void main(String[] args)throws Exception {
  TreasureHunt d=new TreasureHunt(42,"16_25",52000,30139,80,"Island");
  check(d.getMinX()==-131072 && d.getMinY()==229376,"tile conversion");
  rejects(()->new TreasureHunt(0,"bad",52000,30139,80,"Island"),"invalid geodata");
  rejects(()->new TreasureHunt(0,"16_25",52000,30139,101,"Island"),"invalid chance");
  List<TreasureHunt> loaded=TreasureHuntData.load();
  check(loaded.size()==12,"all XML events loaded");
  Set<Integer> ids=new HashSet<>();for(TreasureHunt h:loaded)ids.add(h.getId());check(ids.size()==12,"unique IDs");
  Path xml=Paths.get("data/xml/treasurehunt.xml");String valid=new String(Files.readAllBytes(xml),java.nio.charset.StandardCharsets.UTF_8);
  Files.write(xml,valid.replace("id=\"1\"","id=\"0\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));
  rejects(()->TreasureHuntData.load(),"reject duplicate ID");
  Files.write(xml,valid.replace("npcId=\"52000\"","npcId=\"999\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));
  rejects(()->TreasureHuntData.load(),"reject missing NPC");
  Files.write(xml,valid.replace("weaponId=\"30139\"","weaponId=\"999\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));
  rejects(()->TreasureHuntData.load(),"reject missing tool");
  Files.write(xml,valid.getBytes(java.nio.charset.StandardCharsets.UTF_8));
  new CustomTreasureHunt(d).spawnNpc();check(net.sf.l2j.gameserver.geoengine.GeoData.I.calls==200,"bounded spawn retries");
  L2PcInstance p=new L2PcInstance();StoneMinerInstance n=stone();p.setTarget(n);
  ItemInstance original=new ItemInstance(20,500);original.equipped=true;p.inventory.items.put(20,original);p.inventory.right=original;
  ItemInstance shield=new ItemInstance(22,600);shield.leftHand=true;shield.equipped=true;p.inventory.items.put(22,shield);p.inventory.left=shield;
  ItemInstance legitimate=new ItemInstance(21,30139);p.inventory.items.put(21,legitimate);
  check(p.getTreasureHuntSession().begin(n),"start mining");
  n.reduceCurrentHp(1,p,true,false,new net.sf.l2j.gameserver.model.L2Skill());check(n.damageCalls==0,"reject skill damage");
  n.reduceCurrentHp(1,new net.sf.l2j.gameserver.model.actor.L2Character(),true,false,null);check(n.damageCalls==0,"reject non-player damage");
  n.reduceCurrentHp(1,p,true,false,null);check(n.damageCalls==1,"accept tool melee damage");
  int tool=p.getActiveWeaponInstance().id;
  check(tool!=21 && p.getTreasureHuntSession().ownsTemporary(tool),"exact temporary identity");
  check(p.getTreasureHuntSession().blocksUse(legitimate),"block equipment changes");
  p.failDestroy=true;check(!p.getTreasureHuntSession().finish(),"retain failed cleanup");
  check(Files.exists(Paths.get("data/treasurehunt-sessions/7.properties")),"retain recovery journal");
  p.failDestroy=false;p.setTarget(null);
  check(p.inventory.items.containsKey(21),"preserve legitimate tool");
  check(!p.inventory.items.containsKey(tool) && p.getActiveWeaponInstance()==original && original.equipped,"destroy temporary and restore original");
  check(p.inventory.left==shield && shield.equipped,"restore previous shield");
  check(p.getTreasureHuntSession().finish(),"idempotent cleanup");
  p.setTarget(n);Config.ENABLE_TREASURE_HUNT=false;check(!p.getTreasureHuntSession().begin(n),"disabled event cannot equip");Config.ENABLE_TREASURE_HUNT=true;
  check(p.getTreasureHuntSession().begin(n),"restart session");tool=p.getActiveWeaponInstance().id;
  L2PcInstance relog=new L2PcInstance();relog.inventory.items.putAll(p.inventory.items);relog.inventory.right=p.inventory.right;relog.inventory.left=p.inventory.left;
  relog.getTreasureHuntSession().recover();check(!relog.inventory.items.containsKey(tool),"recover exact tool after restart");
  check(relog.getActiveWeaponInstance()==original,"recover previous weapon after restart");
  // Death pays once, and releases the killer's tool even without a known-list entry.
  p=new L2PcInstance();n=stone();p.setTarget(n);check(p.getTreasureHuntSession().begin(n),"reward session");
  DropCategory cat=new DropCategory();cat.drops.add(new DropData());n.getTemplate().drops.add(cat);
  check(n.doDie(p),"stone dies");check(p.rewards==1,"reward delivered");check(!n.doDie(p) && p.rewards==1,"no duplicate death reward");
  check(p.getActiveWeaponInstance()==null,"cleanup killer without known-list entry");
  p=new L2PcInstance();n=stone();p.setTarget(n);check(p.getTreasureHuntSession().begin(n),"despawn session");
  tool=p.getActiveWeaponInstance().id;n.deleteMe();check(!p.inventory.items.containsKey(tool),"despawn cleanup outside known list");
  TreasureHuntManager manager=TreasureHuntManager.getInstance();check(manager.reload(),"manager valid reload");
  java.lang.reflect.Field list=TreasureHuntManager.class.getDeclaredField("hunts");list.setAccessible(true);Object previous=list.get(manager);
  Files.write(xml,valid.replace("id=\"1\"","id=\"0\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));
  check(!manager.reload() && list.get(manager)==previous,"failed reload preserves live definitions");
  Files.write(xml,valid.getBytes(java.nio.charset.StandardCharsets.UTF_8));
  Config.TREASURE_HUNT_INTERVAL=30;manager.run();
  java.lang.reflect.Field interval=TreasureHuntManager.class.getDeclaredField("interval");interval.setAccessible(true);
  check(interval.getInt(manager)==30,"apply interval change");
  Config.ENABLE_TREASURE_HUNT=false;manager.run();
  java.lang.reflect.Field enabled=TreasureHuntManager.class.getDeclaredField("enabled");enabled.setAccessible(true);
  check(!enabled.getBoolean(manager),"disable running manager");
  System.out.println("PASS: "+count+" behavior assertions with core doubles. Full core build not tested.");
 }
}
'''
with tempfile.TemporaryDirectory(prefix='treasurehunt-tests-') as tmp:
 t=Path(tmp);src=t/'src';classes=t/'classes';classes.mkdir()
 for name,body in S.items():
  p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 paths=list(src.rglob('*.java'))+list((ROOT/'src').rglob('*.java'))
 subprocess.run([JAVA,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),*map(str,paths)],check=True)
 (t/'data/xml').mkdir(parents=True)
 shutil.copyfile(ROOT/'datapack/data/xml/treasurehunt.xml',t/'data/xml/treasurehunt.xml')
 subprocess.run([JAVA,'-cp',str(classes),'TreasureHuntTests'],cwd=t,check=True)
