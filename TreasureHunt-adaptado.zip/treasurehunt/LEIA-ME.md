# Treasure Hunt — adaptação para net.sf.l2j

Primeira versão adaptada a partir das classes enviadas. Ainda requer compilação
no projeto completo e teste em um servidor de desenvolvimento. Não é uma build
do gameserver e não contém JAR pronto.

## Conteúdo

- `src/`: seis classes novas; copiar para a raiz de fontes que contém `net/sf/l2j`.
- `patches/core.patch`: alterações nas seis classes existentes.
- `core-editados/` (no ZIP): essas mesmas seis classes completas, já modificadas
  a partir dos arquivos enviados. É uma alternativa ao patch.
- `datapack/`: três XMLs com a estrutura de diretórios do gameserver.
- `l2jmod.properties.append`: bloco para acrescentar às propriedades existentes.
- `tests/run.py`: testes isolados com substitutos explícitos do core.

As classes antigas do Milenium não devem ser copiadas junto com esta versão.
O novo gerenciador reúne a inicialização e o agendamento antigos; não é preciso
adicionar `TreasureHuntInit` ou `TreasureHuntTask` da versão anterior.

## Instalação

1. Faça backup do projeto, datapack e banco. Trabalhe primeiro em servidor de teste.
2. Copie as classes de `src/` para a raiz de fontes do seu core.
3. Aplique o patch a partir dessa mesma raiz:

   ```sh
   git apply --check --ignore-space-change /caminho/treasurehunt/patches/core.patch
   git apply --ignore-space-change /caminho/treasurehunt/patches/core.patch
   ```

   Se não usa Git, compare/copie as seis classes de `core-editados/` do ZIP.
   Não use as duas opções simultaneamente. Se alterou suas classes depois do
   envio, faça merge das mudanças em vez de substituir os arquivos inteiros.
   O arquivo enviado como `GaneSever.java` está corrigido para `GameServer.java`.
4. Mescle o conteúdo de `datapack/` na pasta do gameserver. Os destinos são:
   - `data/xml/treasurehunt.xml`
   - `data/xml/npcs/events/treasurehunt-npcs.xml`
   - `data/xml/items/weapons/treasurehunt-tool.xml`
5. Evite definições duplicadas dos NPCs 52000–52003 e do item 30139 em outros XMLs.
6. Acrescente o bloco de `l2jmod.properties.append` ao arquivo existente
   `config/custom/l2jmod.properties`. Não substitua as demais propriedades.
7. Compile usando o build normal da sua pack. Este pacote não fornece um build
   alternativo nem as dependências ausentes do projeto.
8. Garanta permissão de escrita em `data/treasurehunt-sessions/`, criada
   automaticamente. Preserve essa pasta junto com os backups do banco.
9. Confira se a geodata das regiões configuradas está instalada e habilitada.
   Para testar, use `EnableTreasureHunt = True` e um intervalo curto, como 30
   segundos. Reinicie o servidor ou recarregue suas configurações.

## Classes existentes alteradas

| Classe | Integração |
|---|---|
| `Config` | Três propriedades, lidas de `config/custom/l2jmod.properties` |
| `GameServer` | Inicializa o gerenciador depois de `SpawnTable` |
| `L2PcInstance` | Sessão por jogador; limpeza em troca de alvo, morte, teleporte e saída; bloqueios de manipulação/drop da ferramenta |
| `UseItem` | Bloqueia troca de arma/mão esquerda enquanto a ferramenta está ativa |
| `EnterWorld` | Recupera a sessão registrada antes da interação normal |
| `AdminAdmin` | Acrescenta `//reload treasurehunt` |

Não foi necessário modificar `Action`, `L2Npc`, `L2NpcInstance` ou o pacote de
cancelamento de alvo. O clique na pedra é tratado em `StoneMinerInstance` e o
cancelamento passa pela troca de alvo do próprio jogador.

## Comportamento e configurações

```properties
EnableTreasureHunt = False
TreasureHuntInterval = 1800
AllowTreasureHuntAutoLoot = True
```

O intervalo é em segundos. O primeiro sorteio ocorre após esse intervalo.
A cada sorteio, cada entrada tem sua chance percentual independente. Quando
sorteada, a pedra anterior daquela entrada é removida e outra posição é gerada.
Se não sorteada, a pedra existente permanece, como na implementação enviada.
Não existe prazo de despawn separado do intervalo.

O gerenciador verifica mudanças nas configurações carregadas a cada segundo.
Desabilitar o evento remove as pedras. Alterar o intervalo reinicia a contagem.
Editar o arquivo de propriedades em disco exige `//reload config` ou reinício;
`//reload treasurehunt` recarrega o XML do evento e reinicia sua contagem.
XML inválido é rejeitado sem substituir a lista anterior.

O primeiro clique seleciona a pedra e equipa a ferramenta; o seguinte segue
o ataque normal do core. Apenas ataques físicos diretos de um jogador usando
a ferramenta criada para sua sessão causam dano. Skills, DOT, pets e summons
não causam dano. A ferramenta é removida e os itens anteriores das duas mãos
são reequipados quando ainda pertencem ao inventário do jogador.

Recompensas seguem sorteio independente por entrada, como no mod antigo,
sem aplicar as rates de drops normais dos monstros. Não há recompensa de spoil
nem de quest. Com autoloot desligado, o prêmio cai no chão, sem reserva para o
matador ou timer adicional de destruição nesta implementação.

## Dados preservados e pontos para conferir

- Foram corrigidos apenas os IDs repetidos do evento: agora são 0 a 11.
- A pedra verde continua com `chance="100"` nos drops: **0,01%**, não 100%.
  As chances não foram aumentadas automaticamente.
- As regiões e seus nomes foram preservados. Nome de território no XML é apenas
  um rótulo: confira as coordenadas reais, especialmente Talking Island e Crystal
  Island. Sortear um bloco inteiro não equivale a sortear uma zona jogável.
- A seleção verifica geodata, altura e uma vizinhança local com NSWE aberto,
  com no máximo 200 tentativas por entrada. Isso não detecta toda água, telhados,
  zonas proibidas ou regiões isoladas. Para controle rigoroso, use áreas de spawn
  delimitadas em uma próxima alteração.
- O efeito de lançamento usa `PathFinding.canMoveToTargetLoc`, já chamado pelo
  `L2Character` fornecido. Sua classe `PathFinding` não foi enviada para inspeção.
- Os itens de recompensa precisam existir: 9501, 9510, 9543, 9506, 9507 e 8762.
  O `NpcTable` enviado ignora drops cujo item não exista e registra um aviso.
- O item 30139 mantém seus atributos e skills originais. Verifique os skills
  5410/1, 3601/9 e 5371/1 no seu datapack. A aparência da marreta e das pedras
  depende dos recursos correspondentes no cliente; XML de servidor não os cria.
- Foram acrescentadas as flags usuais `is_tradable`, `is_dropable`,
  `is_destroyable` e `is_depositable` como `false`. A implementação de `Item` e
  `DocumentItem` não foi enviada; confirme que sua pack reconhece essas flags.
  Os bloqueios Java acrescentados não substituem a auditoria de todos os
  handlers customizados de troca, warehouse, venda e transferência.
- Recuperação usa o ID exato do objeto e um registro local por personagem.
  Não remove ferramentas legítimas pelo ID do template. Falhas de limpeza
  preservam o registro e impedem sobrescrevê-lo com uma nova sessão.
  Não apague esses registros enquanto houver sessões pendentes. Restauração de
  backups de banco e registros fora de sincronia precisa de revisão manual.

## Validação realizada e pendências

Foram executadas 36 verificações de comportamento das classes novas em ambiente
isolado, com substitutos do core. Incluem configuração inválida, IDs duplicados,
tentativas limitadas, preservação de item legítimo, restauração de arma/escudo,
recuperação, falha de remoção, despawn e recompensa sem duplicação.

O patch foi aplicado às seis classes originais, inclusive com CRLF, e comparado
ao resultado esperado. A análise de sintaxe das 12 classes novas/modificadas
passou. A compilação isolada usa sintaxe/bytecode Java 8 no compilador Java 21;
isso não certifica o classpath nem o ambiente Java da pack.

**Ainda não realizados:** build completo, conexão ao banco, inicialização do
gameserver, testes com cliente/geodata e auditoria dos handlers não enviados.
Não considerar esta versão validada para produção antes dessas etapas.

No servidor de teste, confira: cliques e ataques; arma e escudo restaurados ao
cancelar alvo, morrer, teleportar, sair e despawnar; dois jogadores na mesma
pedra; recuperação após reinício; prêmios com autoloot ligado/desligado; bloqueios
de troca, venda, descarte, warehouse, enchant e uso de equipamentos; recarga de
configuração e XML. Registre os erros de compilação ou logs para ajustar a versão.
