/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver;

import net.sf.l2j.gameserver.model.entity.events.treasurehunt.TreasureHuntManager;
import hwid.Hwid;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.Server;
import net.sf.l2j.gameserver.cache.CrestCache;
import net.sf.l2j.gameserver.cache.HtmCache;
import net.sf.l2j.gameserver.cache.ImagesCache;
import net.sf.l2j.gameserver.communitybbs.Manager.ForumsBBSManager;
import net.sf.l2j.gameserver.datatables.AccessLevels;
import net.sf.l2j.gameserver.datatables.AdminCommandAccessRights;
import net.sf.l2j.gameserver.datatables.AnnouncementTable;
import net.sf.l2j.gameserver.datatables.ArmorSetsTable;
import net.sf.l2j.gameserver.datatables.AugmentationData;
import net.sf.l2j.gameserver.datatables.BookmarkTable;
import net.sf.l2j.gameserver.datatables.BufferTable;
import net.sf.l2j.gameserver.datatables.BuyListTable;
import net.sf.l2j.gameserver.datatables.CharNameTable;
import net.sf.l2j.gameserver.datatables.CharTemplateTable;
import net.sf.l2j.gameserver.datatables.ClanTable;
import net.sf.l2j.gameserver.datatables.DoorTable;
import net.sf.l2j.gameserver.datatables.FenceTable;
import net.sf.l2j.gameserver.datatables.FishTable;
import net.sf.l2j.gameserver.datatables.GmListTable;
import net.sf.l2j.gameserver.datatables.HelperBuffTable;
import net.sf.l2j.gameserver.datatables.HennaTable;
import net.sf.l2j.gameserver.datatables.HerbDropTable;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.MapRegionTable;
import net.sf.l2j.gameserver.datatables.MultisellData;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.NpcWalkerRoutesTable;
import net.sf.l2j.gameserver.datatables.PetDataTable;
import net.sf.l2j.gameserver.datatables.RecipeTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.datatables.SkillTreeTable;
import net.sf.l2j.gameserver.datatables.SoulCrystalsTable;
import net.sf.l2j.gameserver.datatables.SpawnTable;
import net.sf.l2j.gameserver.datatables.SpellbookTable;
import net.sf.l2j.gameserver.datatables.StaticObjects;
import net.sf.l2j.gameserver.datatables.SummonItemsData;
import net.sf.l2j.gameserver.datatables.TeleportLocationTable;
import net.sf.l2j.gameserver.datatables.custom.AntiBotTable;
import net.sf.l2j.gameserver.datatables.custom.FakePcsTable;
import net.sf.l2j.gameserver.datatables.custom.IconTable;
import net.sf.l2j.gameserver.datatables.custom.OfflineTradersTable;
import net.sf.l2j.gameserver.datatables.custom.RaidSpawnTable;
import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.datatables.custom.SkipTable;
import net.sf.l2j.gameserver.datatables.custom.WeaponSkinTable;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.handler.AdminCommandHandler;
import net.sf.l2j.gameserver.handler.ChatHandler;
import net.sf.l2j.gameserver.handler.ItemHandler;
import net.sf.l2j.gameserver.handler.SkillHandler;
import net.sf.l2j.gameserver.model.entity.events.territorywar.TerritoryWarManager;
import net.sf.l2j.gameserver.handler.TutorialHandler;
import net.sf.l2j.gameserver.handler.UserCommandHandler;
import net.sf.l2j.gameserver.handler.VoicedCommandHandler;
import net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox.LuckBoxData;
import net.sf.l2j.gameserver.handler.password.PasswordChanger;
import net.sf.l2j.gameserver.idfactory.IdFactory;
import net.sf.l2j.gameserver.instancemanager.AuctionManager;
import net.sf.l2j.gameserver.instancemanager.AutoSpawnManager;
import net.sf.l2j.gameserver.instancemanager.BoatManager;
import net.sf.l2j.gameserver.instancemanager.CastleManager;
import net.sf.l2j.gameserver.instancemanager.CastleManorManager;
import net.sf.l2j.gameserver.instancemanager.ClanHallManager;
import net.sf.l2j.gameserver.instancemanager.ClassDamageManager;
import net.sf.l2j.gameserver.instancemanager.CoupleManager;
import net.sf.l2j.gameserver.instancemanager.CursedWeaponsManager;
import net.sf.l2j.gameserver.instancemanager.DayNightSpawnManager;
import net.sf.l2j.gameserver.instancemanager.DimensionalRiftManager;
import net.sf.l2j.gameserver.instancemanager.FishingChampionshipManager;
import net.sf.l2j.gameserver.instancemanager.FourSepulchersManager;
import net.sf.l2j.gameserver.instancemanager.GrandBossManager;
import net.sf.l2j.gameserver.instancemanager.HuntPassManager;
import net.sf.l2j.gameserver.instancemanager.ItemsOnGroundManager;
import net.sf.l2j.gameserver.instancemanager.MercTicketManager;
import net.sf.l2j.gameserver.instancemanager.MovieMakerManager;
import net.sf.l2j.gameserver.instancemanager.OlyClassDamageManager;
import net.sf.l2j.gameserver.instancemanager.PetitionManager;
import net.sf.l2j.gameserver.instancemanager.QuestManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossInfoManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossPointsManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossSpawnManager;
import net.sf.l2j.gameserver.instancemanager.SevenSigns;
import net.sf.l2j.gameserver.instancemanager.SevenSignsFestival;
import net.sf.l2j.gameserver.instancemanager.SiegeManager;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.instancemanager.balance.BalanceManager;
import net.sf.l2j.gameserver.instancemanager.custom.CharacterKillingManager;
import net.sf.l2j.gameserver.instancemanager.custom.DailyRewardManager;
import net.sf.l2j.gameserver.instancemanager.custom.HwidManager;
import net.sf.l2j.gameserver.instancemanager.custom.IPManager;
import net.sf.l2j.gameserver.instancemanager.custom.TimeInstanceManager;
import net.sf.l2j.gameserver.instancemanager.custom.ZergManager;
import net.sf.l2j.gameserver.instancemanager.dropcustom.DropDataCustom;
import net.sf.l2j.gameserver.instancemanager.games.MonsterRace;
import net.sf.l2j.gameserver.model.L2Manor;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2DoorInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2FenceInstance;
import net.sf.l2j.gameserver.model.actor.instance.NewDailyRewardManager;
import net.sf.l2j.gameserver.model.actor.instance.PvpRankHud;
import net.sf.l2j.gameserver.model.entity.Hero;
import net.sf.l2j.gameserver.model.entity.events.Hide;
import net.sf.l2j.gameserver.model.entity.events.MissionReset;
import net.sf.l2j.gameserver.model.entity.events.NftBossEvent;
import net.sf.l2j.gameserver.model.entity.events.PCBangPoint;
import net.sf.l2j.gameserver.model.entity.events.PvpProtection;
import net.sf.l2j.gameserver.model.entity.events.SoloBossEvent;
import net.sf.l2j.gameserver.model.entity.events.TimeZoneReset;
import net.sf.l2j.gameserver.model.entity.events.TopKillerRoundSystem;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyFarm;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyFarmEvent;
import net.sf.l2j.gameserver.model.entity.events.Tyrannosaurus.Tyrannosaurus;
import net.sf.l2j.gameserver.model.entity.events.Tyrannosaurus.TyrannosaurusEvent;
import net.sf.l2j.gameserver.model.entity.events.autopvpzone.PvPZoneConfig;
import net.sf.l2j.gameserver.model.entity.events.autopvpzone.PvPZoneManager;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFConfig;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFManager;
import net.sf.l2j.gameserver.model.entity.events.clanranking.ClanRankingConfig;
import net.sf.l2j.gameserver.model.entity.events.clanranking.ClanRankingManager;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMConfig;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMManager;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSConfig;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSManager;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBConfig;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBManager;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMConfig;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMManager;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTManager;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTManager;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEventManager;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaConfig;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaEvent;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaTask;
import net.sf.l2j.gameserver.model.olympiad.Olympiad;
import net.sf.l2j.gameserver.model.olympiad.OlympiadGameManager;
import net.sf.l2j.gameserver.model.partymatching.PartyMatchRoomList;
import net.sf.l2j.gameserver.model.partymatching.PartyMatchWaitingList;
import net.sf.l2j.gameserver.model.quest.Quest;
import net.sf.l2j.gameserver.network.L2GameClient;
import net.sf.l2j.gameserver.network.L2GamePacketHandler;
import net.sf.l2j.gameserver.network.clientpackets.TeleportButtonFixed;
import net.sf.l2j.gameserver.script.EventDroplist;
import net.sf.l2j.gameserver.script.faenor.FaenorScriptEngine;
import net.sf.l2j.gameserver.scripting.L2ScriptEngineManager;
import net.sf.l2j.gameserver.taskmanager.FarmRandomZoneTaskManager;
import net.sf.l2j.gameserver.taskmanager.ItemsAutoDestroyTaskManager;
import net.sf.l2j.gameserver.taskmanager.KnownListUpdateTaskManager;
import net.sf.l2j.gameserver.taskmanager.TaskManager;
import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;
import net.sf.l2j.util.DeadLockDetector;
import net.sf.l2j.util.IPv4Filter;
import net.sf.l2j.util.Util;

import org.mmocore.network.SelectorConfig;
import org.mmocore.network.SelectorThread;

import TeleporterInterface.TeleportLocationData2;
import phantom.FakePlayerConfig;
import phantom.FakePlayerManager;
import phantom.task.ThreadPool;

public class GameServer
{
	private static final Logger _log = Logger.getLogger(GameServer.class.getName());

	private final SelectorThread<L2GameClient> _selectorThread;
	private final L2GamePacketHandler _gamePacketHandler;
	private final DeadLockDetector _deadDetectThread;
	public static GameServer gameServer;
	private final LoginServerThread _loginThread;
	public static final Calendar dateTimeServerStarted = Calendar.getInstance();

	public long getUsedMemoryMB()
	{
		return (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576; // 1024 * 1024 = 1048576;
	}

	public SelectorThread<L2GameClient> getSelectorThread()
	{
		return _selectorThread;
	}

	@SuppressWarnings("static-access")
	public GameServer() throws Exception
	{
		gameServer = this;

		final long serverLoadStart = System.currentTimeMillis();

		IdFactory.getInstance();
		ThreadPoolManager.getInstance();
		ThreadPool.init();

		new File("./data/crests").mkdirs();

		Util.printSection("World");
		GameTimeController.getInstance();
		L2World.getInstance();
		MapRegionTable.getInstance();
		AnnouncementTable.getInstance();
		BookmarkTable.getInstance();
		EventDroplist.getInstance();
		FaenorScriptEngine.getInstance();

		Util.printSection("Skills");
		SkillTable.getInstance();
		SkillTreeTable.getInstance();

		Util.printSection("Items");
		IconTable.getInstance();
		ItemTable.getInstance();
		SummonItemsData.getInstance();
		BuyListTable.getInstance();
		MultisellData.getInstance();
		RecipeTable.getInstance();
		ArmorSetsTable.getInstance();
		FishTable.getInstance();
		SpellbookTable.getInstance();
		SoulCrystalsTable.load();
		SkinTable.getInstance();
		WeaponSkinTable.getInstance();
		RaidSpawnTable.getInstance();
		TimeInstanceManager.getInstance();

		Util.printSection("Augments");
		AugmentationData.getInstance();

		Util.printSection("Characters");
		AccessLevels.getInstance();
		AdminCommandAccessRights.getInstance();
		CharTemplateTable.getInstance();
		CharNameTable.getInstance();
		GmListTable.getInstance();
		RaidBossPointsManager.getInstance();

		Util.printSection("Community server");
		if (Config.ENABLE_COMMUNITY_BOARD) // Forums has to be loaded before clan data
			ForumsBBSManager.getInstance().initRoot();
		else
			_log.config("Community server is disabled.");

		Util.printSection("Cache");
		HtmCache.getInstance();
		CrestCache.load();
		ImagesCache.getInstance();
		TeleportLocationTable.getInstance();
		PartyMatchWaitingList.getInstance();
		PartyMatchRoomList.getInstance();
		PetitionManager.getInstance();
		HennaTable.getInstance();
		HelperBuffTable.getInstance();
		CursedWeaponsManager.getInstance();
		SkipTable.getInstance();

		Util.printSection("Clans");
		ClanTable.getInstance();
		AuctionManager.getInstance();
		ClanHallManager.getInstance();

		Util.printSection("Geodata & Pathfinding");
		GeoData.initialize();
		PathFinding.initialize();

		Util.printSection("World Bosses");
		GrandBossManager.getInstance();

		Util.printSection("Zones");
		ZoneManager.getInstance();
		GrandBossManager.getInstance().initZones();

		Util.printSection("Castles");
		CastleManager.getInstance().load();

		Util.printSection("Seven Signs");
		SevenSigns.getInstance().spawnSevenSignsNPC();
		SevenSignsFestival.getInstance();

		Util.printSection("Sieges");
		SiegeManager.getInstance();
		SiegeManager.getSieges();
		MercTicketManager.getInstance();

		Util.printSection("Manor Manager");
		CastleManorManager.getInstance();
		L2Manor.getInstance();

		Util.printSection("Hunt Pass");
		HuntPassManager.getInstance();
		
		Util.printSection("NPCs");
		BufferTable.getInstance();
		HerbDropTable.getInstance();
		PetDataTable.getInstance();
		NpcTable.getInstance();
		NpcWalkerRoutesTable.getInstance();
		DoorTable.getInstance();
		StaticObjects.load();
		SpawnTable.getInstance();
		TreasureHuntManager.getInstance().start();
		RaidBossSpawnManager.getInstance();
		DayNightSpawnManager.getInstance().trim().notifyChangeMode();
		DimensionalRiftManager.getInstance();
		FakePcsTable.getInstance();
		RaidBossInfoManager.getInstance();

		Util.printSection("Olympiads & Heroes");
		OlympiadGameManager.getInstance();
		Olympiad.getInstance();
		Hero.getInstance();

		Util.printSection("Four Sepulchers");
		FourSepulchersManager.getInstance().init();

		Util.printSection("Quests & Scripts");
		QuestManager.getInstance();
		BoatManager.getInstance();

		if (!Config.ALT_DEV_NO_SCRIPTS)
		{
		    try
		    {
		        L2ScriptEngineManager.getInstance().executeScriptList(new File("./data/scripts.cfg"));
		    }
		    catch (Exception e)
		    {
		        _log.log(Level.SEVERE,"Falha ao carregar a lista de scripts.",e);
		    }

		    // Preservar a carga direta que resolveu a inicialização.
		    if (QuestManager.getInstance().getQuest("Frintezza") == null)
		    {
		        final File frintezzaFile = new File(L2ScriptEngineManager.SCRIPT_FOLDER,"ai/individual/Frintezza.java");

		        try
		        {
		            if (!frintezzaFile.isFile())
		            {
		                throw new java.io.FileNotFoundException(
		                    frintezzaFile.getAbsolutePath());
		            }

		            L2ScriptEngineManager.getInstance()
		                .executeScript(frintezzaFile);
		        }
		        catch (Exception e)
		        {
		            _log.log(Level.SEVERE,"Frintezza: falha no carregamento do script.",e);
		        }
		    }

		    final Quest frintezza =QuestManager.getInstance().getQuest("Frintezza");

		    boolean ready = false;

		    try
		    {
		        ready = frintezza != null &&"READY".equals(frintezza.onAdvEvent("frintezza_status", null, null));
		    }
		    catch (Exception e)
		    {
		        _log.log(Level.SEVERE,"Frintezza: falha ao consultar a inicializacao.",e);
		    }

		    if (ready)
		    {
		        _log.info("Frintezza: script carregado e inicializado com sucesso.");
		    }
		    else
		    {
		        _log.severe("Frintezza: inicializacao nao confirmada. " +"Verifique os erros anteriores e a consulta frintezza_status.");
		    }

		    QuestManager.getInstance().report();
		}
		else
		{
		    _log.config("QuestManager: Skipping scripts.");
		}
		
		if (Config.SAVE_DROPPED_ITEM)
			ItemsOnGroundManager.getInstance();

		if (Config.ITEM_AUTO_DESTROY_TIME > 0 || Config.HERB_AUTO_DESTROY_TIME > 0)
			ItemsAutoDestroyTaskManager.getInstance();

		Util.printSection("Monster Derby Track");
		MonsterRace.getInstance();

		Util.printSection("Handlers");
		_log.config("AutoSpawnHandler: Loaded " + AutoSpawnManager.getInstance().size() + " handlers.");
		_log.config("AdminCommandHandler: Loaded " + AdminCommandHandler.getInstance().size() + " handlers.");
		_log.config("ChatHandler: Loaded " + ChatHandler.getInstance().size() + " handlers.");
		_log.config("ItemHandler: Loaded " + ItemHandler.getInstance().size() + " handlers.");
		_log.config("SkillHandler: Loaded " + SkillHandler.getInstance().size() + " handlers.");
		_log.config("TutorialHandler: Loaded " + TutorialHandler.getInstance().size() + " handlers.");
		_log.config("UserCommandHandler: Loaded " + UserCommandHandler.getInstance().size() + " handlers.");
		_log.config("VoicedCommandHandler: Loaded " + VoicedCommandHandler.getInstance().size() + " handlers.");

		if (Config.ALLOW_WEDDING)
			CoupleManager.getInstance();

		if (Config.ALT_FISH_CHAMPIONSHIP_ENABLED)
			FishingChampionshipManager.getInstance();

		Util.printSection("Daily Reward");
		NewDailyRewardManager.getInstance();

		Util.printSection("Custom");
		IPManager.getInstance();
		HwidManager.getInstance();
		ZergManager.getInstance();
		PasswordChanger.getInstance();
		AntiBotTable.getInstance().loadImage();
		DailyRewardManager.getInstance();
		PvpProtection.getInstance();
		DropDataCustom.getInstance();
		TeleportButtonFixed.loadTeleportLocations();
		Config.loadPKManager();
		Config.loadSpoilInstance();
		try
		{
			if (Config.OPEN_DOORS_ACTIVE)
			{
				for (Iterator<Integer> iterator = Config.OPEN_DOORS.iterator(); iterator.hasNext(); )
				{
					int i = iterator.next().intValue();
					L2DoorInstance door = DoorTable.getInstance().getDoor(Integer.valueOf(i));
					door.openMe();
				} 

				_log.info("Open Doors Enabled..");
			}
			else
			{
				_log.info("Open Doors Disabled..");
			} 

		}
		catch (NullPointerException e) {
			_log.info("Erro ao Abrir as portas");
			e.printStackTrace();
		}

		PvPZoneConfig.init();
		PvPZoneManager.getInstance();
		
		LuckBoxData.getInstance().load();

		if (Config.RESET_MISSION_EVENT_ENABLED)
			MissionReset.getInstance().StartNextEventTime();
		
		if (Config.SHOW_PVP_RANK_HUD)
			ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(PvpRankHud.getInstance(),Config.SHOW_PVP_RANK_HUD_INTERVAL,Config.SHOW_PVP_RANK_HUD_INTERVAL);

		if (Config.TOP_KILLER_PLAYER_ROUND)
			TopKillerRoundSystem.getInstance();

		if (Config.ALLOW_HIDE_ITEM_EVENT)
			Hide.getInstance();

		if (Config.ENABLE_CLASS_DAMAGES)
			ClassDamageManager.loadConfig();

		if (Config.ENABLE_OLY_CLASS_DAMAGES)
			OlyClassDamageManager.loadConfig();

		if (Config.PCB_ENABLE)
			ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(PCBangPoint.getInstance(), Config.PCB_INTERVAL * 1000, Config.PCB_INTERVAL * 1000);

		if ((Config.OFFLINE_TRADE_ENABLE || Config.OFFLINE_CRAFT_ENABLE) && Config.RESTORE_OFFLINERS)
			OfflineTradersTable.restoreOfflineTraders();

		if (Config.CKM_ENABLED)
			CharacterKillingManager.getInstance().init();

		Util.printSection("Party Zone");
		if (Config.START_PARTY)
		{
			_log.info("Start Spawn Party Farm: Enabled");
			ThreadPool.schedule(new SpawnMonsters(), 3000);
		}
		if (Config.START_AUTO_PARTY)
		{
			_log.info("Party Zone Auto Event is enabled.");
			PartyFarmEvent.getInstance().StartCalculationOfNextEventTime();
		}
		else
		{
			_log.info("Party Zone Auto Event is disabled.");
		}

		Util.printSection("Tyrannosaurus Zone");
		if (Config.START_LS)
		{
			_log.info("Start Spawn Tyrannosaurus: Enabled");
			ThreadPool.schedule(new SpawnMonsters_LS(), 3000);
		}
		if (Config.START_AUTO_LS)
		{
			_log.info("Tyrannosaurus Auto Event is enabled.");
			TyrannosaurusEvent.getInstance().StartCalculationOfNextEventTime();
		}
		else
		{
			_log.info("Tyrannosaurus Auto Event is disabled.");
		}

		Util.printSection("Solo Boss");
		if (Config.SOLO_BOSS_EVENT)
		{
			_log.info("Solo Boss Auto Event is enabled.");
			SoloBossEvent.getInstance().StartCalculationOfNextEventTime();
		}
		else
			_log.info("Solo Boss Event is disabled");
		
		Util.printSection("NFT Boss");
		if (Config.NFT_BOSS_EVENT)
		{
			_log.info("NFT Boss Auto Event is enabled.");
			NftBossEvent.getInstance().StartCalculationOfNextEventTime();
		}
		else
			_log.info("NFT Boss Event is disabled");

		BalanceManager.getInstance();

		Util.printSection("Tournament");

		ArenaConfig.init();
		if (ArenaConfig.TOURNAMENT_EVENT_TIME)
		{
			_log.info("Tournament Event is enabled.");
			ArenaEvent.getInstance().StartCalculationOfNextEventTime();
		}
		else if (ArenaConfig.TOURNAMENT_EVENT_START)
		{
			_log.info("Tournament Event is enabled.");
			ArenaTask.spawnNpc1();
			ArenaTask.spawnNpc2();
		}
		else
			_log.info("Tournament Event is disabled");

		Util.printSection("Events");

		CTFConfig.init();
		CTFManager.getInstance();

		DMConfig.init();
		DMManager.getInstance();

		LMConfig.init();
		LMManager.getInstance();

		TvTConfig.init();
		TvTManager.getInstance();

		KTBConfig.init();
		KTBManager.getInstance();

		FOSConfig.init();
		FOSManager.getInstance();

		MultiTvTConfig.init();
		MultiTvTManager.getInstance();

		ClanRankingConfig.load();
		ClanRankingManager.getInstance();

		SpawnFenceInstance();
		
		PvPEventManager.getInstance();
        TimeZoneReset.getInstance().StartNextEventTime();
        
        FarmRandomZoneTaskManager.getInstance();

		Util.printSection("Fake Players");
		FakePlayerConfig.init();
		FakePlayerManager.INSTANCE.initialise();

		Util.printSection("HwId");
		Hwid.Init();

		Util.printSection("Server Work");
		ServerWork.getInstance().StartReset();
		ServerWork.getInstance().loadServer();
		long days = ServerWork.getInstance().getCont();
		_log.info(Config.ANNOUNCE_WORK_DAY + ": " + days + " Day's Online.");

		Util.printSection("Teleport Interface Location Data");
		TeleportLocationData2.getInstance();

		TerritoryWarManager.getInstance().initialize();

		Util.printSection("System");
		TaskManager.getInstance();

		Runtime.getRuntime().addShutdownHook(Shutdown.getInstance());
		ForumsBBSManager.getInstance();
		_log.config("IdFactory: Free ObjectIDs remaining: " + IdFactory.getInstance().size());

		KnownListUpdateTaskManager.getInstance();
		MovieMakerManager.getInstance();

		if (Config.DEADLOCK_DETECTOR)
		{
			_log.info("Deadlock detector is enabled. Timer: " + Config.DEADLOCK_CHECK_INTERVAL + "s.");
			_deadDetectThread = new DeadLockDetector();
			_deadDetectThread.setDaemon(true);
			_deadDetectThread.start();
		}
		else
		{
			_log.info("Deadlock detector is disabled.");
			_deadDetectThread = null;
		}

		System.gc();

		long usedMem = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576;
		long totalMem = Runtime.getRuntime().maxMemory() / 1048576;

		_log.info("Gameserver have started, used memory: " + usedMem + " / " + totalMem + " Mo.");
		_log.info("Maximum allowed players: " + Config.MAXIMUM_ONLINE_USERS);

		_log.info("Server Loaded in " + (System.currentTimeMillis() - serverLoadStart) / 1000 + " seconds");

		Util.printSection("Login");
		_loginThread = LoginServerThread.getInstance();
		_loginThread.start();

		final SelectorConfig sc = new SelectorConfig();
		sc.MAX_READ_PER_PASS = Config.MMO_MAX_READ_PER_PASS;
		sc.MAX_SEND_PER_PASS = Config.MMO_MAX_SEND_PER_PASS;
		sc.SLEEP_TIME = Config.MMO_SELECTOR_SLEEP_TIME;
		sc.HELPER_BUFFER_COUNT = Config.MMO_HELPER_BUFFER_COUNT;

		_gamePacketHandler = new L2GamePacketHandler();
		_selectorThread = new SelectorThread<>(sc, _gamePacketHandler, _gamePacketHandler, _gamePacketHandler, new IPv4Filter());

		InetAddress bindAddress = null;
		if (!Config.GAMESERVER_HOSTNAME.equals("*"))
		{
			try
			{
				bindAddress = InetAddress.getByName(Config.GAMESERVER_HOSTNAME);
			}
			catch (UnknownHostException e1)
			{
				_log.log(Level.SEVERE, "WARNING: The GameServer bind address is invalid, using all available IPs. Reason: " + e1.getMessage(), e1);
			}
		}

		try
		{
			_selectorThread.openServerSocket(bindAddress, Config.PORT_GAME);
		}
		catch (IOException e)
		{
			_log.log(Level.SEVERE, "FATAL: Failed to open server socket. Reason: " + e.getMessage(), e);
			System.exit(1);
		}
		_selectorThread.start();

	}

	public static void main(String[] args) throws Exception
	{
	    
		Server.serverMode = Server.MODE_GAMESERVER;

		final String LOG_FOLDER = "./log"; // Name of folder for log file
		final String LOG_NAME = "config/log.cfg"; // Name of log file

		// Create log folder
		File logFolder = new File(LOG_FOLDER);
		logFolder.mkdir();

		// Create input stream for log file -- or store file data into memory
		InputStream is = new FileInputStream(new File(LOG_NAME));
		LogManager.getLogManager().readConfiguration(is);
		is.close();

		// Initialize config
		Config.load();
		//LicenseCheck.validate();
		// Factories
		XMLDocumentFactory.getInstance();
		L2DatabaseFactory.getInstance();

		gameServer = new GameServer();
	}

	public static void SpawnFenceInstance()
	{
		//Kill The Boss
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fenceKtb = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 300, 100, 169592, -89512);
			fenceKtb.spawnMe(169592, -89512, -2912);
			FenceTable.addFence(fenceKtb);
		}
		//Capture The Flag
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fenceCtf = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, -100, 500, 13224, 119848);
			fenceCtf.spawnMe(13224, 119848, -12080);
			FenceTable.addFence(fenceCtf);
		}
		//Last Man Standing
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 500, 0, 57227, -29805);
			fence.spawnMe(57227, -29805, 574);
			FenceTable.addFence(fence);
		}
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 0, 500, 57399, -29611);
			fence.spawnMe(57399, -29611, 574);
			FenceTable.addFence(fence);
		}
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 400, 0, 58591, -29566);
			fence.spawnMe(58591, -29566, 574);
			FenceTable.addFence(fence);
		}
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 0, 400, 58720, -29789);
			fence.spawnMe(58720, -29789, 574);
			FenceTable.addFence(fence);
		}
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 0, 400, -19903, -51756);
			fence.spawnMe(-19903, -51756, -11003);
			FenceTable.addFence(fence);
		}
		for (int i = 0;i < 3;i++)
		{
			L2FenceInstance fence = new L2FenceInstance(IdFactory.getInstance().getNextId(), 2, 0, 400, -12922, -51754);
			fence.spawnMe(-12922, -51754, -11013);
			FenceTable.addFence(fence);
		}
		DoorTable.getInstance().getDoor(21170006).openMe();
		DoorTable.getInstance().getDoor(21170005).openMe();
		DoorTable.getInstance().getDoor(21170004).openMe();
		DoorTable.getInstance().getDoor(21170003).openMe();
	}

	public class SpawnMonsters implements Runnable
	{
		@Override
		public void run()
		{
			PartyFarm.spawnMonsters();
		}
	}

	public class SpawnMonsters_LS implements Runnable
	{
		@Override
		public void run()
		{
			Tyrannosaurus.spawnMonsters();
		}
	}
}