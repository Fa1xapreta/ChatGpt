// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.StoneMinerInstance;
import net.sf.l2j.gameserver.network.serverpackets.Earthquake;
import net.sf.l2j.gameserver.network.serverpackets.PlaySound;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Rnd;

public final class CustomTreasureHunt
{
    private static final Logger LOG = Logger.getLogger(CustomTreasureHunt.class.getName());
    private static final int MAX_ATTEMPTS = 200;
    private final TreasureHunt definition;
    private volatile StoneMinerInstance npc;

    public CustomTreasureHunt(TreasureHunt definition) { this.definition = definition; }
    public TreasureHunt getDefinition() { return definition; }

    /** Called serially by the event manager. No recursive retries. */
    public void spawnNpc()
    {
        GeoData geo = GeoData.getInstance();
        try
        {
            for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++)
            {
                int x = definition.getMinX() + Rnd.get(32768);
                int y = definition.getMinY() + Rnd.get(32768);
                if (!geo.hasGeo(x, y))
                    continue;
                int z = geo.getHeight(x, y, 10000);
                if (z < -10000 || !hasOpenNeighborhood(geo, x, y, z))
                    continue;
                L2Spawn spawn = new L2Spawn(NpcTable.getInstance().getTemplate(definition.getNpcId()));
                spawn.setLocx(x);
                spawn.setLocy(y);
                spawn.setLocz(z);
                spawn.setHeading(0);
                spawn.stopRespawn();
                L2Npc created = spawn.doSpawn(false);
                if (!(created instanceof StoneMinerInstance) || !created.isVisible())
                {
                    if (created != null)
                        created.deleteMe();
                    throw new IllegalStateException("StoneMiner spawn failed for " + definition.getId());
                }
                npc = (StoneMinerInstance) created;
                npc.setTreasureHunt(this);
                npc.broadcastPacket(new SocialAction(npc, 1));
                npc.broadcastPacket(new Earthquake(x, y, z, 5, 3));
                npc.broadcastPacket(new PlaySound("SkillSound5.target_magic_circle_01"));
                npc.throwUpNearbyPlayers();
                Broadcast.gameAnnounceToOnlinePlayers(npc.getName() + " apareceu em " + definition.getTerritoryName() + ".");
                return;
            }
            LOG.warning("TreasureHunt " + definition.getId() + ": no suitable point after " + MAX_ATTEMPTS + " attempts; check geodata.");
        }
        catch (Exception e)
        {
            despawnNpc();
            LOG.log(Level.WARNING, "TreasureHunt spawn failed: " + definition.getId(), e);
        }
    }

    private static boolean hasOpenNeighborhood(GeoData geo, int x, int y, int z)
    {
        // Check every cell in a small patch, not just the two endpoints.
        // NSWE 15 means all four directions open. This is local clearance,
        // not a proof of global reachability, terrain type or absence of water.
        for (int dx = -32; dx <= 32; dx += 16)
            for (int dy = -32; dy <= 32; dy += 16)
            {
                int px = x + dx, py = y + dy;
                if (!geo.hasGeo(px, py) || Math.abs(geo.getHeight(px, py, z) - z) > 32 ||
                    (geo.getNsweNearest(geo.getGeoX(px), geo.getGeoY(py), z) & 15) != 15)
                    return false;
            }
        return true;
    }

    public void despawnNpc()
    {
        StoneMinerInstance old = npc;
        npc = null;
        if (old == null)
            return;
        old.setTreasureHunt(null);
        old.releaseMiners();
        if (old.getSpawn() != null)
            old.getSpawn().stopRespawn();
        old.deleteMe();
    }
}
