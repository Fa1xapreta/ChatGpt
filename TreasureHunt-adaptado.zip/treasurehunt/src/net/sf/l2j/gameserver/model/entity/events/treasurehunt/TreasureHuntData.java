// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.kind.Weapon;

public final class TreasureHuntData
{
    private TreasureHuntData() { }

    /** Parse everything before replacing live events; a failed reload preserves them. */
    public static List<TreasureHunt> load() throws Exception
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        Element root = factory.newDocumentBuilder().parse(new File("./data/xml/treasurehunt.xml")).getDocumentElement();
        if (!"list".equals(root.getTagName()))
            throw new IllegalArgumentException("TreasureHunt: expected <list>");
        List<TreasureHunt> result = new ArrayList<>();
        Set<Integer> ids = new HashSet<>();
        NodeList children = root.getChildNodes();
        for (int i = 0; i < children.getLength(); i++)
        {
            Node node = children.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE)
                continue;
            Element element = (Element) node;
            if (!"treasure".equals(element.getTagName()))
                throw new IllegalArgumentException("Unknown treasure element: " + element.getTagName());
            TreasureHunt hunt = new TreasureHunt(integer(element, "id"), element.getAttribute("geodata"),
                integer(element, "npcId"), integer(element, "weaponId"), integer(element, "chance"), element.getAttribute("territoryName"));
            if (!ids.add(hunt.getId()))
                throw new IllegalArgumentException("Duplicate treasure ID: " + hunt.getId());
            NpcTemplate npc = NpcTable.getInstance().getTemplate(hunt.getNpcId());
            if (npc == null || !"StoneMiner".equals(npc.getType()))
                throw new IllegalArgumentException("NPC must exist with type StoneMiner: " + hunt.getNpcId());
            if (!(ItemTable.getInstance().getTemplate(hunt.getWeaponId()) instanceof Weapon))
                throw new IllegalArgumentException("Treasure tool is not a weapon: " + hunt.getWeaponId());
            result.add(hunt);
        }
        if (result.isEmpty())
            throw new IllegalArgumentException("TreasureHunt: empty configuration");
        return Collections.unmodifiableList(result);
    }

    private static int integer(Element element, String name)
    {
        return Integer.parseInt(element.getAttribute(name));
    }
}
