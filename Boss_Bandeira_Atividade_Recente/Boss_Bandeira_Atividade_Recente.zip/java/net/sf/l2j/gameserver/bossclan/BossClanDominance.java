package net.sf.l2j.gameserver.bossclan;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ClanTable;
import net.sf.l2j.gameserver.model.L2Clan;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.model.actor.L2Npc;

/** Uses the existing property without replacing the pack's large Config class. */
public final class BossClanDominance
{
    private static final Logger LOG=Logger.getLogger(BossClanDominance.class.getName());
    private static final boolean ENABLED=load();
    private BossClanDominance() { }

    private static boolean load()
    {
        Properties p=new Properties();
        try (InputStream in=Files.newInputStream(Paths.get(Config.NPCS_FILE)))
        {
            p.load(in);
            boolean enabled=Boolean.parseBoolean(p.getProperty("ShowBoss_Title_Crest","false").trim());
            LOG.info("BossClanDominance: " + (enabled?"enabled, visual ownership by active clan; owner inactivity 2000ms":"disabled"));
            return enabled;
        }
        catch (Exception e)
        {
            LOG.log(Level.WARNING,"BossClanDominance: cannot read "+Config.NPCS_FILE+"; disabled",e);
            return false;
        }
    }

    public static boolean isBoss(L2Npc npc)
    {
        return ENABLED && npc instanceof L2Attackable && npc.isRaid() && !npc.isMinion();
    }

    public static int ownerId(L2Npc npc)
    {
        return isBoss(npc)?((L2Attackable)npc).getBossDominantClanId():0;
    }

    /** Called only for a real change; reset and repeated hits do not announce. */
    public static void announceChange(L2Attackable boss,int previousOwner,int newOwner)
    {
        if (!isBoss(boss) || boss.isDead() || newOwner<=0 || previousOwner==newOwner
            || boss.getBossDominantClanId()!=newOwner)
            return;
        L2Clan current=ClanTable.getInstance().getClan(newOwner);
        if (current==null) return;
        L2Clan previous=previousOwner>0?ClanTable.getInstance().getClan(previousOwner):null;
        if (previous==null)
            Broadcast.BossAnnounce("Clan " + current.getName() + " dominou o raid boss " + boss.getName() + ".");
        else
            Broadcast.BossAnnounce("Clan " + current.getName() + " tomou o raid boss do Clan " + previous.getName() + ".");
    }
}
