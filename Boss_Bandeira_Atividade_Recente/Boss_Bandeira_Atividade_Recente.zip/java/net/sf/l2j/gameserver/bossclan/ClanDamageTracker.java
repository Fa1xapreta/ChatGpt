package net.sf.l2j.gameserver.bossclan;

import java.util.function.LongSupplier;

/** Visual ownership based on owner activity, with no historical damage totals. */
public final class ClanDamageTracker
{
    private static final long INACTIVE_NANOS=2000000000L;
    private final LongSupplier clock;
    private int owner;
    private long lastOwnerHit;

    public ClanDamageTracker() { this(System::nanoTime); }

    // Injectable monotonic clock for deterministic regression tests.
    ClanDamageTracker(LongSupplier clock) { this.clock=clock; }

    public synchronized boolean record(int clanId,double actualDamage)
    {
        if (clanId<=0 || actualDamage<=0 || Double.isNaN(actualDamage) || Double.isInfinite(actualDamage))
            return false;
        long now=clock.getAsLong();
        if (owner==clanId)
        {
            lastOwnerHit=now;
            return false;
        }
        if (owner==0 || now-lastOwnerHit>=INACTIVE_NANOS)
        {
            owner=clanId;
            lastOwnerHit=now;
            return true;
        }
        return false;
    }

    public synchronized int ownerId() { return owner; }

    public synchronized boolean reset()
    {
        boolean changed=owner!=0;
        owner=0;
        lastOwnerHit=0;
        return changed;
    }
}
