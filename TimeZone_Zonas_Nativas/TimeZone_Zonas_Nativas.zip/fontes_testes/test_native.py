from pathlib import Path
import subprocess,json
R=Path(__file__).parent;B=R.parent
cp=':'.join([str(R/'classes'),str(B/'timezone80/classes'),str(B/'target-hpcp75/classes'),str(B/'timezone77/server-classes'),str(B/'gearscore54/classes'),str(B/'gearscore50/classes'),str(B/'autofarm-current35/l2jserver.jar')]+[str(p) for p in (B/'gearscore50/libs').glob('*.jar')])
# Compile and execute actual pack shape implementations, not reimplemented geometry.
sources=[str(R/'tests/NativeZonesRegression.java'),str(B/'timezone80/tests/TimeZoneLedgerRegression.java')]+[str(B/'gearscore54/current/java/net/sf/l2j/gameserver/model/zone/form'/n) for n in ['ZoneCuboid.java','ZoneCylinder.java','ZoneNPoly.java']]
p=subprocess.run(['java','-jar',str(B/'gearscore50/tools/ecj.jar'),'-8','-encoding','UTF-8','-proc:none','-warn:none','-cp',cp,'-d',str(R/'classes')]+sources,capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0
results=[]
for cls,args in [('NativeZonesRegression',[str(R/'output'),str(B/'timezone80/output/config/custom/TimeZone.properties')]),('TimeZoneLedgerRegression',[str(B/'timezone80/output')])]:
 p=subprocess.run(['java','-cp',cp,'net.sf.l2j.gameserver.timezone.'+cls]+args,capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0;results.append(p.stdout.strip())
(R/'output/TESTES_ZONAS.json').write_text(json.dumps({'results':results,'actual_pack_zone_forms_executed':True,'full_ZoneManager_bootstrap_not_executed':True,'game_client_unchanged':True},indent=2))
