package net.sf.l2j.gameserver.timezone;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import net.sf.l2j.gameserver.model.zone.type.L2TimeZoneInterface;
import net.sf.l2j.gameserver.model.zone.form.*;
public class NativeZonesRegression {
 static int checks;
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);checks++;}
 static void fail(Path p,Path x,Collection<L2TimeZoneInterface> zs,String why)throws Exception {try{TimeZoneConfig.load(p,x,zs);throw new AssertionError(why);}catch(IllegalArgumentException expected){checks++;}}
 public static void main(String[]args)throws Exception {
  Path r=Paths.get(args[0]);Path p=Paths.get(args[1]);Path xml=r.resolve("data/xml/TimeZoneZones.xml");
  Document doc=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(r.resolve("data/xml/zones/TimeZoneInterface.xml").toFile());
  List<L2TimeZoneInterface> zs=new ArrayList<>();NodeList elems=doc.getElementsByTagName("zone");
  for(int i=0;i<elems.getLength();i++){
   Element e=(Element)elems.item(i);L2TimeZoneInterface z=L2TimeZoneInterface.class.getConstructor(int.class).newInstance(40000+i);z.setZoneName(e.getAttribute("zoneName"));
   int lo=Integer.parseInt(e.getAttribute("minZ")),hi=Integer.parseInt(e.getAttribute("maxZ"));NodeList ns=e.getElementsByTagName("node");int[]x=new int[ns.getLength()],y=x.clone();
   for(int j=0;j<x.length;j++){Element n=(Element)ns.item(j);x[j]=Integer.parseInt(n.getAttribute("X"));y[j]=Integer.parseInt(n.getAttribute("Y"));}
   switch(e.getAttribute("shape")){
    case "Cuboid":z.setZone(new ZoneCuboid(x[0],x[1],y[0],y[1],lo,hi));break;
    case "Cylinder":z.setZone(new ZoneCylinder(x[0],y[0],lo,hi,Integer.parseInt(e.getAttribute("rad"))));break;
    case "NPoly":z.setZone(new ZoneNPoly(x,y,lo,hi));break;
    default:throw new AssertionError("unknown shape");
   }
   Element exit=(Element)e.getElementsByTagName("spawn").item(0);z.addSpawn(Integer.parseInt(exit.getAttribute("X")),Integer.parseInt(exit.getAttribute("Y")),Integer.parseInt(exit.getAttribute("Z")));zs.add(z);
  }
  TimeZoneConfig c=TimeZoneConfig.load(p,xml,zs);check(c.zones.size()==4,"four native zones");
  for(TimeZoneDefinition z:c.zones){check(z.nativeZone!=null,"native bound");check(z.contains(z.spawnX,z.spawnY,z.spawnZ),"arrival inside actual native form");check(!z.contains(z.exitX,z.exitY,z.exitZ),"exit outside");check(z.exitX==81256&&z.exitY==149448,"exact exit, no randomized spawn");}
  Collections.reverse(zs);TimeZoneConfig reordered=TimeZoneConfig.load(p,xml,zs);check(reordered.byId.get(1).nativeZone.getZoneName().equals("Frost Lord Hunt"),"lookup by name independent of native id and order");
  TimeZoneDefinition cy=c.byId.get(3);check(!cy.contains(15746,-9374,-3288),"cylinder excludes bounding-square corner");check(cy.contains(15755,-9864,-3288),"cylinder interior");check(!cy.contains(15256,-9864,-3589),"native minZ enforced");
  TimeZoneDefinition po=c.byId.get(1);check(!po.contains(-81000,126000,-2700),"polygon excludes bounding rectangle corner");
  List<L2TimeZoneInterface> missing=new ArrayList<>(zs);missing.remove(c.byId.get(1).nativeZone);fail(p,xml,missing,"missing name rejected");
  List<L2TimeZoneInterface> dup=new ArrayList<>(zs);dup.add(c.byId.get(1).nativeZone);fail(p,xml,dup,"duplicate names rejected");
  String raw=new String(Files.readAllBytes(xml),StandardCharsets.UTF_8);Path tmp=Files.createTempFile("tz-native-config", ".xml");
  Files.write(tmp,raw.replace("x=\"-62264\"","x=\"81256\"").getBytes(StandardCharsets.UTF_8));fail(p,tmp,zs,"arrival outside polygon rejected");
  Files.write(tmp,raw.replace("zoneName=\"Magic Instance\"","zoneName=\"Frost Lord Hunt\"").replace("x=\"-16361\" y=\"-49308\" z=\"-10500\"","x=\"-62264\" y=\"140981\" z=\"-2700\"").getBytes(StandardCharsets.UTF_8));fail(p,tmp,zs,"two cards cannot share native zone");
  Files.delete(tmp);
  TimeZoneLedger ledger=new TimeZoneLedger(c,Collections.emptyList());long wall=1700000000000L,nano=1000000000L;
  TimeZoneDefinition a=c.byId.get(1),b=c.byId.get(3);ledger.admit(a,wall,nano);check(ledger.start(a,wall,nano),"start named polygon budget");ledger.stop(wall+90000,nano+90000000000L,false);check(ledger.view(a,wall+3600000,nano+3600000000000L).remainingMillis==3510000L,"native exit pauses correct balance");check(ledger.view(b,wall,nano).remainingMillis==3600000L,"other native zone keeps separate balance");
  System.out.println("PASS: "+checks+" native zone/config assertions; real Cuboid/Cylinder/NPoly, named lookup, exact exit, bad config rejection, per-card time");
 }
}
