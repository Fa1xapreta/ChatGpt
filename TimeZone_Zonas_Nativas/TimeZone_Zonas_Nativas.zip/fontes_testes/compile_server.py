from pathlib import Path
import subprocess
R=Path(__file__).parent;B=R.parent;cp=':'.join([str(R/'classes'),str(B/'timezone80/classes'),str(B/'target-hpcp75/classes'),str(B/'timezone77/server-classes'),str(B/'gearscore54/classes'),str(B/'gearscore50/classes'),str(B/'autofarm-current35/l2jserver.jar')]+[str(p) for p in (B/'gearscore50/libs').glob('*.jar')]);(R/'classes').mkdir(exist_ok=True)
x=subprocess.run(['java','-jar',str(B/'gearscore50/tools/ecj.jar'),'-8','-encoding','UTF-8','-proc:none','-warn:none','-cp',cp,'-d',str(R/'classes')]+[str(p) for p in (R/'output/java').rglob('*.java')],capture_output=True,text=True);print(x.stdout,x.stderr);assert x.returncode==0
