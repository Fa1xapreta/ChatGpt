package net.sf.l2j.gameserver.model.zone.type;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.L2SpawnZone;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.timezone.TimeZoneDefinition;
import net.sf.l2j.gameserver.timezone.TimeZoneFarm;

/** Loaded by the existing ZoneManager reflection path for type="TimeZoneInterface".
 * Shape and nodes belong to ZoneManager. Native spawn is the exact EXIT, not a randomized arrival.
 */
public final class L2TimeZoneInterface extends L2SpawnZone
{
    private volatile TimeZoneDefinition definition;
    private volatile TimeZoneFarm manager;
    private final Set<Integer> flagged=ConcurrentHashMap.newKeySet();
    public L2TimeZoneInterface(int id){super(id);}
    public synchronized void bind(TimeZoneDefinition d,TimeZoneFarm m)
    {
        if(definition!=null)throw new IllegalStateException("TimeZone already bound: "+getZoneName());
        definition=d;manager=m;
    }
    @Override protected void onEnter(L2Character character)
    {
        TimeZoneFarm m=manager;TimeZoneDefinition d=definition;
        if(m==null||d==null||!(character instanceof L2PcInstance))return;
        L2PcInstance p=(L2PcInstance)character;
        if(m.zoneEntered(p,d.id)&&d.pvp&&flagged.add(p.getObjectId()))p.setInsideZone(ZoneId.PVP,true);
    }
    @Override protected void onExit(L2Character character)
    {
        if(!(character instanceof L2PcInstance))return;L2PcInstance p=(L2PcInstance)character;
        if(flagged.remove(p.getObjectId()))p.setInsideZone(ZoneId.PVP,false);
        TimeZoneFarm m=manager;TimeZoneDefinition d=definition;if(m!=null&&d!=null)m.zoneLeft(p,d.id);
    }
    @Override public void onDieInside(L2Character character) { }
    @Override public void onReviveInside(L2Character character) { }
}
