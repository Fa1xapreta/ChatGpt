package net.sf.l2j.gameserver.timezone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.L2WorldRegion;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.DropCategory;
import net.sf.l2j.gameserver.model.item.DropData;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.model.zone.form.ZoneCuboid;
import net.sf.l2j.gameserver.model.zone.type.L2TimeZoneFarmZone;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;

/** Multi-zone daily farm service. Teleports never execute while holding a Session monitor. */
public final class TimeZoneFarm
{
    private static final Logger LOG=Logger.getLogger(TimeZoneFarm.class.getName());
    private static final int ZONE_BASE=95000000,PAGE_SIZE=4;
    private static volatile TimeZoneFarm live;
    private final ConcurrentMap<Integer,Session> sessions=new ConcurrentHashMap<>();
    private final TimeZoneStore store;
    interface Clock { long wall(); long nanos(); }
    private final Clock clock;
    private static final Clock SYSTEM_CLOCK=new Clock(){public long wall(){return System.currentTimeMillis();}public long nanos(){return System.nanoTime();}};
    private final AtomicLong tokens=new AtomicLong();
    private TimeZoneConfig config;private volatile boolean ready;
    private static final class Pending
    {
        final TimeZoneDefinition zone;final TimeZoneLedger.Snapshot before;final int charged;final long deadline;
        volatile boolean paid,cancelled;final AtomicBoolean refunded=new AtomicBoolean();
        Pending(TimeZoneDefinition z,TimeZoneLedger.Snapshot before,int charged,long deadline){zone=z;this.before=before;this.charged=charged;this.deadline=deadline;}
    }
    private static final class Session
    {
        final int charId;final TimeZoneLedger ledger;final String key;int page=1,uiVersion;long savedRevision=-1;boolean closed;Pending pending;
        Session(int id,TimeZoneLedger l,String key){charId=id;ledger=l;this.key=key;}
    }
    private TimeZoneFarm(){this(null,new TimeZoneStore(),SYSTEM_CLOCK);}
    TimeZoneFarm(TimeZoneConfig configured,TimeZoneStore store,Clock clock)
    {
        this.store=store;this.clock=clock;
        try
        {
            config=configured==null?TimeZoneConfig.load():configured;store.initialize(config.createTable);validateItems();
            if(config.enabled)registerZones();ready=true;live=this;
            ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::tick,1000,1000);
            ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::flushAll,config.saveMs,config.saveMs);
            Runtime.getRuntime().addShutdownHook(new Thread(this::shutdownSave,"TimeZoneFarm-save"));
            LOG.info("TimeZoneFarm: "+(config.enabled?"enabled":"disabled")+", "+config.zones.size()+" zones; per-zone daily budget, pause outside/offline; reset "+config.resetTime+" "+config.resetZone);
        }
        catch(Exception e){LOG.log(Level.SEVERE,"TimeZoneFarm unavailable; admission blocked",e);}
    }
    public static TimeZoneFarm getInstance(){return Holder.INSTANCE;}
    public static boolean managesLocation(int x,int y,int z){TimeZoneFarm m=live;return m!=null&&m.ownsLocation(x,y,z);}
    public static void playerLogin(L2PcInstance p){TimeZoneFarm m=live;if(m!=null)try{m.onLogin(p);}catch(Exception e){LOG.log(Level.WARNING,"TimeZone login hook failed",e);}}
    public static void playerLogout(L2PcInstance p){TimeZoneFarm m=live;if(m!=null)try{m.onLogout(p);}catch(Exception e){LOG.log(Level.WARNING,"TimeZone logout hook failed",e);}}
    private static final class Holder{private static final TimeZoneFarm INSTANCE=new TimeZoneFarm();}
    public boolean isEnabled(){return ready&&config.enabled;}
    public boolean ownsLocation(int x,int y,int z){return isEnabled()&&findZone(x,y,z)!=null;}
    private TimeZoneDefinition findZone(int x,int y,int z)
    { if(config==null)return null;TimeZoneDefinition found=null;for(TimeZoneDefinition d:config.zones)if(d.contains(x,y,z)){if(found!=null)return null;found=d;}return found; }
    private void validateItems()
    {
        for(TimeZoneDefinition z:config.zones)
        {
            if(ItemTable.getInstance().getTemplate(z.costItemId)==null)throw new IllegalArgumentException("Unknown cost item in zone "+z.id);
            for(TimeZoneDefinition.Drop d:z.drops)if(ItemTable.getInstance().getTemplate(d.itemId)==null)throw new IllegalArgumentException("Unknown drop item "+d.itemId);
            for(int id:z.npcIds)if(NpcTable.getInstance().getTemplate(id)==null)throw new IllegalArgumentException("Unknown tooltip NPC "+id);
        }
    }
    private void registerZones()
    {
        ZoneManager manager=ZoneManager.getInstance();
        for(TimeZoneDefinition d:config.zones)if(d.nativeZone==null&&manager.getZoneById(ZONE_BASE+d.id)!=null)throw new IllegalArgumentException("Native zone ID collision "+(ZONE_BASE+d.id));
        L2WorldRegion[][] regions=L2World.getInstance().getAllWorldRegions();
        for(TimeZoneDefinition d:config.zones)
        {
            if(d.nativeZone!=null){d.nativeZone.bind(d,this);continue;}
            L2TimeZoneFarmZone zone=new L2TimeZoneFarmZone(ZONE_BASE+d.id,d,this);
            zone.setZone(new ZoneCuboid(d.minX,d.maxX,d.minY,d.maxY,d.minZ,d.maxZ));zone.setZoneName("TimeZone:"+d.name);manager.addZone(ZONE_BASE+d.id,zone);
            for(int x=0;x<regions.length;x++)for(int y=0;y<regions[x].length;y++)
                if(zone.getZone().intersectsRectangle(L2World.getRegionX(x),L2World.getRegionX(x+1),L2World.getRegionY(y),L2World.getRegionY(y+1)))regions[x][y].addZone(zone);
        }
    }
    public void onLogin(L2PcInstance player){if(ready)session(player);}
    private Session session(L2PcInstance player)
    {
        Session s=sessions.get(player.getObjectId());if(s!=null){s.closed=false;return s;}
        try
        {
            Session fresh=new Session(player.getObjectId(),new TimeZoneLedger(config,store.load(player.getObjectId())),Long.toHexString(tokens.incrementAndGet()));
            // Stored admission resumes only when login actually occurs inside that area.
            for(TimeZoneDefinition zone:config.zones)if(!zone.contains(player.getX(),player.getY(),player.getZ()))fresh.ledger.revoke(zone.id);
            Session old=sessions.putIfAbsent(player.getObjectId(),fresh);return old==null?fresh:old;
        }
        catch(Exception e){LOG.log(Level.WARNING,"TimeZone cannot load character "+player.getObjectId(),e);player.sendMessage("TimeZone: nao foi possivel carregar seu tempo. Tente novamente.");return null;}
    }
    public boolean handle(L2PcInstance player,String command)
    {
        if(command==null)return false;
        boolean known=command.equals("lotusdk RefreshPassInfo")||command.startsWith("tz ")||command.startsWith("lotusdk LotusIN ")||command.equals("lotusdk LotusEx")||command.equals("timezone_toggle");
        if(!known)return false;
        if(!ready){player.sendMessage("TimeZone indisponivel. Verifique o console do servidor.");return true;}
        Session s=session(player);if(s==null)return true;
        if(command.equals("lotusdk RefreshPassInfo")){sendCurrentPage(player,s);return true;}
        if(command.equals("tz open")){send(player,"Open|"+player.getObjectId());sendCurrentPage(player,s);return true;}
        if(command.startsWith("tz page "))
        {
            String n=command.substring(8);if(n.matches("[1-9][0-9]{0,8}"))sendPage(player,s,Integer.parseInt(n));return true;
        }
        if(command.startsWith("tz enter "))
        {
            String n=command.substring(9);if(n.matches("[1-9][0-9]{0,6}")){TimeZoneDefinition z=config.byId.get(Integer.parseInt(n));if(z!=null)enter(player,s,z);}return true;
        }
        if(command.equals("tz exit")||command.equals("lotusdk LotusEx")){exit(player,s);return true;}
        if(command.equals("timezone_toggle")){if(s.ledger.activeId()!=0)exit(player,s);return true;}
        if(command.startsWith("lotusdk LotusIN "))player.sendMessage("Atualize o cliente TimeZone para selecionar uma zona.");
        return true;
    }
    private boolean canMove(L2PcInstance p)
    {
        if(p.isAlikeDead()){p.sendMessage("TimeZone: seu personagem esta morto.");return false;}
        if(p.isTeleporting()){p.sendMessage("TimeZone: aguarde o teleporte atual terminar.");return false;}
        if(p.isInCombat()){p.sendMessage("TimeZone: seu personagem esta em combate.");return false;}
        if(p.isInDuel()){p.sendMessage("TimeZone: saia do duelo antes de teleportar.");return false;}
        if(p.isInOlympiadMode()){p.sendMessage("TimeZone: voce esta na Olimpiada.");return false;}
        if(p.isInStoreMode()){p.sendMessage("TimeZone: feche sua loja antes de teleportar.");return false;}
        if(p.inObserverMode()){p.sendMessage("TimeZone: saia do modo observador antes de teleportar.");return false;}
        if(p.isInJail()){p.sendMessage("TimeZone: seu personagem esta preso.");return false;}
        if(p.isInFunEvent()||p.isInArenaEvent()){p.sendMessage("TimeZone: saia do evento antes de teleportar.");return false;}
        if(p.isCursedWeaponEquipped()){p.sendMessage("TimeZone: voce esta com uma arma amaldicoada.");return false;}
        if(p.getKarma()>0){p.sendMessage("TimeZone: seu personagem esta com karma.");return false;}
        if(p.getActiveTradeList()!=null){p.sendMessage("TimeZone: encerre a negociacao antes de teleportar.");return false;}
        return true;
    }
    private void enter(L2PcInstance p,Session s,TimeZoneDefinition z)
    {
        if(!isEnabled()){p.sendMessage("O TimeZone esta desativado.");return;}
        if(!canMove(p))return;
        if(config.requirePeace&&!p.isInsideZone(ZoneId.PEACE)){p.sendMessage("Entre no TimeZone a partir de uma zona de paz.");return;}
        if(p.getLevel()<z.minLevel||p.getLevel()>z.maxLevel){p.sendMessage("Seu nivel nao permite entrar nesta zona.");return;}
        Pending pending;boolean charged=false;
        synchronized(s)
        {
            if(s.pending!=null||s.ledger.activeId()!=0){p.sendMessage("Saia da zona atual antes de entrar em outra.");return;}
            long wall=clock.wall(),nano=clock.nanos();TimeZoneLedger.Snapshot before=s.ledger.view(z,wall,nano);
            if(before.remainingMillis<=0){p.sendMessage("Seu tempo diario nesta zona terminou.");sendCurrentPage(p,s);return;}
            int cost=s.ledger.needsPayment(z,wall,nano)?z.costCount:0;
            // Reserve the operation before touching inventory; duplicate requests cannot charge again.
            pending=new Pending(z,before,cost,clock.nanos()+config.teleportTimeoutMs*1000000L);s.pending=pending;
        }
        try
        {
            if(pending.charged>0)
            {
                if(!p.destroyItemByItemId("TimeZoneEntry",z.costItemId,pending.charged,p,true)){synchronized(s){if(s.pending==pending)s.pending=null;}p.sendMessage("Voce nao possui o ingresso necessario.");return;}
                charged=true;pending.paid=true;
            }
            synchronized(s)
            {
                if(s.pending!=pending||s.closed)throw new IllegalStateException("Entry cancelled");
                s.ledger.admit(z,clock.wall(),clock.nanos());save(s);
            }
        }
        catch(Exception e)
        {
            synchronized(s){if(s.pending==pending){s.ledger.restore(pending.before);s.pending=null;}}
            if(charged&&pending.refunded.compareAndSet(false,true))p.addItem("TimeZoneRefund",z.costItemId,pending.charged,p,true);
            LOG.log(Level.WARNING,"TimeZone entry not committed for "+p.getObjectId()+" zone "+z.id,e);p.sendMessage("Nao foi possivel registrar a entrada. O ingresso foi devolvido.");return;
        }
        if(!canMove(p)){rollback(p,s,pending);return;}
        try{p.teleToLocation(z.spawnX,z.spawnY,z.spawnZ,0);}
        catch(Exception e){LOG.log(Level.WARNING,"TimeZone teleport failed",e);rollback(p,s,pending);}
    }
    private void rollback(L2PcInstance p,Session s,Pending pending)
    {
        synchronized(s)
        {
            if(s.pending!=pending)return;pending.cancelled=true;
            s.ledger.restore(pending.before);s.ledger.view(pending.zone,clock.wall(),clock.nanos());
            try{save(s);}catch(Exception e){LOG.log(Level.SEVERE,"TimeZone pending refund could not be persisted for "+s.charId,e);p.sendMessage("TimeZone: falha ao cancelar a entrada. Contate um administrador.");return;}
            s.pending=null;
        }
        if(pending.paid&&pending.refunded.compareAndSet(false,true))p.addItem("TimeZoneRefund",pending.zone.costItemId,pending.charged,p,true);
        p.sendMessage("A entrada nao foi concluida. O ingresso foi devolvido.");
    }
    public boolean zoneEntered(L2PcInstance p,int zoneId)
    {
        if(!isEnabled())return false;TimeZoneDefinition z=config.byId.get(zoneId);if(z==null)return false;Session s=session(p);boolean admitted=false;
        if(s!=null)synchronized(s)
        {
            TimeZoneLedger.Snapshot b=s.ledger.view(z,clock.wall(),clock.nanos());
            boolean authorized=s.pending!=null?(!s.pending.cancelled&&s.pending.zone.id==zoneId):b.admitted;
            if(authorized&&findZone(p.getX(),p.getY(),p.getZ())==z&&b.remainingMillis>0&&s.ledger.start(z,clock.wall(),clock.nanos())){s.pending=null;admitted=true;}
        }
        if(admitted){sendCurrentPage(p,s);sendTimer(p,s);send(p,"Entered|"+zoneId);}
        else{p.sendMessage("Entre nesta area usando a janela TimeZone.");ejectSoon(p.getObjectId(),z);}
        return admitted;
    }
    public void zoneLeft(L2PcInstance p,int zoneId)
    {
        Session s=sessions.get(p.getObjectId());if(s==null)return;
        synchronized(s)
        {
            if(s.ledger.activeId()!=zoneId)return;s.ledger.stop(clock.wall(),clock.nanos(),false);
            try{save(s);}catch(Exception e){LOG.log(Level.WARNING,"TimeZone exit save failed for "+s.charId,e);}
        }
        timerOff(p,s);if(p.isOnline())sendCurrentPage(p,s);
    }
    private void exit(L2PcInstance p,Session s)
    {
        int id=s.ledger.activeId();TimeZoneDefinition z=config.byId.get(id);if(z==null||!canMove(p))return;
        // The native zone exit hook accounts the exact time before pausing.
        p.teleToLocation(z.exitX,z.exitY,z.exitZ,0);
    }
    private void ejectSoon(int charId,TimeZoneDefinition z)
    {
        ThreadPoolManager.getInstance().scheduleGeneral(()->{L2PcInstance p=L2World.getInstance().getPlayer(charId);if(p!=null&&z.contains(p.getX(),p.getY(),p.getZ()))p.teleToLocation(z.exitX,z.exitY,z.exitZ,0);},100);
    }
    public void onLogout(L2PcInstance p)
    {
        Session s=sessions.get(p.getObjectId());if(s==null)return;Pending pending;
        synchronized(s){pending=s.pending;}
        if(pending!=null)rollback(p,s,pending);
        synchronized(s)
        {
            s.ledger.stop(clock.wall(),clock.nanos(),true);s.closed=true;
            try{save(s);if(s.pending==null)sessions.remove(s.charId,s);}catch(Exception e){LOG.log(Level.WARNING,"TimeZone logout save pending for "+s.charId,e);}
        }
    }
    private void tick()
    {
        for(Session s:sessions.values())try
        {
            L2PcInstance p=L2World.getInstance().getPlayer(s.charId);
            if(p==null||!p.isOnline()){synchronized(s){s.ledger.stop(clock.wall(),clock.nanos(),true);s.closed=true;}continue;}Pending pending;
            synchronized(s){pending=s.pending;}
            if(pending!=null&&clock.nanos()-pending.deadline>=0)rollback(p,s,pending);
            int id=s.ledger.activeId();if(id==0)continue;TimeZoneDefinition z=config.byId.get(id);
            if(z==null)continue;
            if(findZone(p.getX(),p.getY(),p.getZ())!=z){if(z.contains(p.getX(),p.getY(),p.getZ()))ejectSoon(p.getObjectId(),z);zoneLeft(p,id);continue;}
            long left; synchronized(s){left=s.ledger.view(z,clock.wall(),clock.nanos()).remainingMillis;}
            if(left<=0)
            {
                synchronized(s){s.ledger.stop(clock.wall(),clock.nanos(),false);try{save(s);}catch(Exception e){LOG.log(Level.WARNING,"TimeZone expiration save pending",e);}}
                timerOff(p,s);p.sendMessage("Seu tempo diario nesta zona terminou.");ejectSoon(s.charId,z);sendCurrentPage(p,s);
            }
            else sendTimer(p,s);
        }
        catch(Exception e){LOG.log(Level.WARNING,"TimeZone tick failed for character "+s.charId,e);}
    }
    private void save(Session s) throws Exception
    {if(sessions.get(s.charId)!=s)return;if(!config.enabled){s.savedRevision=s.ledger.revision();return;}Map<Integer,TimeZoneLedger.Snapshot> rows=s.ledger.snapshots(clock.wall(),clock.nanos());store.save(s.charId,rows.values());s.savedRevision=s.ledger.revision();}
    private void flushAll()
    {
        for(Session s:sessions.values())synchronized(s){try
        {
            s.ledger.update(clock.wall(),clock.nanos());if(s.savedRevision!=s.ledger.revision())save(s);if(s.closed&&s.pending==null)sessions.remove(s.charId,s);
        }
        catch(Exception e){LOG.log(Level.WARNING,"TimeZone periodic save pending for "+s.charId,e);}}
    }
    private void shutdownSave()
    {
        for(Session s:sessions.values())synchronized(s){try{s.ledger.stop(clock.wall(),clock.nanos(),true);save(s);}catch(Exception e){LOG.log(Level.SEVERE,"TimeZone final save failed for "+s.charId,e);}}
    }
    private static String wire(String s){if(s==null)return "";if(s.length()>300)s=s.substring(0,300);return s.replace('|',' ').replace('"','\'').replace('\n',' ').replace('\r',' ');}
    private static void send(L2PcInstance p,String body){p.sendPacket(new ExShowScreenMessage("CustomEvent=TimeZoneV2|"+body,1));}
    private void sendTimer(L2PcInstance p,Session s)
    {
        String body;
        synchronized(s)
        {
            int id=s.ledger.activeId();TimeZoneDefinition z=config.byId.get(id);
            long left=z==null?0:s.ledger.view(z,clock.wall(),clock.nanos()).remainingMillis;
            body="Timer|"+(z==null?0:id)+"|"+left+"|"+wire(z==null?"Time Zone":z.name)+"|"+s.charId+"|"+s.key+"|"+(++s.uiVersion);
        }
        send(p,body);
    }
    private void timerOff(L2PcInstance p,Session s)
    {
        String body;synchronized(s){body="Timer|0|0|Time Zone|"+s.charId+"|"+s.key+"|"+(++s.uiVersion);}send(p,body);
    }
    private void sendCurrentPage(L2PcInstance p,Session s){synchronized(s){sendPage(p,s,s.page);}}
    private void sendPage(L2PcInstance p,Session s,int requested)
    {
        synchronized(s)
        {
            int pages=Math.max(1,(config.zones.size()+PAGE_SIZE-1)/PAGE_SIZE);s.page=Math.max(1,Math.min(requested,pages));String token=Long.toHexString(tokens.incrementAndGet());
            send(p,"Begin|"+token+"|"+s.page+"|"+pages+"|"+config.zones.size()+"|"+s.ledger.activeId()+"|"+(isEnabled()?"Time Zone":"Time Zone - desativado")+"|"+(isEnabled()?1:0)+"|"+s.charId+"|"+s.key+"|"+(++s.uiVersion));
            int begin=(s.page-1)*PAGE_SIZE,end=Math.min(begin+PAGE_SIZE,config.zones.size());
            for(int i=begin;i<end;i++)
            {
                TimeZoneDefinition z=config.zones.get(i);int slot=i-begin;long remaining=s.ledger.view(z,clock.wall(),clock.nanos()).remainingMillis;
                int costDue=s.ledger.needsPayment(z,clock.wall(),clock.nanos())?z.costCount:0;
                Item cost=ItemTable.getInstance().getTemplate(z.costItemId);String name=cost==null?"Item #"+z.costItemId:cost.getName();long count=p.getInventory().getInventoryItemCount(z.costItemId,0);
                send(p,"Row|"+token+"|"+slot+"|"+z.id+"|"+wire(z.name)+"|"+(z.pvp?"PVP":"PVE")+"|"+wire(z.difficulty)+"|"+z.minLevel+"|"+z.maxLevel+"|"+remaining+"|"+z.dailyMillis()+"|"+z.costItemId+"|"+costDue+"|"+wire(name)+"|"+count+"|"+wire(z.image)+"|"+wire(z.description.isEmpty()?"-":z.description)+"|"+wire(z.displayLabel));
                List<TimeZoneDefinition.Drop> drops=tooltipDrops(z);int shown=0;
                for(TimeZoneDefinition.Drop d:drops)
                {
                    if(shown++>=config.maxTooltipDrops)break;Item item=ItemTable.getInstance().getTemplate(d.itemId);if(item==null)continue;
                    send(p,"Drop|"+token+"|"+slot+"|"+d.itemId+"|"+wire(item.getName())+"|"+d.min+"|"+d.max+"|"+wire(d.note.isEmpty()?"Drop":d.note));
                }
                if(drops.size()>config.maxTooltipDrops)send(p,"More|"+token+"|"+slot+"|"+(drops.size()-config.maxTooltipDrops));
            }
            send(p,"End|"+token);
        }
    }
    private List<TimeZoneDefinition.Drop> tooltipDrops(TimeZoneDefinition z)
    {
        if(z.npcIds.isEmpty())return z.drops;
        List<TimeZoneDefinition.Drop> all=new ArrayList<>(z.drops);Set<Integer> ids=new HashSet<>();for(TimeZoneDefinition.Drop d:all)ids.add(d.itemId);
        for(int id:z.npcIds)
        {
            NpcTemplate npc=NpcTable.getInstance().getTemplate(id);if(npc==null)continue;
            for(DropCategory category:npc.getDropData())for(DropData d:category.getAllDrops())if(ids.add(d.getItemId()))all.add(new TimeZoneDefinition.Drop(d.getItemId(),d.getMinDrop(),d.getMaxDrop(),category.isSweep()?"Spoil":"Drop dos monstros"));
        }
        return all;
    }
}
