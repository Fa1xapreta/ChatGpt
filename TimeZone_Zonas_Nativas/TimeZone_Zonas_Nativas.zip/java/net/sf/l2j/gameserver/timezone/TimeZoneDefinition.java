package net.sf.l2j.gameserver.timezone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable server-authoritative definition. Drops describe existing farm rewards. */
public final class TimeZoneDefinition
{
    public net.sf.l2j.gameserver.model.zone.type.L2TimeZoneInterface nativeZone;
    public final int id,minutesPerDay,minLevel,maxLevel,costItemId,costCount;
    public final boolean pvp,chargeOnReentry;
    public final String name,difficulty,image,description,displayLabel;
    public final int minX,maxX,minY,maxY,minZ,maxZ,spawnX,spawnY,spawnZ,exitX,exitY,exitZ;
    public final List<Drop> drops;
    public final List<Integer> npcIds;
    public static final class Drop
    {
        public final int itemId,min,max;public final String note;
        public Drop(int itemId,int min,int max,String note) { this.itemId=itemId;this.min=min;this.max=max;this.note=note; }
    }
    TimeZoneDefinition(int id,String name,int minutes,int minLevel,int maxLevel,boolean pvp,String difficulty,
        String image,String description,String displayLabel,int costItemId,int costCount,boolean chargeOnReentry,int[] bounds,int[] spawn,int[] exit,List<Drop> drops,List<Integer> npcIds)
    {
        this.id=id;this.name=name;minutesPerDay=minutes;this.minLevel=minLevel;this.maxLevel=maxLevel;this.pvp=pvp;
        this.difficulty=difficulty;this.image=image;this.description=description;this.displayLabel=displayLabel;this.costItemId=costItemId;this.costCount=costCount;this.chargeOnReentry=chargeOnReentry;
        minX=bounds[0];maxX=bounds[1];minY=bounds[2];maxY=bounds[3];minZ=bounds[4];maxZ=bounds[5];
        spawnX=spawn[0];spawnY=spawn[1];spawnZ=spawn[2];exitX=exit[0];exitY=exit[1];exitZ=exit[2];
        this.drops=Collections.unmodifiableList(new ArrayList<>(drops));this.npcIds=Collections.unmodifiableList(new ArrayList<>(npcIds));
    }
    public long dailyMillis() { return minutesPerDay*60000L; }
    public boolean contains(int x,int y,int z) { return nativeZone!=null?nativeZone.isInsideZone(x,y,z):x>=minX&&x<=maxX&&y>=minY&&y<=maxY&&z>=minZ&&z<=maxZ; }
    public boolean overlaps(TimeZoneDefinition b) { return nativeZone!=null||b.nativeZone!=null?false:minX<=b.maxX&&maxX>=b.minX&&minY<=b.maxY&&maxY>=b.minY&&minZ<=b.maxZ&&maxZ>=b.minZ; }
}
