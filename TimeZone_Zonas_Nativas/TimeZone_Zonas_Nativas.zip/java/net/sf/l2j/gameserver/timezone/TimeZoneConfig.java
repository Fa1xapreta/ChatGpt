package net.sf.l2j.gameserver.timezone;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.model.zone.type.L2TimeZoneInterface;
import net.sf.l2j.gameserver.model.Location;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public final class TimeZoneConfig
{
    public final boolean enabled,requirePeace,createTable;
    public final ZoneId resetZone;public final LocalTime resetTime;
    public final int saveMs,teleportTimeoutMs,maxTooltipDrops;
    public final Map<Integer,TimeZoneDefinition> byId;
    public final List<TimeZoneDefinition> zones;
    private TimeZoneConfig(Properties p,List<TimeZoneDefinition> zones)
    {
        enabled=bool(p.getProperty("Enabled","false"));requirePeace=bool(p.getProperty("RequirePeaceOnEntry","true"));createTable=bool(p.getProperty("CreateTable","true"));
        resetZone=ZoneId.of(p.getProperty("ResetTimeZone","America/Sao_Paulo").trim());resetTime=LocalTime.parse(p.getProperty("ResetTime","00:00").trim());
        maxTooltipDrops=number(p.getProperty("MaxTooltipDrops","16"),1,32,"MaxTooltipDrops");
        teleportTimeoutMs=number(p.getProperty("TeleportTimeoutMs","30000"),5000,120000,"TeleportTimeoutMs");
        saveMs=number(p.getProperty("SaveIntervalMs","5000"),1000,60000,"SaveIntervalMs");
        Map<Integer,TimeZoneDefinition> map=new LinkedHashMap<>();
        for(TimeZoneDefinition z:zones) { if(map.put(z.id,z)!=null)throw new IllegalArgumentException("Duplicate zone id "+z.id); }
        for(TimeZoneDefinition a:zones)for(TimeZoneDefinition b:zones)
        {
            if(a.id!=b.id&&a.nativeZone!=null&&a.nativeZone==b.nativeZone)throw new IllegalArgumentException("Two cards reference native zone "+a.nativeZone.getZoneName());
            if(a.id!=b.id&&b.contains(a.spawnX,a.spawnY,a.spawnZ))throw new IllegalArgumentException("Entry spawn of zone "+a.id+" also inside zone "+b.id);
            if(a.id!=b.id&&a.overlaps(b))throw new IllegalArgumentException("Overlapping zones "+a.id+" and "+b.id);
            if(b.contains(a.exitX,a.exitY,a.exitZ))throw new IllegalArgumentException("Exit of zone "+a.id+" is inside zone "+b.id);
        }
        this.zones=Collections.unmodifiableList(new ArrayList<>(zones));byId=Collections.unmodifiableMap(map);
    }
    public static TimeZoneConfig load() throws Exception { return load(Paths.get("./config/custom/TimeZone.properties"),Paths.get("./data/xml/TimeZoneZones.xml")); }
    public static TimeZoneConfig load(Path properties,Path xml) throws Exception
    {
        return load(properties,xml,null);
    }
    public static TimeZoneConfig load(Path properties,Path xml,Collection<L2TimeZoneInterface> supplied) throws Exception
    {
        Properties p=new Properties();try(InputStream in=Files.newInputStream(properties)){p.load(in);}
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);f.setFeature("http://xml.org/sax/features/external-general-entities",false);f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD,"");f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");f.setXIncludeAware(false);f.setExpandEntityReferences(false);
        Element root;try(InputStream in=Files.newInputStream(xml)){root=f.newDocumentBuilder().parse(in).getDocumentElement();}
        if(!root.getTagName().equals("timezones"))throw new IllegalArgumentException("Expected <timezones>");
        List<TimeZoneDefinition> zones=new ArrayList<>();
        for(Node n=root.getFirstChild();n!=null;n=n.getNextSibling())
        {
            if(!(n instanceof Element))continue;Element e=(Element)n;if(!e.getTagName().equals("zone"))throw new IllegalArgumentException("Unknown element "+e.getTagName());
            if(!bool(e.getAttribute("enabled").isEmpty()?"true":e.getAttribute("enabled")))continue;
            int id=attr(e,"id",1,1000000);String name=text(e,"name",80);int minutes=attr(e,"minutesPerDay",1,1440);
            int min=attr(e,"minLevel",1,100),max=attr(e,"maxLevel",min,100);int item=attr(e,"costItemId",1,Integer.MAX_VALUE),count=attr(e,"costCount",0,Integer.MAX_VALUE);
            String image=text(e,"image",180);if(!image.matches("[A-Za-z0-9_.]+"))throw new IllegalArgumentException("Invalid image path");
            Element spawn=child(e,"spawn");int[] point=point(spawn),out,bounds;
            L2TimeZoneInterface linked=null;String zoneName=e.getAttribute("zoneName").trim();
            if(!zoneName.isEmpty())
            {
                Collection<L2TimeZoneInterface> candidates=supplied;
                if(candidates==null)try{candidates=ZoneManager.getInstance().getAllZones(L2TimeZoneInterface.class);}
                catch(NullPointerException missing){throw new IllegalArgumentException("No TimeZoneInterface zones loaded. Check data/xml/zones/TimeZoneInterface.xml and L2TimeZoneInterface.class",missing);}
                for(L2TimeZoneInterface candidate:candidates)if(zoneName.equals(candidate.getZoneName()))
                { if(linked!=null)throw new IllegalArgumentException("Duplicate native zoneName: "+zoneName);linked=candidate; }
                if(linked==null||linked.getZone()==null)throw new IllegalArgumentException("Native zoneName not found: "+zoneName);
                if(linked.getZone().getLowZ()>=linked.getZone().getHighZ())throw new IllegalArgumentException("Invalid minZ/maxZ in native zone "+zoneName);
                if(linked.getSpawns()==null||linked.getSpawns().size()!=1)throw new IllegalArgumentException("Exactly one exit <spawn X/Y/Z> required in native zone "+zoneName);
                Location exit=linked.getSpawns().get(0);out=new int[]{exit.getX(),exit.getY(),exit.getZ()};
                bounds=new int[]{0,0,0,0,linked.getZone().getLowZ(),linked.getZone().getHighZ()};
            }
            else
            {
                // Compatibility for previously installed rectangle configurations.
                Element area=child(e,"area");out=point(child(e,"exit"));
                bounds=new int[]{attr(area,"minX",-327680,229375),attr(area,"maxX",-327680,229375),attr(area,"minY",-262144,262143),attr(area,"maxY",-262144,262143),attr(area,"minZ",-32768,32767),attr(area,"maxZ",-32768,32767)};
                if(bounds[0]>=bounds[1]||bounds[2]>=bounds[3]||bounds[4]>=bounds[5])throw new IllegalArgumentException("Invalid bounds of zone "+id);
            }
            List<TimeZoneDefinition.Drop> drops=new ArrayList<>();List<Integer> npcs=new ArrayList<>();String description="";
            for(Node c=e.getFirstChild();c!=null;c=c.getNextSibling())if(c instanceof Element)
            {
                Element a=(Element)c;
                if(a.getTagName().equals("description")){description=a.getTextContent().trim();if(description.length()>300)throw new IllegalArgumentException("Description too long");}
                else if(a.getTagName().equals("drops")){for(Node q=a.getFirstChild();q!=null;q=q.getNextSibling())if(q instanceof Element)
                {
                    Element d=(Element)q;
                    if(d.getTagName().equals("item")){int lo=attr(d,"min",1,Integer.MAX_VALUE);drops.add(new TimeZoneDefinition.Drop(attr(d,"id",1,Integer.MAX_VALUE),lo,attr(d,"max",lo,Integer.MAX_VALUE),d.getAttribute("note")));}
                    else if(d.getTagName().equals("npc"))npcs.add(attr(d,"id",1,Integer.MAX_VALUE));
                    else throw new IllegalArgumentException("Unknown drop source "+d.getTagName());
                }
                }
                else if(!a.getTagName().equals("area")&&!a.getTagName().equals("spawn")&&!a.getTagName().equals("exit"))throw new IllegalArgumentException("Unknown zone child "+a.getTagName());
            }
            if(drops.size()>100)throw new IllegalArgumentException("Too many tooltip drops in zone "+id);
            String label=e.getAttribute("displayLabel").trim();if(label.isEmpty())label=bool(e.getAttribute("pvp"))?"PVP":"PVE / "+text(e,"difficulty",40);if(label.length()>40)throw new IllegalArgumentException("Label too long");
            TimeZoneDefinition z=new TimeZoneDefinition(id,name,minutes,min,max,bool(e.getAttribute("pvp")),text(e,"difficulty",40),image,description,label,item,count,bool(e.getAttribute("chargeOnReentry").isEmpty()?"true":e.getAttribute("chargeOnReentry")),bounds,point,out,drops,npcs);
            z.nativeZone=linked;
            if(!z.contains(point[0],point[1],point[2]))throw new IllegalArgumentException("Spawn outside zone "+id);zones.add(z);
        }
        return new TimeZoneConfig(p,zones);
    }
    public long periodStart(long millis)
    {
        ZonedDateTime now=Instant.ofEpochMilli(millis).atZone(resetZone);ZonedDateTime reset=now.toLocalDate().atTime(resetTime).atZone(resetZone);
        if(now.isBefore(reset))reset=now.toLocalDate().minusDays(1).atTime(resetTime).atZone(resetZone);
        return reset.toInstant().toEpochMilli();
    }
    private static int[] point(Element e) { return new int[]{attr(e,"x",-327680,229375),attr(e,"y",-262144,262143),attr(e,"z",-32768,32767)}; }
    private static Element child(Element e,String name)
    {
        Element found=null;for(Node c=e.getFirstChild();c!=null;c=c.getNextSibling())if(c instanceof Element&&((Element)c).getTagName().equals(name)){if(found!=null)throw new IllegalArgumentException("Duplicate "+name);found=(Element)c;}
        if(found==null)throw new IllegalArgumentException("Missing "+name);return found;
    }
    private static String text(Element e,String key,int max) { String v=e.getAttribute(key).trim();if(v.isEmpty()||v.length()>max)throw new IllegalArgumentException("Invalid "+key);return v; }
    private static int attr(Element e,String key,int min,int max) { return number(e.getAttribute(key),min,max,key); }
    private static int number(String s,int min,int max,String key) { int v=Integer.parseInt(s.trim());if(v<min||v>max)throw new IllegalArgumentException("Invalid "+key);return v; }
    private static boolean bool(String s) { if(s.equalsIgnoreCase("true"))return true;if(s.equalsIgnoreCase("false"))return false;throw new IllegalArgumentException("Invalid boolean "+s); }
}
