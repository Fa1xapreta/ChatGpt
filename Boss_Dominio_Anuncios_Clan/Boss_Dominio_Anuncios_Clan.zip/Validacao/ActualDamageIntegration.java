package net.sf.l2j.gameserver.bossclan;
import java.util.ArrayList;
import java.util.List;
import net.sf.l2j.gameserver.model.actor.*;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.status.AttackableStatus;
/** Actual compiled status hook and tracker, with NPC/session/parent-HP fixtures. */
public final class ActualDamageIntegration
{
 private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception
 {
  boolean enabled=Boolean.parseBoolean(args[0]);L2Attackable boss=new L2Attackable();AttackableStatus status=new AttackableStatus(boss);L2PcInstance a=new L2PcInstance(1),b=new L2PcInstance(2);
  status.reduceHp(400,a);check(boss.hp==600,"Normal HP reduction preserved");
  if(!enabled){check(boss.countedDamage==0&&boss.tracker.ownerId()==0,"Feature false leaves combat tracking off");System.out.println("PASS: configuration false preserves ordinary HP behavior");return;}
  check(boss.tracker.ownerId()==1 && boss.countedDamage==400,"Actual HP loss counted");
  status.reduceHp(1,b);check(boss.tracker.ownerId()==1,"Isolated hit cannot steal ownership");
  boss.invul=true;status.reduceHp(100000,b);check(boss.hp==599 && boss.countedDamage==401 && boss.tracker.ownerId()==1,"Invulnerability creates zero contribution");boss.invul=false;
  status.reduceHp(400,b);check(boss.hp==199 && boss.tracker.ownerId()==2,"Other clan must overtake actual cumulative damage");
  status.reduceHp(10000,a);check(boss.countedDamage==1000,"Overkill counts remaining 199 HP, not attempted 10000");
  boss.dead=false;status.setCurrentHp(1000,true);check(boss.tracker.ownerId()==0,"Full HP reset clears encounter");
  boss.raid=false;status.reduceHp(10,a);check(boss.tracker.ownerId()==0,"Normal mob excluded");boss.raid=true;boss.minion=true;status.reduceHp(10,a);check(boss.tracker.ownerId()==0,"Raid minion excluded");
  boss.minion=false;status.setCurrentHp(1000,true);double before=boss.countedDamage;
  // More than enough HP for concurrent damage, no deaths or resets during the run.
  boss.maxHp=100000;status.setCurrentHp(100000,true);List<Thread> threads=new ArrayList<>();
  for(int i=0;i<8;i++){Thread t=new Thread(()->{for(int j=0;j<1000;j++)status.reduceHp(1,a);});threads.add(t);t.start();}
  for(Thread t:threads)t.join();check(boss.hp==92000 && boss.countedDamage-before==8000,"Actual status hook serializes HP deltas without double counting");
  System.out.println("PASS: actual AttackableStatus hook + tracker; real loss, blocked damage, overkill cap, reset, boss/minion filter and 8000 concurrent HP deductions (world/HP parent fixtures)");
 }
}
