package net.sf.l2j.gameserver.bossclan;
import net.sf.l2j.gameserver.datatables.ClanTable;
import net.sf.l2j.gameserver.model.L2Clan;
import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.util.Broadcast;
public final class BossAnnouncementRegression
{
 private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 private static void damage(L2Attackable boss,int clan,double value)
 {
  int old=boss.tracker.ownerId();
  if(boss.tracker.record(clan,value))BossClanDominance.announceChange(boss,old,boss.tracker.ownerId());
 }
 public static void main(String[] args)
 {
  boolean enabled=Boolean.parseBoolean(args[0]);L2Attackable boss=new L2Attackable();
  ClanTable.CLANS.put(1,new L2Clan(1,"Alpha"));ClanTable.CLANS.put(2,new L2Clan(2,"Beta"));
  damage(boss,1,20000);
  if(!enabled){check(Broadcast.SENT.isEmpty(),"Config false suppresses announcements");System.out.println("PASS: disabled feature emits no dominance announcements");return;}
  check(Broadcast.SENT.size()==1 && Broadcast.SENT.get(0).equals("Clan Alpha dominou o raid boss Ketra Commander."),"Initial capture exact message includes boss");
  damage(boss,1,1);damage(boss,2,100);damage(boss,2,19901);
  check(Broadcast.SENT.size()==1,"Same owner, small hit and tie do not announce");
  damage(boss,2,1);
  check(Broadcast.SENT.size()==2 && Broadcast.SENT.get(1).equals("Clan Beta tomou o raid boss do Clan Alpha."),"Takeover exact new/old names; boss name omitted");
  damage(boss,1,2);
  check(Broadcast.SENT.get(2).equals("Clan Alpha tomou o raid boss do Clan Beta."),"Reverse takeover uses former owner correctly");
  int n=Broadcast.SENT.size();BossClanDominance.announceChange(boss,1,1);check(Broadcast.SENT.size()==n,"Same IDs do not announce");
  boss.tracker.reset();BossClanDominance.announceChange(boss,1,0);check(Broadcast.SENT.size()==n,"Reset not announced");
  damage(boss,2,1);check(Broadcast.SENT.get(n).equals("Clan Beta dominou o raid boss Ketra Commander."),"New fight produces initial-capture message");
  n=Broadcast.SENT.size();boss.dead=true;damage(boss,1,100);check(Broadcast.SENT.size()==n,"No late ownership announcement after boss death");boss.dead=false;
  BossClanDominance.announceChange(boss,1,2);check(Broadcast.SENT.size()==n,"Stale owner event ignored");
  boss.minion=true;BossClanDominance.announceChange(boss,2,1);check(Broadcast.SENT.size()==n,"Minion ignored");
  System.out.println("PASS: actual tracker + announcement method; exact first/takeover messages, reverse takeover, no hit/tie/reset duplicates, new encounter, dead/stale/minion filtering (clan lookup and broadcast mocked)");
 }
}
