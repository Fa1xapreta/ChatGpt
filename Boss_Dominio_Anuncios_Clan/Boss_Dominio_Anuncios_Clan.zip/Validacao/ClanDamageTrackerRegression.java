package net.sf.l2j.gameserver.bossclan;
import java.util.ArrayList;
import java.util.List;
public final class ClanDamageTrackerRegression
{
    private static void check(boolean b,String text) { if (!b) throw new AssertionError(text); }
    public static void main(String[] args) throws Exception
    {
        ClanDamageTracker boss=new ClanDamageTracker();
        check(boss.ownerId()==0,"No owner before damage");
        for (double invalid:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY})
            check(!boss.record(1,invalid) && boss.ownerId()==0,"Ignore invalid damage");
        check(!boss.record(0,100000),"Unclanned damage cannot claim");
        check(boss.record(10,20000) && boss.ownerId()==10,"First valid damaging clan claims");
        check(!boss.record(20,100) && boss.ownerId()==10,"Another clan's isolated hit does not steal crest");
        check(!boss.record(20,19900) && boss.ownerId()==10,"Tie retains current owner");
        check(boss.record(20,1) && boss.ownerId()==20,"Only cumulative overtake changes owner");
        check(!boss.record(20,10),"Same owner damage does not repeat ownership broadcast");
        check(boss.record(10,100) && boss.ownerId()==10,"Former owner can overtake again");
        ClanDamageTracker otherBoss=new ClanDamageTracker();otherBoss.record(30,1);
        check(boss.ownerId()==10 && otherBoss.ownerId()==30,"Boss encounters are independent");
        check(boss.reset() && boss.ownerId()==0,"Reset clears owner and all prior damage");
        check(boss.record(20,1) && boss.ownerId()==20,"New fight starts from zero");
        boss.reset();boss.record(1,1);
        List<Thread> threads=new ArrayList<>();
        for(int i=0;i<8;i++)
        {
            Thread t=new Thread(() -> {for(int j=0;j<2000;j++) boss.record(1,1);});threads.add(t);t.start();
        }
        for(Thread t:threads)t.join();
        check(!boss.record(2,16000) && boss.ownerId()==1,"Concurrent contributions are not lost");
        check(boss.record(2,2) && boss.ownerId()==2,"Accurate totals after concurrent hits");
        System.out.println("PASS: actual tracker; isolated hit, cumulative overtake, ties, no repeat updates, reverse overtake, reset, independent bosses, invalid/unclanned input, 16000 concurrent contributions");
    }
}
