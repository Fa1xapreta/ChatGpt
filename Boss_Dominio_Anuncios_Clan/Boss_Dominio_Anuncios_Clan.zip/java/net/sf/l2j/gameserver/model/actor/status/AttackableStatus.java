/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.model.actor.status;

import java.util.Collection;
import net.sf.l2j.gameserver.bossclan.BossClanDominance;

import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.AbstractNpcInfo;

public class AttackableStatus extends NpcStatus
{
	public AttackableStatus(L2Attackable activeChar)
	{
		super(activeChar);
	}
	
	@Override
	public final void reduceHp(double value, L2Character attacker)
	{
		reduceHp(value, attacker, true, false, false);
	}
	
	@Override
	public final void reduceHp(double value, L2Character attacker, boolean awake, boolean isDOT, boolean isHpConsumption)
	{
		if (getActiveChar().isDead())
			return;
		
		if (value > 0)
		{
			if (getActiveChar().isOverhit())
				getActiveChar().setOverhitValues(attacker, value);
			else
				getActiveChar().overhitEnabled(false);
		}
		else
			getActiveChar().overhitEnabled(false);
		
        if (BossClanDominance.isBoss(getActiveChar()))
        {
            // Serialize boss HP deltas: concurrent hits cannot count each other's damage.
            synchronized(this)
            {
                final double hpBefore=getCurrentHp();
                super.reduceHp(value, attacker, awake, isDOT, isHpConsumption);
                final double actualDamage=Math.max(0,hpBefore-getCurrentHp());
                getActiveChar().recordBossClanDamage(attacker,actualDamage);
            }
        }
        else
            super.reduceHp(value, attacker, awake, isDOT, isHpConsumption);
		
		if (!getActiveChar().isDead())
			// And the attacker's hit didn't kill the mob, clear the over-hit flag
			getActiveChar().overhitEnabled(false);
	}
	
	@Override
	public void setCurrentHp(double newHp, boolean broadcastPacket)
	{

        if (BossClanDominance.isBoss(getActiveChar()))
        {
            synchronized(this)
            {
                super.setCurrentHp(newHp,broadcastPacket);
                if (getCurrentHp()>=getActiveChar().getMaxHp())
                    getActiveChar().resetBossClanDominance(true);
            }
        }
        else
            super.setCurrentHp(newHp,broadcastPacket);


		if (getActiveChar().getFakePc() != null)
		{
			Collection<L2PcInstance> plrs = getActiveChar().getKnownList().getKnownType(L2PcInstance.class);
			for (L2PcInstance player : plrs)
			{
				if (player != null)
					player.sendPacket(new AbstractNpcInfo.NpcInfo(getActiveChar(), player));
			}
		}
	}

	@Override
	public L2Attackable getActiveChar()
	{
		return (L2Attackable) super.getActiveChar();
	}
}