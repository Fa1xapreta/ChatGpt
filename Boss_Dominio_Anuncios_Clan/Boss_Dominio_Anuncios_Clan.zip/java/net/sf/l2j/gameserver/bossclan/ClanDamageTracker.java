package net.sf.l2j.gameserver.bossclan;

import java.util.HashMap;
import java.util.Map;

/** Per-encounter numeric totals only. No references to players, clans or NPCs. */
public final class ClanDamageTracker
{
    private Map<Integer,Double> totals;
    private int owner;

    public synchronized boolean record(int clanId,double actualDamage)
    {
        if (clanId<=0 || actualDamage<=0 || Double.isNaN(actualDamage) || Double.isInfinite(actualDamage))
            return false;
        if (totals==null) totals=new HashMap<>();
        double total=Math.min(Double.MAX_VALUE,totals.getOrDefault(clanId,0.0)+actualDamage);
        totals.put(clanId,total);
        if (owner==0 || (clanId!=owner && total>totals.getOrDefault(owner,0.0)))
        {
            owner=clanId;
            return true;
        }
        return false;
    }

    public synchronized int ownerId() { return owner; }

    public synchronized boolean reset()
    {
        boolean changed=owner!=0;
        totals=null;owner=0;
        return changed;
    }
}
