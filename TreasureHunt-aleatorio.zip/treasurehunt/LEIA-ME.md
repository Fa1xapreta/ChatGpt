# Treasure Hunt — aleatório por geodata, sem repetir lugares

Esta versão restaura o sorteio em toda a região indicada no XML. Não exige
pontos cadastrados, não possui modo de teste e não restringe o evento aos locais
usados nas verificações anteriores. Caminhos e montanhas são permitidos quando
a geodata indicar chão caminhável e espaço para a pedra.

## Atualizar a versão já instalada

1. Faça backup das fontes, XMLs, propriedades e dados do evento.
2. Copie/mescle as oito classes de `src/net/` na raiz das fontes da pack. É
   importante atualizar o conjunto inteiro para não misturar versões.
   Se usa o patch opcional, `patches/atualizar-para-aleatorio.patch` foi feito para
   a versão final com a atualização de diagnóstico instalada. Aplique na raiz de
   fontes que contém `net/`, usando uma alternativa OU outra:

   ```sh
   git apply --check --ignore-space-change /caminho/patches/atualizar-para-aleatorio.patch
   git apply --ignore-space-change /caminho/patches/atualizar-para-aleatorio.patch
   ```

3. Substitua `data/xml/treasurehunt.xml` pelo arquivo em `datapack/data/xml/`.
   O novo XML usa `geodata="24_15"` e não possui filhos `<spawn>`.
4. **Na primeira instalação deste histórico**, copie o arquivo inicial
   `historico-inicial/treasurehunt-used-locations.log` para
   `data/treasurehunt-used-locations.log` do gameserver.
   **Se o histórico já existir, preserve-o: nunca substitua pelo arquivo inicial.**
   O arquivo inicial inclui as quatro posições conhecidas das versões anteriores.
   Ele fica separado do datapack para não sobrescrever um histórico em uso ao
   atualizar os XMLs.
5. Compile com limpeza dos arquivos compilados antigos, substitua o JAR realmente
   executado pelo servidor e reinicie. Recarga de XML não atualiza classes Java.
6. Confira a geodata: `config/main/geoengine.properties` deve usar `GeoData > 0`,
   com os arquivos das regiões presentes em `GeoDataPath` e no formato configurado.
   A configuração enviada pelo usuário usa `GeoData = 2`, formato L2J.

Quem já instalou a integração anterior não precisa substituir as seis classes
em `core-editados/` novamente: elas estão no pacote para uma instalação completa.
As integrações com Config, GameServer, L2PcInstance, EnterWorld, UseItem e AdminAdmin
não foram modificadas nesta atualização. Se suas fontes foram editadas depois do
último envio, faça merge para preservar esse trabalho.

NPCs e ferramenta continuam os mesmos. Não duplique definições dos NPCs
52000–52003 ou do item 30139 ao mesclar o datapack.

## Propriedades

Mantenha no arquivo existente `config/custom/l2jmod.properties`:

```properties
EnableTreasureHunt = True
TreasureHuntInterval = 1800
AllowTreasureHuntAutoLoot = True
```

O intervalo é em segundos. O primeiro sorteio ocorre no ciclo seguinte à carga,
aproximadamente um segundo; os seguintes usam o intervalo configurado. Não é
prazo de despawn separado. As chaves antigas `TreasureHuntTestMode/X/Y/Z` não são
usadas e devem permanecer removidas.

## Regiões e sorteio

Foram restauradas as 12 entradas do XML original, com IDs únicos de 0 a 11:

- `16_25`: quatro cores, rótulo original Talking Island.
- `23_24`: quatro cores, rótulo original Crystal Island.
- `24_15`: quatro cores, rótulo original Ketra Orc Outpost.

Os blocos e chances originais foram preservados. O nome do território é apenas
o texto do anúncio; a área física é determinada pelo número da região.
Cada entrada faz seu sorteio de chance e, quando selecionada, tenta até 1000
coordenadas aleatórias dentro dos limites do bloco. As escolhas de X/Y não ficam
presas a caminhos, spawns de monstros ou aos pontos de teste.

Antes de criar a pedra, o mod verifica:

- Geodata presente e habilitada.
- Chão na camada mais alta encontrada, usando a altura real da geodata.
- Espaço da colisão da pedra com margem adicional, sem células bloqueadas por
  paredes na área ocupada.
- Cada célula dessa área é alcançável de ida e volta a partir do centro.
- Há ao menos uma aproximação caminhável a 128 unidades, em uma das oito direções,
  com caminho de ida e volta completo. Um resultado cortado não é aceito.
- O candidato não pertence a um lugar já registrado no histórico.
- Não há sobreposição com outra pedra ativa.

A área ocupada admite variação de até 64 unidades em relação ao chão central,
mas o caminho também precisa passar nas verificações do core. Isso permite
ladeiras caminháveis sem aceitar um degrau ou parede só pela diferença de altura.
Não se compara mais o chão ao Z fixo -4367 que causou os avisos anteriores.

Depois da criação, a posição efetiva e o espaço são conferidos novamente, antes
de ativar a mineração e enviar os efeitos. São permitidas no máximo 16 criações
por entrada/rodada, dentro das 1000 tentativas, para evitar trabalho excessivo se
as validações posteriores do core falharem repetidamente.

Se nenhuma posição nova e válida for encontrada, não há spawn forçado. O console
mostra a região e os motivos agrupados: `GEODATA_MISSING`, `FOOTPRINT_WALL`,
`FOOTPRINT_HEIGHT_EDGE`, `FOOTPRINT_PATH_BLOCKED`, `NO_WALKABLE_APPROACH`,
`USED_LOCATION`, `STONE_OCCUPIED` ou falhas de validação do spawn.

A pedra anterior é mantida até a substituta passar pela validação após criação.
Falhas de XML em uma recarga preservam os eventos atuais. Desabilitar o evento
remove suas pedras e limpa as sessões dos mineradores.

## Nunca repetir lugar

O histórico é global: todas as cores e regiões o compartilham.

- Uma célula XY de **64 x 64 unidades nunca é reutilizada**.
- Um novo centro deve ficar a **pelo menos 64 unidades** dos centros registrados,
  inclusive quando ficam de lados diferentes da borda de uma célula.
- A mesma posição XY não é reutilizada em outro andar/Z.
- A reserva é gravada e forçada ao disco **antes** da criação da pedra.
- O histórico é carregado novamente após reinícios e não expira ao recarregar XML.
- Uma reserva pode ser consumida mesmo que o core falhe depois; ela não é liberada.

**Preserve `data/treasurehunt-used-locations.log` e seus backups.** Se ele estiver
ausente, sem permissão, corrompido, incompleto ou bloqueado por outro servidor,
o evento bloqueia novos spawns. Não apaga nem recria o histórico automaticamente.
Se perder o arquivo, restaure um backup consistente; não use um arquivo vazio
como correção. Não compartilhe esse arquivo entre dois servidores simultâneos.

A regra depende de manter o histórico. Apagar, truncar ou substituir por um backup
antigo perde as posições que só existiam no arquivo mais recente. O histórico
não consegue reconstruir spawns antigos que nunca foram registrados; o arquivo
inicial cobre somente as quatro posições conhecidas do modo fixo anterior.

As regiões são finitas. Se não houver mais posições novas adequadas, a rodada
fica sem aquela pedra em vez de permitir repetição.

## Efeitos, ferramenta e recompensas

Mantidos SocialAction 1, Earthquake (5, 3), som e lançamento dos jogadores próximos.
O destino do lançamento também exige terreno caminhável e espaço livre.

A ferramenta 30139 continua sendo criada/equipada automaticamente no primeiro
clique. O ataque segue o fluxo normal no clique seguinte. O ID exato do objeto
controla a ferramenta temporária; o mod não destrói itens legítimos pelo template.
A troca/cancelamento de alvo, morte, teleporte, saída e despawn limpam a sessão e
restauram as mãos quando os itens anteriores ainda estão no inventário.
Preserve também `data/treasurehunt-sessions/` junto com os backups do banco.

XMLs de NPCs e ferramenta, prêmios e chances de drop não foram alterados. A pedra
verde continua com chance 100/1000000 = 0,01%, como enviada. O autoloot mantém a
configuração anterior; desligado, os itens caem no chão sem reserva exclusiva.

## Validação e limites

Passaram 124 verificações isoladas, com substitutos explícitos do core: regiões,
limites, falta de geo, paredes, encosta caminhável, desnível, caminhos cortados,
aproximação, sobreposição, efeitos, ferramenta, restauração, recarga e chance.
O histórico foi testado com arquivos reais, incluindo reinício, bloqueio de
arquivo, concorrência, repetição perto de bordas, coordenadas negativas, arquivo
corrompido e ausência do arquivo. Os patches e a integridade do ZIP são conferidos.

O usuário confirmou anteriormente os NPCs, efeitos e mineração. **Esta nova
seleção aleatória ainda precisa ser validada no servidor real.** O projeto
completo e dependências não foram fornecidos para build integral.

As verificações de caminhada são locais e dependem da geodata correta. Não há
análise de conectividade do mundo inteiro nem classificação de todo terreno
por água/telhado. A seleção segue a superfície e as regras de movimento da pack;
dados incorretos podem dar resultados incorretos. Os logs registram as coordenadas
reais de cada spawn para conferência, sem precisar procurar às cegas.

Use `//reload treasurehunt` para recarregar o XML sem apagar histórico.
