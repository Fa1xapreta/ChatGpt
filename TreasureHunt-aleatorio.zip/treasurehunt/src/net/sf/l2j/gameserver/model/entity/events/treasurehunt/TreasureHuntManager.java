// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.util.Rnd;

public final class TreasureHuntManager implements Runnable
{
    private static final Logger LOG = Logger.getLogger(TreasureHuntManager.class.getName());
    private List<CustomTreasureHunt> hunts = Collections.emptyList();
    private boolean started, enabled;
    private int interval;
    private long nextRun;

    private TreasureHuntManager() { }
    public static TreasureHuntManager getInstance() { return Holder.INSTANCE; }

    public synchronized void start()
    {
        if (started)
            return;
        reload();
        started = true;
        ThreadPoolManager.getInstance().scheduleGeneral(this, 1000);
    }

    /** Invalid XML leaves existing events untouched. */
    public synchronized boolean reload()
    {
        try
        {
            List<CustomTreasureHunt> replacement = new ArrayList<>();
            for (TreasureHunt definition : TreasureHuntData.load())
                replacement.add(new CustomTreasureHunt(definition));
            clear();
            hunts = replacement;
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
            nextRun = System.nanoTime();
            LOG.info("TreasureHunt: loaded " + hunts.size() + " entries; enabled=" + enabled + ", interval=" + interval + " seconds.");
            return true;
        }
        catch (Exception e)
        {
            LOG.log(Level.SEVERE, "TreasureHunt: configuration rejected; previous events preserved.", e);
            return false;
        }
    }

    @Override
    public void run()
    {
        try { tick(); }
        catch (Exception e) { LOG.log(Level.SEVERE, "TreasureHunt tick failed", e); }
        finally { ThreadPoolManager.getInstance().scheduleGeneral(this, 1000); }
    }

    private synchronized void tick()
    {
        long now = System.nanoTime();
        int configuredInterval = Math.max(1, Config.TREASURE_HUNT_INTERVAL);
        if (enabled != Config.ENABLE_TREASURE_HUNT || interval != configuredInterval)
        {
            boolean enabling = !enabled && Config.ENABLE_TREASURE_HUNT;
            enabled = Config.ENABLE_TREASURE_HUNT;
            interval = configuredInterval;
            nextRun = now + (enabling ? 0 : TimeUnit.SECONDS.toNanos(interval));
            if (!enabled) clear();
        }
        if (!enabled || now - nextRun < 0)
            return;
        nextRun = now + TimeUnit.SECONDS.toNanos(interval);
        for (CustomTreasureHunt hunt : hunts)
            if (Rnd.get(100) < hunt.getDefinition().getChance())
            {
                List<L2Npc> occupied = new ArrayList<>();
                for (CustomTreasureHunt other : hunts)
                    if (other != hunt && other.getNpc() != null)
                        occupied.add(other.getNpc());
                hunt.spawnNpc(occupied);
            }
    }

    private void clear()
    {
        for (CustomTreasureHunt hunt : hunts)
            hunt.despawnNpc();
    }

    private static final class Holder
    {
        private static final TreasureHuntManager INSTANCE = new TreasureHuntManager();
    }
}
