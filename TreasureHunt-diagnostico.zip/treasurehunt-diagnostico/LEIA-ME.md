# Diagnóstico de pontos rejeitados — Treasure Hunt

Atualização de somente duas classes da versão TreasureHunt-final.zip:
CustomTreasureHunt.java e TreasureHuntSpawnPoint.java.

Copie/mescle os dois arquivos de src/net/ na raiz das fontes da pack,
recompile, substitua o JAR executado e reinicie o servidor. Alternativamente,
aplique diagnostico.patch na raiz das fontes com git apply --ignore-space-change.
Não altere o XML nem as propriedades para instalar este diagnóstico.

A alteração detalha o primeiro motivo de rejeição de cada ponto. Mantém os
mesmos limites de altura, NSWE, espaço, caminho e distância entre pedras.
A verificação de caminho reverso só ocorre quando o caminho de ida é válido.

Envie as linhas que começam com TreasureHunt ...: rejected point ... .
Códigos:
- GEODATA_DISABLED: GeoData <= 0 na configuração efetivamente carregada.
- GEODATA_NOT_INITIALIZED: o driver não está inicializado.
- GEODATA_MISSING: a célula não tem dados; confira região, arquivo, formato e carga.
- HEIGHT_MISMATCH: Z cadastrado difere do piso; a linha mostra expectedZ e geoZ.
- HEIGHT_EDGE: uma célula da área livre tem desnível acima do limite.
- NSWE_BLOCKED: alguma direção de uma célula está bloqueada; a linha mostra a célula e nswe.
- PATH_CLIPPED: caminho não chegou ao ponto, ou retornou null; mostra esperado e obtido.
- STONE_OCCUPIED: outra pedra está próxima; pode ser normal ao tentar vários pontos.
- INVALID_CLEARANCE: raio do NPC/margem fora do limite suportado.

Sua configuração enviada tem GeoData=2, GeoDataFormat=L2J e região 24_15 ativa.
Isso declara a carga, mas não comprova a presença/leitura de data/geodata/24_15.l2j.
O caminho relativo é resolvido a partir do diretório de execução do gameserver.
Não foi alterado CoordSynchronize: o log fornecido não o identifica como causa.

82 verificações isoladas passaram, incluindo os códigos de diagnóstico.
O build completo da pack e a execução no servidor do usuário continuam externos.
Esta atualização coleta a causa; não afirma corrigir o bloqueio ainda desconhecido.
