// SPDX-License-Identifier: GPL-3.0-or-later
package net.sf.l2j.gameserver.model.entity.events.treasurehunt;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.model.Location;

/** A manually approved point and a nearby walkable approach, on the intended floor. */
public final class TreasureHuntSpawnPoint
{
    private final int x, y, z, approachX, approachY, approachZ;

    public TreasureHuntSpawnPoint(int x, int y, int z, int approachX, int approachY, int approachZ)
    {
        if (!inWorld(x, y, z) || !inWorld(approachX, approachY, approachZ))
            throw new IllegalArgumentException("Spawn outside Interlude world bounds");
        long dx = (long) x - approachX, dy = (long) y - approachY;
        if (dx * dx + dy * dy < 64L * 64 || dx * dx + dy * dy > 1024L * 1024 || Math.abs(z - approachZ) > 128)
            throw new IllegalArgumentException("Approach must be 64..1024 units away on the same floor");
        this.x = x; this.y = y; this.z = z;
        this.approachX = approachX; this.approachY = approachY; this.approachZ = approachZ;
    }

    private static boolean inWorld(int x, int y, int z)
    {
        return x >= -327680 && x <= 229375 && y >= -262144 && y <= 262143 && z >= -32768 && z <= 32767;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }

    public static final class Validation
    {
        private final Integer groundZ;
        private final String reason;
        private Validation(Integer groundZ, String reason) { this.groundZ = groundZ; this.reason = reason; }
        public Integer getGroundZ() { return groundZ; }
        public String getReason() { return reason; }
    }

    public Integer resolveSafeZ(int clearance) { return validate(clearance).getGroundZ(); }

    /** Return the first rejection cause without changing any safety threshold. */
    public Validation validate(int clearance)
    {
        GeoData geo = GeoData.getInstance();
        if (Config.GEODATA <= 0)
            return rejected("GEODATA_DISABLED GeoData=" + Config.GEODATA);
        if (geo == null)
            return rejected("GEODATA_NOT_INITIALIZED");
        if (!geo.hasGeo(x, y))
            return rejected("GEODATA_MISSING spawn=" + x + " " + y);
        if (!geo.hasGeo(approachX, approachY))
            return rejected("GEODATA_MISSING approach=" + approachX + " " + approachY);
        int groundZ = geo.getHeight(x, y, z);
        int groundApproachZ = geo.getHeight(approachX, approachY, approachZ);
        if (Math.abs(groundZ - z) > 24)
            return rejected("HEIGHT_MISMATCH spawn expectedZ=" + z + " geoZ=" + groundZ);
        if (Math.abs(groundApproachZ - approachZ) > 24)
            return rejected("HEIGHT_MISMATCH approach expectedZ=" + approachZ + " geoZ=" + groundApproachZ);
        String area = areaFailure(geo, x, y, groundZ, clearance);
        if (area != null) return rejected("SPAWN_AREA " + area);
        area = areaFailure(geo, approachX, approachY, groundApproachZ, 32);
        if (area != null) return rejected("APPROACH_AREA " + area);
        PathFinding paths = PathFinding.getInstance();
        if (paths == null) return rejected("PATHFINDING_NOT_INITIALIZED");
        Location forward = paths.canMoveToTargetLoc(approachX, approachY, groundApproachZ, x, y, groundZ);
        if (!reaches(forward, x, y, groundZ))
            return rejected("PATH_CLIPPED forward expected=" + x + " " + y + " " + groundZ + " actual=" + coordinates(forward));
        Location reverse = paths.canMoveToTargetLoc(x, y, groundZ, approachX, approachY, groundApproachZ);
        if (!reaches(reverse, approachX, approachY, groundApproachZ))
            return rejected("PATH_CLIPPED reverse expected=" + approachX + " " + approachY + " " + groundApproachZ + " actual=" + coordinates(reverse));
        return new Validation(groundZ, null);
    }

    private static Validation rejected(String reason) { return new Validation(null, reason); }
    private static String coordinates(Location location)
    {
        return location == null ? "null" : location.getX() + " " + location.getY() + " " + location.getZ();
    }

    private static boolean reaches(Location result, int x, int y, int z)
    {
        // A non-null but clipped path does not establish reachability.
        return result != null && Math.abs(result.getX() - x) <= 8 && Math.abs(result.getY() - y) <= 8 && Math.abs(result.getZ() - z) <= 24;
    }

    public static boolean isClearArea(GeoData geo, int x, int y, int z, int clearance)
    {
        return areaFailure(geo, x, y, z, clearance) == null;
    }

    private static String areaFailure(GeoData geo, int x, int y, int z, int clearance)
    {
        if (Config.GEODATA <= 0 || geo == null) return "GEODATA_UNAVAILABLE";
        if (clearance < 16 || clearance > 256) return "INVALID_CLEARANCE radius=" + clearance;
        int radius = ((clearance + 15) / 16) * 16;
        for (int dx = -radius; dx <= radius; dx += 16)
            for (int dy = -radius; dy <= radius; dy += 16)
            {
                int px = x + dx, py = y + dy;
                if (!geo.hasGeo(px, py)) return "GEODATA_MISSING cell=" + px + " " + py;
                int cellZ = geo.getHeight(px, py, z);
                if (Math.abs(cellZ - z) > 24)
                    return "HEIGHT_EDGE cell=" + px + " " + py + " expectedZ=" + z + " geoZ=" + cellZ;
                int nswe = geo.getNsweNearest(geo.getGeoX(px), geo.getGeoY(py), z) & 15;
                if (nswe != 15)
                    return "NSWE_BLOCKED cell=" + px + " " + py + " z=" + z + " nswe=" + nswe + " required=15";
            }
        return null;
    }
}
