﻿param([Parameter(Mandatory=$true)][string]$Cliente)
$ErrorActionPreference='Stop'
if(Get-Process -Name L2 -ErrorAction SilentlyContinue){throw 'Feche o jogo antes de restaurar.'}
$root=(Resolve-Path -LiteralPath $Cliente).Path
$records=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'restaurar.json') -Raw | ConvertFrom-Json
# Validate every backup before changing the client.
foreach($r in $records){if($r.existed){
 $p=Join-Path $PSScriptRoot $r.relative
 if(!(Test-Path -LiteralPath $p)){throw "Backup ausente: $p"}
 if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() -ne $r.originalSha256){throw "Backup alterado: $p"}
}}
foreach($r in $records){
 $dst=Join-Path $root $r.relative
 if($r.existed){New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null;Copy-Item -LiteralPath (Join-Path $PSScriptRoot $r.relative) -Destination $dst -Force}
 elseif(Test-Path -LiteralPath $dst){Remove-Item -LiteralPath $dst}
}
Write-Host 'Arquivos do cliente restaurados. Reverta separadamente o XML e Java do servidor, se aplicados.'
