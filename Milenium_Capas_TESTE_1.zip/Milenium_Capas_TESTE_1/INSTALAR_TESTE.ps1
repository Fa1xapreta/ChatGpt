﻿param(
 [Parameter(Mandatory=$true)][string]$ClienteTeste,
 [Parameter(Mandatory=$true)][string]$SystemModelo
)
$ErrorActionPreference='Stop'
$kit=$PSScriptRoot
$client=(Resolve-Path -LiteralPath $ClienteTeste).Path
$reference=(Resolve-Path -LiteralPath $SystemModelo).Path
if(!(Test-Path -LiteralPath (Join-Path $client 'system\L2.exe'))){throw 'ClienteTeste deve apontar para a pasta do cliente que contem system, Animations e SysTextures.'}
if([IO.Path]::GetFullPath((Join-Path $client 'system')).TrimEnd('\') -eq $reference.TrimEnd('\')){throw 'O cliente de teste e a SystemModelo devem ser pastas diferentes.'}
if(Get-Process -Name L2 -ErrorAction SilentlyContinue){throw 'Feche o jogo antes de continuar.'}
function AssertHash($path,$expected){
 if(!(Test-Path -LiteralPath $path -PathType Leaf)){throw "Arquivo ausente: $path"}
 if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected){throw "Arquivo diferente da versao analisada: $path"}
}
$expected=Get-Content -LiteralPath (Join-Path $kit 'cliente_esperado.json') -Raw | ConvertFrom-Json
foreach($prop in $expected.PSObject.Properties){AssertHash (Join-Path $client ('system\'+$prop.Name)) $prop.Value}
$resources=Get-Content -LiteralPath (Join-Path $kit 'recursos_system_referencia.json') -Raw | ConvertFrom-Json
$icons=Get-Content -LiteralPath (Join-Path $kit 'recursos_systextures_referencia.json') -Raw | ConvertFrom-Json
foreach($r in $resources){AssertHash (Join-Path $reference $r.file) $r.sha256}
foreach($r in $icons){AssertHash (Join-Path $kit ('systextures\'+$r.file)) $r.sha256}
$payload=Get-Content -LiteralPath (Join-Path $kit 'payload_sha256.json') -Raw | ConvertFrom-Json
foreach($p in $payload){AssertHash (Join-Path $kit $p.file) $p.sha256}
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$backup=Join-Path $client ('Milenium_Capas_Backup_'+$stamp)
New-Item -ItemType Directory -Path $backup | Out-Null
$plan=New-Object 'System.Collections.Generic.List[object]'
foreach($r in $resources){$plan.Add([pscustomobject]@{source=(Join-Path $reference $r.file);relative=('system\'+$r.file)})}
foreach($r in $icons){$plan.Add([pscustomobject]@{source=(Join-Path $kit ('systextures\'+$r.file));relative=('SysTextures\'+$r.file)})}
foreach($name in @('dsetup.dll','armorgrp.dat','itemname-e.dat')){$plan.Add([pscustomobject]@{source=(Join-Path $kit ('system\'+$name));relative=('system\'+$name)})}
# Quarantine only the obsolete cloak engine/resources and the competing cape package.
foreach($relative in @('system\dsetup_base.dll','system\essence_capes.bin','system\essence_cloth.bin','system\essence_fx.bin','Animations\DynastyCloak.ukx')){
 if(Test-Path -LiteralPath (Join-Path $client $relative)){$plan.Add([pscustomobject]@{source=$null;relative=$relative})}
}
$journal=New-Object 'System.Collections.Generic.List[object]'
foreach($p in $plan){
 $dst=Join-Path $client $p.relative;$exists=Test-Path -LiteralPath $dst
 $record=[pscustomobject]@{relative=$p.relative;existed=$exists;originalSha256=$null}
 if($exists){
  $record.originalSha256=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant()
  $saved=Join-Path $backup $p.relative;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $saved) | Out-Null
  Copy-Item -LiteralPath $dst -Destination $saved
  AssertHash $saved $record.originalSha256
 }
 $journal.Add($record)
}
$journal | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backup 'restaurar.json') -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $kit 'RESTAURAR.ps1') -Destination $backup
try{
 foreach($p in $plan){
  $dst=Join-Path $client $p.relative
  if($null -eq $p.source){Remove-Item -LiteralPath $dst;continue}
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
  Copy-Item -LiteralPath $p.source -Destination $dst -Force
  $srcHash=(Get-FileHash -LiteralPath $p.source -Algorithm SHA256).Hash.ToLowerInvariant()
  AssertHash $dst $srcHash
 }
}catch{
 & (Join-Path $backup 'RESTAURAR.ps1') -Cliente $client
 throw
}
Write-Host "Cliente de teste preparado. Backup: $backup"
Write-Host 'Agora aplique o XML e compile a classe Java conforme LEIA-ME. Este script nao altera o servidor.'
