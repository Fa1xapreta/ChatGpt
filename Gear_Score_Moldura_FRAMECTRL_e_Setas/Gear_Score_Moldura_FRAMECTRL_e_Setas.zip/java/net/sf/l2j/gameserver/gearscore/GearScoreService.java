package net.sf.l2j.gameserver.gearscore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.gearscore.GearScoreRecord.GearItem;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.multisell.Ingredient;
import net.sf.l2j.gameserver.model.multisell.Entry;
import net.sf.l2j.gameserver.model.multisell.ListContainer;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;

/** Server-authoritative GearScoreV1 producer for the adapted interface. */
public final class GearScoreService
{
    private static final Logger LOG=Logger.getLogger(GearScoreService.class.getName());
    private static final GearScoreService INSTANCE=new GearScoreService();
    private final GearScoreConfig config=new GearScoreConfig();
    private final GearScoreStore store=new GearScoreStore();
    private final Map<Integer,GearScoreRecord> records=new ConcurrentHashMap<>();
    private final Map<Integer,GearScoreRecord> dirty=new ConcurrentHashMap<>();
    private final Map<Integer,View> views=new ConcurrentHashMap<>();
    private final AtomicLong tokens=new AtomicLong();
    private volatile Map<Integer,Integer> previousGear=Collections.emptyMap(), previousPvp=Collections.emptyMap();
    private Map<Integer,Integer> gearMovements=Collections.emptyMap(), pvpMovements=Collections.emptyMap();
    private boolean started;
    private static final class View
    {
        L2PcInstance session;
        Map<Integer,String> itemKeys=new HashMap<>();
        int self=-1,targetId=-1,targetScore=-1;
        long nextHeartbeat, nextTargetHeartbeat;
        long lastRequest;
        View(L2PcInstance session) { this.session=session; }
    }
    private GearScoreService() { }
    public static GearScoreService getInstance() { return INSTANCE; }

    public synchronized void start()
    {
        if (started || !config.enabled) return;
        started=true;
        try { records.putAll(store.load()); }
        catch (Exception e) { LOG.log(Level.WARNING,"GearScore: import sql/gearscore.sql; offline snapshots unavailable until database is ready",e); }
        rotateRanks();
        ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::tick,1000,config.updateMs);
        ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::flush,config.saveMs,config.saveMs);
        ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::rotateRanks,60000,60000);
        Runtime.getRuntime().addShutdownHook(new Thread(this::flush,"GearScore-save"));
        LOG.info("GearScoreV1 initialized; XML score enabled, ranking and inspection ready.");
    }
    public int score(ItemInstance item)
    {
        return GearScoreMath.item(item.getItem().getScore(),item.getEnchantLevel(),item.isAugmented(),config.enchantBonus,config.augmentBonus);
    }
    private GearItem item(ItemInstance item)
    {
        int aug=item.isAugmented()?item.getAugmentation().getAugmentationId():0;
        return new GearItem(item.getObjectId(),item.getItemId(),item.getEnchantLevel(),aug & 0xffff,
            (aug >>> 16) & 0xffff,item.getItem().getBodyPart(),score(item));
    }
    private GearScoreRecord snapshot(L2PcInstance p)
    {
        List<GearItem> equipped=new ArrayList<>();long total=0;
        // Scan actual instances once: full armor/two-handed/multi-slot items are not counted twice.
        for (ItemInstance i:p.getInventory().getItems())
            if (i!=null && i.isEquipped()) { GearItem x=item(i);equipped.add(x);total+=x.score; }
        equipped.sort(Comparator.comparingInt(i -> i.objectId));
        return new GearScoreRecord(p.getObjectId(),p.getName(),p.getClassId().getId(),
            p.getClan()==null?"":p.getClan().getName(),GearScoreMath.clamp(total),p.getPvpKills(),p.isGM(),equipped);
    }
    private GearScoreRecord refresh(L2PcInstance p)
    {
        GearScoreRecord r=snapshot(p),old=records.put(r.id,r);
        if (old==null || !old.signature().equals(r.signature())) dirty.put(r.id,r);
        return r;
    }
    private void send(L2PcInstance p,String body)
    {
        // Standard screen-message event 140; the interface suppresses CustomEvent text.
        p.sendPacket(new ExShowScreenMessage("CustomEvent=GearScoreV1|"+body,1));
    }
    private void tick()
    {
        try
        {
            Set<Integer> online=new HashSet<>();
            for (L2PcInstance p:L2World.getInstance().getAllPlayers().values())
            {
                if (p==null || !p.isOnline()) continue;
                online.add(p.getObjectId());
                try
                {
                    View v=views.compute(p.getObjectId(),(id,old) -> old==null || old.session!=p?new View(p):old);
                    synchronized(v)
                    {
                        GearScoreRecord r=refresh(p);
                        if (v.self!=r.score || System.currentTimeMillis()>=v.nextHeartbeat) { send(p,"Self|"+r.id+"|"+r.score);v.self=r.score;v.nextHeartbeat=System.currentTimeMillis()+10000; }
                        updateItems(p,v);
                        if (p.getTarget() instanceof L2PcInstance)
                        {
                            L2PcInstance target=(L2PcInstance)p.getTarget();GearScoreRecord t=refresh(target);
                            if (v.targetId!=t.id || v.targetScore!=t.score || System.currentTimeMillis()>=v.nextTargetHeartbeat)
                            { send(p,"Target|"+t.id+"|"+t.score);v.targetId=t.id;v.targetScore=t.score;v.nextTargetHeartbeat=System.currentTimeMillis()+5000; }
                        }
                        else { v.targetId=-1;v.targetScore=-1; }
                    }
                }
                catch (Exception e) { LOG.log(Level.WARNING,"GearScore update failed for "+p.getObjectId(),e); }
            }
            views.keySet().retainAll(online);
        }
        catch (Exception e) { LOG.log(Level.WARNING,"GearScore tick failed",e); }
    }
    private void updateItems(L2PcInstance p,View v)
    {
        Map<Integer,String> now=new HashMap<>();List<GearItem> changed=new ArrayList<>();
        int count=0;
        for (ItemInstance i:p.getInventory().getItems())
        {
            if (i==null || ++count>2048) continue;
            GearItem x=item(i);String key=x.cache();now.put(x.objectId,key);
            if (!key.equals(v.itemKeys.get(x.objectId))) changed.add(x);
        }
        // Rebuild only after removals, so stale object scores cannot accumulate in the client.
        if (!now.keySet().containsAll(v.itemKeys.keySet()))
        {
            send(p,"ClearItems");changed.clear();
            for (ItemInstance i:p.getInventory().getItems())
                if (i!=null && now.containsKey(i.getObjectId())) changed.add(item(i));
        }
        for (GearItem x:changed) send(p,"Item|"+x.cache());
        v.itemKeys=now;
    }
    /** Consume only these two exact UI commands; never weaken other bypass validation. */
    public boolean handle(L2PcInstance p,String command)
    {
        if (command==null || !(command.equals("RankingOpen") || command.startsWith("InspectPlayer?name="))) return false;
        if (!config.enabled || p==null) return true;
        View v=views.compute(p.getObjectId(),(id,old) -> old==null || old.session!=p?new View(p):old);
        synchronized(v)
        {
            long now=System.nanoTime();if (now-v.lastRequest<1000000000L) return true;v.lastRequest=now;
        }
        ThreadPoolManager.getInstance().executeTask(() -> {
            try
            {
                if (!p.isOnline()) return;
                synchronized(v)
                {
                    refresh(p);
                    if (command.equals("RankingOpen")) { ranking(p,false);ranking(p,true); }
                    else inspect(p,command.substring("InspectPlayer?name=".length()));
                }
            }
            catch (Exception e) { LOG.log(Level.WARNING,"GearScore request failed",e);p.sendMessage("Gear Score indisponivel. Tente novamente."); }
        });
        return true;
    }
    private List<GearScoreRecord> sorted(boolean pvp)
    {
        List<GearScoreRecord> list=new ArrayList<>();
        for (GearScoreRecord r:records.values())
            if ((pvp ? r.pvp : r.score) > 0 && (config.includeGm || !r.gm)) list.add(r);
        list.sort(Comparator.comparingInt((GearScoreRecord r) -> pvp?r.pvp:r.score).reversed()
            .thenComparing(r -> r.name,String.CASE_INSENSITIVE_ORDER).thenComparingInt(r -> r.id));
        return list;
    }
    private synchronized void ranking(L2PcInstance p,boolean pvp)
    {
        List<GearScoreRecord> list=sorted(pvp);Map<Integer,Integer> changes=movements(pvp,list);
        String type=pvp?"PvP":"Gear",token=Long.toHexString(tokens.incrementAndGet());int mine=0;
        for (int i=0;i<list.size();i++) if (list.get(i).id==p.getObjectId()) { mine=i+1;break; }
        send(p,"RankBegin|"+type+"|"+token+"|"+mine+"|"+changes.getOrDefault(p.getObjectId(),0));
        for (int i=0;i<Math.min(config.limit,list.size());i++)
        {
            GearScoreRecord r=list.get(i);send(p,"RankRow|"+type+"|"+token+"|"+changes.getOrDefault(r.id,0)+"|"+r.name+"|"+r.classId+"|"+r.clan+"|"+(pvp?r.pvp:r.score));
        }
        send(p,"RankEnd|"+type+"|"+token);
    }
    private static int delta(Map<Integer,Integer> old,int id,int rank)
    { return rank<=0 || !old.containsKey(id)?0:old.get(id)-rank; }
    private synchronized void rotateRanks()
    {
        try { movements(false,sorted(false));movements(true,sorted(true)); }
        catch (Exception e) { LOG.log(Level.WARNING,"GearScore rank baseline failed",e); }
    }
    /** Keep the last REAL position change; unchanged refreshes must not erase the arrow. */
    private synchronized Map<Integer,Integer> movements(boolean pvp,List<GearScoreRecord> list)
    {
        Map<Integer,Integer> previous=pvp?previousPvp:previousGear;
        Map<Integer,Integer> remembered=pvp?pvpMovements:gearMovements;
        Map<Integer,Integer> positions=new HashMap<>(),changes=new HashMap<>();
        for (int i=0;i<list.size();i++)
        {
            int id=list.get(i).id,rank=i+1;
            positions.put(id,rank);
            int change=delta(previous,id,rank);
            changes.put(id,change!=0?change:remembered.getOrDefault(id,0));
        }
        Map<Integer,Integer> stablePositions=Collections.unmodifiableMap(positions);
        Map<Integer,Integer> stableChanges=Collections.unmodifiableMap(changes);
        if (pvp) { previousPvp=stablePositions;pvpMovements=stableChanges; }
        else { previousGear=stablePositions;gearMovements=stableChanges; }
        return stableChanges;
    }
    private Map<Integer,Integer> ranks(boolean pvp)
    {
        Map<Integer,Integer> map=new HashMap<>();List<GearScoreRecord> list=sorted(pvp);
        for(int i=0;i<list.size();i++) map.put(list.get(i).id,i+1);return Collections.unmodifiableMap(map);
    }
    private void inspect(L2PcInstance p,String name)
    {
        if (name.isEmpty() || name.length()>35 || !name.equals(GearScoreMath.field(name))) return;
        L2PcInstance online=L2World.getInstance().getPlayer(name);GearScoreRecord found=online==null?null:refresh(online);
        if (found==null) for (GearScoreRecord r:records.values()) if(r.name.equalsIgnoreCase(name)) { found=r;break; }
        if (found==null || (found.gm && !config.includeGm && found.id!=p.getObjectId()))
        { p.sendMessage("Jogador sem registro de Gear Score.");return; }
        String token=Long.toHexString(tokens.incrementAndGet());
        send(p,"InspectBegin|"+token+"|"+found.name+"|"+found.classId+"|"+found.score);
        for (GearItem i:found.items) send(p,"InspectItem|"+token+"|"+i.wire());
        send(p,"InspectEnd|"+token);
    }
    /** Called before multisell pages, so the first hover already has preview data. */
    public void sendPreviews(L2PcInstance p,ListContainer list)
    {
        if (!config.enabled || p==null || list==null) return;
        Set<String> sent=new HashSet<>();
        for (Entry e:list.getEntries()) for (Ingredient i:e.getProducts())
        {
            String key=i.getItemId()+"|"+i.getEnchantmentLevel();if(!sent.add(key) || sent.size()>512) continue;
            Item template=ItemTable.getInstance().getTemplate(i.getItemId());if(template==null) continue;
            int score=GearScoreMath.item(template.getScore(),i.getEnchantmentLevel(),false,config.enchantBonus,config.augmentBonus);
            send(p,"Item|0|"+key+"|"+score);
        }
    }
    private synchronized void flush()
    {
        for (Map.Entry<Integer,GearScoreRecord> entry:new ArrayList<>(dirty.entrySet()))
        {
            try { store.save(entry.getValue());dirty.remove(entry.getKey(),entry.getValue()); }
            catch (Exception e) { LOG.log(Level.WARNING,"GearScore persistence failed; will retry next interval",e);break; }
        }
    }
}
