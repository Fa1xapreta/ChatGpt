package net.sf.l2j.gameserver.gearscore;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Calls the actual service sorter; no game server, database or worker threads started. */
public final class GearScoreRankingRegression
{
    private static GearScoreRecord record(int id,String name,int gear,int pvp,boolean gm)
    {
        return new GearScoreRecord(id,name,88,"",gear,pvp,gm,Collections.emptyList());
    }
    private static void check(boolean value,String message)
    {
        if (!value) throw new AssertionError(message);
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception
    {
        GearScoreService service=GearScoreService.getInstance();
        Field field=GearScoreService.class.getDeclaredField("records");field.setAccessible(true);
        Map<Integer,GearScoreRecord> records=(Map<Integer,GearScoreRecord>)field.get(service);
        records.clear();
        records.put(1,record(1,"Zero",0,0,false));
        records.put(2,record(2,"Beta",7500,0,false));
        records.put(3,record(3,"Alpha",7500,5,false));
        records.put(4,record(4,"Negative",-1,-1,false));
        records.put(5,record(5,"GM",99999,99999,true));
        records.put(6,record(6,"OnlyPvP",0,10,false));
        Method sorter=GearScoreService.class.getDeclaredMethod("sorted",boolean.class);sorter.setAccessible(true);
        List<GearScoreRecord> gear=(List<GearScoreRecord>)sorter.invoke(service,false);
        List<GearScoreRecord> pvp=(List<GearScoreRecord>)sorter.invoke(service,true);
        check(gear.size()==2,"Gear excludes zero, negative and excluded GM");
        check(gear.get(0).id==3 && gear.get(1).id==2,"Positive ties use the original name ordering");
        check(pvp.size()==2 && pvp.get(0).id==6 && pvp.get(1).id==3,"PvP filters its own metric and preserves descending order");
        Method ranking=GearScoreService.class.getDeclaredMethod("ranks",boolean.class);ranking.setAccessible(true);
        Map<Integer,Integer> ranks=(Map<Integer,Integer>)ranking.invoke(service,false);
        check(ranks.get(3)==1 && ranks.get(2)==2 && !ranks.containsKey(1),"Ranks remain contiguous; zero has no position");
        Method delta=GearScoreService.class.getDeclaredMethod("delta",Map.class,int.class,int.class);delta.setAccessible(true);
        check(((Integer)delta.invoke(null,Collections.singletonMap(3,2),3,1))==1,"Existing movement indicator preserved");
        Method movements=GearScoreService.class.getDeclaredMethod("movements",boolean.class,List.class);movements.setAccessible(true);
        Map<Integer,Integer> changes=(Map<Integer,Integer>)movements.invoke(service,false,gear);
        check(changes.get(3)==0 && changes.get(2)==0,"Initial baseline does not invent arrows");
        records.put(2,record(2,"Beta",8000,0,false));
        gear=(List<GearScoreRecord>)sorter.invoke(service,false);
        changes=(Map<Integer,Integer>)movements.invoke(service,false,gear);
        check(changes.get(2)==1 && changes.get(3)==-1,"Real overtake gives UP +1 / DOWN -1");
        changes=(Map<Integer,Integer>)movements.invoke(service,false,gear);
        check(changes.get(2)==1 && changes.get(3)==-1,"Reopening unchanged does not erase arrows");
        Method rotate=GearScoreService.class.getDeclaredMethod("rotateRanks");rotate.setAccessible(true);rotate.invoke(service);
        changes=(Map<Integer,Integer>)movements.invoke(service,false,gear);
        check(changes.get(2)==1 && changes.get(3)==-1,"Periodic baseline refresh does not erase arrows");
        records.put(3,record(3,"Alpha",9000,5,false));
        gear=(List<GearScoreRecord>)sorter.invoke(service,false);
        changes=(Map<Integer,Integer>)movements.invoke(service,false,gear);
        check(changes.get(2)==-1 && changes.get(3)==1,"Next real overtake reverses arrows");
        records.put(3,record(3,"Alpha",9500,5,false));
        changes=(Map<Integer,Integer>)movements.invoke(service,false,sorter.invoke(service,false));
        check(changes.get(3)==1,"Score increase alone retains last actual position change");
        records.put(7,record(7,"New",100,0,false));
        changes=(Map<Integer,Integer>)movements.invoke(service,false,sorter.invoke(service,false));
        check(changes.get(7)==0,"New entrants have no invented movement");
        changes=(Map<Integer,Integer>)movements.invoke(service,true,sorter.invoke(service,true));
        check(changes.get(6)==0 && changes.get(3)==0,"PvP history remains independent of Gear Score");
        records.clear();
        check(((Map<?,?>)movements.invoke(service,false,sorter.invoke(service,false))).isEmpty(),"Empty list removes stale movement");
        check(((List<?>)sorter.invoke(service,false)).isEmpty(),"Empty ranking valid");
        System.out.println("PASS: actual GearScoreService sorted/ranks/delta/movements/rotateRanks; real overtakes, stable/periodic refresh, reverse movement, independent tabs, new entrants; zero/negative filter, tie order, GM exclusion, PvP, contiguous ranks, empty ranking");
    }
}
